#-------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------

import os
import sys
import time
import errno
import socket
import argparse
from ifcs_cli import IFCS_CLI
from utils.compat_util import *
from verbosity import log

HOST = 'localhost'
CONNECT_ATTEMPTS = 20

def create_inet_socket(PORT):
    connect_attempts = 0
    s_out = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s_out.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Try to connect to the socket in a loop
    connected = False
    while connect_attempts <= CONNECT_ATTEMPTS:
        try:
            s_out.connect((HOST, PORT))
            connected = True
            break
        except BaseException:
            connect_attempts += 1
            log('Attempting to connect to Innovium shell .. ' + str(connect_attempts))
            time.sleep(1)

    if not connected:
        log('Failed to connect to Innovium shell')
        sys.exit(1)

    return s_out


def create_unix_socket(SERV):
    connect_attempts = 0
    s_out = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    # Try to connect to the socket in a loop
    connected = False
    while connect_attempts <= CONNECT_ATTEMPTS:
        try:
            s_out.connect(SERV)
            connected = True
            break
        except BaseException:
            connect_attempts += 1
            log('Attempting to connect to Innovium shell .. ' + str(connect_attempts))
            time.sleep(1)

    if not connected:
        log('Failed to connect to Innovium shell')
        sys.exit(1)

    return s_out


def main():

    intro = "\n\t\tInnovium Remote Command Shell Client. \n\tType '?' or 'help' for help. Type 'exit' or 'quit' to exit shell."
    parser = argparse.ArgumentParser(
        description="IFCS Shell",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument(
        '-e',
        '--env',
        type=str,
        nargs='*',
        default=['switch'],
        help=' runtime environment for cli, set board, emulator or switch')
    parser.add_argument(
        '-p',
        '--port',
        nargs='?',
        help='port to connect with the innovium shell server')
    parser.add_argument(
        '-u',
        '--serv',
        nargs='?',
        help='server address to connect with the innovium shell server')
    parser.add_argument(
        '-s',
        '--single',
        type=str,
        help='run a single command')
    parser.add_argument(
            '-C',
            '--cmd',
            dest='cmd',
            nargs='*',
            help='space separated list of commands to execute')

    args = parser.parse_args()

    cli = IFCS_CLI(intro)
    try:
        if args.env:
            cli.set_rt_env(args.env[0])
    except BaseException:
        log("Unsupported environment. Exiting..")
        return

    cli.set_remote(True)
    cli.init_cmds()
    if args.port:
        sock = create_inet_socket(int(args.port))

    if args.serv:
        sock = create_unix_socket(args.serv)

    cli.set_remote_port(sock)

    data = compat_bytesToStr(sock.recv(1024))

    if "Err" in data:
        if "Max client" in data:
            log("Max clients %d reached. Closing connection" % int(data.split('-')[1]))
            sock.shutdown(socket.SHUT_RDWR)
            sock.close()
            return
    if "Success" in data:
        log("\t\tConnected to Innovium Shell Server")

    if args.cmd:
        for aCmd in args.cmd:
            log("Executing Command: %s" % aCmd)
            cli.onecmd(aCmd)

    if args.single:
        cli.onecmd(args.single)
    else:
        doQuit = False
        while doQuit != True:
            try:
                cli.cmdloop()
                doQuit = True
            except (KeyboardInterrupt, Exception) as e:
                log("%s\n" % str(e))

    sock.shutdown(socket.SHUT_RDWR)
    sock.close()


if __name__ == "__main__":
    main()
