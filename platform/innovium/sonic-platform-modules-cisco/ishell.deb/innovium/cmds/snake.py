
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

'''
L2snake test is used to setup forwarding rules to test unidirectional snake test
and bi-directional flow snake test

Unidirectional flow snake config:
=================================

-    Each port set to internal loopback
-    Packet on port (i), sent to port (i+1)
-    Last port fwds packet to first port


IVM:0>diagtest snake config -p 1-4 -lb 'PCS'


IVM:0>ifcs show sysport

Total sysport count: 33
+---------------------------------------------------------------------+
|             sysport_handle | default_cvid | egress_untagged_vlan_id |
|---------------------------------------------------------------------|
| (sysport:   1), 0x68200001 |            2 |                       1 |  --- For 1->2
| (sysport:   2), 0x68200002 |            3 |                       2 |  --- For 2->3
| (sysport:   3), 0x68200003 |            4 |                       3 |  --- For 3->4
| (sysport:   4), 0x68200004 |            1 |                       4 |  --- For 4->1



IVM:0>ifcs show l2_entry

Total l2_entry count: 8
+----------------------------------------------------------------------------
|          mac_addr |                    l2vni |                destination |
|----------------------------------------------------------------------------
| 00:00:00:00:00:bb | (l2vni:   1), 0x3c200001 | (sysport:   4), 0x68200004 |     ----- BB SRC MAC
| 00:00:00:00:00:aa | (l2vni:   1), 0x3c200001 | (sysport:   1), 0x68200001 |     ----- AA DST MAC for 4->1
| 00:00:00:00:00:aa | (l2vni:   2), 0x3c200002 | (sysport:   2), 0x68200002 |     ----- AA DST MAC for 1->2
| 00:00:00:00:00:bb | (l2vni:   2), 0x3c200002 | (sysport:   1), 0x68200001 |
| 00:00:00:00:00:bb | (l2vni:   3), 0x3c200003 | (sysport:   2), 0x68200002 |
| 00:00:00:00:00:aa | (l2vni:   3), 0x3c200003 | (sysport:   3), 0x68200003 |     ----- AA DST MAC for 2->3
| 00:00:00:00:00:bb | (l2vni:   4), 0x3c200004 | (sysport:   3), 0x68200003 |
| 00:00:00:00:00:aa | (l2vni:   4), 0x3c200004 | (sysport:   4), 0x68200004 |     ----- AA DST MAC for 3->4
+----------------------------------------------------------------------------


Bidirectional flows snake config:
=================================
-    Fwd Flow: (Ixia -> 1 (->2); 2 -> 3(->4), 4 -> Ixia ... )
        - Incoming on Odd ports, Outgoing on Even ports
-    Rev Flow: (Ixia -> 4 (->3); 3 -> 2(->1); 1 -> Ixia ... )
        - Incoming on Even ports, Outgoing on Odd ports

IVM:0>diagtest snake config -p 1-4 -lb 'PCS' -b

IVM:0>ifcs show sysport

Total sysport count: 33
+---------------------------------------------------------------------+
|             sysport_handle | default_cvid | egress_untagged_vlan_id |
|---------------------------------------------------------------------|
| (sysport:   1), 0x68200001 |            2 |                       1 |        ---- FWD for (1->2)
| (sysport:   2), 0x68200002 |            1 |                       2 |        ----     REV for (2->1)
| (sysport:   3), 0x68200003 |            4 |                       3 |        ---- FWD for (3->4)
| (sysport:   4), 0x68200004 |            3 |                       4 |        ----     REV for (4->3)



IVM:0>ifcs show l2_entry

Total l2_entry count: 8
+---------------------------------------------------------------------------
|          mac_addr |                    l2vni |               destination |
|---------------------------------------------------------------------------
| 00:00:00:00:00:bb | (l2vni:   1), 0x3c200001 |(sysport:   1), 0x68200001 | ----   REV BB DST MAC, for (2->1)
| 00:00:00:00:00:aa | (l2vni:   1), 0x3c200001 |(sysport:   2), 0x68200002 | ----   REV AA SRC MAC, SP2
| 00:00:00:00:00:aa | (l2vni:   2), 0x3c200002 |(sysport:   2), 0x68200002 | ---- FWD AA DST MAC, for (1->2)
| 00:00:00:00:00:bb | (l2vni:   2), 0x3c200002 |(sysport:   1), 0x68200001 | ---- FWD BB SRC MAC, SP1
| 00:00:00:00:00:bb | (l2vni:   3), 0x3c200003 |(sysport:   3), 0x68200003 | ----   REV BB DST MAC, for (4->3)
| 00:00:00:00:00:aa | (l2vni:   3), 0x3c200003 |(sysport:   4), 0x68200004 | ----   REV AA SRC MAC, SP4
| 00:00:00:00:00:bb | (l2vni:   4), 0x3c200004 |(sysport:   3), 0x68200003 | ---- FWD BB SRC MAC, SP3
| 00:00:00:00:00:aa | (l2vni:   4), 0x3c200004 |(sysport:   4), 0x68200004 | ---- FWD AA DST MAC, for (3->4)

'''
import shlex
import argparse
import itertools
import time
import random
import json
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_ctypes import *
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.node import Node as node
from print_table import PrintTable

MAX_DEV_PORTS = 520

def getSysportHandleFromDevPort(node_id, devPort):
    attr = ifcs_attr_t()
    actual_count = ctypes.c_uint32()

    attr.id = IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_devport_attr_get(node_id, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle

# Object to store A "run" devport stats.
class DevportStats():
    def __init__(self):
        self.devport_rx_frames = [0] * MAX_DEV_PORTS
        self.devport_rx_bytes = [0] * MAX_DEV_PORTS
        self.devport_rx_gbps = [0] * MAX_DEV_PORTS
        self.devport_tx_frames = [0] * MAX_DEV_PORTS
        self.devport_tx_bytes = [0] * MAX_DEV_PORTS
        self.devport_tx_gbps = [0] * MAX_DEV_PORTS
        self.devport_rx_errors = [0] * MAX_DEV_PORTS
        self.devport_tx_errors = [0] * MAX_DEV_PORTS
        self.timestamp = [0] * MAX_DEV_PORTS
        self.devport_list = []
        self.lb_type = 0
        self.num_pkt = OrderedDict()
        self.node_id = 0
        self.verbose = 0
        self.time = 0

    def display(self):
        print ("\nLoopback type    : %s" %(self.lb_type))
        print ("Number of packets:")
        for size, num in self.num_pkt.iteritems():
            print ("    Size: %4s, Packets: %s" %(size, num))

        header = []
        header.append('Devport')
        header.append('RX(frames)')
        header.append('RX(bytes)')
        header.append('RX(Gbps)')
        header.append('RX(error frames)')
        header.append('TX(frames)')
        header.append('TX(bytes)')
        header.append('TX(Gbps)')
        header.append('TX(error frames)')
        table = PrintTable()
        table.add_row(header)
        for p in range(MAX_DEV_PORTS):
            if p not in self.devport_list:
                continue
            devport_row = []
            devport_row.append(str(p))
            devport_row.append(str(self.devport_rx_frames[p]))
            devport_row.append(str(self.devport_rx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_rx_gbps[p]))
            devport_row.append(str(self.devport_rx_errors[p]))
            devport_row.append(str(self.devport_tx_frames[p]))
            devport_row.append(str(self.devport_tx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_tx_gbps[p]))
            devport_row.append(str(self.devport_tx_errors[p]))
            table.add_row(devport_row)
        table.print_table()
        table.reset_table()

SNAKE_UNCONFIG = 0
SNAKE_CONFIGD = 1
SNAKE_RUNNING = 2
SNAKE_STOPPED = 3

#Snake: This test injects a packet on a port and the forwarding
#       rules are configured in such a way that the packet loops
#       through all the ports and then back to CPU.
#       This is a work in progress, so we pass it for now
#
class Snake(Command):
    state = SNAKE_UNCONFIG
    #Global across all Snake objects.

    #All run's devport stats are saved in below list
    devport_stats_runs = []

    #Class variables
    dmac_l2_entry_array = []
    smac_l2_entry_array = []
    port_sp_hdl         = OrderedDict()
    cpu_sp_hdl          = ifcs_handle_t()
    stp_hdl             = ifcs_handle_t()


    #Incremented for each run config (diagtest snake config)
    run = -1

    def __init__(self, cli, quiet="false"):
        self.sub_cmds = {
                         'config'       : self.config,
                         'config_show'  : self.config_show,
                         'start_traffic': self.start_traffic,
                         'stop_traffic' : self.stop_traffic,
                         'gen_report'   : self.gen_report,
                         'verify'       : self.verify,
                         #'dump_report'  : self.dump_report,
                         'unconfig'     : self.unconfig,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.quiet = quiet
        self.arg_list = []
        super(Snake, self).__init__()

    def __del__(self):
        return

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log_dbg(1, "Invalid cmd")
            self.help(args)
            return IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.help(args)

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['config', 'Configure snake test'])
        table.add_row(['config_show', 'Show snake test configuration'])
        table.add_row(['start_traffic', 'Start snake test traffic'])
        table.add_row(['stop_traffic', 'Stop snake test traffic'])
        table.add_row(['gen_report', 'Generate snake test report for given sampling time'])
        table.add_row(['verify', 'Verify if traffic is running on all configured ports'])
        #table.add_row(['dump_report', 'Dump snake tests report to file'])
        table.add_row(['unconfig', 'Unconfigure snake test'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        snake_help_string = """
Usage::

    Type "diagtest snake <command>" followed by -h to see command's sub-options.
"""
        print snake_help_string

    def insert_run_data(self, run_data):
        # Increment run and insert run data
        Snake.run += 1
        Snake.devport_stats_runs.append(run_data)

    def get_run_data(self, run):
        return Snake.devport_stats_runs[run]

    def get_cur_run_data(self):
        run = Snake.run
        return Snake.devport_stats_runs[run]

    def get_max_devport(self, node_id=0):
        #Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):

            devport = arg

            devport_list.append(devport)
        devport_list = []

        callback_type = CFUNCTYPE(
            UNCHECKED(None),
            ifcs_node_id_t,
            ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        attr = ifcs_attr_t()
        ifcs_attr_t_init(pointer(attr))
        ifcs_attr_t_id_set(pointer(attr), IFCS_DEVPORT_ATTR_TYPE)
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_DEVPORT_TYPE_ETH)

        try:
            rc = ifcs_devport_get_all(node_id, 1, pointer(attr), callback, 0, None)
            if ( rc != IFCS_SUCCESS):
                print("Failed to get all devport rc: {0}".format(rc))
        except:
            print("In except of devport get_all")
            pass

        return (len(devport_list))

    def config_snake_unidir(self, devport_stats):
       '''
       1. Packets are initiated from CPU to port 1
       2. Port 1 forwards and port 2
       3. Port 2 is internal loopbacked and gets packet
       4. Port 2 forwards it to port 3 and so on till 128
       5. Port 128 forwards to port 1
       6. Port 1, because of loopback gets packet again and cycle repeats
       +--------+
       | CPU    |
       +---+----+
           |
         +-------------------------------------------------------+
         | |    +----------------------------------------------+ |
         | |    |                                              | |
         | |    |  +-------  +-------  +---+   +---+ +------+  | |
         | |    |  |      |  |      |  |   |       | |      |  | |
         | +> +-v--++    +v--+     +v--+   v      +v-++    +v--+ |
         |    |   1 |    | 2 |     | 3 |          |127|    |128| |
         +----+-+-+-+----++-++-----++-++-----------+-+------+-+--+
                | ^       | ^       | ^            | ^      | ^
                | |       | |       | |            | |      | |
                +>+       +>+       +-+            +-+      +-+
       '''
       port_sp_hdl = Snake.port_sp_hdl
       mac_addr_t = c_uint8 * 6
       devport_list = devport_stats.devport_list
       l2vni_hdl = ifcs_handle_t()
       dmac_l2_entry_array = Snake.dmac_l2_entry_array
       smac_l2_entry_array = Snake.smac_l2_entry_array

       # SRC MAC config
       try:
           attr_count = 2
           attr = (ifcs_attr_t * attr_count)()

           for i, port in enumerate(devport_stats.devport_list):
               count = port
               port_hdl = ifcs_handle_t()
               port_sp = IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_hdl.value = IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_l2_entry_key_t()
               if port == devport_list[-1]:
                   l2vni_hdl.value = IFCS_HANDLE_L2VNI(devport_list[0])
               else:
                   l2vni_hdl.value = IFCS_HANDLE_L2VNI(devport_list[i + 1])

               ifcs_l2_entry_key_t_init(pointer(l2_entry))
               ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, pointer(attr))
               assert rc == IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)
       except:
           src_l2entry_create_failed = 1
           print("Hit except (SMAC) config 1")
           pass

       # Dest MAC config
       try:
           for i, port in enumerate(devport_stats.devport_list):
               count = port
               port_hdl = ifcs_handle_t()
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = IFCS_HANDLE_SYSPORT(devport_list[i])
               l2_entry = ifcs_l2_entry_key_t()
               ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = IFCS_HANDLE_L2VNI(port)

               ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, pointer(attr))
               assert rc == IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
       except:
           print("Hit except (DMAC) config 1")
           dst_l2entry_create_failed = 1
           pass

       try:
           # SYSPORT attr set
           #Build Sysport attr for Default VID config
           sp_attr_ct = 3
           sp_attr = (ifcs_attr_t * sp_attr_ct)()

           for i, port in enumerate(devport_stats.devport_list):
               sp_attr[0].id = IFCS_SYSPORT_ATTR_DEFAULT_CVID
               if port == devport_stats.devport_list[-1]:
                   sp_attr[0].value.u16 = devport_stats.devport_list[0]
               else:
                   sp_attr[0].value.u16 = devport_stats.devport_list[i + 1]
               sp_attr[1].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
               sp_attr[1].value.u16 = port
               sp_attr[2].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
               sp_attr[2].value.data = IFCS_BOOL_TRUE

               rc = ifcs_sysport_attr_set(self.cli.node_id, port_sp_hdl[port], 3, pointer(sp_attr))
               assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
       except:
           print("Hit except (Sysport) config")
           sysport_attr_set_failed = 1
           pass

    def config_snake_bidir(self, devport_stats):
       '''
           Fwd Flow: (Ixia -> 1 (->2); 2 -> 3(->4), 4 -> Ixia ... )
               > Incoming on Odd ports, Outgoing on Even ports

           Rev Flow: (Ixia -> 4 (->3); 3 -> 2(->1); 1 -> Ixia ... )
               > Incoming on Even ports, Outgoing on Odd ports
       '''
       port_sp_hdl = Snake.port_sp_hdl
       mac_addr_t = c_uint8 * 6
       devport_list = devport_stats.devport_list
       l2vni_hdl = ifcs_handle_t()
       dmac_l2_entry_array = Snake.dmac_l2_entry_array
       smac_l2_entry_array = Snake.smac_l2_entry_array

       rev_devport_list = [i for i in reversed(devport_list)]
       try:
           attr_count = 2
           attr = (ifcs_attr_t * attr_count)()

           # SRC MAC entries for FWD flow
           for i, port in enumerate(devport_stats.devport_list):
               if (i % 2):
                   #pkts enter only on every other port starting from 1st port.
                   #So, skip alternate ports starting from second
                   continue
               count = port
               port_hdl = ifcs_handle_t()
               port_sp = IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_hdl.value = IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_l2_entry_key_t()
               ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = IFCS_HANDLE_L2VNI(devport_list[i + 1])

               ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)
               attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, pointer(attr))
               assert rc == IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)

           print ("Created l2_entries for SMAC for FWD flow")
           # SRC MAC entries for REVERSE flow
           for i, port in enumerate(rev_devport_list):
               if (i % 2):
                   #pkts enter only on every other port starting from 1st port.
                   #So, skip alternate ports starting from second
                   continue
               count = port
               port_hdl = ifcs_handle_t()
               port_sp = IFCS_HANDLE_VALUE(port_sp_hdl[port])
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_l2_entry_key_t()
               ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = IFCS_HANDLE_L2VNI(rev_devport_list[i + 1])

               ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, pointer(attr))
               assert rc == IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)
           print ("Created l2_entries for SMAC for REVERSE flow")
       except:
           src_l2entry_create_failed = 1
           print("Hit except (SMAC) config 2")
           pass

       try:
           # Dest MAC entries for FWD flow
           for i, port in enumerate(devport_stats.devport_list):
               if ((i % 2) == 0):
                   #l2entry needed only to forward pkt to every other port starting from
                   #2nd port. So, skip alternate ports starting from first
                   continue
               count = port
               port_hdl = ifcs_handle_t()
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = IFCS_HANDLE_SYSPORT(port)
               l2_entry = ifcs_l2_entry_key_t()
               ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = IFCS_HANDLE_L2VNI(port)
               attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST

               ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].value.handle = port_hdl
               attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, pointer(attr))
               assert rc == IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
           print ("Created l2_entries for DMAC for FWD flow")

           # Dest MAC entries for REVERSE flow
           for i, port in enumerate(rev_devport_list):
               if ((i % 2) == 0):
                   #l2entry needed only to forward pkt to every other port starting from
                   #2nd port. So, skip alternate ports starting from first
                   continue
               count = port
               port_hdl = ifcs_handle_t()
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_hdl.value = IFCS_HANDLE_SYSPORT(port)
               l2_entry = ifcs_l2_entry_key_t()
               ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = IFCS_HANDLE_L2VNI(port)

               ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = port_hdl
               attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, pointer(attr))
               assert rc == IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
           print ("Created l2_entries for DMAC for REVERSE flow")
       except:
           print("Hit except (DMAC) config 2")
           dst_l2entry_create_failed = 1
           pass

       try:
           # SYSPORT attr set
           #Build Sysport attr for Default VID config
           sp_attr_ct = 3
           sp_attr = (ifcs_attr_t * sp_attr_ct)()

           for i, port in enumerate(devport_stats.devport_list):
               sp_attr[0].id = IFCS_SYSPORT_ATTR_DEFAULT_CVID
               if ((i % 2) == 0):
                   #In FWD dir, every other port starting from first, CVID is next port.
                   #This way, by hitting corresponding l2_entries pkt goes to next port.
                   sp_attr[0].value.u16 = devport_stats.devport_list[i + 1]
               else:
                   #In REV dir, every other port starting from second, CVID is previous port
                   #This way, by hitting corresponding l2_entries pkt goes to previous port.
                   sp_attr[0].value.u16 = devport_stats.devport_list[i - 1]

               sp_attr[1].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
               sp_attr[1].value.u16 = port
               sp_attr[2].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
               sp_attr[2].value.data = IFCS_BOOL_TRUE

               rc = ifcs_sysport_attr_set(self.cli.node_id, port_sp_hdl[port], 3, pointer(sp_attr))
               assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
           print ("Configured CVID and Untagged VID for all sysports")
       except:
           print("Hit except (Sysport) config")
           sysport_attr_set_failed = 1
           pass

    def config(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test config', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-p', type=str, default="all", help='Port list')
        parser.add_argument('-lb', type=str, choices=['NONE', 'PCS', 'PMA'], default='NONE', help='Loopback type')
        parser.add_argument('-shp', type=str, choices=['NONE', 'P_SHP', 'Q_SHP', 'ALL'], default='NONE', help='Shaping type')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-b', help='Bi-directional traffic from first and last ports', action="store_true")
        try:
            res = parser.parse_args(self.arg_list)
        except:
            return 'FAILED'

        '''
        If -p arg not given, default port range is all ports.
        '''
        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res.p == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res.p
                devport_arg_list = res.p.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config and stats
        devport_stats = DevportStats()
        devport_list = devport_stats.devport_list

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_stats.devport_list.append(j)
            else:
                devport_stats.devport_list.append(int(dp))

        allowed_lb_types = ['none', 'pcs', 'pma']
        if (res.lb.upper() not in map(str.upper, allowed_lb_types)):
            print("Invalid Loopback type specified: ", lb_type)
            return 'FAILED'
        lb_type = res.lb
        devport_stats.lb_type = res.lb
        shp_type = res.shp

        verbose = res.v
        devport_stats.verbose = res.v

        bidir = res.b
        config_fdb_methods = {"unidir": self.config_snake_unidir,
                              "bidir" : self.config_snake_bidir
        }

        # locals
        sysport_hdl_get_failed = 0
        stp_create_failed = 0
        stp_port_set_failed = 0
        l2vni_create_failed = 0
        l2vni_stp_config_failed = 0
        l2vni_member_config_failed = 0
        src_l2entry_create_failed = 0
        dst_l2entry_create_failed = 0
        sysport_attr_set_failed = 0
        devport_lb_config_failed = 0
        devport_shp_config_failed = 0
        queue_shp_config_failed = 0

        # Configure
        dport = devport_stats.devport_list[0]
        ret = ifcs_status_t()
        vni_hdl = ifcs_handle_t()
        attr = ifcs_attr_t()
        vni_attr = (ifcs_attr_t * 2)()

        attr.id = IFCS_LINKSCAN_ATTR_ENABLE
        attr.value.u32 = IFCS_BOOL_FALSE

        '''
        rc = ifcs_linkscan_attr_set(0, 1, pointer(attr))
        assert rc == IFCS_SUCCESS, "Linkscan disable FAILED!!. RC " + str(rc)
        if (verbose == 1):
            print("Linkscan disabled")
        '''

        maxPorts = MAX_DEV_PORTS
        cpu_port = 0
        port_sp_hdl = Snake.port_sp_hdl
        port_sp_hdl.clear()

        dmac_l2_entry_array = Snake.dmac_l2_entry_array
        smac_l2_entry_array = Snake.smac_l2_entry_array
        cpu_sp_hdl = Snake.cpu_sp_hdl
        stp_hdl = Snake.stp_hdl

        try:
            for port in devport_stats.devport_list:
                port_sp_hdl[port] = getSysportHandleFromDevPort(devport_stats.node_id, port)
            cpu_sp_hdl.value = getSysportHandleFromDevPort(devport_stats.node_id, cpu_port)
        except:
            print("Sysport get FAILED!!")
            sysport_hdl_get_failed = 1
            pass

        if shp_type.upper() == 'P_SHP' or shp_type.upper() == 'ALL':
            try:
                for devport in devport_stats.devport_list:
                    attrCount = 3
                    attrList = (ifcs_attr_t * attrCount)()
                    #Set the max_rate shaper to 1Gbps
                    attrList[0].id = IFCS_DEVPORT_ATTR_MAX_RATE_ENABLE
                    attrList[0].value.data = 1
                    attrList[1].id = IFCS_DEVPORT_ATTR_MAX_RATE
                    attrList[1].value.u64 = 10 * 1000 * 1000 #max_rate config is in th Kbps units
                    attrList[2].id = IFCS_DEVPORT_ATTR_MAX_BURST_SIZE
                    attrList[2].value.u32 = 160000
                    ret = ifcs_devport_attr_set(0, devport, attrCount, pointer(attrList))
                    assert ret == IFCS_SUCCESS

            except:
                print("Devport Shaper config FAILED!!")
                devport_shp_config_failed = 1
                pass

        if shp_type.upper() == 'Q_SHP' or shp_type.upper() == 'ALL':
            try:
                attr = (ifcs_attr_t * IFCS_QUEUE_ATTR_MAX_COUNT)()
                queue = ifcs_queue_t()
                attr_val = ifcs_uint32_t()
                ifcs_queue_t_init(pointer(queue))
                for devport in devport_stats.devport_list:
                    for i in range(0,8):
                        queue.devport = devport
                        queue.queue_id = i
                        ifcs_attr_t_init(pointer(attr[0]))
                        ifcs_attr_t_init(pointer(attr[1]))
                        ifcs_attr_t_init(pointer(attr[2]))
                        ifcs_attr_t_id_set(pointer(attr[0]), IFCS_QUEUE_ATTR_MAX_RATE_ENABLE)
                        ifcs_attr_t_value_data_set(pointer(attr[0]), IFCS_BOOL_TRUE)
                        ifcs_attr_t_id_set(pointer(attr[1]), IFCS_QUEUE_ATTR_MAX_RATE)
                        ifcs_attr_t_value_u64_set(pointer(attr[1]), 20000000000)
                        ifcs_attr_t_id_set(pointer(attr[2]), IFCS_QUEUE_ATTR_MAX_RATE_BURST_SIZE)
                        ifcs_attr_t_value_u32_set(pointer(attr[2]), 160000)
                        rc = ifcs_queue_attr_set(0, pointer(queue), 3, pointer(attr[0]))
                        assert IFCS_STATUS_REASON(rc) == IFCS_SUCCESS

            except:
                print("Queue Shaper config FAILED!!")
                queue_shp_config_failed = 1
                pass


        ####### STEP0 #######
        ###### STP CONFIG #######
        try:
            stp_hdl.value = IFCS_NULL_HANDLE
            ret = ifcs_stp_create(0, pointer(stp_hdl), 0, pointer(attr))
            assert ret == IFCS_SUCCESS, "STP instance creation FAILED!!"
        except:
            print("STP create FAILED!!")
            stp_create_failed = 1
            pass

        try:
            #mbrs=OrderedDict()
            #for mbr in port_sp_hdl:
            #    mbrVal = IFCS_HANDLE_VALUE(mbr)
            #    mbrs[mbr] = IFCS_HANDLE_SYSPORT(mbrVal)

            mbrs = port_sp_hdl
            member_count = len(mbrs)
            member_list = (ifcs_handle_t * member_count)()
            member_attr_count = 0
            member_attr_list = (ifcs_attr_t * member_attr_count)()
            count=0
            for mbr in mbrs:
                member_list[count] = mbrs[mbr]
                count += 1

            stp_attr_count = 1
            stp_attr = ifcs_attr_t()
            stp_attr.id        = IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = IFCS_STP_PORT_STATE_FORWARDING;

            ret = ifcs_stp_port_add(0, stp_hdl, count, pointer(member_list), stp_attr_count, pointer(stp_attr))
            assert ret == IFCS_SUCCESS,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni)
            #for mbr in mbrs:
            #    ret = ifcs_stp_port_attr_set(0, stp_hdl, mbrs[mbr], stp_attr_count, pointer(stp_attr))
            #    assert ret == IFCS_SUCCESS,\
            #           "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
            #            str(l2vni)
        except:
            stp_port_set_failed = 1
            print("STP port set FAILED!!")
            pass

        ###### VNI CONFIG ######
        # Create VNI and add members
        try:
            ###### VNI CONFIG ######
            # Create VNI and add members
            l2vni_hdl = ifcs_handle_t()
            for i in devport_stats.devport_list:
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                ret = ifcs_l2vni_create(0, pointer(l2vni_hdl), 0, pointer(attr))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI creation " + str(i)
        except:
            print("Hit except L2VNI create config")
            l2vni_create_failed = 1
            pass

        try:
            # Set STP instance for created VNI
            vni_attr[0].id = IFCS_L2VNI_ATTR_STP_INSTANCE
            vni_attr[0].value.handle = stp_hdl
            ret = ifcs_l2vni_attr_set(0, l2vni_hdl, 1, pointer(vni_attr))
            assert ret == IFCS_SUCCESS, "STP instance vni attr set FAILED!!"
        except:
            l2vni_stp_config_failed = 1
            print("Hit except L2VNI stp config")
            pass

        try:
            for i in devport_stats.devport_list:
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                ret = ifcs_l2vni_member_add(0, l2vni_hdl,
                                             member_count, pointer(member_list),
                                             member_attr_count, pointer(member_attr_list))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add " + str(l2vni)

                #Add CPU port to VNI membership
                ret = ifcs_l2vni_member_add(0, l2vni_hdl,
                                             1, pointer(cpu_sp_hdl),
                                             member_attr_count, pointer(member_attr_list))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add for CPU port" + str(l2vni)
        except:
            print("Hit except L2VNI member config")
            l2vni_member_config_failed = 1
            pass

        ####### config FDB based on unidir topo or bidir topo #######
        if bidir:
            config_fdb_methods['bidir'](devport_stats)
        else:
            config_fdb_methods['unidir'](devport_stats)

        ##### Config Loopback mode #######
        if (lb_type.upper() != 'NONE'):
            try:
                # Disable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = IFCS_BOOL_FALSE;

                for port in devport_stats.devport_list:
                    rc = ifcs_devport_attr_set(0, port, devport_attr_ct, pointer(devport_attr))
                    assert rc == IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)

                devport_attr_ct = 1
                devport_attr = (ifcs_attr_t * devport_attr_ct)()
                for port in devport_stats.devport_list:
                    if (lb_type.upper() == 'PCS'):
                        lb = IFCS_DEVPORT_LOOPBACK_PCS
                    elif (lb_type.upper() == 'PMA'):
                        lb = IFCS_DEVPORT_LOOPBACK_PMA
                    else:
                        lb = IFCS_DEVPORT_LOOPBACK_NONE
                    devport_attr[0].id = IFCS_DEVPORT_ATTR_LOOPBACK
                    devport_attr[0].value.u32 = lb
                    rc = ifcs_devport_attr_set(0, port, devport_attr_ct, pointer(devport_attr))
                    assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"

                # Enable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = IFCS_BOOL_TRUE;

                for port in devport_stats.devport_list:
                    rc = ifcs_devport_attr_set(0, port, devport_attr_ct, pointer(devport_attr))
                    assert rc == IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)
            except:
                print("Hit except (Devport loopback) config")
                devport_lb_config_failed = 1
        else:
             try:
                # Enable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = IFCS_BOOL_TRUE;

                for port in devport_stats.devport_list:
                    rc = ifcs_devport_attr_set(0, port, devport_attr_ct, pointer(devport_attr))
                    assert rc == IFCS_SUCCESS,\
                        "ERR during port admin enable:" + str(port)
             except:
                print("Hit except (Devport loopback NONE) config")
                devport_lb_config_failed = 1


        if sysport_hdl_get_failed or stp_create_failed or stp_port_set_failed or \
           l2vni_create_failed or l2vni_stp_config_failed or l2vni_member_config_failed or \
           src_l2entry_create_failed or dst_l2entry_create_failed or sysport_attr_set_failed or \
           devport_lb_config_failed or devport_shp_config_failed or queue_shp_config_failed:
            print "Snake test configuration failed"
            return 'FAILED'
        else:
            # Config success, save the config data useful for report generation
            self.insert_run_data(devport_stats)

        Snake.state = SNAKE_CONFIGD

        if (self.quiet == "false"):
            #show config
            self.config_show(args)

        # Wait for all ports to go link-up for 5 secs
        if (lb_type.upper() != 'NONE'):
            timer_val=5
        else:
            timer_val=15
        wait_time=0
        devport_attr_ct = 1
        devport_attr = (ifcs_attr_t * devport_attr_ct)()
        devport_attr[0].id = IFCS_DEVPORT_ATTR_LINK_STATUS;
        devport_attr[0].value.u32 = 0;
        actual_count = ctypes.c_uint32()
        link_status=True
        while wait_time<timer_val:
            link_status=True
            for devport in devport_stats.devport_list:
                rc = ifcs_devport_attr_get (devport_stats.node_id, devport, 1,
                                 pointer(devport_attr), pointer(actual_count));
                assert rc == IFCS_SUCCESS,\
                    "ERR during port admin enable:" +\
                    str(devport)

                if (devport_attr[0].value.u32 != 1):
                    link_status=False
            if link_status:
                break;
            else:
                wait_time+=0.1
                time.sleep(0.1)

        assert link_status == True, "Not all devports are up"

        return 'PASS'

    def config_show(self, args):
        devport_stats = self.get_cur_run_data()
        table = PrintTable()
        header = []
        header.append("Devports")
        header.append("Loopback type")
        table.add_row(header)

        data = []
        data.append(str(devport_stats.devport_list)[1:-1])
        data.append(str(devport_stats.lb_type))
        table.add_row(data)
        table.print_table()
        table.reset_table()
        pass

    def start_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test start_traffic', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-n', type=int, default=100, help='Number of packets')
        parser.add_argument('-s', type=int, default=1500, help='Packet size')
        parser.add_argument('-payload', type=str, choices=['zero', 'incremental', 'stress'], default='incremental', help='Packet payload')
        try:
            res = parser.parse_args(self.arg_list)
        except:
            return "FAILED"

        devport_stats = self.get_cur_run_data()
        length = res.s
        num_pkt = res.n
        try:
            devport_stats.num_pkt[length] += num_pkt
        except (KeyError):
            devport_stats.num_pkt[length] = num_pkt

        if (length < 64):
            length = 128

        # Start traffic
        data = (c_byte * length)()
        curByte = 65
        smac_dmac_sz = 12 # 12 bytes
        for j in range(smac_dmac_sz):
            if (j == 0):
                bytes = chr(0)
            elif (j == 5):
                bytes += chr(0xaa)
            elif (j == 11):
                bytes += chr(0xbb)
            else:
                bytes += chr(0)
        for j in range(length - smac_dmac_sz):
           if(res.payload == 'stress'):
               curByte = random.randint(0, 255)
               bytes += chr(curByte)
           elif(res.payload == 'incremental'):
               bytes += chr(curByte)
               curByte = (curByte + 1) & 0xff
           else:
               bytes += chr(0)

        data = bytes
        pdata = cast(data, c_void_p)
        try:
            packet = ifcs_hostif_packet_info_t()
            ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            dport = devport_stats.devport_list[0]
            packet.dsp = getSysportHandleFromDevPort(devport_stats.node_id, dport)
            packet.pkt_buf = pdata
            packet.pkt_buf_len = length
        except Exception as e:
            print "exc", e
        for loop in range(0, num_pkt):
		rc = ifcs_hostif_send_packet(devport_stats.node_id, pointer(packet))
		if (rc != IFCS_SUCCESS):
		   log_err('Packet send to pcie failed')
		   print('Packet send to pcie failed')
		   return 'FAILED'

        Snake.state = SNAKE_RUNNING
        return 'PASS'

    def stop_traffic(self, args):
        dmac_l2_entry_array = Snake.dmac_l2_entry_array
        smac_l2_entry_array = Snake.smac_l2_entry_array
        port_sp_hdl = Snake.port_sp_hdl
        cpu_sp_hdl = Snake.cpu_sp_hdl
        stp_hdl = Snake.stp_hdl
        mac_addr_t = c_uint8 * 6
        devport_obj = Devport(self.cli)

        devport_stats = self.get_cur_run_data()
        verbose = devport_stats.verbose
        devport_list = devport_stats.devport_list

        port = devport_list[0]
        port_hdl = ifcs_handle_t()
        l2vni_hdl = ifcs_handle_t()
        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
        port_hdl.value = IFCS_HANDLE_SYSPORT(port)
        l2_entry = ifcs_l2_entry_key_t()
        ifcs_l2_entry_key_t_init(pointer(l2_entry))
        l2vni_hdl.value = IFCS_HANDLE_L2VNI(port)

        ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
        ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                l2_entry.key.mac_l2vni)
        ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                mac_addr)
        ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                l2vni_hdl)

        attr_count = 0
        attr = (ifcs_attr_t * 2)()
        fwd_policy = ifcs_fwd_policy_t()
        ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = IFCS_FWD_ACTION_DROP
        ifcs_attr_t_id_set(pointer(attr[attr_count]), IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_attr_t_value_fwd_policy_set(pointer(attr[attr_count]), pointer(fwd_policy))
        attr_count += 1

        rc = ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, pointer(attr))
        assert rc == IFCS_SUCCESS, "Attr set to Drop FDB entry FAILED!!: rc = [" + str(rc) + "]"

        time.sleep(5)

        port_stats = []
        port_stats = devport_obj.stats_get(port)
        pre_counts = range(2)
        pre_counts[0] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
        pre_counts[1] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]

        time.sleep(1)

        port_stats = []
        port_stats = devport_obj.stats_get(port)
        post_counts = range(2)
        post_counts[0] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
        post_counts[1] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]

        if (((post_counts[1] - pre_counts[1]) > 0) or ((post_counts[0] - pre_counts[0]) > 0)):
            print("Traffic NOT stopped. Try again")
            return 'FAILED'

        attr_count = 0
        fwd_policy = ifcs_fwd_policy_t()
        ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = IFCS_FWD_ACTION_FORWARD
        ifcs_attr_t_id_set(pointer(attr[attr_count]), IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_attr_t_value_fwd_policy_set(pointer(attr[attr_count]), pointer(fwd_policy))
        attr_count += 1

        rc = ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, pointer(attr))
        assert rc == IFCS_SUCCESS, "Attr set back to Fwd FDB entry FAILED!!: rc = [" + str(rc) + "]"

        Snake.state = SNAKE_STOPPED
        return 'PASS'


    def gen_report(self, args, display = True, skipPop = False):
        if not skipPop:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test gen_report', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-t', type=int, default=10, help='Time in seconds to collect stats')
        parser.add_argument('-v', type=int, default=0, help='Verbose [0-Off, 1-On')
        pre_timestamp = [0] * MAX_DEV_PORTS
        new_timestamp = [0] * MAX_DEV_PORTS

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"

        devport_stats = self.get_cur_run_data()
        devport_stats.time = res.t
        verbose = res.v

        #Account for Inter-frame/packet-gap(12B) + preamble(8B)
        IPG_LEN = 12
        PREAMBLE_LEN = 8
        misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

        devport_obj = Devport(self.cli)

        for p in range(MAX_DEV_PORTS):
            # Get current stats
            if p not in devport_stats.devport_list:
                continue

            port_stats = devport_obj.stats_get(p)
            pre_timestamp[p] = round(time.time(),4)
            devport_stats.devport_rx_frames[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
            devport_stats.devport_rx_bytes[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_BYTES_OK']]
            devport_stats.devport_tx_frames[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]
            devport_stats.devport_tx_bytes[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_BYTES_OK']]
            devport_stats.devport_rx_errors[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY']]
            devport_stats.devport_tx_errors[p] = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY']]

        # Sleep for given time and get stats again to calculate rate
        rx_rate = [0] * MAX_DEV_PORTS
        tx_rate = [0] * MAX_DEV_PORTS

        if display:
            print "Devport stats rate calculation being done, please wait %d secs" %(devport_stats.time)

        if (verbose):
            devport_stats.display()

        #Sleeping
        time.sleep(devport_stats.time)

        for p in range(MAX_DEV_PORTS):
            if p not in devport_stats.devport_list:
                continue
            port_stats = devport_obj.stats_get(p)
            new_timestamp[p] = round(time.time(),4)
            new_devport_rx_frames = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK']]
            new_devport_rx_bytes = port_stats[globals()['IFCS_DEVPORT_STATS_ID_RX_BYTES_OK']]
            new_devport_tx_frames = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK']]
            new_devport_tx_bytes = port_stats[globals()['IFCS_DEVPORT_STATS_ID_TX_BYTES_OK']]

            #Calculate Delta
            delta_rx_frames = new_devport_rx_frames - devport_stats.devport_rx_frames[p]
            delta_tx_frames = new_devport_tx_frames - devport_stats.devport_tx_frames[p]
            delta_rx_bytes = new_devport_rx_bytes - devport_stats.devport_rx_bytes[p]
            delta_tx_bytes = new_devport_tx_bytes - devport_stats.devport_tx_bytes[p]
            delta_timestamp = float(new_timestamp[p] - pre_timestamp[p])

            delta_tx_bytes += (delta_tx_frames * misc_delta_bytes)
            delta_rx_bytes += (delta_rx_frames * misc_delta_bytes)

            rx_rate[p] = float(float(delta_rx_bytes * 8)/float(1000*1000*1000*delta_timestamp))
            tx_rate[p] = float(float(delta_tx_bytes * 8)/float(1000*1000*1000*delta_timestamp))

            devport_stats.devport_rx_frames[p] = new_devport_rx_frames
            devport_stats.devport_rx_bytes[p] = new_devport_rx_bytes
            devport_stats.devport_tx_frames[p] = new_devport_tx_frames
            devport_stats.devport_tx_bytes[p] = new_devport_tx_bytes
            devport_stats.devport_rx_gbps[p] = rx_rate[p]
            devport_stats.devport_tx_gbps[p] = tx_rate[p]

        if display:
            devport_stats.display()


        '''
        for i in range(len(Snake.devport_stats_runs)):
            print ("Run %d config and stats:" %(i+1))
            print ("-----------------------")
            Snake.devport_stats_runs[i].display()
        '''
        pass

    def verify(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Snake test verify_traffic', prog='snake', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-rate', type=int, default=0, help='rx in gbps')
        parser.add_argument('-display', type=int, default=0, help='Log verbose')
        parser.add_argument('-ports', nargs='+', type=int, help='tx rx ports to verify for rate')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAIL"
        rate = res.rate

        devport_stats = self.get_cur_run_data()
        # Caluculate rate
        self.gen_report(args, display = res.display, skipPop = True)
        ret = "PASS"

        num_ports = 0
        if res.ports is not None:
            num_ports = len(res.ports)

        # Verify the Tx and Rx rate for a given port pair
        if num_ports != 0:
            tx_port = res.ports[0]
            rx_port = res.ports[1]
            if (devport_stats.devport_tx_gbps[tx_port] == 0) or devport_stats.devport_rx_gbps[rx_port] == 0:
                ret = "FAIL"
                print ret
                return ret

            if rate != 0:
               #if (devport_stats.devport_rx_gbps[p] < (rate - 1)) or (devport_stats.devport_rx_gbps[p] > (rate + 1)):
               #400G and 200G line rate traffic test failing with above validation. Modifying as below to be generic
               if (abs(devport_stats.devport_rx_gbps[rx_port]-rate)/rate > 0.01):
                   ret = "FAIL"
                   print ret
                   return ret
        else:
            for p in devport_stats.devport_list:
                # If any of the configured ports rate is 0, snake test has problem
                if (devport_stats.devport_rx_gbps[p] == 0):
                    ret = "FAIL"
                    break
                if rate != 0:
                   #if (devport_stats.devport_rx_gbps[p] < (rate - 1)) or (devport_stats.devport_rx_gbps[p] > (rate + 1)):
                   if (abs(devport_stats.devport_rx_gbps[p]-rate)/rate > 0.01):
                       ret = "FAIL"
                       break
        print ret
        return ret

    def dump_report(self, args):
        pass

    def unconfig(self, args):
        devport_stats = self.get_cur_run_data()
        verbose = devport_stats.verbose
        devport_list = devport_stats.devport_list

        dmac_l2_entry_array = Snake.dmac_l2_entry_array
        smac_l2_entry_array = Snake.smac_l2_entry_array
        port_sp_hdl = Snake.port_sp_hdl
        cpu_sp_hdl = Snake.cpu_sp_hdl
        stp_hdl = Snake.stp_hdl

        member_count = len(port_sp_hdl)
        member_list = (ifcs_handle_t * member_count)()

        for count, port in enumerate(port_sp_hdl):
            member_list[count] = port_sp_hdl[port]

        if verbose:
            print("Removing L2 entry")

        try:
            #for l2_entry in smac_l2_entry_array:
            while smac_l2_entry_array:
                l2_entry = smac_l2_entry_array.pop(0)
                rc = ifcs_l2_entry_delete(0, pointer(l2_entry))
                assert rc == IFCS_SUCCESS, "Delete SMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except:
            print("Hit except (SMAC L2entry) delete")
            pass

        try:
            #for l2_entry in dmac_l2_entry_array:
            while dmac_l2_entry_array:
                l2_entry = dmac_l2_entry_array.pop(0)
                rc = ifcs_l2_entry_delete(0, pointer(l2_entry))
                assert rc == IFCS_SUCCESS, "Delete DMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except:
            print("Hit except (DMAC L2entry) delete")
            pass

        if verbose:
            print("Removing L2VNI members")
        try:
            for i in devport_list:
                l2vni_hdl = ifcs_handle_t()
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                ret = ifcs_l2vni_member_remove(0, l2vni_hdl,
                                               member_count, pointer(member_list))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr remove " + str(i)

                #Add CPU port to VNI membership
                ret = ifcs_l2vni_member_remove(0, l2vni_hdl,
                                               1, pointer(cpu_sp_hdl))
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI mbr remove for CPU port" + str(i)
        except:
            print("Hit except L2VNI member delete")
            pass

        try:
            for i in devport_list:
                l2vni_hdl.value = IFCS_HANDLE_L2VNI(i)
                ret = ifcs_l2vni_delete(0, l2vni_hdl.value)
                assert ret == IFCS_SUCCESS,\
                       "ERR during L2VNI delete " + str(i)
        except:
            print("Hit except L2VNI delete")
            pass


        try:
            ret = ifcs_stp_delete(0, stp_hdl)
            assert ret == IFCS_SUCCESS, "ERR during STP delete"
        except:
            print("Hit except STP delete")
            pass

        # set sysport cvid attr to default
        sp_attr_ct = 3
        sp_attr = (ifcs_attr_t * sp_attr_ct)()

        try:
            for i, port in enumerate(devport_stats.devport_list):
                sp_attr[0].id = IFCS_SYSPORT_ATTR_DEFAULT_CVID
                sp_attr[0].value.u16 = 0
                sp_attr[1].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
                sp_attr[1].value.u16 = 0
                sp_attr[2].id = IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
                sp_attr[2].value.data = IFCS_BOOL_FALSE

                rc = ifcs_sysport_attr_set(self.cli.node_id, port_sp_hdl[port], 3, pointer(sp_attr))
                assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
        except:
            print("Hit except sysport cvid default")

        # Set Loopback state to NONE
        try:
            # Disable all the ports
            devport_attr_ct = 1
            devport_attr = (ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = IFCS_BOOL_FALSE;

            for port in devport_stats.devport_list:
                rc = ifcs_devport_attr_set(0, port, devport_attr_ct, pointer(devport_attr))
                assert rc == IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

            devport_attr_ct = 1
            devport_attr = (ifcs_attr_t * devport_attr_ct)()
            for port in devport_stats.devport_list:
                lb = IFCS_DEVPORT_LOOPBACK_NONE
                devport_attr[0].id = IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_devport_attr_set(0, port, devport_attr_ct, pointer(devport_attr))
                assert rc == IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"

        except:
            print("Hit except (Devport loopback) config")

        Snake.state = SNAKE_UNCONFIG
        return 'PASS'
