
#-------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
from utils.log_utils import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_ctypes import *
from ifcs_cmds.all import *
from ifcs_cmds.cli_types import *

# Class implements Debug state dump related commands


class DebugParser(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(DebugParser, self).__init__()

        self.sub_cmds = {
            'ifcs': self.debug_ifcs,
            'help': self.help,
            '?': self.help
        }


        self.show_debug_names = ['']

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Ifcs run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(1, "IfcsKeyError")
            self.help(args)
            return IFCS_INVAL
        except (ValueError):
            log_dbg(1, "IfcsValueError")
            self.help(args)
            return IFCS_INVAL
        except BaseException:
            log_dbg(1, "IfcsOtherError")
            self.help(args)
            return IFCS_INVAL


    def debug_all_ifcs(self):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        test_run_id = time.strftime("%b_%d_%Y_%H%M%S", time.localtime())
        fileName = os.environ['HOME'] + '/ifcsDump_' + str(test_run_id) + '.p'
        try:
            fh = open(fileName, 'wb')
        except Exception as e:
            log_dbg(1, "File open error (", e, "): " + str(fileName))
            return

        log_dbg(1, "Writing to file " + fileName + "...")
        fh.write(json.dumps(all_state,indent=4))
        fh.close()
        return IFCS_SUCCESS

    def debug_modlist_ifcs(self, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        print json.dumps(all_state,indent=4)
        return json.dumps(all_state,indent=4)

    def debug_modlist_devport_ifcs(self, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        for entry in all_state[0]["Devport"]:
            entry['speed'] = ifcs_obj.enum_to_str('speed', entry['speed'])
            entry['fec_mode'] = ifcs_obj.enum_to_str('fec_mode', entry['fec_mode'])
            entry['link_status'] = ifcs_obj.enum_to_str('link_status', entry['link_status'])
            entry['loopback'] = ifcs_obj.enum_to_str('loopback', entry['loopback'])
            entry['intf_type'] = ifcs_obj.enum_to_str('type', entry['type'])


        # printing for remote cli to capture stdout
        print json.dumps(all_state,indent=4)
        return json.dumps(all_state,indent=4)

    def debug_modlist_devport_counters_ifcs(self, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            state = []
            try:
                all_devport = ifcs_obj.getAlldevport()
                for devport in all_devport:
                    statsList = {}
                    output = ifcs_obj.stats_get(devport)
                    statsList['hw_port'] = devport

                    statsList['rx_octets'] = output[IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
                    statsList['rx_uc_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_UNICAST]
                    statsList['rx_mc_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_MULTICAST]
                    statsList['rx_bc_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_BROADCAST]
                    statsList['rx_mac_ctrl'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_PFC]
                    statsList['rx_drop_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_DROP]
                    statsList['rx_err_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]

                    statsList['tx_octets'] = output[IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
                    statsList['tx_uc_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_UNICAST]
                    statsList['tx_mc_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_MULTICAST]
                    statsList['tx_bc_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_BROADCAST]
                    statsList['tx_mac_ctrl'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_PFC]
                    statsList['tx_drop_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_DROP]
                    statsList['tx_err_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]

                    state.append(statsList)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state['DevportStats'] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        print json.dumps(all_state,indent=4)
        return json.dumps(all_state,indent=4)


    def debug_modlist_ifcs_usage(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                if name.lower() == 'nexthop':
                    output = ifcs_obj.getNexthopUsage()
                elif name.lower() == 'intf':
                    output = ifcs_obj.getIntfUsage()
                elif name.lower() == 'ecmp':
                    if 'members' in modules:
                        output = ifcs_usage_t()
                        ifcs_usage_t_init(pointer(output))
                        rc = ifcs_ecmp_member_usage_get(self.cli.node_id,
                                                        0,
                                                        0,
                                                        0,
                                                        pointer(output))
                        name = name + '_members'
                    else:
                        output = ifcs_obj.getEcmpUsage()
                elif name.lower() == 'route_entry':
                    #output = ifcs_obj.getIntfUsage()
                    output = ifcs_usage_t()
                    ifcs_usage_t_init(pointer(output))
                    attr = ifcs_attr_t()
                    ifcs_attr_t_id_set(pointer(attr), IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE)
                    if 'host' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_USAGE_GET_TYPE_HOST)
                    elif 'prefix' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_USAGE_GET_TYPE_PREFIX)
                    rc = ifcs_route_entry_usage_get(self.cli.node_id,
                                                    0,
                                                    1,
                                                    pointer(attr),
                                                    pointer(output))

                current_usage = output.current
                max_usage = output.max
                state['curr'] = current_usage
                state['max'] = max_usage
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        print json.dumps(all_state,indent=4)
        return json.dumps(all_state,indent=4)


    def debug_modlist_nexthop_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllnexthop()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        nexthop_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["Nexthop"]:
            reqd_dict = {}
            reqd_dict['obj.handle'] = entry
            reqd_dict['intf'] = ifcs_obj.getIntf(entry)
            reqd_dict['dest_mac'] = ifcs_obj.getDestMac(entry)
            reqd_dict['no_decrement_ttl'] = ifcs_obj.getNoDecrementTtl(entry)
            reqd_dict['index_el.index'] = IFCS_HANDLE_VALUE(entry)
            reqd_dict['ctc_policy'] = ifcs_obj.getCtcPolicy(entry)[-1]
            reqd_dict['fwd_policy'] = ifcs_obj.getFwdPolicy(entry)[-1]

            if IFCS_HANDLE_VALUE(entry) < 129:
                reqd_dict['port_type'] = 'normal'
                continue
            handle_value = ifcs_obj.getLocalDestination(entry)
            if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_SYSPORT:
                sysportObj = ifcsObjs.get_ifcs_obj_from_name('sysport')
                val = sysportObj.getDevport(handle_value)
                #this can be a cpu dest
                #val = IFCS_HANDLE_VALUE(int(handle_value))
                if val == 0:
                    reqd_dict['port_type'] = 'cpu'
                else:
                    reqd_dict['port_type'] = 'normal'
            else:
                reqd_dict['port_type'] = 'normal'
            reqd_obj_list.append(reqd_dict)
        nexthop_dict['Nexthop'] = reqd_obj_list

        # printing for remote cli to capture stdout
        print json.dumps(nexthop_dict,indent=4)
        return json.dumps(nexthop_dict,indent=4)


    def debug_modlist_ecc_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        state = {}
        obj_state = {}
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        try:
            ecc_node_stat = ifcs_ecc_node_stats_t()
            ifcs_node_ecc_stats(0, pointer(ecc_node_stat))
            state['TOTAL'] = ecc_node_stat.total_count
            state['TYPE_CE'] = ecc_node_stat.type_ce_count
            state['TYPE_UE'] = ecc_node_stat.type_ue_count
            state['TYPE_TREE'] = ecc_node_stat.type_tree_count
            state['TYPE_INV'] = ecc_node_stat.type_invalid_count
            state['RATELIMIT'] = ecc_node_stat.rate_limit_hit_count
            state['SW_FIXED_CE'] = ecc_node_stat.sw_fixed_ce_count
            state['SW_FIXED_UE'] = ecc_node_stat.sw_fixed_ue_count
        except Exception as e:
            if 'no attribute' in e.message:
                state = ''
            else:
                log_err(e.message)
                return
        obj_state['Ecc'] = state
        all_state.append(obj_state)

        # printing for remote cli to capture stdout
        print json.dumps(all_state,indent=4)
        return json.dumps(all_state,indent=4)


    def debug_modlist_l2_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs l2entry state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_l2_entry = ifcs_obj.getAlll2_entry()
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_l2_entry
            all_state.append(obj_state)

        l2_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["L2_entry"]:
            reqd_entry = {}

            handle_value = ifcs_obj.getEntryDest(entry)
            #handle_value = entry['entry_dest']
            if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_SYSPORT:
                sysport_obj = ifcsObjs.get_ifcs_obj_from_name('sysport')
                val = sysport_obj.getDevport(handle_value)
                #val = sysport_obj.getDevport(entry['entry_dest'])
                #this can be a cpu dest
                #val = IFCS_HANDLE_VALUE(int(handle_value))
                if val == 0:
                    reqd_entry['port_type'] = 'cpu'
                else:
                    reqd_entry['port_type'] = 'normal'
            else:
                reqd_entry['port_type'] = 'normal'

            '''
            reqd_entry['l2_entry_key._dirty_mac_l2vni'] = entry['l2_entry_key._dirty_mac_l2vni']
            reqd_entry['key.mac_addr'] = entry['tl_l2_objects']['0']['key.mac_addr']
            reqd_entry['key.l2vni'] = entry['tl_l2_objects']['0']['key.l2vni']
            reqd_entry['fwd_action'] = entry['tl_l2_objects']['0']['pkt_policy.fwd_policy.fwd_action']
            reqd_entry['entry_dest'] = entry['entry_dest']
            reqd_entry['entry_type'] = entry['entry_type']
            '''
            reqd_entry['l2_entry_key._dirty_mac_l2vni'] = entry.contents._dirty_mac_l2vni
            reqd_entry['key.mac_addr'] = ifcs_obj.get_mac_addr_from_l2_entry(entry)
            l2vni_str = entry.contents.key.mac_l2vni.l2vni
            reqd_entry['key.l2vni'] = IFCS_HANDLE_VALUE(l2vni_str)
            reqd_entry['fwd_action'] = ifcs_obj.getEntryFwdPolicy(entry)
            reqd_entry['entry_dest'] = handle_value
            reqd_entry['entry_type'] = ifcs_obj.getEntryType(entry)
            reqd_obj_list.append(reqd_entry)

        l2_dict["L2_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        #print json.dumps(all_state,indent=4)
        #return json.dumps(all_state,indent=4)

        # printing for remote cli to capture stdout
        dump = json.dumps(l2_dict,indent=4)
        print dump
        return dump

    def debug_modlist_intf_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_intf = ifcs_obj.getAllintf()
                intf_val_list = []
                for intf in all_intf:
                    intf_val_dict = {}
                    if ifcs_obj.getType(intf) != 1: #need only svi
                        continue
                    intf_val = ifcs_obj.handle_to_str(intf)
                    l3vni_val = ifcs_obj.getForwardingInstance(intf)
                    mtu_val = ifcs_obj.getMtu(intf)
                    l2vni_val = ifcs_obj.getTransportInstance(intf)
                    src_mac_val = ifcs_obj.getTransportMac(intf)

                    intf_val_dict['intf_index'] = IFCS_HANDLE_VALUE(intf)
                    intf_val_dict['l3vni'] = IFCS_HANDLE_VALUE(l3vni_val)
                    intf_val_dict['l2vni'] = l2vni_val
                    intf_val_dict['mtu'] = mtu_val
                    intf_val_dict['src_mac'] = src_mac_val

                    intf_val_list.append(intf_val_dict)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return

        # printing for remote cli to capture stdout
        dump = json.dumps(intf_val_list,indent=4)
        print dump
        return dump

    def debug_modlist_route_v4_host_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.getAllroute_entry()
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            if addr_family == 0 and hex(entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4).strip('L') == '0xffffffff':
                reqd_entry = {}
                handle_value = ifcs_obj.getNexthop(entry)
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4
                reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
                reqd_entry['prefix_len'] = 32
                reqd_entry['nexthop'] = handle_value
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        print dump
        return dump

    def debug_modlist_route_v6_host_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.getAllroute_entry()
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = 0
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()
            if prefix_len == 128:
                reqd_entry = {}
                handle_value = ifcs_obj.getNexthop(entry)
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = handle_value
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        print dump
        return dump


    def debug_modlist_route_v4_prefix_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.getAllroute_entry()
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            if addr_family == 0 and hex(entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4).strip('L') != '0xffffffff':
                reqd_entry = {}
                handle_value = ifcs_obj.getNexthop(entry)
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4
                mask = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4
                mask_str = socket.inet_ntoa(struct.pack('!L', mask))
                reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
                reqd_entry['prefix_len'] = IPAddress(mask_str).netmask_bits()
                reqd_entry['nexthop'] = handle_value
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        print dump
        return dump

    def debug_modlist_route_v6_prefix_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.getAllroute_entry()
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = -1
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()
            if prefix_len != 128 and prefix_len != -1:
                reqd_entry = {}
                handle_value = ifcs_obj.getNexthop(entry)
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = handle_value
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        print dump
        return dump


    def debug_ifcs(self, args):
        log_dbg(1, "Debugging ifcs state ..")

        ifcsObjs = IfcsAll(self.cli)
        arg_list = args.split()

        if (len(arg_list) > 6) and (arg_list[2] not in ifcsObjs.get_ifcs_obj_names()):
            log_err("Invalid command")
            return IFCS_INVAL

        modules = arg_list[2:]

        if len(modules) == 0:
            # All modules
            return self.debug_all_ifcs()
        else:
            if 'usage' in modules:
                #just get the usage details for the module
                return self.debug_modlist_ifcs_usage(modules)
            else:
                if 'nexthop' in modules:
                    return self.debug_modlist_nexthop_ifcs(modules)
                elif 'intf' in modules:
                    return self.debug_modlist_intf_ifcs(modules)
                elif 'ecc' in modules:
                    return self.debug_modlist_ecc_ifcs(modules)
                elif 'l2_entry' in modules:
                    return self.debug_modlist_l2_entry_ifcs(modules)
                elif 'route_entry' in modules:
                    #return self.debug_modlist_route_entry_ifcs(modules)
                    if 'v4_host' in modules:
                        return self.debug_modlist_route_v4_host_entry_ifcs(modules)
                    elif 'v4_prefix' in modules:
                        return self.debug_modlist_route_v4_prefix_entry_ifcs(modules)
                    elif 'v6_prefix' in modules:
                        return self.debug_modlist_route_v6_prefix_entry_ifcs(modules)
                    elif 'v6_host' in modules:
                        return self.debug_modlist_route_v6_host_entry_ifcs(modules)
                elif 'devport' in modules and 'counters' in modules:
                    return self.debug_modlist_devport_counters_ifcs(modules)
                elif 'devport' in modules:
                    return self.debug_modlist_devport_ifcs(modules)
                else:
                    return self.debug_modlist_ifcs(modules)


    def help(self, args):
        print args, "helping.."
        return
