
#-------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
from utils.log_utils import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']
from collections import OrderedDict

from ifcs_cmds.all import *
from ifcs_cmds.cli_types import *
from debug_encode import *
 

# Class implements Debug state dump related commands
class Debug(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(Debug, self).__init__()

        self.sub_cmds = {
            'ifcs': self.debug_ifcs,
            'device': self.debug_device,
            'help': self.help,
            '?': self.help
        }

        self.sub_device_cmds = {
            'pen': self.debug_device_pen,
 
        }

 
        self.show_debug_names = ['ifcs', 'device']

    def __del__(self):
        return

    def validate_ifcs_args(self, args):
        # split the args
        arg_list = args.split()

        if arg_list[-2] == 'all' and len(arg_list) > 3:
            file_path = arg_list[-1].split('/')
            file_path = '/'.join(file_path[:-1])
            if os.path.isdir(file_path) and os.path.exists(file_path):
                arg_list = arg_list[:-1]
            else:
                raise KeyError(file_path + " Doesn't exist")

        # ensure length is atleast 3
        if len(arg_list) < 3:
            raise KeyError("Invalid command")

        # get all ifcs objs
        ifcsObjs = IfcsAll(self.cli)

        # api_class
        try:
            api_class = arg_list[2]
        except:
            raise KeyError("Invalid command")

        # dispatch
        try:
            dispatch = arg_list[-1]
            api_class_instance = arg_list[-2]
        except:
            raise KeyError("Invalid command")

        # all ifcs_obj_names
        obj_names = ifcsObjs.get_ifcs_obj_names()

        # validate if arg_list contains valid api_class
        if (len(arg_list) > 2) and ((api_class not in obj_names) and (api_class != "all" and api_class != "snapshot")):
            raise KeyError("Invalid Command")

        # if arg_list contains stats, ensure the api_class instance is provided
        if dispatch == 'stats' and ((api_class_instance == 'all') or (api_class_instance in obj_names)):
            raise KeyError("Invalid Command")

        # if arg_list doesn't contain stats, ensure that dispatch is obj_name
        if dispatch != 'stats' and dispatch != api_class and dispatch != 'mod':
            raise KeyError("Invalid command")

        return

    def parse_ifcs_args(self, args):
        # split the args
        arg_list = args.split()

        if arg_list[-2] == 'all' and len(arg_list) > 3:
            file_path = arg_list[-1].split('/')
            file_path = '/' + '/'.join(file_path[:-1])
            if os.path.isdir(file_path) and os.path.exists(file_path):
                arg_list = arg_list[:-1]
            else:
                raise KeyError(file_path + " Doesn't exist")

        # get the last arg
        last_arg = arg_list[-1]

        if last_arg == 'all' or last_arg == 'snapshot':
            dispatch = last_arg
        elif last_arg == 'stats':
            dispatch = last_arg
        else:
            dispatch = 'modules'

        return dispatch, args

    def run_cmd(self, args):
        log_dbg(1, "In Ifcs run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(1, "IfcsKeyError")
            self.help(args)
            return IFCS_INVAL
        except (ValueError):
            log_dbg(1, "IfcsValueError")
            self.help(args)
            return IFCS_INVAL
        except BaseException:
            log_dbg(1, "IfcsOtherError")
            self.help(args)
            return IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        elif remline == text:
            if 'ifcs' == cmd.rstrip():
                ifcsObjs = IfcsAll(self.cli)
                return [j.lower() for j in ifcsObjs.get_ifcs_obj_names()
                        if j.startswith(text)]
            else:
                return [
                    j for j in self.sub_device_cmds.keys() if j.startswith(text)]
        else:
            try:
                return getattr(
                    self,
                    'complete_' +
                    cmd)(
                    cmd,
                    remline,
                    line,
                    text)
            except AttributeError:
                return None

    def complete_device(self, cmd, remline, line, text):
        if remline == 'decode':
            return [i.lower() for i in self.sub_device_decode_cmds.keys()]
        elif remline == 'restore':
            return [i.lower() for i in self.sub_device_restore_cmds.keys()]
        elif remline in self.sub_device_cmds.keys():
            return [i.lower()
                    for i in ['ib', 'comp'] if i.lower().startswith(text)]
        elif remline.split()[1] in self.sub_device_cmds.keys():
            return [i.lower()
                    for i in ['ib', 'comp'] if i.lower().startswith(text)]
        else:
            return [i.lower() for i in self.sub_device_cmds.keys()
                    if i.lower().startswith(text)]

    def complete_ifcs(self, cmd, remline, line, text):
        ifcsObjs = IfcsAll(self.cli)
        if remline == 'ifcs':
            return [i.lower() for i in ifcsObjs.keys()]
        else:
            return [i.lower() for i in ifcsObjs.keys().lower().startswith(text)]

    def debug_snapshot(self, args):
        log('Generating ifcs state dump. This might take a while..')
        im_nmgr_wb_snapshot(self.cli.node_id)
        log('Saved IFCS State to '+ os.environ['IFCS_WB_FILE'])
        try:
            debug_encode([], [])
        except Exception as e:
            print (e)


    def get_stats_dict_from_stats(self, ifcs_obj, obj):
        stats     = {}
        stats_list = ifcs_obj.stats_get(obj)
        # Decode the stat ids into stat names
        for stat_id in range(len(stats_list)):
            stats[ifcs_obj.statslist[stat_id].lower()] = int(
                stats_list[stat_id])
        return stats

    def debug_all_ifcs(self, args):
        log('Generating ifcs state dump. This might take a while..')

        outfile = ''
        arg_list = args.split()

        if arg_list[-2] == 'all' and len(arg_list) > 3:
            outfile = arg_list[-1]
            file_path = arg_list[-1].split('/')
            file_path = '/' + '/'.join(file_path[:-1])
            if os.path.isdir(file_path) and os.path.exists(file_path):
                outfile = arg_list[-1]
                arg_list = arg_list[:-1]
                args = ' '.join(arg_list)

        arg_split = args.split()
        arg_split.append('mod')
        args = ' '.join(arg_split)
        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            api_state = {}
            mod_state = {}
            state     = []
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                mod_state['module']  = ifcs_obj.getAllIfcsState(args)
            except:
                mod_state['module']  = {}
            state.append(mod_state)
            try:
                count = 0
                all_objs = getattr(ifcs_obj, 'getAll'+name)()
                for count, obj in enumerate(all_objs):
                    obj_state = OrderedDict()
                    obj_state[name] = count
                    try:
                        obj_state['attributes'] = json.loads(ifcs_obj.getIfcsState(obj))
                    except:
                        obj_state['attributes'] = {}
                    try:
                        obj_state['stats'] = self.get_stats_dict_from_stats(ifcs_obj, obj)
                    except:
                        obj_state['stats'] = {}
                    state.append(obj_state)
            except Exception as e:
                if 'no attribute' in e.message:
                    obj_state = {}
                    obj_state['attributes'] = {}
                    obj_state['stats'] = {}
                    state.append(obj_state)
                else:
                    log_err(e.message)
                    return

            # Fill up the object
            api_state[name.capitalize()] = state
            all_state.append(api_state)

        if outfile:
            log('..Writing ifcs state dump to ' + outfile)
            with open(outfile, 'w') as f:
                f.write(json.dumps(all_state, indent=4))
                f.flush()
                f.close()
        print json.dumps(all_state, indent=4)
        return IFCS_SUCCESS

    def debug_statlist_ifcs(self, args):

        # fetch ifcs all object
        arg_list     = args.split()
        ifcsObjs     = IfcsAll(self.cli)
        all_stats    = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        object_id    = int(arg_list[-2])
        object_name  = arg_list[-3]
        OBJ_NAME     = object_name.upper()

        # find the object in question
        for name in ifcsObjNames:
            if name.lower() != object_name:
                continue

            # found the object
            obj_state     = {}
            stats         = {}
            ifcs_obj      = ifcsObjs.get_ifcs_obj_from_name(name)
            object_handle = globals()['IFCS_HANDLE_%s' % (OBJ_NAME)](object_id)
            try:
                stats_list = ifcs_obj.stats_get(object_handle)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return

            # Decode the stat ids into stat names
            for stat_id in range(len(stats_list)):
                stats[ifcs_obj.statslist[stat_id].lower()] = int(
                    stats_list[stat_id])

            # Fill up the object
            obj_state[name.capitalize()] = hex(object_handle)
            obj_state['Stats']           = stats
            all_stats.append(obj_state)

        print json.dumps(all_stats, indent=4)
        return IFCS_SUCCESS

    def debug_modlist_ifcs(self, args):
        log('Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()

        for name in ifcsObjNames:
            if name.lower() not in args:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        print json.dumps(all_state, indent=4)
        return IFCS_SUCCESS

    def debug_ifcs(self, args):
        log_dbg(1, "Debugging ifcs state ..")

        # setup the cmd dispatch dictionary
        dispatch_cmds = {
            'snapshot'  : self.debug_snapshot,
            'all'       : self.debug_all_ifcs,
            'modules'   : self.debug_modlist_ifcs,
            'stats'     : self.debug_statlist_ifcs,
        }

        # validate args
        try:
            self.validate_ifcs_args(args)
        except Exception as e:
            log_err(e.message)
            return

        # parse the args
        try:
            dispatch, args = self.parse_ifcs_args(args)
        except Exception as e:
            log_err(e.message)
            return

        # dispatch the command
        dispatch_cmds[dispatch](args)

    def debug_device(self, args):
        log_dbg(1, "Debugging device state ..")
        arg_list = args.split()

        if arg_list[2] not in self.sub_device_cmds.keys():
            log_err("Invalid command")
            return IFCS_INVAL

        self.sub_device_cmds[arg_list[2]](args)
        return IFCS_SUCCESS

    def debug_device_pen(self, args):
        log_dbg(1, "Debugging pen state..")
        """
            debug device pen ib <ib-id> comp <cmp-id>
            or
            debug device pen ib <ib-id>
            or
            debug device pen comp <cmp-id>
            or
            debug device pen
        """
        arg_list = args.split()

        if arg_list[2] != 'pen':
            log_err("Invalid command")
            return IFCS_INVAL

        parser = argparse.ArgumentParser(prog="debug")
        parser.add_argument("group")
        parser.add_argument("cmd")
        parser.add_argument("obj")
        ib_id = []
        if 'ib' in arg_list:
            parser.add_argument("ib")
            parser.add_argument("ib_list", nargs="+", type=int)

        cmp_id = []
        if 'comp' in arg_list:
            parser.add_argument("comp")
            parser.add_argument("cmp_list", nargs="+", type=int)

        if 'internal' in arg_list:
            parser.add_argument("internal")
        parsed_res = parser.parse_args(arg_list)

        try:
            ib_id = parsed_res.ib_list
            cmp_id = parsed_res.cmp_list
        except BaseException:
            pass

        try:
            if parsed_res.internal:
                debug_internal(cmp_id, ib_id)
                return
        except Exception as e:
            pass

        try:
            debug_encode(cmp_id, ib_id)
        except Exception as e:
            print (e)
        return IFCS_SUCCESS

 

    def help(self, args):
        table = PrintTable()
        table.add_row(["Debug Commands Help", "Description"])
        table.add_row(["debug ifcs all", "Displays all IFCS objects with all their attributes and values in JSON"])
        table.add_row(["debug ifcs <api_name>", "Displays all IFCS objects of <api_name> with all their attributes and values in JSON"])
        table.add_row(["debug ifcs <api_name> <handle> stats", "Displays Stats for IFCS object of <api_name> <handle> in JSON"])
        table.set_justification("left")
        table.print_table()
        table.reset_table()
        return
