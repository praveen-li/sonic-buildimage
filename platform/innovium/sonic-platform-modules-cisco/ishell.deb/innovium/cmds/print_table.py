#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

class PrintTable():
    def __init__(self):
        self.rows = []
        self.h_size = 1
        self.just = 'right'

    def reset_table(self):
        del self.rows[:]

    def set_header_size(self, size):
        ''' Method to set header size '''
        self.h_size = size

    def set_justification(self, just):
        ''' Method to set header size '''
        if just not in ['right','left']:
            raise ValueError

        self.just = just

    def add_row(self, row):
        ''' Method to add row to rows'''
        self.rows.append(row)

    def print_table(self, brief=False):
        '''Prints out the table in ascii form'''

        column_widths = None
        for column in self.rows:
            if not column_widths:
                column_widths = [len(str(x)) for x in column]
            else:
                column_widths = [max(x, len(str(y))) for x, y in zip(column_widths, column)]

        # print seperator
        header_seperator = ["-"*w for w in column_widths]
        print "+-{0}-+".format("---".join(list(header_seperator)))

        # print header
        for h in range(0, self.h_size):
            header = self.rows[h]
            if self.just == 'right':
                header_col = [str(c).rjust(w) for w, c in zip(column_widths, header)]
            elif self.just == 'left':
                header_col = [str(c).ljust(w) for w, c in zip(column_widths, header)]
            if brief:
                print "| {0} |".format(" | ".join(list(header_col)))
            else:
                print "| {0} |".format(" : ".join(list(header_col)))

        # print seperator
        if self.h_size:
            print "|-{0}-|".format("---".join(list(header_seperator)))


        # print data
        for columns in self.rows[self.h_size:]:
            if self.just == 'right':
                cols = [str(c).rjust(w) for w, c in zip(column_widths, columns)]
            elif self.just == 'left':
                cols = [str(c).ljust(w) for w, c in zip(column_widths, columns)]
            if brief:
                print "| {0} |".format(" | ".join(list(cols)))
            else:
                print "| {0} |".format(" : ".join(list(cols)))

        # print seperator
        print "+-{0}-+".format("---".join(list(header_seperator)))

        # Clean up after print
        del self.rows[:]

if __name__ == '__main__':

    table = PrintTable()

    # Test 1 Rows are fewer that fields
    table.add_row(['key','value'])
    table.add_row(['ip_addr','ip_mask','l3vni_handle','nexthop'])
    table.add_row(['10.10.10.0,255.255.255.0,0x12345678','0x3c050000'])
    table.print_table()
