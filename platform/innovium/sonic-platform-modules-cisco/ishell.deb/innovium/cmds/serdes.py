
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_ctypes import *
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.node import Node as node
from print_table import PrintTable

# Class implements Ifcs related commands
class Serdes(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'prbs'        : self.prbs,
                         'aapl'        : self.aapl,

                         'mapping'     : self.mapping,
                         'intr'        : self.intr,
                         'test'        : self.test,
                         'tx-eq'       : self.tx_eq,
                         'gainshape1'   : self.gainshape,
                         'gainshape2'   : self.gainshape,
                         'laneswap'    : self.laneswap,

                         'pcie'        : self.pcie,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(Serdes, self).__init__()

        self.list_polynomials = ['prbs7', 'prbs9', 'prbs11', 'prbs13', 'prbs15', 'prbs23', 'prbs31']
        self.list_rates       = ['10g', '25g', '26g', '27g', '28g', '51g', '53g', '54g', '56g']

        self.ringenummap = {}
        self.ringenummap['Ring'] = ['A', 'B']

    def __del__(self):
        return

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError):
            log_dbg(1, "Invalid cmd")
            self.help(args)
            return IFCS_PARAM
        except Exception as ex:
            self.cli.error()
            self.help(args)

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def getIfcsType(self, ifcs_obj_name):
        '''Get IFCS Type Object'''
        log_dbg(1, "In getIfcsType ifcs_obj_name " + ifcs_obj_name)

        if ifcs_obj_name == 'sysport':
            return sysport(self.cli)
        if ifcs_obj_name == 'devport':
            return devport(self.cli)
        if ifcs_obj_name == 'node':
            return node(self.cli)

        return None

    def debug_info(self, args):
        """
        Method to print serdes debug commands
        """
        print("\n Serdes debug info: ")
        pass



    def aapl(self, args):
        """
        Method to execute aapl commands
        """
        def remote_shell_callback(node_id, buff):
            print("%s" % buff)

        callback_type = CFUNCTYPE(
            UNCHECKED(None),
            ifcs_node_id_t,
            ctypes.c_char_p)
        callback = callback_type(remote_shell_callback)

        node_id = self.cli.node_id
        arg_list = shlex.split(args)
        num_args = len(self.arg_list)

        if num_args < 6:
            log_err("Incorrect params passed to the test\n")
            self.help_aapl(args)
            return

        devport = int(arg_list[3])
        lane = int(arg_list[4])

        serdes_info = im_serdes_info_t()
        rc = im_devport_get_serdes_info(self.cli.node_id, devport,
                                        lane, pointer(serdes_info))
        if rc != IFCS_SUCCESS:
            log_err("Failed to get serdes info\n");
            return

        # Extract the aapl command to pass
        # to Aapl lib
        argv = arg_list[5]

        # Append -addr <#> to the command
        addr_opt = " -addr %d:0x%x" % (serdes_info.ring, serdes_info.sbus_addr)
        argv = argv + addr_opt
        arg_list[5] = argv
        argc = (len(shlex.split(argv)))
        argv = (ctypes.c_char_p * argc)()
        argv[:] = arg_list[5].split()

        rc = im_devport_serdes_aapl_cmd(node_id,
                                        devport, lane,
                                        argc, argv, callback)

        if rc != IFCS_SUCCESS:
            log_err("ERR executing AAPL command, rc %d", rc)
            return

        return

    def display(self, devport_info, brief=False):
        '''display ifcs object attributes'''

        table = PrintTable()

        table.add_row(['devport', 'lane', 'isg', 'isg lane', 'ring', 'sbus_addr'])
        for devport in range(len(devport_info)):
            if len(devport_info[devport]) == 6:
                table.add_row([devport_info[devport][0], devport_info[devport][1], devport_info[devport][2],
                               devport_info[devport][3], devport_info[devport][4], devport_info[devport][5]])


        table.print_table(brief)
        table.reset_table()


    def enum_to_str(self, attr_name, attr_val):
        return (self.attrenummap[attr_name][attr_val])

    def mapping(self, args):

        # Get the Devport object/instance
        devport_obj = Devport(self.cli)

        # Parse devport arg
        args_list = args.split()
        devport_arg = args_list.pop(3)

        # To store the lane map info
        devport_info = []
        lane_info = []

        if devport_arg == 'all':
            try:
                all_devport = devport_obj.getAlldevport()
            except BaseException:
                log_err(" Failed to get all devport")
                return

            all_devport = sorted(all_devport)
            for devport, count in zip(all_devport, range(len(all_devport))):
                # Get num lanes and start lane for each devport
                num_lanes = devport_obj.getNumLanes(devport)
                start_lane = devport_obj.getStartLane(devport)

                # For each lane, get serdes info
                for lane_num in range(num_lanes):
                    serdes_info = im_serdes_info_t()

                    rc = im_devport_get_serdes_info(self.cli.node_id, devport,
                                              lane_num, pointer(serdes_info))
                    if rc != IFCS_SUCCESS:
                        log_err("Error getting serdes info for devport %d, rc %d", devport, rc)
                        return
                    # Fill the serdes info
                    lane_info = []
                    lane_info.append(devport)
                    lane_info.append(lane_num)
                    lane_info.append(devport_obj.enum_to_str('serdes_group', serdes_info.isg))
                    lane_info.append(serdes_info.serdes_num)
                    lane_info.append(self.ringenummap['Ring'][serdes_info.ring])
                    sbus_addr = "%d (0x%x)" % (serdes_info.sbus_addr, serdes_info.sbus_addr)
                    lane_info.append(sbus_addr)

                    # Add the lane_info in to devport list
                    devport_info.append(lane_info)


            # Print the data
            self.display(devport_info, brief=True)

            return

        try:
            # For a specific devport
            devport = int(devport_arg)
        except ValueError:
            log_err("Invalid arg for devport: %s" % devport_arg)
            self.help_mapping()
            return

        # Get num lanes and start lane for each devport
        num_lanes = devport_obj.getNumLanes(devport)
        start_lane = devport_obj.getStartLane(devport)

        # For each lane, get serdes info
        for lane_num in range(num_lanes):
            serdes_info = im_serdes_info_t()
            rc = im_devport_get_serdes_info(self.cli.node_id, devport,
                                            lane_num, pointer(serdes_info))
            if rc != IFCS_SUCCESS:
                log_err("Error getting serdes info for devport %d, rc %d", devport, rc)
                return
            # Fill the serdes info
            lane_info = []
            lane_info.append(devport)
            lane_info.append(lane_num)
            lane_info.append(devport_obj.enum_to_str('serdes_group', serdes_info.isg))
            lane_info.append(serdes_info.serdes_num)
            lane_info.append(self.ringenummap['Ring'][serdes_info.ring])
            sbus_addr = "%d (0x%x)" % (serdes_info.sbus_addr, serdes_info.sbus_addr)
            lane_info.append(sbus_addr)

            # Add the lane_info in to devport list
            devport_info.append(lane_info)

        # Print the data
        self.display(devport_info, brief=True)

        return

    def intr(self, args):
        """
        Method to issue generic interrupts to the serdes
        """
        node_id = self.cli.node_id
        arg_list = shlex.split(args)
        num_args = len(self.arg_list)

        if num_args < 7:
            log_err("Incorrect params passed to the test\n")
            self.help_intr(args)
            return

        try:
            devport = int(arg_list[3])
            lane = int(arg_list[4])
            intr_code = int(arg_list[5])
            intr_data = int(arg_list[6])
        except Exception as ex:
            log_err("Error parsing params")
            self.help_intr(args)
            return

        serdes_info = im_serdes_info_t()
        rc = im_devport_get_serdes_info(self.cli.node_id, devport,
                                        lane, pointer(serdes_info))
        if rc != IFCS_SUCCESS:
            log_err("Error getting serdes info for devport %d lane %d, rc %d", devport, lane, rc)
            return

        rsp_data = ctypes.c_uint32()
        rc = im_devport_serdes_intr(node_id, devport, lane,
                                    intr_code, intr_data,
                                    pointer(rsp_data))
        print("ring: %s sbus_addr: %d intr_code %d intr_data %d rsp_data: 0x%x\n"
                 % (self.ringenummap['Ring'][serdes_info.ring],
                    serdes_info.sbus_addr,
                    intr_code,
                    intr_data,
                    rsp_data.value))

        return

    def aapl_test(self, args):
        '''
        AAPL test hook
        '''

        arg_list = shlex.split(args)

        # Read -1 , write - 2
        cmd = int(arg_list[4])
        reg = int(arg_list[5], 16)

        data = ctypes.c_uint32(0)
        if cmd == 2:
            data.value = int(arg_list[6])

        rc = im_devport_serdes_aapl_test(self.cli.node_id, cmd,
                                         reg, pointer(data))

        if rc != IFCS_SUCCESS:
            log_err("PCIe reg access error, cmd %d reg 0x%x data 0x%x rc %d",
                            cmd, reg, data, rc)
            return


    # ------------
    # test command
    # ------------
    def test(self, args):

        sub_cmds = {
                     'aapl'        : self.aapl_test,
                     'help'        : self.help,
                     '?'           : self.help
                   }

        arg_list = shlex.split(args)


        try:
            rc = sub_cmds[arg_list[3]](args)
            return rc
        except (KeyError):
            log_dbg(1, "IfcsKeyError")
            self.help(args)
            return IFCS_PARAM
        except (ValueError):
            log_dbg(1, "IfcsValueError")
            self.help(args)
            return IFCS_INVAL


    def tx_eq(self, args):
        '''
        Print the Tx EQ settings for a given lane
        '''
        num_args = len(self.arg_list)

        if num_args < 5:
            log_err("Incorrect params passed to the test\n")
            self.help_tx_eq(args)
            return

        try:
            devport = int(self.arg_list[3])
            lane = int(self.arg_list[4], 16)
        except Exception as ex:
            log_err("Error parsing params")
            self.help_tx_eq(args)
            return

        # Get the serdes info
        serdes_info = im_serdes_info_t()
        rc = im_devport_get_serdes_info(self.cli.node_id, devport,
                                        lane, pointer(serdes_info))
        if rc != IFCS_SUCCESS:
            log_err("Failed to get serdes info\n");
            return

        tx_pre1 = ctypes.c_int8()
        tx_pre2 = ctypes.c_int8()
        tx_pre3 = ctypes.c_int8()
        tx_attn = ctypes.c_int8()
        tx_post = ctypes.c_int8()

        lane_mask = 0x1 << lane

        # Get the tx settings from h/w
        rc = im_devport_get_tx_eq(self.cli.node_id,
                                  devport,
                                  lane_mask,
                                  pointer(tx_pre1),
                                  pointer(tx_pre2),
                                  pointer(tx_pre3),
                                  pointer(tx_attn),
                                  pointer(tx_post))
        if rc != IFCS_SUCCESS:
            log_err("Failed to get Tx EQ\n");
            return
        table = PrintTable()
        table.add_row(['Ring', 'Sbus', 'Pre1', 'Pre2', 'Pre3', 'Attn', 'Post'])
        table.add_row([self.ringenummap['Ring'][serdes_info.ring], serdes_info.sbus_addr,
                       tx_pre1.value, tx_pre2.value, tx_pre3.value,
                       tx_attn.value, tx_post.value])


        table.print_table()
        table.reset_table()

        return

    def gainshape(self, args):
        '''
        Get/Set the CTLE gainshape settings
        '''
        # Get the Devport object/instance
        devport_obj = Devport(self.cli)

        num_args = len(self.arg_list)

        if num_args < 4:
            log_err("Incorrect params! \n")
            self.help_gainshape(args)
            return

        # Get the current CTLE settings
        devport = int(self.arg_list[3])
        num_lanes = devport_obj.getNumLanes(devport)
        cur_gainshape1 = devport_obj.getRxGainshape1(devport)
        cur_gainshape2 = devport_obj.getRxGainshape2(devport)

        if num_args == 4:
            # display the values returned
            table = PrintTable()
            table.add_row(['Devport', 'Lane', 'Gainshape1', 'Gainshape2'])
            for lane in range(num_lanes):
                table.add_row([devport, lane, cur_gainshape1[lane], cur_gainshape2[lane]])

            table.print_table()
            table.reset_table()

            return

        elif num_args < 5:
            log_err("Incorrect params! \n")
            self.help_gainshape(args)
            return

        lane_mask = self.arg_list[4]
        devport_obj.setLaneMask(devport, lane_mask)
        gainshape = int(self.arg_list[5])

        new_gs = []

        for i in range(num_lanes):
            if ((0x1 << i) & int(lane_mask, 16)):
                new_gs.append(gainshape)
            else:
                if self.arg_list[2] == 'gainshape1':
                    new_gs.append(cur_gainshape1[i])
                elif self.arg_list[2] == 'gainshape2':
                    new_gs.append(cur_gainshape2[i])

        if self.arg_list[2] == 'gainshape1':
            devport_obj.setRxGainshape1(devport, str(new_gs))
        elif self.arg_list[2] == 'gainshape2':
            devport_obj.setRxGainshape2(devport, str(new_gs))

        return

    def laneswap(self, args):
        '''
        Set the laneswap for a given ISG
        '''
        num_args = len(self.arg_list)

        if num_args < 5:
            log_err("Incorrect params passed to the test\n")
            self.help_laneswap(args)
            return

        try:
            isg_num = int(self.arg_list[3])
            laneswap = self.arg_list[4]
        except Exception as ex:
            log_err("Error parsing params")
            self.help_laneswap(args)
            return

        rc = im_devport_serdes_set_laneswap(self.cli.node_id, isg_num, int(laneswap, 16))
        if rc != IFCS_SUCCESS:
            log_err("Failed to set laneswap\n")
            self.help_laneswap(args)

        return

    # ------------
    # test command
    # ------------
    def show(self, args):

        sub_cmds = {
                     'debug-info'  : self.debug_info,
                     'help'        : self.help,
                     '?'           : self.help
                   }

        arg_list = shlex.split(args)
        try:
            rc = sub_cmds[arg_list[3]](args)
            return rc
        except (KeyError):
            log_dbg(1, "IfcsKeyError")
            self.help(args)
            return IFCS_PARAM
        except (ValueError):
            log_dbg(1, "IfcsValueError")
            self.help(args)
            return IFCS_INVAL

    def help(self, args):
        """
        Print help strings
        """
        self.help_prbs(args)
        self.help_aapl(args)

        self.help_mapping(args)
        self.help_intr(args)
        self.help_tx_eq(args)

        self.help_pcie(args)

    def help_aapl(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes aapl <devport> <lane>\"<cmd>\"  - execute AAPL command\n" \
              "  <devport>    - devport number (use 'all' for all devports)\n" \
              "  <lane>       - lane number\n" \
              "  <cmd>        - pre-canned AAPL commands\n"\
              "                 try \"aapl -help\" for list of commands\n"



    def help_mapping(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes mapping <devport> - print serdes mapping info\n" \
              "  <devport>    - devport number (use 'all' for all devports)\n"

    def help_intr(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes intr <devport> <lane> <intr_code> <intr_data>i - Issue interrupt to serdes\n" \
              "  <devport>    - devport number (use 'all' for all devports)\n" \
              "  <lane>       - lane number\n" \
              "  <intr_code>  - interrupt code\n" \
              "  <intr_data>  - interrupt data\n"
    def help_tx_eq(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes tx-eq <devport> <lane> - get serdes tx-eq\n" \
              "  <devport>    - devport number\n" \
              "  <lane>       - lane mask\n\n" \
              "  Note: The attenuation value read back may differ by +/- 3\n" \
              "        depending on the combination of the Tx EQ settings \n"

    def help_gainshape(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes gainshape1 <devport> - get serdes Rx CTLE gainshape\n" \
              "  diagtest serdes gainshape2 <devport> - get serdes Rx CTLE gainshape\n" \
              "  diagtest serdes gainshape1 <devport> <lane> <gainshape> - set serdes CTLE gainshape\n" \
              "  diagtest serdes gainshape2 <devport> <lane> <gainshape> - set serdes CTLE gainshape\n" \
              "  <devport>    - devport number\n" \
              "  <lane>       - lane mask\n" \
              "  <gainshape>       - CTLE gainshape value to set\n" \

    def help_laneswap(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes laneswap <isg-num> <value> - set serdes lane swap\n" \
              "  <isg-num>    - ISG number\n" \
              "  <value>      - Value as string\n"



    def help_pcie(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes pcie <sbus-addr> <aapl cmd> - Run AAPL commands against the PCIe serdes\n" \
              "  <sbus-addr>  - SBus addr of the PCIe serdes lanes (6, 8, 10, 12)\n" \
              "  <cmd>        - pre-canned AAPL commands\n"\
              "                 try \"aapl -help\" for list of commands\n"



    def _get_prbs_poly(self, poly_string):
        ''' Map the PRBS polynomial string input from
            the user to the corresponding enum
        '''
        if poly_string == 'prbs7':
            return IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS7
        if poly_string == 'prbs9':
            return IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS9
        if poly_string == 'prbs11':
            return IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS11
        if poly_string == 'prbs13':
            return IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS13
        if poly_string == 'prbs15':
            return IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS15
        if poly_string == 'prbs23':
            return IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS23
        if poly_string == 'prbs31':
            return IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS31

        return None

    def _get_prbs_rate(self, rate_string):
        ''' Map the PRBS rate string input from
            the user to the corresponding enum
        '''
        if rate_string == '10g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_10_3125GBS
        if rate_string == '25g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_25_78125GBS
        if rate_string == '26g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_26_5625GBS
        if rate_string == '27g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_27_1875GBS
        if rate_string == '28g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_28_125GBS
        if rate_string == '51g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_51_5625GBS
        if rate_string == '53g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_53_125GBS
        if rate_string == '54g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_54_375GBS
        if rate_string == '56g':
            return IFCS_DEVPORT_SERDES_PRBS_RATE_56_25GBS

        return None

    def _prbs_tx_stop(self, args):
        """
        Clean up PRBS setup

        """
        node_id = self.cli.node_id

        self.tx_port       = int(self.arg_list[5])
        self.tx_lane_mask  = int(self.arg_list[6], 16)

        if self.tx_port < 0:
            log_err("Invalid tx port number param\n")
            return

        if self.tx_lane_mask  > 0xFF:
            log_err("Invalid tx lane mask param\n");
            return

        attr_count = 4
        attr_list_p = (ifcs_attr_t * attr_count)()

        attr_list_p[0].id = IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = self.tx_lane_mask

        attr_list_p[1].id = IFCS_DEVPORT_ATTR_PRBS_TX_RATE
        attr_list_p[1].value.u32 = IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED

        attr_list_p[2].id = IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
        attr_list_p[2].value.u32 = IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED

        attr_list_p[3].id = IFCS_DEVPORT_ATTR_PRBS_GENERATOR
        attr_list_p[3].value.u32 = 0

        rc = ifcs_devport_attr_set(node_id, self.tx_port,
                                   attr_count, pointer(attr_list_p));

        if rc != IFCS_SUCCESS:
            print("Failed to stop Tx PRBS")

        print("Tx PRBS stop complete")
        return

    def _prbs_rx_stop(self, args):
        """
        Clean up PRBS setup

        """
        node_id = self.cli.node_id
        self.rx_port       = int(self.arg_list[5])
        self.rx_lane_mask  = int(self.arg_list[6], 16)

        if self.rx_port < 0:
            log_err("Invalid rx port number param\n")
            return

        if self.rx_lane_mask  > 0xFF:
            log_err("Invalid rx lane mask param\n");
            return


        # Stop PRBS Comparator/checker
        attr_count = 5
        attr_list_p = (ifcs_attr_t * attr_count)()

        attr_list_p[0].id = IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = self.rx_lane_mask

        attr_list_p[1].id = IFCS_DEVPORT_ATTR_PRBS_RX_RATE
        attr_list_p[1].value.u32 = IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED

        attr_list_p[2].id = IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
        attr_list_p[2].value.u32 = IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED

        attr_list_p[3].id = IFCS_DEVPORT_ATTR_PRBS_CHECKER
        attr_list_p[3].value.u32 = 0

        attr_list_p[4].id = IFCS_DEVPORT_ATTR_PRBS_COMPARATOR
        attr_list_p[4].value.u32 = 0

        rc = ifcs_devport_attr_set(node_id, self.rx_port,
                                   attr_count, pointer(attr_list_p));

        if rc != IFCS_SUCCESS:
            print("Failed to stop Rx PRBS")
            return
        print("Rx PRBS stop complete")
        return

    def _validate_user_input(self, args):
        '''
        Check for user test params passed
        '''
        check_failed = False
        self.tx_serdes = 0
        self.rx_serdes = 0
        self.lpbk_mode = 0
        self.rx_stop = 0
        self.tx_stop = 0
        self.rx_stop = 0

        self.arg_list  = args.split()
        num_args = len(self.arg_list)

        if num_args < 4:
            log_err("Incorrect params passed to the test\n")
            self.help_prbs(args)
            check_failed = True
            return check_failed

        # Tx or Rx ?
        if self.arg_list[3] == 'tx':
            self.tx_serdes = 1
            if self.arg_list[4] == 'stop':
                self.tx_stop = 1
                return

        elif self.arg_list[3] == 'rx':
            self.rx_serdes = 1
            if self.arg_list[4] == 'stop':
                self.rx_stop = 1
                return
        else:
            log_err("Incorrect param - select tx or rx\n")
            self.help_prbs(args)
            check_failed = True
            return check_failed


        if self.tx_serdes == 1:

            if num_args < 8:
                log_err("Incorrect params passed to the test\n")
                self.help_prbs(args)
                check_failed = True
                return check_failed

            self.tx_port       = int(self.arg_list[4])
            self.tx_lane_mask  = int(self.arg_list[5], 16)
            self.prbs_tx_poly   = self._get_prbs_poly(self.arg_list[6])
            self.prbs_tx_rate   = self._get_prbs_rate(self.arg_list[7])

            print("\n Tx port      : %d" % self.tx_port)
            print(" Tx lane mask   : 0x%x" % self.tx_lane_mask)
            for i in range(8):
                if ((self.tx_lane_mask >> i) & 0x1):
                    lane = i
                    print("Lane: %d" % lane)
                    serdes_info = im_serdes_info_t()
                    rc = im_devport_get_serdes_info(self.cli.node_id, self.tx_port,
                                                    lane, pointer(serdes_info))
                    if rc != IFCS_SUCCESS:
                        log_err("Error getting serdes info for devport %d lane %d, rc %d", self.tx_port, lane, rc)
                        return

                    print(" Sbus addr      : %d (0x%x)" % (serdes_info.sbus_addr,  serdes_info.sbus_addr))
                    print(" Ring           : %d (%s)" %(serdes_info.ring, self.ringenummap['Ring'][serdes_info.ring]))

            print(" Tx polynomial: %s" % self.arg_list[6])
            print(" Tx rate      : %s\n" % self.arg_list[7])

            # Loopback mode check
            if num_args > 8:
                self.lpbk_mode = int(self.arg_list[8])
                if (self.lpbk_mode != 0) and (self.lpbk_mode != 1):
                    log_err("Invalid lpbk mode param\n")
                    check_failed = True
                    self.help_prbs(args)
                    return check_failed

                log("Using internal loopback mode")
                self.rx_port = self.tx_port
                self.rx_lane_mask = self.tx_lane_mask
                self.prbs_rx_poly  = self.prbs_tx_poly
                self.prbs_rx_rate  = self.prbs_tx_rate

                if self.lpbk_mode == 1 and num_args != 10:
                    log_err("Missing delay param\n")
                    check_failed = True
                    self.help_prbs(args)
                    return check_failed

                self.prbs_delay    = int(self.arg_list[9])
            else:
                # Disable by default
                self.lpbk_mode = 0

            if self.tx_port < 0:
                log_err("Invalid tx port number param\n")
                check_failed = True

            if self.tx_lane_mask < 0 or self.tx_lane_mask  > 0xFF:
                log_err("Invalid tx lane mask param\n");
                check_failed = True

            if self.prbs_tx_poly is None:
                log_err("Invalid PRBS polynomial param\n")
                check_failed = True

            if self.prbs_tx_rate is None:
                log_err("Invalid PRBS rate param\n")
                check_failed = True


        elif self.rx_serdes == 1:

            if num_args < 9:
                log_err("Incorrect params passed to the test\n")
                self.help_prbs(args)
                check_failed = True
                return check_failed

            self.rx_port       = int(self.arg_list[4])
            self.rx_lane_mask  = int(self.arg_list[5], 16)
            self.prbs_rx_poly  = self._get_prbs_poly(self.arg_list[6])
            self.prbs_rx_rate  = self._get_prbs_rate(self.arg_list[7])
            self.prbs_delay    = int(self.arg_list[8])

            lane = 0
            serdes_info = im_serdes_info_t()
            rc = im_devport_get_serdes_info(self.cli.node_id, self.rx_port,
                                        lane, pointer(serdes_info))
            if rc != IFCS_SUCCESS:
                log_err("Error getting serdes info for devport %d lane %d, rc %d", devport, lane, rc)
                return



            print("\n Rx port    : %d" % self.rx_port)
            print(" Rx lane mask : 0x%x" % self.rx_lane_mask)
            for i in range(8):
                if ((self.rx_lane_mask >> i) & 0x1):
                    lane = i
                    print("Lane: %d" % lane)
                    serdes_info = im_serdes_info_t()
                    rc = im_devport_get_serdes_info(self.cli.node_id, self.rx_port,
                                                    lane, pointer(serdes_info))
                    if rc != IFCS_SUCCESS:
                        log_err("Error getting serdes info for devport %d lane %d, rc %d", self.rx_port, lane, rc)
                        return

                    print(" Sbus addr      : %d (0x%x)" % (serdes_info.sbus_addr,  serdes_info.sbus_addr))
                    print(" Ring           : %d (%s)" %(serdes_info.ring, self.ringenummap['Ring'][serdes_info.ring]))

            print(" Rx polynomial: %s" % self.arg_list[6])
            print(" Rx rate      : %s" % self.arg_list[7])
            print(" PRBS delay   : %d\n" % self.prbs_delay)

            if self.rx_port < 0:
                log_err("Invalid rx port number param\n")
                check_failed = True

            if self.rx_lane_mask < 0 or self.rx_lane_mask  > 0xFF:
                log_err("Invalid rx lane mask param\n");
                check_failed = True

            if self.prbs_rx_poly is None:
                log_err("Invalid PRBS polynomial param\n")
                check_failed = True

            if self.prbs_rx_rate is None:
                log_err("Invalid PRBS rate param\n")
                check_failed = True

            if self.prbs_delay < 0:
                log_err("Invalid delay param\n")
                check_failed = True

        return check_failed

    def _setup_tx(self, args):

        node_id = self.cli.node_id

        # TODO - fix it
        if self.lpbk_mode == 1:
            # Set internal loopbck mode if selected
            attr_count = 1
            attr_list_p = (ifcs_attr_t * attr_count)()

            #6 Set SerDes ILB
            attr_list_p[0].id = IFCS_DEVPORT_ATTR_PRBS_ILB
            attr_list_p[0].value.u32 = 1;

            rc = ifcs_devport_attr_set (node_id, self.tx_port,
                            attr_count, pointer(attr_list_p));

            if rc != IFCS_SUCCESS:
                print("Failed to set up PRBS ILB")
                return


        #1  Set port ADMIN_STATE to DISABLE on Tx port
        attr_count = 5
        attr_list_p = (ifcs_attr_t * attr_count)()

        attr_list_p[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE
        attr_list_p[0].value.u32 = 0;

        #2  Lane select bitmask - select the lanes to operate on
        attr_list_p[1].id = IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[1].value.u32 = self.tx_lane_mask;

        #3  Set the Tx EQ parameters (optional)
        #   User sets the Tx EQ params prior to
        #   invoking the prbs command

        #4  Set Tx Rate and Tx PRBS polynomial
        attr_list_p[2].id = IFCS_DEVPORT_ATTR_PRBS_TX_RATE
        attr_list_p[2].value.u32 = self.prbs_tx_rate;

        attr_list_p[3].id = IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY
        attr_list_p[3].value.u32 = self.prbs_tx_poly;

        #5  Tx PRBS Generator enable - start PRBS traffic
        attr_list_p[4].id = IFCS_DEVPORT_ATTR_PRBS_GENERATOR
        attr_list_p[4].value.u32 = 1;

        rc = ifcs_devport_attr_set (node_id, self.tx_port,
                        attr_count, pointer(attr_list_p));

        if rc != IFCS_SUCCESS:
            print("Failed to set up Tx PRBS")
            return


        print("Tx PRBS config complete\n")
        return

    def _setup_rx(self, args):
        '''
        Method to setup Rx serdes and run PRBS check
        '''
        node_id = self.cli.node_id

        attr_count = 1
        attr_list_p = (ifcs_attr_t * attr_count)()

        # Disable the port
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_ADMIN_STATE
        attr_list_p[0].value.u32 = 0

        rc = ifcs_devport_attr_set (node_id, self.rx_port,
                                    attr_count, pointer(attr_list_p));

        if rc != IFCS_SUCCESS:
            print("Failed to disable ADMIN STATE Rx port")
            return

        attr_count = 5
        attr_list_p = (ifcs_attr_t * attr_count)()

        # Lane select bitmask - select the lanes to operate on
        attr_list_p[0].id = IFCS_DEVPORT_ATTR_LANE_MASK
        attr_list_p[0].value.u32 = self.rx_lane_mask;

        #6  Set Rx Rate and Rx polynomial
        attr_list_p[1].id = IFCS_DEVPORT_ATTR_PRBS_RX_RATE
        attr_list_p[1].value.u32 = self.prbs_rx_rate;

        attr_list_p[2].id = IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY
        attr_list_p[2].value.u32 = self.prbs_rx_poly;

        #7  Enable Rx serdes
        attr_list_p[3].id = IFCS_DEVPORT_ATTR_PRBS_CHECKER
        attr_list_p[3].value.u32 = 1;

        #8  Start PRBS comparator
        attr_list_p[4].id = IFCS_DEVPORT_ATTR_PRBS_COMPARATOR
        attr_list_p[4].value.u32 = 1;

        rc = ifcs_devport_attr_set (node_id, self.rx_port,
                        attr_count, pointer(attr_list_p));

        if rc != IFCS_SUCCESS:
            print("Failed to set up Rx PRBS")
            return

        #9  User specified delay
        log("Waiting for user specified delay: %d sec" % self.prbs_delay)
        time.sleep(self.prbs_delay)

        #11 Check error counters
        print("Chekcing PRBS error count")

        # Error counter to be read on per lane bassis
        for i in range(8):
            if ((self.rx_lane_mask >> i) & 0x1):
                cur_lane = (0x1 << i)
                attr_count = 1
                attr_list_p = (ifcs_attr_t * attr_count)()

                # Select the lane
                attr_list_p[0].id = IFCS_DEVPORT_ATTR_LANE_MASK
                attr_list_p[0].value.u32 = cur_lane;

                rc = ifcs_devport_attr_set (node_id, self.rx_port,
                                            attr_count, pointer(attr_list_p));

                if rc != IFCS_SUCCESS:
                    print("Failed to set Rx lane")
                    return

                attr = ifcs_attr_t()
                actual_count = ctypes.c_uint32(0)

                attr.id = IFCS_DEVPORT_ATTR_PRBS_ERR_COUNT
                rc = ifcs_devport_attr_get(node_id, self.rx_port, 1, pointer(attr),
                                           pointer(actual_count))
                if rc != IFCS_SUCCESS:
                    print("Failed to get Rx PRBS error count")
                    return

                print("PRBS error count for lane %d: 0x%x\n" % (i, attr.value.u32))

                # TODO - To be enabled once OLY access works */
                #ber = ifcs_flt_t(0)
                #rc = im_devport_serdes_get_ber(self.cli.node_id, self.rx_port,
                #                               i, pointer(ber))
                #if rc != IFCS_SUCCESS:
                #    print("Failed to get Bit Error Rate (BER)")
                #    return

                #print("Bit Error Rate (BER) for lane %d: %0.3e  \n" % (i, ber.value))

    # ------------
    # test command
    # ------------
    def prbs(self, args):

        if self._validate_user_input(args) == True:
            return
        if self.tx_serdes == 1:
            # Tx serdes
            if self.tx_stop == 1:
                self._prbs_tx_stop(args)
                return

            log("Setting up Tx serdes")
            self._setup_tx(args)
        if self.lpbk_mode == 1 or self.rx_serdes == 1:
            # Rx serdes
            if self.rx_stop == 1:
                self._prbs_rx_stop(args)
                return

            log("Setting up Rx serdes")
            self._setup_rx(args)




    def pcie(self, args):
        '''
        Method to swap the PCIe serdes firmware
        '''
        def remote_shell_callback(node_id, buff):
            print("%s" % buff)

        callback_type = CFUNCTYPE(
            UNCHECKED(None),
            ifcs_node_id_t,
            ctypes.c_char_p)
        callback = callback_type(remote_shell_callback)

        node_id = self.cli.node_id
        arg_list = shlex.split(args)
        num_args = len(self.arg_list)

        if num_args < 5:
            log_err("Incorrect params passed to the test\n")
            self.help_pcie(args)
            return

        sbus_addr = int(arg_list[3])
        devport = 0 # dummy
        lane = 0 #dummy

        # Extract the aapl command to pass
        # to Aapl lib
        argv = arg_list[4]

        # Append -addr <#> to the command
        addr_opt = " -addr 0:0x%x" % (sbus_addr)
        argv = argv + addr_opt
        arg_list[4] = argv
        argc = (len(shlex.split(argv)))
        argv = (ctypes.c_char_p * argc)()
        argv[:] = arg_list[4].split()

        rc = im_devport_serdes_aapl_cmd(node_id,
                                        devport, lane,
                                        argc, argv, callback)

        if rc != IFCS_SUCCESS:
            log_err("ERR executing AAPL command, rc %d", rc)
            return

        return



    def help_prbs(self, args):
        print "Usage:: \n" + \
              "  diagtest serdes prbs tx <devport> <lane-mask> <poly> <rate> <lpbk> <delay>\n" \
              " <devport>   - tx devport number\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF)\n" \
              " <poly>          - PRBS polynomial\n" \
              "                    prbs7\n" \
              "                    prbs9\n" \
              "                    prbs11\n" \
              "                    prbs13\n" \
              "                    prbs15\n" \
              "                    prbs23\n" \
              "                    prbs31\n" \
              " <rate>          - PRBS rate\n" \
              "                    10g (10.3125)\n" \
              "                    25g (25.78125)\n" \
              "                    26g (26.5625)\n" \
              "                    27g (27.1875)\n" \
              "                    28g (28.125)\n" \
              "                    51g (51.5625)\n" \
              "                    53g (53.125)\n" \
              "                    54g (54.375)\n" \
              "                    56g (56.25)\n" \
              " ----- Optional params -----\n"\
              " <lpbk>          - Loopback(local/internal) mode\n" \
              "                     - 1: Enable\n" \
              "                     - 0: Disable\n\n" \
              " <delay>         - Time (in sec) to run the PRBS, required if loopback mode is used\n" \
              "\n"\
              "  diagtest serdes prbs rx <devport> <lane-mask> <poly> <rate> <delay>\n" \
              " <devport>   - tx devport number\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF)\n" \
              " <poly>          - PRBS polynomial\n" \
              "                    prbs7\n" \
              "                    prbs9\n" \
              "                    prbs11\n" \
              "                    prbs13\n" \
              "                    prbs15\n" \
              "                    prbs23\n" \
              "                    prbs31\n" \
              " <rate>          - PRBS rate\n" \
              "                    10g (10.3125)\n" \
              "                    25g (25.78125)\n" \
              "                    26g (26.5625)\n" \
              "                    27g (27.1875)\n" \
              "                    28g (28.125)\n" \
              "                    51g (51.5625)\n" \
              "                    53g (53.125)\n" \
              "                    54g (54.375)\n" \
              "                    56g (56.25)\n"\
              " <delay>         - Time (in sec) to run the PRBS\n" \
              "\n"\
              "  diagtest serdes prbs tx stop <devport> <lane-mask>\n" \
              " <devport>   - tx devport number\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF)\n" \
              "\n"\
              "  diagtest serdes prbs rx stop <devport> <lane-mask>\n" \
              " <devport>   - tx devport number\n" \
              " <lane-mask> - tx devport lane number (0x0 - 0xFF)\n"
