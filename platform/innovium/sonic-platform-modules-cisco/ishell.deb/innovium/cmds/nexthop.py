
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from verbosity import *
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *

class Nexthop(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create'           : self.create,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        #super(Nexthop, self).__init__()


    def _create_(
            self,
            nodeId,
            intf=None,
            localDestination=None,
            type=None,
            dmacType=None,
            destMac=None,
            destIpFamily=None,
            destIp=None,
            fwdPolicy=None,
            ctcPolicy=None,
            direction=None,
            evpnMhPeerId=None,
            userCookie=None,
            noDecrementTtl=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            bulkKeyCount=None,
            bulkKeys=None,
            bulkAttrCounts=None,
            bulkAttrs=None,
            bulkStatuses=None,
            ifcsCall=True,
            bulk=False):
        if bulk is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_nexthop_bulk_create(
                    nodeId,
                    NULL,
                    bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkAttrCounts),
                    pointer(bulkAttrs),
                    pointer(bulkStatuses)))
            if expRc:
                assert rc == expRc, "Bulk nexthop creation failed rc expected: {0} actual :{1}".format(
                    expRc, rc)
            else:
                ifcsObj.raiseExpOnFail(rc, "Bulk nexthop  create failed")
        else:

            handle = ifcs_ctypes.ifcs_handle_t()
            if userHandle is not None:
                handle.value = userHandle
            else:
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

            attrList = (ifcs_ctypes.ifcs_attr_t * 14)()
            for index in range(14):
                rc = ifcs_ctypes.ifcs_attr_t_init(pointer(attrList[index]))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            if invalidAttrId is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_MAX_COUNT
                attrList[index].value.u32 = 0
                index += 1
            if intf is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_INTF
                attrList[index].value.handle = intf
                index += 1
            if localDestination is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_LOCAL_DESTINATION
                attrList[index].value.handle = localDestination
                index += 1
            if type is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_TYPE
                attrList[index].value.u32 = type
                index += 1
            if dmacType is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DMAC_TYPE
                attrList[index].value.u32 = dmacType
                index += 1
            if destMac is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DEST_MAC
                attrList[index].value.mac = destMac
                index += 1
            if destIp is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DEST_IP
                attrList[index].value.ip_addr = build_ipaddr_attr(
                    destIpFamily, destIp)
                index += 1
            if fwdPolicy is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_FWD_POLICY
                attrList[index].value.fwd_policy = fwdPolicy
                index += 1
            if ctcPolicy is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_CTC_POLICY
                attrList[index].value.ctc_policy = ctcPolicy
                index += 1
            if direction is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DIRECTION
                attrList[index].value.u32 = direction
                index += 1
            if evpnMhPeerId is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_EVPN_MH_PEER_ID
                attrList[index].value.u8 = evpnMhPeerId
                index += 1
            if userCookie is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_USER_COOKIE
                attrList[index].value.u32 = userCookie
                index += 1
            if noDecrementTtl is not None:
                attrList[index].id = ifcs_ctypes.IFCS_NEXTHOP_ATTR_NO_DECREMENT_TTL
                attrList[index].value.data = noDecrementTtl
                index += 1

            if attrCount is None:
                if index > ifcs_ctypes.IFCS_NEXTHOP_ATTR_MAX_COUNT:
                    attrCount = ifcs_ctypes.IFCS_NEXTHOP_ATTR_MAX_COUNT
                else:
                    attrCount = index
            if ifcsCall is True:
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_nexthop_create(
                        nodeId,
                        pointer(handle),
                        attrCount,
                        attrList))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log("Nexthop creation failed rc: {0}".format(rc))
                else:
                    log("Nexthop handle= " + hex(handle.value))
            return rc
            #ifcsObj.__init__(self, nodeId, self.handle)

    def run_cmd(self, args):
        log_dbg(1, "in Nexthop run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "NexthopKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "NexthopValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def create(self, args):
        log_dbg(1, "in Nexthop create")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Nexthop create', prog='nexthop', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-interface_handle', action="store", help='Interface handle', required=True)
        requiredArgs.add_argument('-dest_mac', action="store", help='Destination MAC address', required=True)
        requiredArgs.add_argument('-local_destination_handle', action="store", help='Local destination handle', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Create parse_args failed')
            return 1
        # Get interface handle
        intf_handle = int(res.interface_handle, 0)

        # Get Dest mac addr
        dest_mac_flds = res.dest_mac.split(":")
        # Prepending 0x to each element in mac addr
        dest_mac_flds = ["0x"+i for i in dest_mac_flds]
        dest_mac = [int(i, 0) for i in dest_mac_flds]
        # Convert list to tuple
        dest_mac = tuple(dest_mac)

        # Get local_dest handle
        local_dest_handle = int(res.local_destination_handle, 0)

        return self._create_(self.cli.node_id,
                             intf=intf_handle,
                             destMac=dest_mac,
                             localDestination=local_dest_handle)

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create', 'Create Nexthop'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        nexthop_help_string = """
Usage::

    Type "config nexthop <command>" followed by -h to see command's sub-options.
"""
        print nexthop_help_string
