
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse
import pdb

from cmdmgr import Command
from verbosity import *
from ctypes import *
from ifcs_ctypes import *
from testutil import pci
from testutil import pkt
from ecmp import *
from nexthop import *
from route_entry import *
from dup_copy_dest_port import *
from collector import *
from collector_set import *
from sflow import *
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *


class Config(Command):
    def __init__(self, cli):
        self.sub_cmds = {'ecmp'            : self.ecmp,
                         'nexthop'         : self.nexthop,
                         'route_entry'     : self.route_entry,
                         'dup_copy_dest_port'     : self.dup_copy_dest_port,
                         'collector'       : self.collector,
                         'collector_set'   : self.collector_set,
                         'sflow'           : self.sflow,
                         'help'            : self.help,
                         '?'               : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []

    def run_cmd(self, args):
        log_dbg(1, "in config run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (KeyError):
            log_dbg(1, "ConfigKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "ConfigValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_ecmp(self, text):
        ecmp = Ecmp(self.cli)
        return [j for j in ecmp.sub_cmds.keys() if j.startswith(text)]

    def complete_nexthop(self, text):
        #pdb.set_trace()
        ecmp = Nexthop(self.cli)
        return [j for j in nexthop.sub_cmds.keys() if j.startswith(text)]

    def ecmp(self, args):
        ecmp_obj = Ecmp(self.cli)
        return ecmp_obj.run_cmd(args)

    def nexthop(self, args):
        nexthop_obj = Nexthop(self.cli)
        return nexthop_obj.run_cmd(args)

    def route_entry(self, args):
        route_entry_obj = Routeentry(self.cli)
        route_entry_obj.run_cmd(args)

    def dup_copy_dest_port(self, args):
        dcdp_obj = DupCopyDestPort(self.cli)
        return dcdp_obj.run_cmd(args)

    def collector(self, args):
        collector_obj = Collector(self.cli)
        return collector_obj.run_cmd(args)

    def collector_set(self, args):
        collector_set_obj = CollectorSet(self.cli)
        return collector_set_obj.run_cmd(args)

    def sflow(self, args):
        sflow_obj = Sflow(self.cli)
        sflow_obj.run_cmd(args)

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['ecmp', 'ECMP commands'])
        table.add_row(['nexthop', 'Nexthop commands'])
        table.add_row(['route', 'Route commands'])
        table.add_row(['dcdp', 'Dcdp commands'])
        table.add_row(['sflow', 'sflow commands'])
        table.add_row(['collector', 'Collector commands'])
        table.add_row(['collectorset', 'Collector Set commands'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        config_help_string = """
Usage::

    Type "config <command> <options>" followed by -h to see command's sub-options.
"""
        print config_help_string
