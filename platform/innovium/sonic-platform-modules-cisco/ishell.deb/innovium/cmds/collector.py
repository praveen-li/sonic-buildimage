#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------


from utils.common_util import build_ipaddr_attr
from utils.common_util import build_attr_list
from utils.common_util import build_fwd_policy_attr_value
from utils.common_util import getHandlesFromIfcsHandleList
from utils.mac_util import mac_addr_to_str
from utils.mac_util import get_ctype_arr
from utils.mac_util import convertMacstrtoarr
import shlex
import time
import random
import copy
import argparse
from cmdmgr import Command
from verbosity import *
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *

class Collector(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create'           : self.create,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []




    def _create_(
            self,
            nodeId,
            collectorType=None,
            direction=None,
            dcdp=None,
            localDestination=None,
            vizTc=None,
            rspanDot1qTpid=None,
            rspanDot1qVlan=None,
            rspanDot1qPri=None,
            rspanDot1qCfi=None,
            destMac=None,
            srcMac=None,
            srcIpFamily=None,
            srcIp=None,
            destIpFamily=None,
            destIp=None,
            dscp=None,
            ttl=None,
            ipv4DfFlag=None,
            dot1qVlan=None,
            sessionId=None,
            truncate=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        attrList = (ifcs_ctypes.ifcs_attr_t * 20)()
        for index in range(20):
            rc = ifcs_ctypes.ifcs_attr_t_init(pointer(attrList[index]))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_COLLECTOR_TYPE
            attrList[index].value.u32 = collectorType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if dcdp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DCDP
            attrList[index].value.handle = dcdp
            index += 1
        if localDestination is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_LOCAL_DESTINATION
            attrList[index].value.handle = localDestination.handle
            index += 1
        if vizTc is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_VIZ_TC
            attrList[index].value.tc = vizTc
            index += 1
        if rspanDot1qTpid is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_TPID
            attrList[index].value.u16 = rspanDot1qTpid
            index += 1
        if rspanDot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_VLAN
            attrList[index].value.u16 = rspanDot1qVlan
            index += 1
        if rspanDot1qPri is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_PRI
            attrList[index].value.u8 = rspanDot1qPri
            index += 1
        if rspanDot1qCfi is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_CFI
            attrList[index].value.u8 = rspanDot1qCfi
            index += 1
        if destMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_MAC
            attrList[index].value.mac = destMac
            index += 1
        if srcMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_MAC
            attrList[index].value.mac = srcMac
            index += 1
        if srcIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_IP
            attrList[index].value.ip_addr = build_ipaddr_attr(
                srcIpFamily, srcIp)
            index += 1
        if destIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_IP
            attrList[index].value.ip_addr = build_ipaddr_attr(
                destIpFamily, destIp)
            index += 1
        if dscp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DSCP
            attrList[index].value.u8 = dscp
            index += 1
        if ttl is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TTL
            attrList[index].value.u8 = ttl
            index += 1
        if ipv4DfFlag is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_IPV4_DF_FLAG
            attrList[index].value.u8 = ipv4DfFlag
            index += 1
        if dot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DOT1Q_VLAN
            attrList[index].value.u16 = dot1qVlan
            index += 1
        if sessionId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SESSION_ID
            attrList[index].value.u16 = sessionId
            index += 1
        if truncate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TRUNCATE
            attrList[index].value.u32 = truncate
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    attrList))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Collector creation failed rc: {0}".format(rc))
            else:
                log("Collector handle= " + hex(handle.value))
            return rc

    def run_cmd(self, args):
        log_dbg(1, "in Sflow run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "SflowKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "SflowValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None




    def create(self, args):
        log_dbg(1, "in collector  create")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Collector create', prog='collector', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-direction', action="store", help='Direction INGRESS | EGRESS', required=True)
        requiredArgs.add_argument('-dcdp', action="store", help='Dcdp handle', required=True)
        requiredArgs.add_argument('-src_mac', action="store", help='Source mac', required=True)
        requiredArgs.add_argument('-dest_mac', action="store", help='Destination mac', required=True)
        requiredArgs.add_argument('-src_ip', action="store", help='Source IP', required=True)
        requiredArgs.add_argument('-dest_ip', action="store", help='Destination IP', required=True)
        requiredArgs.add_argument('-dscp', action="store", help='Dscp value', required=True)
        requiredArgs.add_argument('-ttl', action="store", help='TTL value', required=True)
        requiredArgs.add_argument('-session_id', action="store", help='Session Id value', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Create parse_args failed')
            return 1


        # Get direction
        Dir = str(res.direction)
        if Dir == 'INGRESS':
            direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_INGRESS
        elif Dir == 'EGRESS':
            direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_EGRESS

        # Get dcdp handle
        dcdp_handle = int(res.dcdp, 0)

        # Get dscp
        dscp = int(res.dscp, 0)

        # Get ttl
        ttl = int(res.ttl, 0)

        # Get session id
        session_id  = int(res.session_id, 0)


        # Get src mac addr
        src_mac_flds = res.src_mac.split(":")
        # Prepending 0x to each element in mac addr
        src_mac_flds = ["0x"+i for i in src_mac_flds]
        src_mac = [int(i, 0) for i in src_mac_flds]
        # Convert list to tuple
        src_mac = tuple(src_mac)

        # Get Dest mac addr
        dest_mac_flds = res.dest_mac.split(":")
        # Prepending 0x to each element in mac addr
        dest_mac_flds = ["0x"+i for i in dest_mac_flds]
        dest_mac = [int(i, 0) for i in dest_mac_flds]
        # Convert list to tuple
        dest_mac = tuple(dest_mac)

        # Get src ip
        src_ip_l = res.src_ip.split(".")
        src_ip_l = [int(i, 0) for i in src_ip_l]
        # Get dest ip
        dest_ip_l = res.dest_ip.split(".")
        dest_ip_l = [int(i, 0) for i in dest_ip_l]

        # Set src ip family
        if '.' in res.src_ip:
            srcIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        else:
            srcIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6
        # Set dest ip family
        if '.' in res.dest_ip:
            destIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        else:
            destIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6

        # Convert IP and Mask to 32bit values
        src_ip = src_ip_l[0] << 24 | src_ip_l[1] << 16 | src_ip_l[2] << 8 | src_ip_l[3]
        dest_ip = dest_ip_l[0] << 24 | dest_ip_l[1] << 16 | dest_ip_l[2] << 8 | dest_ip_l[3]

        collectorType = ifcs_ctypes.IFCS_COLLECTOR_TYPE_SFLOW

        return self._create_(self.cli.node_id, collectorType=collectorType,direction=direction,
                             dcdp=dcdp_handle, srcMac=src_mac, destMac=dest_mac,
                             srcIpFamily=srcIpFamily, destIpFamily=destIpFamily, srcIp=src_ip, destIp=dest_ip,
                             dscp=dscp, ttl=ttl, sessionId=session_id)



    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create', 'Create Collector'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        collector_help_string = """
Usage::

    Type "config collector <command>" followed by -h to see command's sub-options.
"""
        print collector_help_string
