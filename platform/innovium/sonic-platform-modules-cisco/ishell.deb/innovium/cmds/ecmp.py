
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse
import pdb

from cmdmgr import Command
from verbosity import *
from ctypes import *
from ifcs_ctypes import *
from testutil import pci
from testutil import pkt
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *

class Ecmp(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create'           : self.create,
                         'add_members'      : self.add_members,
                         'remove_members'   : self.remove_members,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        #super(Ecmp, self).__init__()


    def _add_members_(
            self,
            ecmp_handle,
            memberList,
            attrList=None,
            memberCount=None,
            attrCount=None,
            expRc=None,
            customLog=None):

        memberhandleList = (ifcs_handle_t * len(memberList))()
        for index in xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            if memberList is not None:
                memberCount = len(memberList)
            else:
                memberCount = 0
        if attrCount is None:
            if attrList is not None:
                attrCount = len(attrList)
            else:
                attrCount = 0
        if attrList is None:
            attrList = 0
        #pdb.set_trace()
        rc = IFCS_STATUS_REASON(
            ifcs_ecmp_member_add(
                self.cli.node_id,
                ecmp_handle,
                memberCount,
                memberhandleList,
                attrCount,
                attrList))
        if rc != IFCS_SUCCESS:
            log("Ecmp member add failed rc: {0}".format(rc))
        else:
            log("Ecmp member add successful")
        return rc


    def _remove_members_(
            self,
            ecmp_handle,
            memberList,
            memberCount=None,
            expRc=None,
            customLog=None):

        memberhandleList = (ifcs_handle_t * len(memberList))()
        for index in xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            memberCount = len(memberList)
        rc = IFCS_STATUS_REASON(
            ifcs_ecmp_member_remove(
                self.cli.node_id,
                ecmp_handle,
                memberCount,
                memberhandleList))
        if rc != IFCS_SUCCESS:
            log("Ecmp member remove failed rc: {0}".format(rc))
        else:
            log("Ecmp member remove successful")
        return rc


    def _create_(self,
                          nodeId,
                          type=None, numberOfSlots=None, groupSize=None,
                          userHandle=None,
                          expRc=None,
                          invalidAttrId=None,
                          attrCount=None,
                          bulkKeyCount=None, bulkKeys=None,
                          bulkAttrCounts=None,
                          bulkAttrs=None,
                          bulkStatuses=None,
                          ifcsCall=True,
                          bulk=False):
        if bulk is True:
            rc = IFCS_STATUS_REASON(
                ifcs_ecmp_bulk_create(
                    nodeId,
                    NULL,
                    bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkAttrCounts),
                    pointer(bulkAttrs),
                    pointer(bulkStatuses)))
            if expRc:
                assert rc == expRc, "Bulk ecmp creation failed rc expected: {0} actual :{1}".format(
                    expRc, rc)
            else:
                log_err("Bulk Ecmp create failed rc = " + rc)
                return
        else:
            handle = ifcs_handle_t()
            if userHandle is not None:
                handle.value = userHandle
            else:
                handle.value = IFCS_NULL_HANDLE

            attrList = (ifcs_attr_t * 6)()
            for index in range(6):
                rc = ifcs_attr_t_init(pointer(attrList[index]))
                assert rc == IFCS_SUCCESS
            index = 0

            if invalidAttrId is not None:
                attrList[index].id = IFCS_ECMP_ATTR_MAX_COUNT
                attrList[index].value.u32 = 0
                index += 1
            if type is not None:
                attrList[index].id = IFCS_ECMP_ATTR_TYPE
                attrList[index].value.u32 = type
                index += 1
            if numberOfSlots is not None:
                attrList[index].id = IFCS_ECMP_ATTR_NUMBER_OF_SLOTS
                attrList[index].value.u32 = numberOfSlots
                index += 1
            if groupSize is not None:
                attrList[index].id = IFCS_ECMP_ATTR_GROUP_SIZE
                attrList[index].value.u32 = groupSize
                index += 1

            if attrCount is None:
                if index > IFCS_ECMP_ATTR_MAX_COUNT:
                    attrCount = IFCS_ECMP_ATTR_MAX_COUNT
                else:
                    attrCount = index
            if ifcsCall is True:
                rc = IFCS_STATUS_REASON(
                    ifcs_ecmp_create(
                        nodeId,
                        pointer(handle),
                        attrCount,
                        attrList))
                if rc != IFCS_SUCCESS:
                    log("Ecmp creation failed rc: {0}".format(rc))
                else:
                    log("Ecmp handle= " + hex(handle.value))
            return rc

            #super(Ecmp, self).__init__()

    def run_cmd(self, args):
        log_dbg(1, "in Ecmp run")
        #pdb.set_trace()
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "EcmpKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "EcmpValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        #pdb.set_trace()
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def create(self, args):
        log_dbg(1, "in Ecmp create")
        return self._create_(self.cli.node_id)

    def add_members(self, args):
        log_dbg(1, "in Ecmp add_members")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='ECMP add_members', prog='ecmp', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-ecmp_handle', action="store", help='ECMP handle', required=True)
        requiredArgs.add_argument('-members', action="store", help='Comma separated handles', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Add_members parse_args failed')
            return 1
        ecmp_handle = int(res.ecmp_handle, 0)
        members = res.members.split(",")
        members = [int(i, 0) for i in members]
        return self._add_members_(ecmp_handle, members)

    def remove_members(self, args):
        log_dbg(1, "in Ecmp remove_members")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='ECMP remove_members', prog='ecmp', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-ecmp_handle', action="store", help='ECMP handle', required=True)
        requiredArgs.add_argument('-members', action="store", help='Comma separated handles', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Remove_members parse_args failed')
            return 1
        ecmp_handle = int(res.ecmp_handle, 0)
        members = res.members.split(",")
        members = [int(i, 0) for i in members]
        return self._remove_members_(ecmp_handle, members)

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create', 'Create ECMP group'])
        table.add_row(['add_members', 'Add members to an ECMP group'])
        table.add_row(['remove_members', 'Remove members from an ECMP group'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        ecmp_help_string = """
Usage::

    Type "config ecmp <command>" followed by -h to see command's sub-options.
"""
        print ecmp_help_string
        #pdb.set_trace()
