#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2020
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

import shlex
import time
import random
import copy
import argparse
import sys
import re
ifcs_ctypes = sys.modules['ifcs_ctypes']
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from testutil import pci
from testutil import pkt
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *

class VizBDC(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create_instance'           : self.create_instance,
                         'delete_instance'           : self.delete_instance,
                         'help'                      : self.help,
                         '?'                         : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        self.bdc_collector_set_handle = 0
        self.bdc_collector_handle = 0
        self.bdc_visibility_sampler_handle = 0
        self.bdc_policy = None
        self.handle = 0
        self.nodeId = 0
        self.deviceType = -1
        self.switchId = -1
        self.cos_queue_ids = []
        self.sysPort = None

    def _get_sysport_from_devport_(
            self,
            nodeId,
            dev_port,
            userHandle=None):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        actual_count = c_int()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        rc = ifcs_ctypes.ifcs_devport_attr_get(nodeId, dev_port, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Sysport get unsuccessful")
            return rc

        rc = ifcs_ctypes.ifcs_attr_t_value_handle_get(pointer(out_attr), pointer(handle))
        if rc:
            log("Sysport handle get unsuccessful")
            return rc

        self.sysPort = int(handle.value)
        #log("BDC Collector sysport handle= " + hex(handle.value))
        return rc

   # build ip address from family,address
    def build_ipaddr(self, ipAddr):
       ipAddrStruct = ifcs_ctypes.ifcs_ip_address_t()
       ipAddrStruct.addr_family = 0
       ipAddrStruct.addr.ipv4 = ipAddr
       return ipAddrStruct



    def _node_bdc_enable_(
            self,
            nodeId,
            enable=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        maxAttr = int(ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if enable is not None:
            attrList[index].id = ifcs_ctypes.IFCS_NODE_ATTR_VIZ_BDC_ENABLE
            attrList[index].value.data = enable
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_node_attr_set(
                    nodeId,
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            enable_str = "enable" if enable == ifcs_ctypes.IFCS_BOOL_TRUE else "disable"
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("BDC {0} in node failed rc: {1}".format(enable_str, rc))
            else:
                pass
                #log("BDC {0} in node success rc: {1}".format(enable_str, rc))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _collector_create_(
            self,
            nodeId,
            collectorType=None,
            direction=None,
            dcdp=None,
            localDestination=None,
            vizTc=None,
            rspanDot1qTpid=None,
            rspanDot1qVlan=None,
            rspanDot1qPri=None,
            rspanDot1qCfi=None,
            destMac=None,
            srcMac=None,
            srcIpFamily=None,
            srcIp=None,
            destIpFamily=None,
            destIp=None,
            dscp=None,
            ttl=None,
            ipv4DfFlag=None,
            dot1qVlan=None,
            sessionId=None,
            truncate=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_COLLECTOR_TYPE
            attrList[index].value.u32 = collectorType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if dcdp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DCDP
            attrList[index].value.handle = dcdp
            index += 1
        if localDestination is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_LOCAL_DESTINATION
            attrList[index].value.handle = localDestination
            index += 1
        if vizTc is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_VIZ_TC
            attrList[index].value.tc = vizTc
            index += 1
        if rspanDot1qTpid is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_TPID
            attrList[index].value.u16 = rspanDot1qTpid
            index += 1
        if rspanDot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_VLAN
            attrList[index].value.u16 = rspanDot1qVlan
            index += 1
        if rspanDot1qPri is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_PRI
            attrList[index].value.u8 = rspanDot1qPri
            index += 1
        if rspanDot1qCfi is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_CFI
            attrList[index].value.u8 = rspanDot1qCfi
            index += 1
        if destMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_MAC
            attrList[index].value.mac = destMac
            index += 1
        if srcMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_MAC
            attrList[index].value.mac = srcMac
            index += 1
        if srcIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_IP
            attrList[index].value.ip_addr = self.build_ipaddr(srcIp)
            index += 1
        if destIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_IP
            attrList[index].value.ip_addr = self.build_ipaddr(destIp)
            index += 1
        if dscp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DSCP
            attrList[index].value.u8 = dscp
            index += 1
        if ttl is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TTL
            attrList[index].value.u8 = ttl
            index += 1
        if ipv4DfFlag is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_IPV4_DF_FLAG
            attrList[index].value.u8 = ipv4DfFlag
            index += 1
        if dot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DOT1Q_VLAN
            attrList[index].value.u16 = dot1qVlan
            index += 1
        if sessionId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SESSION_ID
            attrList[index].value.u16 = sessionId
            index += 1
        if truncate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TRUNCATE
            attrList[index].value.u32 = truncate
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("BDC Collector creation failed rc: {0}".format(rc))
            else:
                self.bdc_collector_handle = int(handle.value)
                #log("BDC Collector handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _collector_set_create_(
            self,
            nodeId,
            collectorSetType=None,
            direction=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorSetType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_COLLECTOR_SET_TYPE
            attrList[index].value.u32 = collectorSetType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("BDC CollectorSet creation failed rc: {0}".format(rc))
            else:
                self.bdc_collector_set_handle = int(handle.value)
                #log("BDC CollectorSet handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _add_members_(
            self,
            collector_set_handle,
            memberList,
            attrList=None,
            memberCount=None,
            attrCount=None,
            expRc=None,
            customLog=None,
            ifcsCall=True):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            if memberList is not None:
                memberCount = len(memberList)
            else:
                memberCount = 0
        if attrCount is None:
            if attrList is not None:
                attrCount = len(attrList)
            else:
                attrCount = 0
        if not attrList:
            attrList = None
        if not ifcsCall:
            return ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_add(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t),
                attrCount,
                attrList))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("BDC CollectorSet member add failed rc: {0}".format(rc))
        else:
            pass
        #    log("BDC CollectorSet member add successful")
        return rc

    def _visibility_sampler_create_(
            self,
            nodeId,
            type=None,
            mode=None,
            probabilisticCaptureRate=None,
            microburstCaptureAvgPacketRate=None,
            microburstCaptureMaxPacketsPerBurst=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if type is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_TYPE
            attrList[index].value.u32 = type
            index += 1
        if mode is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MODE
            attrList[index].value.u32 = mode
            index += 1
        if probabilisticCaptureRate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_PROBABILISTIC_CAPTURE_RATE
            attrList[index].value.u32 = probabilisticCaptureRate
            index += 1
        if microburstCaptureAvgPacketRate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MICROBURST_CAPTURE_AVG_PACKET_RATE
            attrList[index].value.u32 = microburstCaptureAvgPacketRate
            index += 1
        if microburstCaptureMaxPacketsPerBurst is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MICROBURST_CAPTURE_MAX_PACKETS_PER_BURST
            attrList[index].value.u32 = microburstCaptureMaxPacketsPerBurst
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_visibility_sampler_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Visibility Sampler creation failed rc: {0}".format(rc))
            else:
                self.bdc_visibility_sampler_handle = int(handle.value)
                #log("Visibility Sampler handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _bdc_policy_create_(
            self,
            collector_set_handle,
            visibility_sampler_handle,
            ifcsCall=True):

        if self.bdc_policy != None:
            log("BDC policy already exists")
            return ifcs_ctypes.IFCS_INVAL
        self.bdc_policy = ifcs_ctypes.ifcs_bdc_policy_t()

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_init(
                    pointer(self.bdc_policy)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                self.bdc_policy = None
                log("BDC policy creation failed rc: {0}".format(rc))
                return rc
            else:
                pass
                #log("BDC policy creation success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_collector_set_set(
                    pointer(self.bdc_policy),
                    collector_set_handle))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Adding Collector Set to BDC policy failed rc: {0}".format(rc))
                return rc
            else:
                pass
                #log("Adding Collector Set to BDC policy success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_visibility_sampler_set(
                    pointer(self.bdc_policy),
                    visibility_sampler_handle))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Adding Visibility Sampler to BDC policy failed rc: {0}".format(rc))
                return rc
            else:
                pass
                #log("Adding Visibility Sampler to BDC policy success rc: {0}".format(rc))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _bdc_policy_queue_id_enable_(
            self,
            nodeId,
            policy=None,
            enable=None,
            queue=[],
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        maxAttr = int(ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if policy is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_BDC_POLICY
            attrList[index].value.bdc_policy = policy
            index += 1
        if enable is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_BDC_ENABLE
            attrList[index].value.data = enable
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_SUCCESS
            for queue_id in queue:
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_queue_id_attr_set(
                        nodeId,
                        queue_id,
                        attrCount,
                        compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    if enable == ifcs_ctypes.IFCS_BOOL_TRUE:
                        log("Setup BDC Policy on Class of Service Queue {0} and enable BDC failed: {1}".format(queue_id, rc))
                    else:
                        log("Disable BDC on Class of Service Queue {0} failed: {1}".format(queue_id, rc))
                    return rc
                else:
                    pass
                    #log("Setup BDC Policy on Class of Service Queue {0} and enable {1} BDC passed: {2}".format(queue_id, enable, rc))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _remove_members_(
            self,
            collector_set_handle,
            memberList,
            memberCount=None,
            expRc=None,
            customLog=None,
            ifcsCall=True):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            memberCount = len(memberList)
        if not ifcsCall:
            return ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_remove(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("BDC CollectorSet member remove failed rc: {0}".format(rc))
        else:
            pass
            #log("BDC CollectorSet member remove successful")
        return rc

    def run_cmd(self, args):
        log_dbg(1, "in BDC run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "VizBDCKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "VizBDCValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def _parse_queue_ids_(
            self,
            queue_ids):
        # Supported formats 1 | 0,4,6 | 1-4
        try:
            queue_ids = queue_ids.strip()
            if re.match(r'^\d$', queue_ids):
                queue_ids = [queue_ids]
            elif re.match(r'^(\d,)+\d$', queue_ids):
                queue_ids = queue_ids.split(',')
            elif re.match(r'^\d-\d$', queue_ids):
                queue_ids = queue_ids.split('-')
                queue_ids = compat_listrange(int(queue_ids[0]), int(queue_ids[1]) + 1)
            else:
                return None
            return [int(x) for x in queue_ids]
        except:
            return None

    def create_instance(self, args):
        log_dbg(1, "in BDC collector instance")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='BDC Collector create', prog='config bdc create_instance', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-smac', action="store", help='Source mac. Format: AA:BB:CC:DD:EE:FF', required=True)
        requiredArgs.add_argument('-dmac', action="store", help='Destination mac. Format: AA:BB:CC:DD:EE:FF', required=True)
        requiredArgs.add_argument('-vlan', action="store", help='Vlan id (0-4095)', required=False)
        requiredArgs.add_argument('-sip', action="store", help='Source IPv4 address. Format: dot-decimal', required=True)
        requiredArgs.add_argument('-dip', action="store", help='Destination IPv4 address. Format: dot-decimal', required=True)
        requiredArgs.add_argument('-dscp', action="store", help='DSCP value (0-44)', required=True, type=int)
        requiredArgs.add_argument('-ttl', action="store", help='TTL value (1-255)', required=True, type=int)
        requiredArgs.add_argument('-dev_port', action="store", help='Device port (0-167)', required=True, type=int)
        requiredArgs.add_argument('-tc', action="store", help='Traffic Class for BDC packets (0-15)', required=True, type=int)
        requiredArgs.add_argument('-df', action="store", help='Do not fragment flag in IPv4 header during BDC (0 | 1)', required=True, type=int)
        requiredArgs.add_argument('-queue', action="store", help='One or more Class of Service Queues (0-7). Specify one queue or comma separated queues  or range of queues. Examples: 1 | 0,4,6 | 1-4', required=True)
        requiredArgs.add_argument('-sampler_mode', action="store", help='Visibility sampler mode 0(Capture All) | 1(Probabilistic Capture) | 2(Microburst Capture)', required=True, type=int, choices=compat_listrange(3), default=1)
        requiredArgs.add_argument('-capture_rate', action="store", help='Capture rate for visibility sampler expressed as 1 in every N packets, where this attribute specifies N (10-16777215). Applicable only when visibility sampler mode is Probabilistic Capture.', required=False, type=int, default=10000)
        requiredArgs.add_argument('-avg_packet_rate', action="store", help='Avg rate (packets/sec) of packets to be captured (122-100000). Applicable only when visibility sampler mode is Microburst Capture.', required=False, type=int, default=8192)
        requiredArgs.add_argument('-max_packets_per_burst', action="store", help="Maximum number of packets to be captured per microburst event (64-16384). Applicable only when visibility sampler mode is Microburst Capture. Guidance for specifying value: Value should be >= avg_packet_rate * node's attribute update_interval_c * (1/1000000). Supported values are 64, 128, 256, 512, 1K, 2K...16K", required=False, type=int, default=256)

        try:
            res = parser.parse_args(self.arg_list)
        except:
            if len(self.arg_list) == 1 and self.arg_list[0] == '-h':
                return 0
            log('Missing arguments or invalid arguments provided')
            return 1

        if self.bdc_collector_set_handle != 0:
            log("BDC Collector is already exist")
            return ifcs_ctypes.IFCS_INVAL
        self.cos_queue_ids = [];

        # Get dscp
        dscp = int(res.dscp)
        # Get ttl
        ttl = int(res.ttl)
        # Get dev_port
        dev_port = int(res.dev_port)
        # Get traffic class
        viz_tc = int(res.tc)
        # Get IPv4 do not fragment flag
        ipv4_df_flag = int(res.df)
        # Get Class of Service Queue 1
        queue_ids = self._parse_queue_ids_(res.queue)
        if not queue_ids:
            log('Invalid value for -queue argument')
            return ifcs_ctypes.IFCS_INVAL
        self.cos_queue_ids = queue_ids;
        # Get visibility sampler mode
        try:
            sampler_mode = int(res.sampler_mode)
            sampler_mode = [ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_CAPTURE_ALL,
                            ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_PROBABILISTIC_CAPTURE,
                            ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_MICROBURST_CAPTURE][sampler_mode]
        except:
            log('Invalid value for -sampler_mode argument')
            return ifcs_ctypes.IFCS_INVAL
        # Get capture rate
        if sampler_mode == ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_PROBABILISTIC_CAPTURE:
            capture_rate = int(res.capture_rate)
        else:
            capture_rate = None
        # Get Microburst Capture mode parameters
        if sampler_mode == ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_MICROBURST_CAPTURE:
            avg_packet_rate = int(res.avg_packet_rate)
            max_packets_per_burst = int(res.max_packets_per_burst)
        else:
            avg_packet_rate = None
            max_packets_per_burst = None
        # Get src mac addr
        src_mac_flds = res.smac.split(":")
        # Prepending 0x to each element in mac addr
        src_mac_flds = ["0x"+i for i in src_mac_flds]
        src_mac = [int(i, 0) for i in src_mac_flds]
        # Convert list to tuple
        src_mac = tuple(src_mac)
        # Get Dest mac addr
        dest_mac_flds = res.dmac.split(":")
        # Prepending 0x to each element in mac addr
        dest_mac_flds = ["0x"+i for i in dest_mac_flds]
        dest_mac = [int(i, 0) for i in dest_mac_flds]
        # Convert list to tuple
        dest_mac = tuple(dest_mac)
        # Get src ip
        src_ip_l = res.sip.split(".")
        src_ip_l = [int(i, 0) for i in src_ip_l]
        # Get dest ip
        dest_ip_l = res.dip.split(".")
        dest_ip_l = [int(i, 0) for i in dest_ip_l]
        srcIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        destIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        # Convert IP and Mask to 32bit values
        src_ip = src_ip_l[0] << 24 | src_ip_l[1] << 16 | src_ip_l[2] << 8 | src_ip_l[3]
        dest_ip = dest_ip_l[0] << 24 | dest_ip_l[1] << 16 | dest_ip_l[2] << 8 | dest_ip_l[3]
        collectorType = ifcs_ctypes.IFCS_COLLECTOR_TYPE_BDC

        actual_count = c_int()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE_TYPE
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Device Type get unsuccessful")
            return rc

        self.deviceType = out_attr.value.u32

        actual_count = c_int()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_SWITCH_ID
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Switch id get unsuccessful")
            return rc

        self.switchId = out_attr.value.u32

        # Get sysport
        rc  = self._get_sysport_from_devport_(self.cli.node_id, dev_port)
        if rc:
            return rc

        # self._node_bdc_enable_() cannot be successfully invoked after enabling node.
        # Enable BDC in the config.yaml file of the node by including viz_bdc_enable: "1".
        # An example is below.
        #
        # ifcs:
        #   options:
        #     log_level: "warn"
        # nodes:
        # - node_id: "0"
        #   options:
        #     sku: "configs/sku/innovium.77700.model"
        #     ecmp_hierarchical_enable: "1"
        #     viz_bdc_enable: "1"

        # Make sure BDC is enabled in node.
        actual_count = c_int()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_VIZ_BDC_ENABLE
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("BDC enable flag get unsuccessful")
            return rc
        if out_attr.value.data != ifcs_ctypes.IFCS_BOOL_TRUE:
            log('BDC attribute is not enabled in node. It must be set before enabling node. The option to use in yaml is viz_bdc_enable: "1"')
            return ifcs_ctypes.IFCS_INVAL

        # Create BDC collector
        try:
            rc = self._collector_create_(self.cli.node_id, collectorType=collectorType,
                                         srcMac=src_mac, destMac=dest_mac,
                                         srcIpFamily=srcIpFamily, destIpFamily=destIpFamily,
                                         srcIp=int(src_ip), destIp=int(dest_ip),
                                         dscp=dscp, ttl=ttl, localDestination=self.sysPort,
                                         dot1qVlan = (int(res.vlan) & 0xFFF if res.vlan is not None else None),
                                         vizTc=viz_tc, ipv4DfFlag=ipv4_df_flag)
        except Exception as e:
            rc = ifcs_ctypes.IFCS_DRIVER_ERROR
            log(e.message)
        if rc:
            log("BDC Collector create failed rc: {0}".format(rc))
            return rc

        rc  =  self._collector_set_create_(self.cli.node_id, collectorSetType=ifcs_ctypes.IFCS_COLLECTOR_TYPE_BDC)

        if rc:
            log("BDC Collector set failed rc: {0}".format(rc))
            return rc

        rc  = self._add_members_(self.bdc_collector_set_handle, [self.bdc_collector_handle])
        if rc:
            return rc

        # Create Visibility Sampler and configure it to sample every packet
        rc  =  self._visibility_sampler_create_(self.cli.node_id,
                                                type=ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_TYPE_BDC,
                                                mode=sampler_mode,
                                                probabilisticCaptureRate=capture_rate,
                                                microburstCaptureAvgPacketRate=avg_packet_rate,
                                                microburstCaptureMaxPacketsPerBurst=max_packets_per_burst)
        if rc:
            return rc

        # Create a BDC policy with the Visibility Sampler and Collector Set
        rc  =  self._bdc_policy_create_(collector_set_handle=self.bdc_collector_set_handle,
                                        visibility_sampler_handle=self.bdc_visibility_sampler_handle)
        if rc:
            return rc

        # Setup BDC Policy on Class of Service Queue 1 and enable BDC
        rc  =  self._bdc_policy_queue_id_enable_(self.cli.node_id,
                                                policy=self.bdc_policy,
                                                enable=ifcs_ctypes.IFCS_BOOL_TRUE,
                                                queue=queue_ids)
        return rc

    def _bdc_policy_delete_(
            self,
            ifcsCall=True):

        self.bdc_policy = ifcs_ctypes.ifcs_bdc_policy_t()

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_init(
                    pointer(self.bdc_policy)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                self.bdc_policy = None
                log("BDC policy creation failed rc: {0}".format(rc))
                return
            else:
                pass
                #log("BDC policy creation success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_collector_set_set(
                    pointer(self.bdc_policy),
                    ifcs_ctypes.IFCS_NULL_HANDLE))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Remove Collector Set from BDC policy failed rc: {0}".format(rc))
            else:
                pass
                #log("Remove Collector Set from BDC policy success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_visibility_sampler_set(
                    pointer(self.bdc_policy),
                    ifcs_ctypes.IFCS_NULL_HANDLE))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Remove Visibility Sampler to BDC policy failed rc: {0}".format(rc))
            else:
                pass
                #log("Remove Visibility Sampler to BDC policy success rc: {0}".format(rc))

    def _collector_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False,
            ifcsCall=True):
        if bulk is True and ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector Delete failed')
        elif ifcsCall is True:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector Delete failed')

    def _collector_set_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False,
            ifcsCall=True):
        if bulk is True and ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector_set Delete failed')
        elif ifcsCall is True:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector_set Delete failed')

    def _visibility_sampler_delete_(
            self,
            expRc=None,
            customLog=None,
            ifcsCall=True):
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_visibility_sampler_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'Visibility Sampler Delete failed')

    def delete_instance(self,args):
        self.nodeID = self.cli.node_id
        if self.bdc_policy is not None:
            # Disable the BDC on Class of Service Queue
            self._bdc_policy_queue_id_enable_(self.cli.node_id,
                                              enable=ifcs_ctypes.IFCS_BOOL_FALSE,
                                              queue=self.cos_queue_ids)
            # Remove the BDC policy from the given Class of Service
            self._bdc_policy_delete_()
            self._bdc_policy_queue_id_enable_(self.cli.node_id,
                                              policy=self.bdc_policy,
                                              queue=self.cos_queue_ids)
        self.bdc_policy = None
        self.cos_queue_ids = []
        # Delete Visibility Sampler
        if self.bdc_visibility_sampler_handle != 0:
            self.handle = self.bdc_visibility_sampler_handle
            self._visibility_sampler_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        self.bdc_visibility_sampler_handle = 0
        # Remove collector from collector set and delete collector set
        if self.bdc_collector_set_handle != 0:
            self._remove_members_(self.bdc_collector_set_handle, [self.bdc_collector_handle])
            self.handle = self.bdc_collector_set_handle
            self._collector_set_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        # Delete collector
        if self.bdc_collector_handle != 0:
            self.handle = self.bdc_collector_handle
            self._collector_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        self.bdc_collector_set_handle = 0
        self.bdc_collector_handle = 0
        self.handle = 0
        self.sysPort = None
        # May disable BDC in node
        # self._node_bdc_enable_() cannot be successfully invoked after enabling node.
        return 0

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create_instance', 'Create BDC instance'])
        table.add_row(['delete_instance', 'Delete BDC instance'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        telemetry_bdc_help_string = """
Usage::

    Type "config bdc <command>" followed by -h to see command's sub-options.
"""
        log(telemetry_bdc_help_string)
