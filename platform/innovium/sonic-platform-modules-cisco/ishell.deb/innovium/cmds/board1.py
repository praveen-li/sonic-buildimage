#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------


import shlex
from cmdmgr import Command
from verbosity import *
from ctypes import *
from ifcs_ctypes import *
from board1_ctypes import *

# Class implements Cpld related command
class Board1(Command):
    def __init__(self, cli):
        self.sub_cmds = {'cpld_open'       : self.open,
                         'cpld_close'      : self.close,
                         'cpld_scan'       : self.scan,
                         'sfp'             : self.sfp,
                         'cpld_read'       : self.read,
                         'cpld_write'      : self.write,
                         'cpld_test'       : self.cpld_test,
                         'bmc_status'      : self.bmc_status,
                         'vrm'             : self.vrm,
                         'fan_speed'       : self.fan_speed,  
                         'led'             : self.led,
                         'help'            : self.help,
                         '?'               : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(Board1, self).__init__()
        self.num_nodes = cli.num_nodes
        self.active_node = 0
        if (cpld2_open() <= 0):
            log_err("CPLD device could not be opened")

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
        except:
            log_err("Error")
            self.help(args)
        return

    def open(self, args):
        if (cpld2_open() <= 0):
            log_err("CPLD device could not be opened")
        print "CPLD device opened"
        pass
    
    def close(self, args):
        if (cpld2_close() < 0):
            log_err("CPLD device could not be closed")
        print "CPLD device closed"
        pass

    def scan(self, args):
        if (cpld2_scan_xcvr() <= 0):
            log_err("Could not scan CPLD2 devices")
        print "CPLD device scan complete"
        pass
    
    def sfp(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            sfp_id = int(self.arg_list.pop(0))
            if (sfp_id < 1 or sfp_id > 66):
                log_err("Valid Ports are between 1 and 66")
                return
            if (sfp_id < 64):
                if (cpld2_dump_qsfp_info(sfp_id) < 0):
                    log_err("Error dumping QSFP info....")
                    return
            else:
                if (cpld2_dump_sfp_info(sfp_id-64) < 0):
                    log_err("Error dumping QSFP info....")
                    return
            print "Dumped SFP/QSFP info"
        except:
            log_err("Usage: board1 sfp <port_id>")
            return

    def read(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            reg_id = int(self.arg_list.pop(0), 16)
            value = c_uint8(0)
            if (cpld2_read(reg_id, pointer(value)) < 0):
                log_err("Error reading register....")
            print "Read the data " + str(value.value)
        except:
            log_err("Usage: board1 cpld_read <reg>")
            return
    
    def write(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            reg_id = int(self.arg_list.pop(0), 16)
            value = int(self.arg_list.pop(0))
            if (cpld2_write_reg(reg_id, value) < 0):
                log_err("Error writing to register....")
            print "Wrote the data " + str(value)
        except:
            log_err("Usage: board1 cpld_write <reg> <value>")
            return

    def led(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            sfp_id = int(self.arg_list.pop(0))
            if (sfp_id < 1 or sfp_id > 66):
                log_err("Valid Ports are between 1 and 66")
                return
            on_off = self.arg_list.pop(0)
            if on_off == 'on':
                if (sfp_id <= 64):
                    if (cpld2_qsfp_led_on(sfp_id) < 0):
                        log_err("Error setting the QSFP LED....")
                else:
                    if (cpld2_sfp_led_on(sfp_id-64) < 0):
                        log_err("Error setting the SFP LED....")
            elif on_off == 'off':
                if (sfp_id <= 64):
                    if (cpld2_qsfp_led_off(sfp_id) < 0):
                        log_err("Error clearing the QSFP LED....")
                else:
                    if (cpld2_sfp_led_off(sfp_id-64) < 0):
                        log_err("Error clearing the SFP LED....")
            else:
                log_err("Invalid command, should be on or off")
        except:
            log_err("Usage: board1 led <1-66> on/off")
            return

    def cpld_test(self, args):
	print "CPLD test starting"
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            test_name = self.arg_list.pop(0)
            if test_name == 'read' or test_name == 'all':
                value = c_uint8(0)
                # Read from Switch board type register
                if (cpld2_read(0x203, pointer(value)) < 0):
                    log_err("Error reading register 0x203....")
                    return
    
                if value.value != 2:
                    log_err("Board is not midstone200i, test failed")
                    return

                print "cpld-2 read test succeeded"

            if test_name == 'write' or test_name == 'all':
                out_val = c_uint8(0xbe)
                # Write to Software scratch register
                if (cpld2_write(0x201, out_val) < 0):
                    log_err("Error writing to scratch register.")

                in_val = c_uint8(0)
                
                # Read from Switch board type register
                if (cpld2_read(0x201, pointer(in_val)) < 0):
                    log_err("Error reading scratch register....")
                    return
    
                if in_val.value != out_val.value:
                    log_err("cpld register write test failed")
                    return

                print "cpld-2 write test succeeded"
            
            if test_name == 'xcvr_read':
                qsfp_port = int(self.arg_list.pop(0))
                data = c_uint8(0)
                # Read from the xcvr register 0, on bus 0xA0
                if (cpld2_qsfp_read(qsfp_port, 0xA0, 0x0, pointer(data), 1) < 0):
                    log_err("Error reading the QSFP SPROM Register 0....")
                    return
    
                if data.value < 1 or data.value > 0x18:
                    log_err("QSFP read test failed, read invalid identifer" + str(data))
                    return

                print "cpld-2 xcvr read test succeeded"

            if test_name == 'xcvr_write':
                qsfp_port = int(self.arg_list.pop(0))
                out_data = c_uint8(0xbe)
                if (cpld2_qsfp_write(qsfp_port, 0xA0, 99, pointer(out_data), 1) < 0):
                    log_err("Error writing to the QSFP SPROM Register 99....")
                    return

                in_data = c_uint8(0)
                # Read from the xcvr register 99, on bus 0xA0
                if (cpld2_qsfp_read(qsfp_port, 0xA0, 99, pointer(in_data), 1) < 0):
                    log_err("Error reading the QSFP SPROM Register 99....")
                    return
    
                if in_data.value != out_data.value:
                    log_err("QSFP write test failed, read invalid identifer" + str(data))
                    return

                print "cpld-2 xcvr write test succeeded"

            if test_name == 'xcvr_scan' or test_name == 'all':
                if (cpld2_scan_xcvr() < 0):
                    log_err("CPLD unable to scan for xcvrs")

                print "cpld-2 Xcvr scan test succeeded"
            
            if test_name != 'read' and test_name != 'write' and test_name != 'xcvr_read' and test_name != 'xcvr_write' and test_name != 'all':
                log_err("Wrong test name, possible tests: read, write, xcvr_read, xcvr_write")

            return

        except:
            log_err("Usage: board1 cpld_test <test-name>")
            return

    def bmc_status(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        if (bmc_sensor_status() < 0):
            log_err("Error getting BMC status")
        return

    def vrm(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            slave = int(self.arg_list.pop(0), 16)
            op = self.arg_list.pop(0)
            if op == 'set':
                vol = int(self.arg_list.pop(0))
                if (bmc_vrm_voltage_set(slave, vol) < 0):
                    log_err("Error setting the VRM")
                    return
                print "VRM voltage set"
            if op == 'get':
                if (bmc_vrm_voltage_get(slave) < 0):
                    log_err("Error getting the VRM voltage")
                    return
        except:
            log_err("Usage: board1 vrm <0x29/0x35/0x3f> set/get <voltage>")
            return

    def fan_speed(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            fan_num = int(self.arg_list.pop(0))
            if (fan_num < 1 or fan_num > 4):
                log_err("Valid Ports are between 1 and 4")
                return
            op = self.arg_list.pop(0)
            if op == 'set':
                speed = int(self.arg_list.pop(0))
                if (bmc_fan_speed_set(fan_num, speed) < 0):
                    log_err("Error setting the fan speed")
                    return
                print "Fan speed set"
            if op == 'get':
                if (bmc_fan_speed_get() < 0):
                    log_err("Error getting the fan speed")
                    return
        except:
            log_err("Usage: board1 fan_speed <1-4> set/get <speed>")
            return
                
    def help(self, args):
        self.cli.error()
        print "Usage: \n", \
              "board1 cpld_open                              - Open the CPLD device\n", \
              "board1 cpld_close                             - Close the CPLD device\n", \
              "board1 cpld_scan                              - Scan CPLD device for QSFP/SFP xcvrs\n", \
              "board1 sfp <SFP ID>                           - Dump the QSFP/SFP info\n", \
              "board1 cpld_read <Reg>                        - Read a CPLD register\n", \
              "board1 cpld_write <Reg> <value>               - Write to a CPLD register\n", \
              "board1 cpld_test <test-name>                  - Run a CPLD test\n", \
              "board1 led <1-66> on/off                      - Turn LED on/off\n", \
              "board1 fan_speed <1-4> set/get <speed>        - Set/Get fan speed\n", \
              "board1 vrm <0x29/0x35/0x3f> set/get <voltage> - Set/Get VRM voltage\n", \
              "help or ?                                     - show this text\n"
