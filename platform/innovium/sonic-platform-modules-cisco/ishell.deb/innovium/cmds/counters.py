
#-------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']
from collections import OrderedDict

from ifcs_cmds.all import *
from print_table import PrintTable



# Class implements Ifcs related commands
class Counters(Command):
    def __init__(self, cli):
        self.sub_cmds = {
            'enable': self.enable,
            'disable': self.disable,
            'show': self.show,
            'clear': self.clear,
            'help': self.help,
            '?': self.help
        }
        self.counter_display_method = {
            'sysport': self.display_sysport_counters,
            'devport': self.display_devport_counters,
            'l2vni': self.display_l2vni_counters,
            'intf': self.display_intf_counters,
            'cpu_queue': self.display_cpu_queue_counters,

        }
        self.counter_clear_method = {
            'sysport': self.clear_sysport_counters,
            'devport': self.clear_devport_counters,
            'l2vni': self.clear_l2vni_counters,
            'intf': self.clear_intf_counters,
            'cpu_queue': self.clear_cpu_queue_counters,
            'hardware': self.clear_hardware_counters,
        }
        self.supported_operands = ['sysport','devport','l2vni','intf', 'cpu_queue', 'hardware']
        self.supported_hw_operands = ['port','ib','global','partition','queue']
        self.cli = cli
        self.arg_list = []
        super(Counters, self).__init__()
        self.ifcs_names = ['port', 'l2vni']
        self.help_str = "ifcs:        IFCS object cli commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Counters run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        rc = self.sub_cmds[self.arg_list[1]](args)
        if rc != IFCS_SUCCESS:
            log_err("Failed to run CLI command: {0}".format(convert_error_code_to_string(rc)))
            return rc

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper()
                    for i in self.ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.ifcs_names if i.lower().startswith(text)]

    complete_port = complete_show
    complete_l2vni = complete_show

    def getCountersType(self, args):
        log_dbg(1, "In getCountersType with args: " + args)

        counter_type = args.split()[3]

        # This if condition needs to be expanded for other counter types
        if counter_type == 'sysport':
            return 'sysport'
        elif counter_type == 'devport':
            return 'devport'
        elif counter_type == 'l2vni':
            return 'l2vni'
        elif counter_type == 'intf':
            return 'intf'
        elif counter_type == 'cpu_queue':
            return 'cpu_queue'
        elif counter_type == 'hardware':
            return 'hardware'
        else:
            return 'unsupported'

    def getIfcsType(self, ifcs_obj_name):
        '''Get IFCS Type Object'''
        log_dbg(1, "In getIfcsType ifcs_obj_name " + ifcs_obj_name)

        if ifcs_obj_name == 'sysport':
            return Sysport(self.cli)
        if ifcs_obj_name == 'devport':
            return Devport(self.cli)
        if ifcs_obj_name == 'l2vni':
            return L2vni(self.cli)
        if ifcs_obj_name == 'intf':
            return Intf(self.cli)
        if ifcs_obj_name == 'hardware':
            return Hardware(self.cli)

        return None

    # ------------
    # disable command
    # ------------
    def disable(self, args):
        log_dbg(1, "Disable the stats polling thread " + args)

        allobjs = IfcsAll(self.cli)
        node = allobjs.get_ifcs_obj_from_name('node')
        node.setStatsPollInterval(0)

        log("Disabled statistics polling")
        return

    # ------------
    # enable command
    # ------------
    def enable(self, args):
        log_dbg(1, "Enable the stats polling thread " + args)

        allobjs = IfcsAll(self.cli)
        node = allobjs.get_ifcs_obj_from_name('node')
        node.setStatsPollInterval(1000)

        log("Enabled statistics polling")
        return

    # ------------
    # show command
    # ------------
    def show(self, args, filter_option):
        log_dbg(1, "In counters show with args: " + args)

        self.filter_option = filter_option

        try:
            counter_type = self.getCountersType(args)
        except IndexError:
            log_err("Counter type not specified")

        try:
            rc = self.counter_display_method[counter_type](args)
        except BaseException:
            log_err("Failed to get counters")

        return rc

    # ------------
    # clear command
    # ------------
    def clear(self, args):
        log_dbg(1, "In counters clear with args: " + args)

        try:
            counter_type = self.getCountersType(args)
        except IndexError:
            log_err("Counter type not specified")

        try:
            rc = self.counter_clear_method[counter_type]()
        except BaseException:
            log_err("Failed to clear counters")

        return rc

    # --------------------------------------------
    #   Rate collection
    # --------------------------------------------
    # -------------------------------------------
    # hardware counter clear methods
    # -------------------------------------------
    def clear_hardware_counters(self):
        log_dbg(1, "In display hardware counters show ")

    # -------------------------------------------
    # sysport counter clear methods
    # -------------------------------------------
    def clear_sysport_counters(self):
        log_dbg(1, "In display sysport counters show ")

        allobjs = IfcsAll(self.cli)
        sysport = allobjs.get_ifcs_obj_from_name('sysport')

        if sysport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            all_sysports = sysport.getAllsysport()
        except BaseException:
            log_err("Error retrieving sysports")

        # iterate over all devports
        for port in all_sysports:
            # clear the sysport stats
            sysport.stats_clear(port)

    # -------------------------------------------
    # l2vni counter clear methods
    # -------------------------------------------
    def clear_l2vni_counters(self):
        log_dbg(1, "In display l2vni counters show ")

        allobjs = IfcsAll(self.cli)
        l2vni = allobjs.get_ifcs_obj_from_name('l2vni')
        if l2vni is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            all_l2vni = l2vni.getAlll2vni()
        except BaseException:
            log_err("Error retrieving sysports")

        # iterate over all l2vni
        for iter_l2vni in all_l2vni:
            # clear the l2vni stats
            l2vni.stats_clear(iter_l2vni)

    # -------------------------------------------
    # intf counter clear methods
    # -------------------------------------------
    def clear_intf_counters(self):
        log_dbg(1, "In display intf counters show ")

        allobjs = IfcsAll(self.cli)
        intf = allobjs.get_ifcs_obj_from_name('intf')
        if intf is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            all_intf = intf.getAllintf()
        except BaseException:
            log_err("Error retrieving sysports")

        # iterate over all intf
        for iter_intf in all_intf:
            # clear the intf stats
            intf.stats_clear(iter_intf)

    # -------------------------------------------
    # counter clear methods
    # -------------------------------------------
    def clear_devport_counters(self):
        log_dbg(1, "In devport counters clear ")

        allobjs = IfcsAll(self.cli)
        devport = allobjs.get_ifcs_obj_from_name('devport')
        if devport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            all_devports = devport.getAlldevport()
        except BaseException:
            log_err("Error retrieving devports")

        # iterate over all devports
        for port in all_devports:
            devport.stats_clear(port)

    # -------------------------------------------
    # cpu queue counter clear methods
    # -------------------------------------------
    def clear_cpu_queue_counters(self):
        log_dbg(1, "In cpu queue counters clear ")

        allobjs = IfcsAll(self.cli)
        cpu_queue = allobjs.get_ifcs_obj_from_name('cpu_queue')
        if cpu_queue is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            all_cpu_queues = cpu_queue.getAllcpu_queue()
        except BaseException:
            log_err("Error retrieving cpu queues")

        # iterate over all cpu queues
        for queue in all_cpu_queues:
            cpu_queue.stats_clear(queue)

    # -------------------------------------------
    # sysport counter display methods
    # -------------------------------------------
    def display_sysport_counters(self, args):
        log_dbg(1, "In sysport counters clear ")

        allobjs = IfcsAll(self.cli)
        sysport = allobjs.get_ifcs_obj_from_name('sysport')

        if sysport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return IFCS_UNSUPPORTED

        try:
            all_sysports = sysport.getAllsysport()
        except BaseException:
            log_err("Error retrieving devports")
            return IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'Sysport (handle)',
            'Rx Bytes',
            'Rx Pkts',
            'Rx Errors',
            'Tx Bytes',
            'Tx Pkts',
        ]
        table.add_row(field_names)

        all_sysports = sorted(all_sysports)

        # iterate over all sysports
        for port in all_sysports:
            # get the sysport stats
            stats_list = sysport.stats_get(port)

            input_bytes = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_RX] \
                          + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_RX]
            input_pkts = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_RX] \
                         + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_RX]
            input_errors = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_HEADER_ERRS_PKTS_RX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_ADDR_ERRS_PKTS_RX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_HEADER_ERRS_PKTS_RX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_ADDR_ERRS_PKTS_RX]
            output_bytes = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_TX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_TX]
            output_pkts = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_TX] \
                          + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_TX]

            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if input_bytes or input_pkts or input_errors or output_bytes or output_pkts:
                    table.add_row([sysport.handle_to_str(port), str(input_bytes), str(
                        input_pkts), str(input_errors), str(output_bytes), str(output_pkts)])
            else:
                table.add_row([sysport.handle_to_str(port),str(input_bytes), str(
                    input_pkts), str(input_errors), str(output_bytes), str(output_pkts)])

        table.print_table(brief=True)

    # -------------------------------------------
    # l2vni counter display methods
    # -------------------------------------------
    def display_l2vni_counters(self, args):
        log_dbg(1, "In display l2vni counters show ")

        allobjs = IfcsAll(self.cli)
        l2vni = allobjs.get_ifcs_obj_from_name('l2vni')

        if l2vni is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return IFCS_UNSUPPORTED

        try:
            all_l2vni = l2vni.getAlll2vni()
        except BaseException:
            log_err("Error retrieving l2vni")
            return IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'L2vni',
            'Rx Bytes',
            'Rx Pkts',
            'Tx Bytes',
            'Tx Pkts',
        ]
        table.add_row(field_names)

        all_l2vni = sorted(all_l2vni)

        # iterate over all l2vnis
        for itr_l2vni in all_l2vni:
            # get the l2vni stats
            stats_list = l2vni.stats_get(itr_l2vni)

            input_bytes = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_INGRESS_BYTES]
            input_pkts = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_INGRESS_PKTS]
            output_bytes = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_EGRESS_BYTES]
            output_pkts = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_EGRESS_PKTS]


            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if input_bytes or input_pkts or output_bytes or output_pkts:
                    table.add_row([l2vni.handle_to_str(itr_l2vni), str(input_bytes), str(
                        input_pkts), str(output_bytes), str(output_pkts)])
            else:
                table.add_row([l2vni.handle_to_str(itr_l2vni), str(input_bytes), str(
                    input_pkts), str(output_bytes), str(output_pkts)])

        table.print_table(brief=True)

    # -------------------------------------------
    # intf counter display methods
    # -------------------------------------------
    def display_intf_counters(self, args):
        log_dbg(1, "In display int fcounters show ")

        allobjs = IfcsAll(self.cli)
        intf = allobjs.get_ifcs_obj_from_name('intf')

        if intf is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return IFCS_UNSUPPORTED

        try:
            all_intf = intf.getAllintf()
        except BaseException:
            log_err("Error retrieving intf")
            return IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'Intf',
            'Rx Bytes',
            'Rx Pkts',
        ]
        table.add_row(field_names)

        all_intf = sorted(all_intf)

        # iterate over all intf
        for itr_intf in all_intf:
            # get the intf stats
            stats_list = intf.stats_get(itr_intf)

            input_pkts = stats_list[ifcs_ctypes.IFCS_INTF_STATS_ID_L3INTF_INGRESS_UCAST_PKTS]
            input_bytes = stats_list[ifcs_ctypes.IFCS_INTF_STATS_ID_L3INTF_INGRESS_UCAST_BYTES]

            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if input_bytes or input_pkts:
                    table.add_row([intf.handle_to_str(itr_intf), str(input_bytes), str(
                        input_pkts)])
            else:
                table.add_row([intf.handle_to_str(itr_intf), str(input_bytes), str(
                    input_pkts)])

        table.print_table(brief=True)

    # -------------------------------------------
    # devport counter display methods
    # -------------------------------------------
    def display_devport_counters(self, args):
        log_dbg(1, "In display devport counters show ")

        allobjs = IfcsAll(self.cli)
        devport = allobjs.get_ifcs_obj_from_name('devport')

        if devport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return IFCS_UNSUPPORTED

        try:
            all_devports = devport.getAlldevport()
        except BaseException:
            log_err("Error retrieving devports")
            return IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'Devport (id)',
            'Rx Frames All',
            'Rx Frames Ok',
            'Rx Frames Err',
            'Rx Bytes All',
            'Rx Bytes Ok',
            'Tx Frames All',
            'Tx Frames Ok',
            'Tx Frames Err',
            'Tx Bytes All',
            'Tx Bytes Ok',
        ]
        table.add_row(field_names)

        all_devports = sorted(all_devports)

        # iterate over all devports
        for port in all_devports:

            # get the sysport stats
            stats_list = devport.stats_get(port)

            rx_frames_all = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ALL]
            rx_frames_ok  = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            rx_frames_err = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]
            rx_bytes_all  = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
            rx_bytes_ok   = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            tx_frames_all = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ALL]
            tx_frames_ok  = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            tx_frames_err = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]
            tx_bytes_all  = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
            tx_bytes_ok   = stats_list[self.cli.ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]


            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if rx_frames_all or rx_frames_ok or rx_frames_err or rx_bytes_all or rx_bytes_ok or tx_frames_all or tx_frames_ok or tx_frames_err or tx_bytes_all or tx_bytes_ok:
                    table.add_row([str(int(port)), str(rx_frames_all), str(rx_frames_ok), str(rx_frames_err), str(
                        rx_bytes_all), str(rx_bytes_ok), str(tx_frames_all), str(tx_frames_ok), str(tx_frames_err),str(tx_bytes_all), str(tx_bytes_ok)])
            else:
                table.add_row([str(int(port)), str(rx_frames_all), str(rx_frames_ok), str(rx_frames_err), str(
                    rx_bytes_all), str(rx_bytes_ok), str(tx_frames_all), str(tx_frames_ok), str(tx_frames_err),str(tx_bytes_all), str(tx_bytes_ok)])

        table.print_table(brief=True)

    # -------------------------------------------
    # cpu_queue counter display methods
    # -------------------------------------------
    def display_cpu_queue_counters(self, args):
        log_dbg(1, "In display cpu queue counters show ")

        allobjs = IfcsAll(self.cli)
        cpu_queue = allobjs.get_ifcs_obj_from_name('cpu_queue')

        if cpu_queue is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return IFCS_UNSUPPORTED

        try:
            all_cpu_queues = cpu_queue.getAllcpu_queue()
        except BaseException:
            log_err("Error retrieving cpu queues")
            return IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'CPU Q (id)',
            'Total In Use',
            'Total Use Watermark',
            'Packets Dropped',
            'Cells Dropped',
            'Tx Packets',
            'Tx Bytes',
        ]
        table.add_row(field_names)

        all_cpu_queues = sorted(all_cpu_queues)

        # iterate over all CPU queues
        for queue in all_cpu_queues:

            # get the sysport stats
            stats_list = cpu_queue.stats_get(queue)

            total_in_use = stats_list[self.cli.ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_TOTAL_USE_COUNT]
            total_use_watermark  = stats_list[self.cli.ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_TOTAL_USE_WATERMARK]
            packets_dropped   = stats_list[self.cli.ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_PACKET_DROP_COUNT]
            cells_dropped = stats_list[self.cli.ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_CELL_DROP_COUNT]
            tx_packets = stats_list[self.cli.ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_PACKET_TX_COUNT]
            tx_bytes  = stats_list[self.cli.ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_BYTE_TX_COUNT]

            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if tx_packets or tx_bytes or current_in_use or total_use_watermark or packets_dropped or cells_dropped:
                    table.add_row([str(int(queue)), str(total_in_use), str(total_use_watermark), str(packets_dropped),
                        str(cells_dropped), str(tx_packets), str(tx_bytes)])
            else:
                    table.add_row([str(int(queue)), str(total_in_use), str(total_use_watermark), str(packets_dropped),
                        str(cells_dropped), str(tx_packets), str(tx_bytes)])

        table.print_table(brief=True)

    # -------------------------------------------
    # hardware counter display methods
    # -------------------------------------------

    def help(self, args):
        table = PrintTable()

        table.add_row(['IFCS Counters Help', 'Description'])
        table.add_row(['ifcs show counters devport',
                       'Displays input & output packets and bytes for all devports'])
        table.add_row(['ifcs show counters l2vni',
                       'Displays input & output packets and bytes for all l2vnis'])
        table.add_row(['ifcs show counters intf',
                       'Displays input & output packets and bytes for all intfs'])
        table.add_row(['ifcs show counters sysport',
                       'Displays input & output packets and bytes for all sysports'])
        table.add_row(['ifcs clear counters devport',
                       'Clears input & output packets and bytes for all devports'])
        table.add_row(['ifcs clear counters l2vni',
                       'Clears input & output packets and bytes for all l2vnis'])
        table.add_row(['ifcs clear counters intf',
                       'Clears input & output packets and bytes for all intfs'])
        table.add_row(['ifcs clear counters sysport',
                       'Clears input & output packets and bytes for all sysports'])
        log("")
        table.set_justification('left')
        table.print_table()
        table.reset_table()
