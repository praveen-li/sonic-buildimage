#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2020
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

import shlex
import time
import random
import copy
import argparse
import sys
import re
ifcs_ctypes = sys.modules['ifcs_ctypes']
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from testutil import pci
from testutil import pkt
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *

class VizHDC(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create_instance'           : self.create_instance,
                         'delete_instance'           : self.delete_instance,
                         'apply_instance'            : self.apply_instance,
                         'get_queue_status'          : self.get_queue_status,
                         'help'                      : self.help,
                         '?'                         : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        self.hdc_collector_set_handle = 0
        self.hdc_collector_handle = 0
        self.hdc_visibility_sampler_handle = 0
        self.hdc_delay_threshold_handle = []
        self.hdc_delay_threshold_value = []
        self.curr_index = 0
        self.hdc_policy_arr = []
        self.hdc_policy = None
        self.handle = 0
        self.nodeId = 0
        self.deviceType = -1
        self.switchId = -1
        self.cos_queue_ids = []
        self.show_queue_ids = []
        self.queue = None
        self.sysPort = None
        self.devport_all_list = []
        self.num_devports = 0
        self.hostifTrap = None
        self.cpu_queue_meter_cir_enable = None
        self.cpu_queue_meter_cir = None
        self.cpu_queue_meter_burst_size = None
        self.cpu_queue_num = None

    def _get_sysport_from_devport_(
            self,
            nodeId,
            dev_port,
            userHandle=None):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        rc = ifcs_ctypes.ifcs_devport_attr_get(nodeId, dev_port, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Sysport get from devport {} failure rc: {} ".format(dev_port,rc))
            return rc

        rc = ifcs_ctypes.ifcs_attr_t_value_handle_get(pointer(out_attr), pointer(handle))
        if rc:
            log("Sysport handle get for devport {} failure rc: {}".format(devport,rc))
            return rc

        self.sysPort = int(handle.value)
        log_dbg(1,"HDC Collector sysport handle= " + hex(handle.value))
        return rc

    # Get a list of all 'queue(s)' for devport
    def getDevport_queue_id(self, devport):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            queue_list.append(arg.contents.queue_id)

        queue_list = []

        callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None),
                                  ifcs_ctypes.ifcs_node_id_t,
                                  POINTER(ifcs_ctypes.ifcs_queue_t),
                                  c_uint32,
                                  POINTER(ifcs_ctypes.ifcs_attr_t),
                                  POINTER(None))
        callback = callback_type(myCallback)
        callback_p = compat_funcPointer(
            callback, ifcs_ctypes.ifcs_queue_user_cb_t)

        queue_entry = ifcs_ctypes.ifcs_queue_t()
        rc = ifcs_ctypes.ifcs_queue_t_init(pointer(queue_entry))
        ifcs_ctypes.ifcs_queue_t_devport_set(pointer(queue_entry), devport)
        try:
            rc = ifcs_ctypes.ifcs_queue_get_all(self.cli.node_id,
                                                pointer(queue_entry),
                                                0, 0, callback_p,
                                                0, None)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to get Devport {}, all queue rc: {}".
                        format(str(port), convert_error_code_to_string(rc)))
        except Exception as e:
            log("Failed to get Devport's queue : {}".format(e))
            raise e

        queue_list.sort(key = int)
        return queue_list


    # Get a list of all 'ETH' (front panel) devports
    def _get_devport_list_(self, node_id=0):
        log_dbg(1, "in _get_devport_list_:")

        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            devport = arg
            devport_list.append(int(devport))

        devport_list = []

        callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None),
                                  ifcs_ctypes.ifcs_node_id_t,
                                  ifcs_ctypes.ifcs_devport_t,
                                  c_uint32,
                                  POINTER(ifcs_ctypes.ifcs_attr_t),
                                  POINTER(None))
        callback = callback_type(myCallback)

        callback_p = compat_funcPointer(
            callback, self.cli.ifcs_ctypes.ifcs_devport_user_cb_t)

        attr = ifcs_ctypes.ifcs_attr_t()
        ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
        ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr),
                                       ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr),
                                              ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

        rc = ifcs_ctypes.ifcs_devport_get_all(self.cli.node_id,
                                              1, pointer(attr),
                                              callback_p, 0, None)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("Failed to get all devport rc: {}".format(rc))
            return rc

        devport_list.sort(key = int)
        return (devport_list)

    # build ip address from family,address
    def build_ipaddr(self, ipAddr):
        log_dbg(1, "in build_ipaddr:")

        ipAddrStruct = ifcs_ctypes.ifcs_ip_address_t()
        ipAddrStruct.addr_family = 0
        ipAddrStruct.addr.ipv4 = ipAddr
        return ipAddrStruct

    def __cpu_queue_attr_get(self, nodeId, queue_num):
        #   Get cpu queue attributes changed for restoring them later
        self.cpu_queue_meter_cir_enable = None
        self.cpu_queue_meter_cir = None
        self.cpu_queue_meter_burst_size = None

        attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
        for index in range(3):
            rc = ifcs_ctypes.ifcs_attr_t_init(
                compat_pointerAtIndex(
                    attr_list, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

        attr_count = 0
        for attr_id in [
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE_ENABLE,
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE,
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_BURST_SIZE]:
            rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(
                attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), attr_id)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            attr_count += 1

        actual_count = c_uint32()
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_cpu_queue_attr_get(
                nodeId, queue_num, attr_count, compat_pointer(
                    attr_list, ifcs_ctypes.ifcs_attr_t), pointer(actual_count)))
        if rc != ifcs_ctypes.IFCS_SUCCESS or actual_count.value != attr_count:
            log("Get attr for cpu_queue {} failed with error code {}. returned attr count {}".format(
                queue_num, rc, actual_count.value))
        else:
            attr_id = c_uint32()
            attr_val = c_uint32()
            for index in range(3):
                rc = ifcs_ctypes.ifcs_attr_t_id_get(compat_pointerAtIndex(
                    attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_id))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
                if attr_id.value == ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE_ENABLE:
                    attr_val_bool = c_int()
                    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointerAtIndex(
                        attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_val_bool))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    self.cpu_queue_meter_cir_enable = int(attr_val_bool.value)
                elif attr_id.value == ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE:
                    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(
                        attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_val))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    self.cpu_queue_meter_cir = int(attr_val.value)
                elif attr_id.value == ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_BURST_SIZE:
                    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(
                        attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_val))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    self.cpu_queue_meter_burst_size = int(attr_val.value)
                else:
                    assert 1 == 0
            if None in [
                    self.cpu_queue_meter_cir_enable,
                    self.cpu_queue_meter_cir,
                    self.cpu_queue_meter_burst_size]:
                assert 1 == 0
            self.cpu_queue_num = queue_num
            log_dbg(
                1,
                "HDC: Get attr for cpu_queue {} returned meter_committed_information_rate_enable {}, meter_committed_information_rate {}, meter_committed_burst_size {}".format(
                    queue_num,
                    self.cpu_queue_meter_cir_enable,
                    self.cpu_queue_meter_cir,
                    self.cpu_queue_meter_burst_size))
        return rc

    def __cpu_queue_attr_restore(self, nodeId):
        #   Restore cpu queue attributes to previous state
        if None not in [
                self.cpu_queue_meter_cir_enable,
                self.cpu_queue_meter_cir,
                self.cpu_queue_meter_burst_size,
                self.cpu_queue_num]:
            self.__cpu_queue_attr_set(
                nodeId,
                self.cpu_queue_num,
                self.cpu_queue_meter_cir_enable,
                self.cpu_queue_meter_cir,
                self.cpu_queue_meter_burst_size)
        self.cpu_queue_meter_cir_enable = None
        self.cpu_queue_meter_cir = None
        self.cpu_queue_meter_burst_size = None
        self.cpu_queue_num = None
        return

    def __cpu_queue_attr_set(
            self,
            nodeId,
            queue_num,
            meter_cir_enable,
            meter_cir,
            meter_burst_size):
        #   Set cpu queue attributes
        attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
        for index in range(3):
            rc = ifcs_ctypes.ifcs_attr_t_init(
                compat_pointerAtIndex(
                    attr_list, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

        attr_count = 0
        rc = ifcs_ctypes.ifcs_attr_t_id_set(
            compat_pointerAtIndex(
                attr_list,
                ifcs_ctypes.ifcs_attr_t,
                attr_count),
            ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE_ENABLE)
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        # Observed that when setting max value for CIR, the CPU queue policing is disabled,
        # but CIR enable field is shown as true.
        if meter_cir == 60000000:
            meter_cir_enable = False
        rc = ifcs_ctypes.ifcs_attr_t_value_data_set(
            compat_pointerAtIndex(
                attr_list,
                ifcs_ctypes.ifcs_attr_t,
                attr_count),
            ifcs_ctypes.IFCS_BOOL_TRUE if meter_cir_enable else ifcs_ctypes.IFCS_BOOL_FALSE)
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        attr_count += 1

        if meter_cir:
            rc = ifcs_ctypes.ifcs_attr_t_id_set(
                compat_pointerAtIndex(
                    attr_list,
                    ifcs_ctypes.ifcs_attr_t,
                    attr_count),
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            rc = ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(
                attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), meter_cir)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            attr_count += 1

        if meter_burst_size:
            rc = ifcs_ctypes.ifcs_attr_t_id_set(
                compat_pointerAtIndex(
                    attr_list,
                    ifcs_ctypes.ifcs_attr_t,
                    attr_count),
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_BURST_SIZE)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            rc = ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(
                attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), meter_burst_size)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            attr_count += 1

        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_cpu_queue_attr_set(
                nodeId, queue_num, attr_count, compat_pointer(
                    attr_list, ifcs_ctypes.ifcs_attr_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Set attr for cpu_queue {} failed with error code {}".format(queue_num, rc))
        else:
            log_dbg(
                1,
                "HDC: Set attr for cpu_queue {} with meter_committed_information_rate_enable {}, meter_committed_information_rate {}, meter_committed_burst_size {}".format(
                    queue_num,
                    True if meter_cir_enable else False,
                    meter_cir,
                    meter_burst_size))
        return rc

    def __host_if_trap_create(
            self,
            nodeId,
            queue_num,
            meter_cir,
            meter_burst_size):
        if meter_cir is not None:
            rc = self.__cpu_queue_attr_get(nodeId, queue_num)
            if rc:
                return rc
            rc = self.__cpu_queue_attr_set(
                nodeId, queue_num, True, meter_cir, meter_burst_size)
            if rc:
                return rc

        #   Create Host If Trap
        handle = ifcs_ctypes.ifcs_handle_t(ifcs_ctypes.IFCS_NULL_HANDLE)
        attrList = (ifcs_ctypes.ifcs_attr_t * 2)()
        for index in range(2):
            rc = ifcs_ctypes.ifcs_attr_t_init(
                compat_pointerAtIndex(
                    attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        rc = ifcs_ctypes.ifcs_attr_t_id_set(
            compat_pointerAtIndex(
                attrList,
                ifcs_ctypes.ifcs_attr_t,
                index),
            ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM)
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.ifcs_attr_t_value_cpu_queue_set(
            compat_pointerAtIndex(
                attrList,
                ifcs_ctypes.ifcs_attr_t,
                index),
            ifcs_ctypes.ifcs_cpu_queue_t(queue_num))
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        index += 1

        attrCount = index
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_hostif_trap_create(
                nodeId, pointer(handle), attrCount, compat_pointer(
                    attrList, ifcs_ctypes.ifcs_attr_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Create hostif_trap for queue_num {} failed with error code {}".format(
                queue_num, rc))
            self.__cpu_queue_attr_restore(nodeId)
        else:
            self.hostifTrap = int(handle.value)
            log_dbg(1, "HDC: Created hostif_trap {}".format(hex(self.hostifTrap)))
        return rc

    def __host_if_trap_delete(self, nodeId):
        if self.hostifTrap is not None:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hostif_trap_delete(
                    nodeId, ifcs_ctypes.ifcs_handle_t(
                        self.hostifTrap)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Delete hostif_trap {} failed with error code {}".format(
                    hex(self.hostifTrap), rc))
            else:
                log_dbg(1, "HDC: Deleted hostif_trap {}".format(
                    hex(self.hostifTrap)))
                self.hostifTrap = None
        self.__cpu_queue_attr_restore(nodeId)
        return

    def _collector_create_(
            self,
            nodeId,
            collectorType=None,
            direction=None,
            dcdp=None,
            localDestination=None,
            vizTc=None,
            rspanDot1qTpid=None,
            rspanDot1qVlan=None,
            rspanDot1qPri=None,
            rspanDot1qCfi=None,
            destMac=None,
            srcMac=None,
            srcIpFamily=None,
            srcIp=None,
            destIpFamily=None,
            destIp=None,
            dscp=None,
            ttl=None,
            ipv4DfFlag=None,
            dot1qVlan=None,
            sessionId=None,
            truncate=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):
        log_dbg(1, "in _collector_create_:")

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_COLLECTOR_TYPE
            attrList[index].value.u32 = collectorType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if dcdp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DCDP
            attrList[index].value.handle = dcdp
            index += 1
        if localDestination is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_LOCAL_DESTINATION
            attrList[index].value.handle = localDestination
            index += 1
        if vizTc is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_VIZ_TC
            attrList[index].value.tc = vizTc
            index += 1
        if rspanDot1qTpid is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_TPID
            attrList[index].value.u16 = rspanDot1qTpid
            index += 1
        if rspanDot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_VLAN
            attrList[index].value.u16 = rspanDot1qVlan
            index += 1
        if rspanDot1qPri is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_PRI
            attrList[index].value.u8 = rspanDot1qPri
            index += 1
        if rspanDot1qCfi is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_CFI
            attrList[index].value.u8 = rspanDot1qCfi
            index += 1
        if destMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_MAC
            attrList[index].value.mac = destMac
            index += 1
        if srcMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_MAC
            attrList[index].value.mac = srcMac
            index += 1
        if srcIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_IP
            attrList[index].value.ip_addr = self.build_ipaddr(srcIp)
            index += 1
        if destIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_IP
            attrList[index].value.ip_addr = self.build_ipaddr(destIp)
            index += 1
        if dscp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DSCP
            attrList[index].value.u8 = dscp
            index += 1
        if ttl is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TTL
            attrList[index].value.u8 = ttl
            index += 1
        if ipv4DfFlag is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_IPV4_DF_FLAG
            attrList[index].value.u8 = ipv4DfFlag
            index += 1
        if dot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DOT1Q_VLAN
            attrList[index].value.u16 = dot1qVlan
            index += 1
        if sessionId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SESSION_ID
            attrList[index].value.u16 = sessionId
            index += 1
        if truncate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TRUNCATE
            attrList[index].value.u32 = truncate
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("HDC Collector creation failed rc: {}".format(rc))
            else:
                self.hdc_collector_handle = int(handle.value)
                log_dbg(1,"HDC Collector handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _collector_set_create_(
            self,
            nodeId,
            collectorSetType=None,
            direction=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):
        log_dbg(1, "in _collector_set_create_:")

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorSetType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_COLLECTOR_SET_TYPE
            attrList[index].value.u32 = collectorSetType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("HDC CollectorSet creation failed rc: {}".format(rc))
            else:
                self.hdc_collector_set_handle = int(handle.value)
                log_dbg(1,"HDC CollectorSet handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _add_members_(
            self,
            collector_set_handle,
            memberList,
            attrList=None,
            memberCount=None,
            attrCount=None,
            expRc=None,
            customLog=None,
            ifcsCall=True):
        log_dbg(1, "in _add_members_:")

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            if memberList is not None:
                memberCount = len(memberList)
            else:
                memberCount = 0
        if attrCount is None:
            if attrList is not None:
                attrCount = len(attrList)
            else:
                attrCount = 0
        if attrList is None:
            attrList = None
        if not ifcsCall:
            return ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_add(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                memberhandleList,
                attrCount,
                attrList))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("HDC CollectorSet member add failed rc: {}".format(rc))
        else:
            pass
            log_dbg(1, "HDC CollectorSet member add success")
        return rc

    def _visibility_sampler_create_(
            self,
            nodeId,
            type=None,
            mode=None,
            probabilisticCaptureRate=None,
            microburstCaptureAvgPacketRate=None,
            microburstCaptureMaxPacketsPerBurst=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):
        log_dbg(1, "in _visibility_sampler_create_:")

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if type is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_TYPE
            attrList[index].value.u32 = type
            index += 1
        if mode is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MODE
            attrList[index].value.u32 = mode
            index += 1
        if probabilisticCaptureRate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_PROBABILISTIC_CAPTURE_RATE
            attrList[index].value.u32 = probabilisticCaptureRate
            index += 1
        if microburstCaptureAvgPacketRate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MICROBURST_CAPTURE_AVG_PACKET_RATE
            attrList[index].value.u32 = microburstCaptureAvgPacketRate
            index += 1
        if microburstCaptureMaxPacketsPerBurst is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MICROBURST_CAPTURE_MAX_PACKETS_PER_BURST
            attrList[index].value.u32 = microburstCaptureMaxPacketsPerBurst
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_visibility_sampler_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Visibility Sampler creation failed rc: {}".format(rc))
            else:
                self.hdc_visibility_sampler_handle = int(handle.value)
                log_dbg(1,"Visibility Sampler handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _delay_threshold_create_(
            self,
            nodeId,
            delayThreshold=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            ifcsCall=True):
        log_dbg(1, "in _delay_threshold_create_:")

        # Validate delay threshold:
        # 1. Max of 4 unique values of delay threshold.
        # 2. Do not allow repetition; as the same value doesn't have any value add.

        exist_delay_threshold_count = self.hdc_delay_threshold_value.count(delayThreshold)
        delay_threshold_arr_count   = len(self.hdc_delay_threshold_value)
        if (exist_delay_threshold_count == 0) and (delay_threshold_arr_count == 4):
            log("{} Delay threshold values exist!".format(delay_threshold_arr_count))
            return -1

        # Reuse handle of already created delay threshold; skip creating Delay Threshold.
        if (exist_delay_threshold_count != 0):
            self.curr_index = self.hdc_delay_threshold_value.index(delayThreshold)
            return 0

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        index = 0
        maxAttr = int(ifcs_ctypes.IFCS_DELAY_THRESHOLD_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_DELAY_THRESHOLD_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if delayThreshold is not None:
            attrList[index].id = ifcs_ctypes.IFCS_DELAY_THRESHOLD_ATTR_THRESHOLD
            attrList[index].value.u32 = delayThreshold
            index += 1

        attrCount = index

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_delay_threshold_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Delay Threshold {} creation failed rc: {}".format(delayThreshold, rc))
            else:
                # store this delayThreshold value & handle in respective arrays in current index
                self.hdc_delay_threshold_value.insert(delay_threshold_arr_count, delayThreshold)
                self.hdc_delay_threshold_handle.insert(delay_threshold_arr_count, int(handle.value))
                self.curr_index = delay_threshold_arr_count
                log_dbg(1,"Delay Threshold handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _hdc_policy_create_(
            self,
            collector_set_handle,
            visibility_sampler_handle,
            delay_threshold_handle,
            ifcsCall=True):
        log_dbg(1, "in _hdc_policy_create_:")

        if self.hdc_policy != None:
            log("HDC policy already exists")
            return ifcs_ctypes.IFCS_INVAL

        self.hdc_policy = ifcs_ctypes.ifcs_hdc_policy_t()

        # 4 steps:
        # --> 1. Init hdc_policy_t
        # --> 2. Set Collector set
        # --> 3. Set Visibility sampler set
        # --> 4. Set Delay Threshold set
        if ifcsCall is True:
            # --> 1. Init hdc_policy_t
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hdc_policy_t_init(
                    pointer(self.hdc_policy)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                self.hdc_policy = None
                log("HDC policy init failed rc: {}".format(rc))
                return rc
            else:
                pass
                log_dbg(1,"HDC policy init success")

            # --> 2. Set Collector set
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hdc_policy_t_collector_set_set(
                    pointer(self.hdc_policy),
                    collector_set_handle))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Adding Collector Set to HDC policy failed rc: {}".format(rc))
                return rc
            else:
                pass
                log_dbg(1,"Adding Collector Set to HDC policy success")

            # --> 3. Set Visibility sampler set
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hdc_policy_t_visibility_sampler_set(
                    pointer(self.hdc_policy),
                    visibility_sampler_handle))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Adding Visibility Sampler to HDC policy failed rc: {}".format(rc))
                return rc
            else:
                pass
                log_dbg(1,"Adding Visibility Sampler to HDC policy success")

            # --> 4. Set Delay Threshold set
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hdc_policy_t_delay_threshold_set(
                    pointer(self.hdc_policy),
                    delay_threshold_handle))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Adding Delay Threshold to HDC policy failed rc: {}".format(rc))
            else:
                pass
                log_dbg(1, "Adding Delay Threshold to HDC policy success")

            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    # Routine to 'enable'/'disable' the HDC Policy in given queue(s)/devport(s) combination.
    def _hdc_policy_queue_apply_(
            self,
            nodeId,
            policy=None,
            enable=None,
            queue=[],
            devport=[],
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        log_dbg(1, "in _hdc_policy_queue_apply_:")

        maxAttr = int(ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1

        attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ATTR_HDC_POLICY
        if enable == ifcs_ctypes.IFCS_BOOL_TRUE:
            if (policy is not None):
                attrList[index].value.hdc_policy = policy
        else:
            ifcs_ctypes.ifcs_hdc_policy_t_init(pointer(attrList[index].value.hdc_policy))
        index += 1

        if enable is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ATTR_HDC_ENABLE
            attrList[index].value.data = enable
            index += 1

        if attrCount is None:
            if index > ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_QUEUE_ATTR_MAX_COUNT
            else:
                attrCount = index

        if ifcsCall is True:
            for one_devport in devport:
                for queue_id in queue:
                    # {
                    # Initialize 'rc' to a valid value
                    rc = ifcs_ctypes.IFCS_SUCCESS
                    self.queue = ifcs_ctypes.ifcs_queue_t()
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_queue_t_init(
                            pointer(self.queue)))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        self.queue = None
                        log("Queue init failed rc: {}".format(rc))
                        return rc
                    else:
                        pass

                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_queue_t_devport_set(
                            pointer(self.queue), one_devport))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log("Failure to set devport in Queue rc: {}".format(rc))
                        return rc
                    else:
                        pass

                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_queue_t_queue_id_set(
                            pointer(self.queue), queue_id))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log("Failure to set queue_id in Queue rc: {}".format(rc))
                        return rc
                    else:
                        pass

                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_queue_attr_set(
                            nodeId,
                            pointer(self.queue),
                            attrCount,
                            compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                    enable_str = "enable" if enable == ifcs_ctypes.IFCS_BOOL_TRUE else "disable"
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        # 'IFCS_NOTFOUND' & 'IFCS_EXIST' are valid case & need not cry foul
                        if (rc == ifcs_ctypes.IFCS_NOTFOUND) or (rc == ifcs_ctypes.IFCS_EXIST):
                            log_dbg(1, "HDC Policy {} on Queue {} devport {} failed rc: {}".format(enable_str, queue_id, one_devport, rc))
                            continue
                        else:
                            log("HDC Policy {} on Queue {} devport {} failed rc: {}".format(enable_str, queue_id, one_devport, rc))
                            break
                    else:
                        pass
                        log_dbg(1, "HDC Policy {} on Queue {} devport {} sucess".format(enable_str, queue_id, one_devport))
                    # }
        return rc

    def _hdc_policy_show_queue_(
            self,
            nodeId,
            queue_l=[],
            devport=None,
            ifcsCall=True):

        log_dbg(1, "in _hdc_policy_show_queue_:")

        queue_l.sort(key = int)
        port_qs = self.getDevport_queue_id(devport)

        # compare given 'queue' & obtained 'port_qs' to check
        log_dbg(1, "Queue(s) {} created for devport {}"
                .format(port_qs, devport))

        # If only few (port_qs) Qs have been really created, skip individual checking.
        if (len(queue_l) > len(port_qs)):
            return False

        for index in compat_xrange(len(queue_l)):
            if (queue_l[index] not in port_qs):
                return False

        return True

    def _remove_members_(
            self,
            collector_set_handle,
            memberList,
            memberCount=None,
            expRc=None,
            customLog=None,
            ifcsCall=True):

        log_dbg(1, "in _remove_members_:")

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            memberCount = len(memberList)
        if not ifcsCall:
            return ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_remove(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                memberhandleList))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("HDC CollectorSet member remove failed rc: {}".format(rc))
        else:
            pass
            log_dbg(1,"HDC CollectorSet member remove success")
        return rc

    def run_cmd(self, args):
        log_dbg(1, "in HDC run_cmd:")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "VizHDCKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "VizHDCValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def _parse_queue_ids_(
            self,
            queue_ids):
        log_dbg(1, "in _parse_queue_ids_:")

        # Supported formats 1 | 0,4,6 | 1-4
        try:
            queue_ids = queue_ids.strip()
            if re.match(r'^\d$', queue_ids):
                queue_ids = [queue_ids]
            elif re.match(r'^(\d,)+\d$', queue_ids):
                queue_ids = queue_ids.split(',')
            elif re.match(r'^\d-\d$', queue_ids):
                queue_ids = queue_ids.split('-')
                queue_ids = compat_listrange(int(queue_ids[0]), int(queue_ids[1]) + 1)
            else:
                return None
            return [int(x) for x in queue_ids]
        except:
            return None

    def create_instance(self, args):
        log_dbg(1, "in create_instance:")

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        parser = argparse.ArgumentParser(description='HDC Collector create',
                                         prog='config hdc create_instance',
                                         formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')

        requiredArgs.add_argument('-smac', action="store",
                                    help='Source mac. Format: AA:BB:CC:DD:EE:FF',
                                    required=True)
        requiredArgs.add_argument('-dmac', action="store",
                                    help='Destination mac. Format: AA:BB:CC:DD:EE:FF',
                                    required=True)
        requiredArgs.add_argument('-vlan', action="store",
                                    help='Vlan id (0-4095)',
                                    required=False)
        requiredArgs.add_argument('-sip', action="store",
                                    help='Source IPv4 address. Format: dot-decimal',
                                    required=True)
        requiredArgs.add_argument('-dip', action="store",
                                    help='Destination IPv4 address. Format: dot-decimal',
                                    required=True)

        requiredArgs.add_argument('-dscp', action="store",
                                    help='DSCP value (0-63)',
                                    required=True, type=int)
        requiredArgs.add_argument('-ttl', action="store",
                                    help='TTL value (1-255)',
                                    required=True, type=int)
        requiredArgs.add_argument('-devport', action="store",
                                    help='Device port 0 (CPU Port) | Front port number (Actual range depends on configuration)',
                                    required=True, type=int)
        requiredArgs.add_argument('-cpu_queue', action="store",
                                    help='CPU Queue number. Applicable only when Device port is 0',
                                    required=False, type=int)
        requiredArgs.add_argument('-cpu_rate', action="store",
                                    help='Meter Committed Information Rate (CIR) on the CPU Queue (122-60000000). Units are in PPS. To disable, set this value to max value. Applicable only when Device port is 0',
                                    required=False, type=int)
        requiredArgs.add_argument('-cpu_burst_size', action="store",
                                    help="Burst size associated with the meter committed information rate token bucket (1-1000000000). Units are in packets. Guidance for specifying value: Burst size should be >= cpu_rate * node's attribute update_interval_b [in update_interval_unit_us] * (1/1000000) [in sec/us]. Applicable only when Device port is 0",
                                    required=False, type=int)
        requiredArgs.add_argument('-tc', action="store",
                                    help='Traffic Class for HDC packets (0-15)',
                                    required=True, type=int)
        requiredArgs.add_argument('-df', action="store",
                                    help='Do not fragment flag in IPv4 header during HDC (0 | 1)',
                                    required=True, type=int)

        requiredArgs.add_argument('-sampler_mode', action="store",
                                    help='Visibility sampler mode ' \
                                         '1 (Probabilistic Capture) | ' \
                                         '2 (Microburst Capture)',
                                    required=True, type=int, choices=compat_listrange(1,3), default=1)
        requiredArgs.add_argument('-capture_rate', action="store",
                                    help='Capture rate for visibility sampler expressed as 1 in every N packets, ' \
                                         'where this attribute specifies N (10-16777215). Applicable only when ' \
                                         'visibility sampler mode is Probabilistic Capture.',
                                    required=False, type=int, default=10000)
        requiredArgs.add_argument('-avg_packet_rate', action="store",
                                    help='Avg rate (packets/sec) of packets to be captured (122-100000). ' \
                                         'Applicable only when visibility sampler mode is Microburst Capture.',
                                    required=False, type=int, default=8192)
        requiredArgs.add_argument('-max_packets_per_burst', action="store",
                                    help='Maximum number of packets to be captured per microburst event (64-16384). ' \
                                         'Applicable only when visibility sampler mode is Microburst Capture. ' \
                                         'Guidance for specifying value: ' \
                                         'Value should be >= avg_packet_rate * node\'s attribute update_interval_c * (1/1000000). ' \
                                         'Supported values are 64, 128, 256, 512, 1K, 2K...16K',
                                    required=False, type=int, default=256)

        try:
            res = parser.parse_args(self.arg_list)
        except:
            if len(self.arg_list) == 1 and self.arg_list[0] in ['-h', '--help']:
                return 0
            log('create_instance: Missing arguments or invalid arguments provided')
            return 1

        if self.hdc_collector_set_handle != 0:
            log("HDC Collector already exists")
            return ifcs_ctypes.IFCS_INVAL

        # Get dscp
        dscp = int(res.dscp)
        # Get ttl
        ttl = int(res.ttl)
        # Get dev_port
        dev_port = int(res.devport)
        # Get cpu_queue
        cpu_queue = None
        meter_cir = None
        meter_burst_size = None
        if dev_port == 0:
            if res.cpu_queue is None:
                log('Argument error: -cpu_queue is required when -devport is 0')
                return ifcs_ctypes.IFCS_INVAL
            cpu_queue = int(res.cpu_queue)
            if res.cpu_rate is not None:
                meter_cir = int(res.cpu_rate)
                if meter_cir < 0:
                    log('Argument error: -cpu_rate cannot be negative')
                    return ifcs_ctypes.IFCS_INVAL
                # Don't validate range, let sdk do it
            if res.cpu_burst_size is not None:
                if meter_cir is None:
                    log('Argument error: -cpu_rate is required when -devport is 0 and -cpu_burst_size is specified')
                    return ifcs_ctypes.IFCS_INVAL
                meter_burst_size = int(res.cpu_burst_size)
                if meter_burst_size < 0:
                    log('Argument error: -cpu_burst_size cannot be negative')
                    return ifcs_ctypes.IFCS_INVAL
                # Don't validate range, let sdk do it
            if meter_cir is None:
                meter_cir = 60000
                # Set default values as it was observed that SDK does not enable CPU queue policing
                # after any user applied CPU queue policer configuration
            if meter_burst_size is None:
                # Provide a calculated value
                rate = c_uint32(meter_cir)
                burst_size = c_uint32()
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.im_cpu_queue_burst_size_get(
                        self.cli.node_id, rate, pointer(burst_size)))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log("Get cpu_burst_size for cpu_rate {} failed with error code {}. Please check argument -cpu_rate".format(meter_cir, rc))
                    return ifcs_ctypes.IFCS_INVAL
                else:
                    meter_burst_size = int(burst_size.value)
                    log_dbg(
                        1, "HDC: Got cpu_burst_size {} for cpu_rate {}".format(
                            meter_burst_size, meter_cir))
        # Get traffic class
        viz_tc = int(res.tc)
        # Get IPv4 do not fragment flag
        ipv4_df_flag = int(res.df)
        # Get visibility sampler mode
        try:
            sampler_mode = int(res.sampler_mode)
            sampler_mode = [ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_CAPTURE_ALL,
                            ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_PROBABILISTIC_CAPTURE,
                            ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_MICROBURST_CAPTURE][sampler_mode]
        except:
            log("Invalid value for -sampler_mode {} argument".format(sampler_mode))
            return ifcs_ctypes.IFCS_INVAL

        # Get capture rate
        if sampler_mode == ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_PROBABILISTIC_CAPTURE:
            capture_rate = int(res.capture_rate)
            # Validate 'capture_rate' for range of 10-16777215
            if (capture_rate < 10) or (capture_rate > 16777215):
                log("Invalid value for capture_rate: " + format(capture_rate))
                return ifcs_ctypes.IFCS_INVAL
        else:
            capture_rate = None

        # Get Microburst Capture mode parameters
        if sampler_mode == ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_MICROBURST_CAPTURE:
            avg_packet_rate = int(res.avg_packet_rate)
            max_packets_per_burst = int(res.max_packets_per_burst)
            # Validate 'avg_packet_rate' for range of 122-100000
            if (avg_packet_rate < 122) or (avg_packet_rate > 100000):
                log("Invalid value for avg_packet_rate: " + format(avg_packet_rate))
                return ifcs_ctypes.IFCS_INVAL
            # Validate 'max_packets_per_burst' for range of 122-100000
            if (max_packets_per_burst < 64) or (max_packets_per_burst > 16384):
                log("Invalid value for max_packets_per_burst: " + format(max_packets_per_burst))
                return ifcs_ctypes.IFCS_INVAL
        else:
            avg_packet_rate = None
            max_packets_per_burst = None
        # Get src mac addr
        src_mac_flds = res.smac.split(":")
        # Prepending 0x to each element in mac addr
        src_mac_flds = ["0x"+i for i in src_mac_flds]
        src_mac = [int(i, 0) for i in src_mac_flds]
        # Convert list to tuple
        src_mac = tuple(src_mac)
        # Get Dest mac addr
        dest_mac_flds = res.dmac.split(":")
        # Prepending 0x to each element in mac addr
        dest_mac_flds = ["0x"+i for i in dest_mac_flds]
        dest_mac = [int(i, 0) for i in dest_mac_flds]
        # Convert list to tuple
        dest_mac = tuple(dest_mac)
        # Get src ip
        src_ip_l = res.sip.split(".")
        src_ip_l = [int(i, 0) for i in src_ip_l]
        # Get dest ip
        dest_ip_l = res.dip.split(".")
        dest_ip_l = [int(i, 0) for i in dest_ip_l]
        srcIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        destIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        # Convert IP and Mask to 32bit values
        src_ip = src_ip_l[0] << 24 | src_ip_l[1] << 16 | src_ip_l[2] << 8 | src_ip_l[3]
        dest_ip = dest_ip_l[0] << 24 | dest_ip_l[1] << 16 | dest_ip_l[2] << 8 | dest_ip_l[3]
        collectorType = ifcs_ctypes.IFCS_COLLECTOR_TYPE_HDC

        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE_TYPE
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_node_attr_get(
                    self.cli.node_id, 1,
                    pointer(out_attr),
                    pointer(actual_count)))
        if rc:
            log("Device Type get failure rc: {}".format(rc))
            return rc

        self.deviceType = out_attr.value.u32

        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_SWITCH_ID
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_node_attr_get(
                    self.cli.node_id, 1,
                    pointer(out_attr),
                    pointer(actual_count)))
        if rc:
            log("Switch id get failure rc: {}".format(rc))
            return rc

        self.switchId = out_attr.value.u32

        # Get sysport
        rc  = self._get_sysport_from_devport_(self.cli.node_id, dev_port)
        if rc:
            return rc

        # Make sure HDC is enabled in node.
        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_VIZ_HDC_ENABLE
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("HDC enable flag get failure rc: {}".format(rc))
            return rc
        if out_attr.value.data != ifcs_ctypes.IFCS_BOOL_TRUE:
            log('HDC attribute is not enabled in node. It must be set before enabling node. The option to use in yaml is viz_hdc_enable: "1"')
            return ifcs_ctypes.IFCS_INVAL

        if cpu_queue is not None:
            # Create Host If Trap
            rc = self.__host_if_trap_create(
                self.cli.node_id, cpu_queue, meter_cir, meter_burst_size)
            if rc:
                return rc

        # Step-B14:
        # Create Collector (C_1)) with:
        # ==> local destination
        # Create HDC collector
        try:
            rc = self._collector_create_(self.cli.node_id, collectorType=collectorType,
                                         srcMac=src_mac, destMac=dest_mac,
                                         srcIpFamily=srcIpFamily, destIpFamily=destIpFamily,
                                         srcIp=int(src_ip), destIp=int(dest_ip),
                                         dscp=dscp, ttl=ttl, localDestination = self.sysPort if cpu_queue is None else self.hostifTrap,
                                         dot1qVlan = (int(res.vlan) & 0xFFF if res.vlan is not None else None),
                                         vizTc=viz_tc, ipv4DfFlag=ipv4_df_flag)
        except Exception as e:
            rc = ifcs_ctypes.IFCS_DRIVER_ERROR
            log("Exception during HDC collector create: {}".format(e))
        if rc:
            self.__host_if_trap_delete(self.cli.node_id)
            log("HDC Collector create failed rc: {}".format(rc))
            return rc

        # Step-B15:
        # Create Collector Set (CS_1)) consisting of:
        # ==>  member collector (C_1)
        rc  =  self._collector_set_create_(self.cli.node_id, collectorSetType=ifcs_ctypes.IFCS_COLLECTOR_TYPE_HDC)

        if rc:
            log("HDC Collector set failed rc: {}".format(rc))
            # Cleanup collector
            self._cleanup_collector(self.cli.node_id)
            self.__host_if_trap_delete(self.cli.node_id)
            return rc

        rc  = self._add_members_(self.hdc_collector_set_handle, [self.hdc_collector_handle])
        if rc:
            log("HDC Add members to Collector set failed rc: {}".format(rc))
            self._cleanup_collector_set(self.cli.node_id)
            self._cleanup_collector(self.cli.node_id)
            self.__host_if_trap_delete(self.cli.node_id)
            return rc

        # Step-B16:
        # Create Visibility Sampler (VS_1) and
        # ==> configure it to capture at rate of 'capture_rate' PPS
        # ==> with each microburst to capture max of 'microburstCaptureAvgPacketRate' packets.
        # Create Visibility Sampler and configure it to sample every packet
        rc  =  self._visibility_sampler_create_(self.cli.node_id,
                                                type=ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_TYPE_HDC,
                                                mode=sampler_mode,
                                                probabilisticCaptureRate=capture_rate,
                                                microburstCaptureAvgPacketRate=avg_packet_rate,
                                                microburstCaptureMaxPacketsPerBurst=max_packets_per_burst)
        if rc:
            log("HDC Visibility Sampler create failed rc: {}".format(rc))
            self._cleanup_collector_set(self.cli.node_id)
            self._cleanup_collector(self.cli.node_id)
            self.__host_if_trap_delete(self.cli.node_id)
            return rc

        return ifcs_ctypes.IFCS_SUCCESS

    def delete_instance(self,args):
        log_dbg(1, "in delete_instance:")

        self.nodeID = self.cli.node_id

        if not self.hdc_delay_threshold_handle:
            log("HDC Delay Threshold deletion failure; handle: {}".format(self.hdc_delay_threshold_handle))

        if (self.hdc_collector_handle == 0):
            log("HDC Collector cleanup failed; handle: {}".format(self.hdc_collector_handle))

        if (self.hdc_collector_set_handle == 0):
            log("HDC Collector Set cleanup failed; handle: {}".format(self.hdc_collector_set_handle))

        if (self.hdc_visibility_sampler_handle == 0):
            log("HDC Visibility Sampler cleanup failed; handle: {}".format(self.hdc_visibility_sampler_handle))
            return ifcs_ctypes.IFCS_NOTFOUND

        # Delete Delay Threshold (all in the array, if any)
        log_dbg(1,"Delay threshold: {} exists".  format(len(self.hdc_delay_threshold_handle)))
        for index in compat_xrange(len(self.hdc_delay_threshold_handle)):
            self.handle = self.hdc_delay_threshold_handle[index]
            delay_threshold = self.hdc_delay_threshold_value[index]
            if self.handle != 0:
                rc = self._delay_threshold_handle_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
                if rc:
                    log("Delay threshold delete {} failed rc: {}".format(delay_threshold, rc))
                    return rc
                else:
                    pass
                    log_dbg(1,"Delay threshold {} delete success".format(delay_threshold))
                    self.handle = 0
                    delay_threshold = 0

        if self.hdc_delay_threshold_value:
            del self.hdc_delay_threshold_value [:]
        if self.hdc_delay_threshold_handle:
            del self.hdc_delay_threshold_handle [:]

        # Delete Visibility Sampler
        if self.hdc_visibility_sampler_handle != 0:
            self.handle = self.hdc_visibility_sampler_handle
            self._visibility_sampler_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        self.hdc_visibility_sampler_handle = 0

        # Remove collector from collector set and delete collector set
        if self.hdc_collector_set_handle != 0:
            self._remove_members_(self.hdc_collector_set_handle, [self.hdc_collector_handle])
            self.handle = self.hdc_collector_set_handle
            self._collector_set_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)

        # Delete collector
        if self.hdc_collector_handle != 0:
            self.handle = self.hdc_collector_handle
            self._collector_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        self.__host_if_trap_delete(self.nodeID)
        self.hdc_collector_set_handle = 0
        self.hdc_collector_handle = 0
        self.handle = 0
        self.sysPort = None

        return 0

    def apply_instance(self,args):
        log_dbg(1, "in HDC apply instance")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        parser = argparse.ArgumentParser(description='HDC Policy apply',
                                         prog='config hdc apply_instance',
                                         formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')

        requiredArgs.add_argument('-delay_threshold', action="store",
                                    help='Delay threshold value in units of nanoseconds ' \
                                         '10 - 16,000,000',
                                    required=False, type=int)
        requiredArgs.add_argument('-queue', action="store",
                                    help='One or more Class of Service Queues (0-7). ' \
                                         'Specify one queue or comma separated queues ' \
                                         'or range of queues. ' \
                                         'Examples: 1 | 0,4,6 | 1-4',
                                    required=True)
        requiredArgs.add_argument('-devport_all', action="store_true",
                                    help='All valid Device ports',
                                    required=False)
        requiredArgs.add_argument('-devport', action="store",
                                    help='Device port. Actual range depends on configuration',
                                    required=False, type=int)
        requiredArgs.add_argument('-enable', action="store_true",
                                    help='Enable HDC policy',
                                    required=False)
        requiredArgs.add_argument('-disable', action="store_true",
                                    help='Disable HDC policy',
                                    required=False)

        try:
            res = parser.parse_args(self.arg_list)
        except:
            if len(self.arg_list) == 1 and self.arg_list[0] in ['-h', '--help']:
                return 0
            log('apply_instance: Missing arguments or invalid arguments provided')
            return 1

        # Get enable/disable value of apply_policy
        if res.enable:
            apply_policy = ifcs_ctypes.IFCS_BOOL_TRUE
            # handle delay_threshold as optional only for 'enable'
            if not res.delay_threshold:
                log("Specify delay_threshold for policy '-enable' option!!!")
                return ifcs_ctypes.IFCS_INVAL
            else:
                # Get delay_threshold
                delay_threshold = int(res.delay_threshold)
                # Validate 'delay_threshold' for range of 100ns to 16ms
                if (delay_threshold < 100) or (delay_threshold > 16000000):
                    log("Invalid value for delay_threshold: " + format(delay_threshold))
                    return ifcs_ctypes.IFCS_INVAL
        elif res.disable:
            apply_policy = ifcs_ctypes.IFCS_BOOL_FALSE

        # initialize 'dev_port'
        dev_port = 0
        self.devport_all_list = []
        # 'dev_port' <devport> parameter IS specified
        if (res.devport) is not None:
            # Get dev_port
            dev_port = int(res.devport)
            # 'devport_all' parameter IS specified
            if res.devport_all:
                log("Do not specify both '-devport_all' & specific devport " + format(dev_port))
                return ifcs_ctypes.IFCS_INVAL
            else:
                # Validate 'dev_port'/'devport_all' options
                if (dev_port == 0):
                    log("Devport cannot be 0 !!!")
                    return ifcs_ctypes.IFCS_INVAL
                else:
                    self.devport_all_list.insert(0, res.devport)
                    self.num_devports     = len(self.devport_all_list)
        # 'dev_port' <devport> parameter is NOT specified
        else:
            if not res.devport_all:
                log("Specify either '-devport_all' or a specific devport with '-devport <devportID>'")
                return ifcs_ctypes.IFCS_INVAL
            else:
                self.devport_all_list = self._get_devport_list_()
                self.num_devports     = len(self.devport_all_list)

        # Validate 'enable'/'disable' options
        if (res.enable) and (res.disable):
            log("Do not specify both '-enable' & '-disable' together!!!")
            return ifcs_ctypes.IFCS_INVAL
        elif ( not (res.enable) ) and ( not (res.disable) ):
            log("Specify either '-enable' or '-disable' for policy!!!")
            return ifcs_ctypes.IFCS_INVAL

        # Get Class of Service Queue
        queue_ids = self._parse_queue_ids_(res.queue)
        self.cos_queue_ids = queue_ids

        # Validate 'queue' values
        if not queue_ids:
            log('Invalid value for -queue argument')
            return ifcs_ctypes.IFCS_INVAL

        # Step-B17:
        # Create Delay Threshold with a
        # ==> threshold value of 'delayThreshold'

        # Create the Delay Threshold & HDC Policy only for 'enable'
        if res.enable:
            # Create Delay threshold configure it to sample every packet
            rc  =  self._delay_threshold_create_(self.cli.node_id,
                                                 delayThreshold=delay_threshold)
            if rc:
                log("HDC Delay threshold create failed rc: {}".format(rc))
                return rc

            else:
                pass
                log_dbg(1, "HDC Delay threshold create success")

            # Step-B18:
            # ==> Create a HDC policy with:
            # ==> Delay threshold as 'DTH_1',
            # ==> Visibility Sampler as 'VS_1',
            # ==> Collector Set as 'CS_1'
            rc  =  self._hdc_policy_create_(collector_set_handle=self.hdc_collector_set_handle,
                                            delay_threshold_handle=self.hdc_delay_threshold_handle[self.curr_index],
                                            visibility_sampler_handle=self.hdc_visibility_sampler_handle)

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                self.hdc_policy = None
                log("HDC policy creation failed rc: {}".format(rc))
                return rc
            else:
                pass
                # Insert this created policy to the array of HDC policy
                self.hdc_policy_arr.insert(self.curr_index, self.hdc_policy)
                log_dbg(1,"HDC policy creation success")

        # Step-B19:
        # ==> Setup HDC Policy on Queue (devport, queue_id) and enable HDC
        rc  =  self._hdc_policy_queue_apply_(self.cli.node_id,
                                             policy=self.hdc_policy,
                                             enable=apply_policy,
                                             devport=self.devport_all_list,
                                             queue=queue_ids)

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("HDC policy apply on queue {} devport {} failed rc: {}".format(queue_ids, self.devport_all_list, rc))
            self._cleanup_hdc_policy()
        else:
            self.hdc_policy = None
            pass
            log_dbg(1,"HDC Policy apply on queue {} devport {} success".format(queue_ids, self.devport_all_list))

        return rc

    def get_queue_status(self,args):
        log_dbg(1, "in get_queue_status:")

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        parser = argparse.ArgumentParser(description='HDC Policy get queue status',
                                         prog='config hdc get_queue_status',
                                         formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')

        requiredArgs.add_argument('-queue', action="store",
                                    help='One or more Class of Service Queues (0-7). ' \
                                         'Specify one queue or comma separated queues ' \
                                         'or range of queues. ' \
                                         'Examples: 1 | 0,4,6 | 1-4',
                                    required=True)
        requiredArgs.add_argument('-devport', action="store",
                                    help='Device port. Actual range depends on configuration',
                                    required=True, type=int)
        self.nodeID = self.cli.node_id

        try:
            res = parser.parse_args(self.arg_list)
        except:
            if len(self.arg_list) == 1 and self.arg_list[0] in ['-h', '--help']:
                return 0
            log('get_queue_status: Missing arguments or invalid arguments provided')
            return 1

        # Get dev_port
        dev_port = int(res.devport)

        # Get Class of Service Queue
        queue_ids = self._parse_queue_ids_(res.queue)
        self.cos_queue_ids = queue_ids

        # Validate 'queue' values
        if not queue_ids:
            log('Invalid value for -queue argument')
            return ifcs_ctypes.IFCS_INVAL

        rc = self._hdc_policy_show_queue_(self.cli.node_id,
                                          devport=dev_port,
                                          queue_l=self.cos_queue_ids)
        if rc == True:
            log('True')
        else:
            log('False')
        return 0

    def _hdc_policy_delete_(
            self,
            ifcsCall=True):

        log_dbg(1, "in _hdc_policy_delete_:")

        self.hdc_policy = ifcs_ctypes.ifcs_hdc_policy_t()

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hdc_policy_t_init(
                    pointer(self.hdc_policy)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                self.hdc_policy = None
                log("HDC policy deletion failed rc: {}".format(rc))
                return
            else:
                pass
                log_dbg(1,"HDC policy deletion success")

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hdc_policy_t_collector_set_set(
                    pointer(self.hdc_policy),
                    ifcs_ctypes.IFCS_NULL_HANDLE))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Remove Collector Set from HDC policy failed rc: {}".format(rc))
            else:
                pass
                log_dbg(1,"Remove Collector Set from HDC policy success")

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hdc_policy_t_visibility_sampler_set(
                    pointer(self.hdc_policy),
                    ifcs_ctypes.IFCS_NULL_HANDLE))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Remove Visibility Sampler to HDC policy failed rc: {}".format(rc))
            else:
                pass
                log_dbg(1,"Remove Visibility Sampler to HDC policy success")

    def _cleanup_hdc_policy(self, expRC=None):
        log_dbg(1, "in _cleanup_hdc_policy:")

        if self.hdc_policy is not None:
            # Disable the HDC Policy on Queue
            self._hdc_policy_queue_apply_(self.cli.node_id,
                                          enable=ifcs_ctypes.IFCS_BOOL_FALSE,
                                          queue=self.cos_queue_ids)
            # Remove the HDC policy from Queue
            self._hdc_policy_delete_()
            self._hdc_policy_queue_apply_(self.cli.node_id,
                                          policy=self.hdc_policy,
                                          queue=self.cos_queue_ids)

    def _collector_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False,
            ifcsCall=True):
        log_dbg(1, "in _collector_delete_:")

        if bulk is True and ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{} actual:{}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector Delete failed')
        elif ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{} actual:{}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector Delete failed')

    def _cleanup_collector(self, expRC=None):
        log_dbg(1, "in _cleanup_collector:")

        if self.hdc_collector_handle != 0:
            self.handle = self.hdc_collector_handle
            rc = self._collector_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        if rc:
            log("HDC Collector cleanup failed rc: {}".format(rc))
        else:
            self.hdc_collector_handle = 0
            self.handle = 0
        return rc

    def _collector_set_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False,
            ifcsCall=True):
        log_dbg(1, "in _collector_set_delete_:")

        if bulk is True and ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{} actual:{}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector_set Delete failed')
        elif ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{} actual:{}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'collector_set Delete failed')

    def _cleanup_collector_set(self, expRC=None):
        log_dbg(1, "in _cleanup_collector_set:")

        if self.hdc_collector_set_handle != 0:
            self._remove_members_(self.hdc_collector_set_handle, [self.hdc_collector_handle])
            self.handle = self.hdc_collector_set_handle
            rc = self._collector_set_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        if rc:
            log("HDC Collector Set cleanup failed rc: {}".format(rc))
        else:
            self.hdc_collector_set_handle = 0
            self.handle = 0
        return rc

    def _delay_threshold_handle_delete_(
            self,
            expRc=None,
            customLog=None,
            ifcsCall=True):
        log_dbg(1, "in _delay_threshold_handle_delete_:")

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_delay_threshold_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                if rc:
                    log("HDC Delay Threshold deletion failure rc: {}".format(rc))
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'Delay Threshold Delete failed')
            return rc

    def _cleanup_delay_threshold(self, expRC=None):
        log_dbg(1, "in _cleanup_delay_threshold:")

        if self.hdc_delay_threshold_handle != 0:
            self.handle = self.hdc_delay_threshold_handle
            rc = self._delay_threshold_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        if rc:
            log("HDC Delay Threshold cleanup failed rc: {}".format(rc))
        else:
            self.hdc_delay_threshold_handle = 0
            self.handle = 0
        return rc

    def _visibility_sampler_delete_(
            self,
            expRc=None,
            customLog=None,
            ifcsCall=True):
        log_dbg(1, "in _visibility_sampler_delete_:")

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_visibility_sampler_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{} actual:{}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    ifcsObj.raiseExpOnFail(rc, customLog)
                else:
                    ifcsObj.raiseExpOnFail(rc, 'Visibility Sampler Delete failed')

    def _cleanup_visibility_sampler(self, expRC=None):
        if self.hdc_visibility_sampler_handle != 0:
            self.handle = self.hdc_visibility_sampler_handle
            rc = self._visibility_sampler_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        if rc:
            log("HDC Visibility Sampler cleanup failed rc: {}".format(rc))
        else:
            self.hdc_visibility_sampler_handle = 0
            self.handle = 0
        return rc

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create_instance', 'Create HDC instance'])
        table.add_row(['delete_instance', 'Delete HDC instance'])
        table.add_row(['apply_instance', 'Apply HDC policy'])
        table.add_row(['get_queue_status', 'Get queue status'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        telemetry_hdc_help_string = """
Usage::

    Type "config hdc <command>" followed by -h to see command's sub-options.
"""
        log(telemetry_hdc_help_string)
