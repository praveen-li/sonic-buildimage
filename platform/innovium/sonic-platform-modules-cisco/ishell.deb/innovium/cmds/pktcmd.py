
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import shlex
import argparse
import random
import time


from testutil import pkt

from testutil.util import hexdump
from verbosity import *
from cmdmgr import Command
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

from struct import *
from ifcs_cmds.devport import Devport as Devport
from collections import OrderedDict

# temporary, to provide backtrace on breakage
import sys,traceback

expected_packets = [[[] for i in range(49)] for j in range(7)]
tx_count = 0
rx_count = 0
rx_drop_count = 0

def rx_verify(nodeId, user_data, packet):
    global tx_count
    global rx_count
    global rx_drop_count
    global expected_packets

    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    rx_queue = packet.contents.queue_num
    packet_data = cast(buf, POINTER(c_char))
    packet_data = packet_data[:buf_len]
    #print "Rx packet:"
    #hexdump(packet_data)
    tx_ring = ord(packet_data[12]) # skip the DMAC-SMAC

    if not(expected_packets[tx_ring][rx_queue]):
        print("Unexpected packet: len:0x%04x tx_r:%d rx_q:%d rx_count:%d tx_count:%d"
              % (buf_len, tx_ring, rx_queue, rx_count, tx_count))
        hexdump(packet_data)
        #trigger(0, 1)

    # cur_pkt_idx = ((ord(packet_data[1]) << 16) + (ord(packet_data[2]) << 8) + ord(packet_data[3]))
    # print("RX rx:%d drop:%d tx:%d q_cnt:0x%06x len:0x%04x tx_r:0x%02x rx_q:0x%02x"
    #       % (rx_count, rx_drop_count, tx_count, cur_pkt_idx, buf_len, tx_ring, rx_queue))
    # hexdump(packet_data[:16]) # [-16:] [:16]

    expected = expected_packets[tx_ring][rx_queue].pop(0)
    if (packet_data != expected[24:]):
        # We failed to match, so run down the Q expected packets in case of DTM drop
        test_expected = expected
        test_rx_drop_count = rx_drop_count;
        while True:
            if (packet_data[0:3] == expected[24:27]):
                break

            if not(expected_packets[tx_ring][rx_queue]):
                trigger(0, 0)
                print("Bad Match rx_count:%d rx_drop:%d tx_r:%d rx_q:%d tx_count:%d len:0x%04x"
                      % (rx_count, rx_drop_count, tx_count, tx_ring, rx_queue, buf_len))
                hexdump(packet_data)
                print("Expected packet:")
                hexdump(expected[24:])
                print("Last packet seen: (test_drop:%d)" % (test_rx_drop_count))
                hexdump(test_expected[24:])
                trigger(0, 1)

            test_rx_drop_count += 1
            test_expected = expected_packets[tx_ring][rx_queue].pop(0)

    rx_count += 1
    if (rx_count % 10000 == 0):
        print("RX rx:%d drop:%d" % (rx_count, rx_drop_count))

    return


def rx_lite_verify(nodeId, user_data, packet):
    global expected_packets
    global rx_count
    global rx_drop_count

    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    rx_queue = packet.contents.queue_num
    packet_data = cast(buf, POINTER(c_char))
    packet_data = packet_data[:buf_len]
    tx_ring = ord(packet_data[0])

    if not(expected_packets[tx_ring][rx_queue]):
        print("Unexpected packet1: len:0x%04x tx_r:%d rx_q:%d rx_count:%d tx_count:%d"
              % (buf_len, tx_ring, rx_queue, rx_count, tx_count))
        hexdump(packet_data)
        trigger(0, 1)

    expected = expected_packets[tx_ring][rx_queue].pop(0)
    if (packet_data[0:3] != expected[24:27]):
        # We failed to match, so run down the Q expected packets in case of DTM drop
        test_expected = expected
        test_rx_drop_count = rx_drop_count;
        while True:
            if (packet_data[0:3] == expected[24:27]):
                break

            if not(expected_packets[tx_ring][rx_queue]):
                trigger(0, 0)
                print("Bad Match rx_count:%d rx_drop:%d tx_r:%d rx_q:%d tx_count:%d len:0x%04x"
                      % (rx_count, rx_drop_count, tx_count, tx_ring, rx_queue, buf_len))
                hexdump(packet_data)
                print("Expected packet:")
                hexdump(expected[24:])
                print("Last packet seen: (test_drop:%d)" % (test_rx_drop_count))
                hexdump(test_expected[24:])
                trigger(0, 1)

            test_rx_drop_count += 1
            test_expected = expected_packets[tx_ring][rx_queue].pop(0)

    rx_count += 1
    if (rx_count % 10000 == 0):
        print("RX rx:%d drop:%d" % (rx_count, rx_drop_count))

    return

# Class implements Pkt related command
class Pkt(Command):

    def __init__(self, cli):
        self.sub_cmds = {'send'        : self.send,
                         'sendbob'     : self.sendbob,
                         'speedtest'   : self.speedtest,
                         'recv'        : self.recv,
                         'l2setup'     : self.l2setup,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.cli = cli
        self.arg_list = []
        self.cbfn = None
        super(Pkt, self).__init__()

    def run_cmd(self, args):
        log_dbg(1, "in Pkt run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except Exception as ex:
            traceback.print_exc(file=sys.stdout)
            print "run cmd: ", type(ex).__name__, ex.args
            self.cli.error()
            self.help(args)
            return
        except (KeyError):
            log_dbg(1, "PktKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "PktValueError")
            self.help(args)
        except:
            log_dbg(1, "PktOtherError")
            self.help(args)
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return self.sub_cmds.keys()

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def sendbob(self, args):
        global expected_packets
        global tx_count
        global rx_count
        global rx_drop_count

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        ib = int(self.arg_list.pop(0))
        ib_num = int(self.arg_list.pop(0))
        count = int(self.arg_list.pop(0))

        if (len(self.arg_list) > 0):
            test_size = int(self.arg_list.pop(0))
        else:
            test_size = 0

        nodeId = 0

        # Set up the listener
        cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(rx_verify)
        ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(nodeId, None, cbfn)

        # create the trap
        attr_count = 1
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

        # Any handle
        trap_handle = ifcs_ctypes.ifcs_handle_t()
        trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(ifcs_ctypes.IFCS_HOSTIF_TRAP_SWITCH_TO_CPU)
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                       attr_count, pointer(attr))
        assert (rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST), "STC Trap enable failed: rc = [" + str(rc) + "]"

        # Setup test
        if (test_size == 0):
            print("Testing count:" +str(count) + " length: rnd")
        else:
            print("Testing count:" +str(count) + " length:" + str(test_size))

        tx_q_count = [0 for i in range(49)]
        start_drop_count = pkt.get_dtm_discard_count()
        tx_count = 0
        rx_count = 0
        rx_drop_count = 0
        drop_count = 0

        start_time = time.time()

        # test_size = 63
        for i in range(count):
            # if (i % 2048 == 0):
            #     test_size += 1

            # min length is 64 with inner header, max is 9228 with all headers
            if (ib_num == 33):
                if (test_size == 0):
                    length = random.randint(0x4c-12, 128-24)
                else:
                    length = test_size
            else:
                #length = random.randint(0x4c, 128-12)
                if (test_size == 0):
                    length = random.randint(0x4c, 128-12)
                else:
                    length = test_size

            tx_busy_count = 0
            startByte = random.randint(0, 255)
            startByte = tx_count % 256
            tx_ring = tx_count % 4 #random.randint(0, 3)
            rx_queue = tx_ring #random.randint(0, 7) # Bob only can use Q 0-7

            curByte = startByte
            smac_dmac_sz = 12 # 12 bytes
            for j in range(smac_dmac_sz):
                if (j == 0):
                    bytes = chr(0)
                elif (j == 5):
                    bytes += chr(0xaa)
                elif (j == 11):
                    bytes += chr(0xbb)
                else:
                    bytes += chr(0)

            # Start with some special bytes to ID the packet
            bytes +=  chr(tx_ring)
            bytes += chr((tx_q_count[rx_queue] >> 16) & 0xff)
            bytes += chr((tx_q_count[rx_queue] >> 8) & 0xff)
            bytes += chr(tx_q_count[rx_queue] & 0xff)
            bytes += chr(rx_queue)
            bytes += chr(length >> 8)
            bytes += chr(length & 0xff)

            for j in range(length - smac_dmac_sz - 7):
                bytes += chr(curByte)
                curByte = (curByte + 1) & 0xff

            '''
            for j in range(length - 7):
                bytes += chr(curByte)
                curByte = (curByte + 1) & 0xff
            '''

            if (ib_num == 33):
                devport_obj = Devport(self.cli)
                sysport_hndl = devport_obj.getSysport(0)
                cpu_sysport = ifcs_ctypes.IFCS_HANDLE_VALUE(sysport_hndl)
                # CPU packet: set the vf2 queue for proper operation, set the vf0 queue so the result looks right
                packet = pkt.ldh_vf2(ib, ib_num, rx_queue) + pkt.ldh_vf0(ib, 33, cpu_sysport, rx_queue) + bytes
                length += 12 + 12
                expected_packets[tx_ring][rx_queue].append(packet)
            else:
                packet = pkt.ldh_vf2(ib, ib_num, rx_queue) + bytes
                length += 12

            # print("TX tx:%d q_cnt:0x%06x len:0x%04x 1st:0x%02x last:0x%02x rx_q:0x%02x tx_r:0x%02x"
            #       % (tx_count, tx_q_count[rx_queue], length, startByte, curByte, rx_queue, tx_ring))
            print "Tx packet:"
            hexdump(packet)

            p = cast(packet, c_void_p);
            while (1):
                rc = im_hostif_send_packet_zcopy(nodeId, tx_ring, p, length)
                if (rc == ifcs_ctypes.IFCS_SUCCESS):
                    break
                if (rc != ifcs_ctypes.IFCS_BUSY):
                    log_err('Packet send to pcie failed')
                    attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
                    rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                                   attr_count, pointer(attr))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "STC Trap disable failed: rc = [" + str(rc) + "]"
                    ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(nodeId)
                    return
                tx_busy_count += 1
                time.sleep(0.001)

            tx_count += 1
            tx_q_count[rx_queue] += 1

        # trigger(0, 0)

        myflag = 0;
        if (ib_num == 33):
            old_recv_count = rx_count - 1  # prevent the print from firing the first time through
            drop_count = pkt.get_dtm_discard_count()
            while (tx_count != (rx_count + (drop_count - start_drop_count))):
                myflag = myflag + 1
                if (old_recv_count == rx_count):
                    print("Waiting for rx:%d rx_drop:%d dtm_drop:%d"
                           % (tx_count - rx_count, rx_drop_count, (drop_count - start_drop_count)))
                    for i in range(7):
                        for j in range(49):
                            if len(expected_packets[i][j]) != 0:
                                print("TX_R:%d RX_Q:%d pending:%d" % (i, j, len(expected_packets[i][j])))
                old_recv_count = rx_count

                time.sleep(0.1)
                drop_count = pkt.get_dtm_discard_count()
                if(myflag == 3):
                    break

        stop_time = time.time()

        # clear traps & handlers
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                       attr_count, pointer(attr))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "STC Trap disable failed: rc = [" + str(rc) + "]"

        ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(nodeId)

        if (start_time == stop_time):
            print ("Done elapsed:%0.2fs packets per second: (run too short)" % (stop_time - start_time))
        else:
            print ("Done elapsed:%0.2fs packets per second:%0.2f"
                   % ((stop_time - start_time), ((tx_count + rx_count) / (stop_time - start_time))))
        print("  Sent:%d tx_busy:%d Rx:%d RxDrop:%d DTM_drop:%d"
              % (tx_count, tx_busy_count, rx_count, rx_drop_count, (drop_count - start_drop_count)))
        return


    def speedtest(self, args):
        global expected_packets
        global tx_count
        global rx_count

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        nodeId = 0
        ib = int(self.arg_list.pop(0))
        ib_num = int(self.arg_list.pop(0))
        count = int(self.arg_list.pop(0))

        sizes = map(int, self.arg_list)
        if len(sizes) == 0:
            sizes = [64, 128, 512, 1024, 1500, 2048, 4096, 8192, 9204, -1500, -9204]

        # Set up the listener
        cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(rx_lite_verify)
        ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(nodeId, None, cbfn)

        attr_count = 1
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

        # Any handle
        trap_handle = ifcs_ctypes.ifcs_handle_t()
        trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(ifcs_ctypes.IFCS_HOSTIF_TRAP_SWITCH_TO_CPU)
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                       attr_count, pointer(attr))
        assert (rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST), "STC Trap enable failed: rc = [" + str(rc) + "]"

        for test_size in sizes:
            print("Testing count:" +str(count) + " length:" + str(test_size))

            tx_busy_count = 0
            start_drop_count = pkt.get_dtm_discard_count()
            tx_count = 0
            rx_count = 0
            rx_drop_count = 0
            tx_q_count = [0 for i in range(49)]

            start_time = time.time()

            for i in range(count):
                if (test_size >= 0):
                    length = test_size
                else:
                    length = random.randint(64, -test_size)

                tx_ring = tx_count % 4 #random.randint(0, 3)
                rx_queue = tx_ring #random.randint(0, 7)

                bytes  = chr(tx_ring)
                bytes += chr((tx_q_count[rx_queue] >> 16) & 0xff)
                bytes += chr((tx_q_count[rx_queue] >> 8) & 0xff)
                bytes += chr(tx_q_count[rx_queue] & 0xff)
                bytes += chr(0) * (length - 4)

                packet = pkt.ldh_vf2(ib, ib_num, rx_queue) + pkt.ldh_vf0(ib, 33, 33, rx_queue) + bytes
                length += 12 + 12
                expected_packets[tx_ring][rx_queue].append(packet)

                # print("TX tx:%d q_cnt:0x%06x len:0x%04x rx_q:0x%02x tx_r:0x%02x"
                #       % (tx_count, tx_q_count[rx_queue], length, rx_queue, tx_ring))
                # hexdump(packet[24:40])

                p = cast(packet, c_void_p)
                while (1):
                    rc = im_hostif_send_packet_zcopy(nodeId, tx_ring, p, length)
                    if (rc == ifcs_ctypes.IFCS_SUCCESS):
                        break
                    if (rc != ifcs_ctypes.IFCS_BUSY):
                        log_err('Packet send to pcie failed')
                        rc = ifcs_ctypes.ifcs_hostif_trap_delete(nodeId, trap_handle)
                        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete Trap entry failed: rc = [" + str(rc) + "]"
                        ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(nodeId)
                        return
                    tx_busy_count += 1
                    time.sleep(0.001)

                tx_count += 1

            #trigger(0, 0)
            tx_stop_time = time.time()

            old_recv_count = rx_count - 1  # prevent the print from firing the first time through
            drop_count = pkt.get_dtm_discard_count()
            old_drop_count = drop_count - 1
            while (tx_count != (rx_count + (drop_count - start_drop_count))):
                if ((old_recv_count == rx_count) and (old_drop_count == drop_count)):
                    print("Waiting for rx:%d dtm_drop:%d"
                          % (tx_count - (rx_count + (drop_count - start_drop_count)), (drop_count - start_drop_count)))
                old_recv_count = rx_count
                old_drop_count = drop_count

                time.sleep(0.1)
                drop_count = pkt.get_dtm_discard_count()

            rx_stop_time = time.time()

            if (test_size > 0):
                length = test_size
            else:
                length = -test_size / 2

            tx_elapsed = tx_stop_time - start_time
            tx_pps = count / (tx_stop_time - start_time)
            tx_bandwidth = tx_pps * length
            print("TX elapsed:%0.2fs count:%d tx_busy:%d length:%dB pps:%0.2f bandwidth(total):%0.1f Bps"
                  % (tx_elapsed, tx_count, tx_busy_count, length, tx_pps, tx_bandwidth))

            rx_elapsed = rx_stop_time - start_time
            rx_pps = rx_count / (rx_stop_time - start_time)
            rx_bandwidth = rx_pps * length
            print("RX elapsed:%0.2fs count:%d dropped:%d length:%dB pps:%0.2f bandwidth(total):%0.1f Bps"
                  % (rx_elapsed, rx_count, (drop_count - start_drop_count), length, rx_pps, rx_bandwidth))

        # clear traps & handlers
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(nodeId, trap_handle,
                                       attr_count, pointer(attr))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "STC Trap disable failed: rc = [" + str(rc) + "]"

        ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(nodeId)
        return

    #pkt send -d <dest> -o <option> -f <name>
    def send(self, args):
        log_dbg(1, "In Pkt Send")
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            parser = argparse.ArgumentParser(description='Transmit Packet via CPU',prog="pkt_send")
            parser.add_argument('-d', nargs=1, type=int, help='Packet destination Port')
            parser.add_argument('-o', nargs='+', type=int, help='Transmit Options')
            parser.add_argument('-f', type=str, help='Packet filename')
            res = parser.parse_args(self.arg_list)
            fname = res.f
            tx_opt = res.o[0]
            dest = res.d[0]
        except:
            self.help(args)
            return
        #Open File and retrive contents
        f = open(fname, 'r')
        a = (f.read()).split();
        data = (c_byte * 2048)()
        for i in range(len(a)):
            data[i] = int(a[i], 16)
        f.close()
        buf_len = 5
        pdata = cast(data, c_void_p)
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = tx_opt
            packet.trap_handle = 0 # is ignored
            if tx_opt == 0:
                packet.ssp = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dest)
                packet.dsp = 0
            else:
                packet.ssp = 0 # is ignored
                packet.dsp = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dest)
            packet.queue_num = 0 # is ignored
            packet.ring_num = 0
            packet.pkt_buf = pdata
            packet.pkt_buf_len = len(a)
        except Exception as e:
            print "exc", e
        rc = ifcs_ctypes.ifcs_hostif_send_packet(0, pointer(packet))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('Packet send to switch failed')
        return


    def l2setup(self, args):
        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT_HANDLE
        actual_count = c_uint32()

        sysport_hdl = (ifcs_ctypes.ifcs_handle_t * 5)

        for i in range(1,5):
            rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, i, pointer(attr),
                                    pointer(actual_count))
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('Sysport handle get failed')
            sysport_hdl[i] = attr.value.handle;

        stp_hdl = ifcs_ctypes.ifcs_handle_t(ifcs_ctypes.IFCS_MOD_STP, 99)
        rc = ifcs_ctypes.ifcs_stp_instance_create(0, pointer(stp_hdl), 0, 0)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('stp instance create failed')

        attr.id = ifcs_ctypes.IFCS_L2VNI_STP_INSTANCE
        attr.value.handle = stp_hdl
        l2vni_hdl = ifcs_ctypes.IFCS_HANDLE_L2VNI(10);
        rc = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), 1, pointer(attr))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('l2vni create failed')

        for i in range(1,5):
            rc = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl, sysport_hdl[i], ifcs_ctypes.IFCS_BOOL_TRUE)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('l2vni member add failed')

            rc = ifcs_ctypes.ifcs_stp_port_state_set(0, stp_hdl, sysport_hdl[i],
                                         ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('stp forwarding state set failed')

        attr_list = (ifcs_ctypes.ifcs_attr_t() * 2)()
        attr_list[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr_list[0].value.handle = sysport_hdl[1]
        attr_list[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr_list[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_STATIC
        l2entry = ifcs_ctypes.ifcs_l2entry_key_t()
        l2entry.l2vni_handle = l2vni_hdl
        l2entry.mac_addr = (c_ubyte * 6)()
        l2entry.mac_addr[0] = 1
        l2entry.mac_addr[1] = 1
        l2entry.mac_addr[2] = 1
        l2entry.mac_addr[3] = 1
        l2entry.mac_addr[4] = 1
        l2entry.mac_addr[5] = 1
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry), 2, pointer(attr_list))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('fdb create failed')


    def recv(self, args):
        def print_pkt(buf, buf_len):
            pdata = cast(buf, POINTER(c_byte * buf_len))
            for i in range(buf_len):
                print("{:02X}".format(pdata.contents[i])),
            print ""
            return

        ################################################################################
        # CPU receive Packet Callback Function
        # node_id - Node ID
        # event_num - Rx Event
        # user_data - Data
        # packet - Ifcs Packet
        ################################################################################
        def rx_cbfn(node_id, user_data, packet):
            rx_qnum = packet.contents.queue_num
            rx_trap_handle = packet.contents.trap_handle

            print("rx_cbfn: Packet Received via CPU: Len(" + str(packet.contents.pkt_buf_len) + ")"),
            #INFO("Packet Received via CPU: Len(" + str(packet.contents.pkt_buf_len) + ")")

            #FIXME: get src_port from SSP
            ssp = packet.contents.ssp
            assert ifcs_ctypes.IFCS_HANDLE_MODULE(ssp) == ifcs_ctypes.IFCS_MOD_SYSPORT, "SSP is not System Type Handle"

            src_port = int(ifcs_ctypes.IFCS_HANDLE_VALUE(ssp) - 1)

            print("rx_cbfn: Appending to Reveived Packet List\n"),
            print("rx_cbfn: Packet received from {0}\n".format(src_port)),

            buf_len = packet.contents.pkt_buf_len
            buf = c_char_p(packet.contents.pkt_buf)
            packet = cast(buf, POINTER(c_char))
            packet = packet[:buf_len]
            hexdump(packet)
            #print_pkt(buf, buf_len)

            return

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(rx_cbfn)
        if (ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(0, None, self.cbfn) != ifcs_ctypes.IFCS_SUCCESS):
            log_err("Error: registering callback funtion");
        log_dbg(1, "Packet Recieve callback registered")
        print("Packet Recieve callback registered")
        # create the trap
        attr_count = 1
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

        # Any handle
        trap_handle = ifcs_ctypes.ifcs_handle_t()
        trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(ifcs_ctypes.IFCS_HOSTIF_TRAP_SWITCH_TO_CPU)
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(0, trap_handle,
                                       attr_count, pointer(attr))
        assert (rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST), "STC Trap enable failed: rc = [" + str(rc) + "]"

        return

    def help(self, args):
        self.cli.error()
        print "Usage:"
        print "pkt send -d <dest> -o <option> -f <filename>    - send pkt from host port"
        print "pkt recv                                        - register a receive callback"
        print "pkt l2setup                                     - l2 setup"
        print "pkt sendbob <ib> <ib_port> <num>                - send <num> BOB packets to <ib_port>"
        print "pkt speedtest <ib> <ib_port> <count> [sizes...] - test tx and rx rates"
        print "pkt help or ?                                   - show this text"
