#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
from ctypes import *

def macAddrTupleToCByte(macAddr):
    '''Convert MAC address from tuple to ctypes - ubyte'''
    return (c_ubyte * 6)(*macAddr)

def macAddrCbyteToTuple(macAddr):
    '''Convert macaddr from c_byte array to Tuple'''
    return tuple(macAddr[i] for i in range(6))

def ip6AddrTupleToCByte(ipAddr):
    '''Convert IPV6 address from tuple to ctypes - ubyte'''
    return (c_ubyte * 16)(*ipAddr)

def ip6AddrCByteToTuple(ipAddr):
    '''Convert IPV6 address from c_byte array to Tuple'''
    return tuple(ipAddr[i] for i in range(16))

def alloc(objType, numElements = 1):
    '''Allocates an object Type object and initializes to 0'''
    if numElements > 1:
        ifcsObj = (objType * numElements)()
    else:
        ifcsObj = objType()
    memset(pointer(ifcsObj), 0, sizeof(objType) * numElements)
    return ifcsObj
