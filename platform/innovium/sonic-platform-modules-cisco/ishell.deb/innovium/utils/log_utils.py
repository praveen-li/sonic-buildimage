#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

# Filename: log_utils.py
from ctypes import *
from ifcs_ctypes import *

def get_logfile_name():
    logname_str = c_char_p(b" " * 1024)
    rc = im_get_logfile_name(logname_str, 1024)
    assert rc == IFCS_SUCCESS, "Couldnt get log filename "
    return str(logname_str.value.decode())

def get_apidata_name():
    logname_str = c_char_p(b" " * 1024)
    rc = im_get_apidata_name(logname_str, 1024)
    assert rc == IFCS_SUCCESS, "Couldnt get api data filename "
    return str(logname_str.value.decode())
