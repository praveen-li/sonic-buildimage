#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ifcs_ctypes import *
from ifcs_utils import *

# Implements Base Object for all IFCS SDK Objects
class ifcsObj(object):
    '''Base Class for all IFCS Objects'''

    # Dictionary of objects based on ifcs_handle_t
    handleObj = dict()

    def __init__(self, nodeId, handle):
        '''Initialize the Object: Handle and Node ID'''
        self.nodeId = nodeId
        self.handle = handle
        ifcsObj.handleObj[handle] = self

    def getNodeId(self):
        '''Get the Node Id of this object'''
        return self.nodeId

    def getHandle(self):
        ''' Return IFCS Handle of this object'''
        return self.handle

    @staticmethod
    def getObj(handle):
        '''Return Object corresponding to Handle
        handle - IFCS Handle of the Object
        '''
        return ifcsObj.handleObj[handle]

    def printHandle(self):
        '''Return a Hex Printable Handle'''
        return "{0:#0{1}x}".format(self.handle, 8)

    @staticmethod
    def raiseExpOnFail(status, msg):
        '''Raise an exception based on status
           The status is IFCS status, and the exception corresponds to the
           ifcs_status_t'''

        status_string = [
            (IFCS_SUCCESS, "ifcs_success"),
            (IFCS_UNINIT, "ifcs_uninit"),
            (IFCS_BUSY, "ifcs_busy"),
            (IFCS_CONFIG, "ifcs_config"),
            (IFCS_MEMORY, "ifcs_memory"),
            (IFCS_PARAM, "ifcs_param"),
            (IFCS_EXIST, "ifcs_exist"),
            (IFCS_MULTI_EXIST, "ifcs_multi_exist"),
            (IFCS_ENTRY_REPLACED, "ifcs_entry_replaced"),
            (IFCS_LENGTH_MISMATCH, "ifcs_length_mismatch"),
            (IFCS_NOTFOUND, "ifcs_notfound"),
            (IFCS_INVAL, "ifcs_inval"),
            (IFCS_UNSUPPORTED, "ifcs_unsupported"),
            (IFCS_RESOURCE_FULL, "ifcs_resource_full"),
            (IFCS_TIMEOUT, "ifcs_timeout")
        ]

        if status == IFCS_SUCCESS:
            return None

        INFO(msg + ' rc: {}'.format(status))
        for index in range(len(status_string)):
            if status == status_string[index][0]:
                expStr = status_string[index][1]
                raise Exception(expStr, status)

        INFO("Unknown IFCS Status Returned by API")
        raise ValueError("Unknown Status Returned by IFCS")
