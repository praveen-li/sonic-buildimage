#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import json
import shlex
import argparse
import os
import signal
import subprocess
from time import sleep
from   ifcs_ctypes import *
import datetime
import pdb
import logging
import random
from collections import OrderedDict

 
import inspect
import ntpath
from operator import itemgetter
from log_utils import *
import pickle
try:
    from icm_ctypes import *
except:
     pass



WBDUMPFILE = "wb.dump.json"

try:
    multi_ib_bitmap = int(pytest.config.getoption("--multi_ib_bitmap"))
except:
    multi_ib_bitmap = 0

valid_dev_ports_list=[]
map_count = 0
all_active_ibs = []
all_dev_ports = []

asic_temp_thread = None


try:
    # 32 x 4 + 20 x2 == 168 + 1 for CPU + 2 extra
    portmap = (icm_portmap_t * 171)()
except:
    class struct_icm_portmap_s(Structure):
        pass

    struct_icm_portmap_s.__slots__ = [
        'port',
        'ib',
        'ibport',
    ]
    struct_icm_portmap_s._fields_ = [
        ('port', c_uint16),
        ('ib', c_uint8),
        ('ibport', c_uint8),
    ]

    icm_portmap_t = struct_icm_portmap_s
    portmap = (icm_portmap_t * 131)()

# Generate CSV file with stats to insert into the database, sname and svalue can
# be anything, but are limited to 128 char. ABT will insert abt id, and convert testname
# to testid
def insertstatsdict(stats):
    major = ctypes.c_uint32(0)
    minor = ctypes.c_uint32(0)
    patch = ctypes.c_uint32(0)
    ifcs_get_version(pointer(major), pointer(minor), pointer(patch))
    sdkversion = "%d.%d.%d" % (major.value, minor.value, patch.value)

    # Start from right and look at the first entry that is 'test_.*py'
    testname = ""           # Best effort to get test name
    filename = str(int(time.time() * 1000)) + ".stats.csv" # Default value, non wrap-around number

    # Get time we are creating these entries
    now = str(datetime.datetime.now())

    # Start from right, look for the entry after splitting on '/' and matches test_.*.py
    for entry in reversed(sys.argv):
        values = entry.split('/')
        tname = values[-1]

        # Is this a test name?
        if re.match('test_.*.py', tname):
            testname = entry    # Save it
            filename = tname + ".stats.csv"
            break
        else:
            if 'test_' in entry and 'wrapper' not in entry:
                bkup_testname = entry
                bkup_filename = bkup_testname + ".stats.csv"

    if testname == "":
        # If code path reaches here, it means either a c test is run with base_ctest_wrapper
        # or the name of the test is incorrect (doesnot start with test_)
        testname = bkup_testname
        filename = bkup_filename

    # CSV dump all the entries out
    import csv
    with open(os.environ['WORKSPACE'] + "/logs/" + filename, 'wb') as csvfile:
        # write header line
        csvfile.write("sname,svalue,sdkversion,created,testname\n")

        # Write out data rows
        writer = csv.writer(csvfile)
        for key, value in stats.items():
            writer.writerow([key, value, sdkversion, now, testname])

# Compatibility with exported API
def insertstats(sname, svalue):
    stats = {}
    stats[sname] = svalue
    insertstatsdict(stats)

def disable_mac_learning(node):
    #disable mac learning with node_attr
    attr = ifcs_attr_t()
    rc = ifcs_attr_t_init(pointer(attr))
    assert rc == IFCS_SUCCESS
    attr.id = IFCS_NODE_ATTR_LEARN_ENABLE
    attr.value.data = 0
    rc = ifcs_node_attr_set(node, 1, pointer(attr))
    assert rc == IFCS_SUCCESS

def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def getSysportHandleFromDevPort(devPort):
    attr = ifcs_attr_t()
    actual_count = ctypes.c_uint32()
    nodeId = 0

    attr.id = IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_devport_attr_get(nodeId, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle


# The Class that will replace the asctime with what this generates, aka
# microsecond
class MyFormatter(logging.Formatter):
    _converter = datetime.datetime.fromtimestamp
    def formatTime(self, record, datefmt=None):
        ct = self._converter(record.created)
        if datefmt:
            stamp = ct.strftime(datefmt)
        else:
            tm = ct.strftime("%Y-%m-%d %H:%M:%S")
            stamp = "%s.%03d" % (tm, record.msecs)
        return stamp

# Create the logget
logger = logging.getLogger('pytest')

if not len(logger.handlers):
    # Setup the correct formatter
    console = logging.StreamHandler()
    FORMAT = '%(asctime)s [%(filename)s:%(lineno)d] %(levelname)s - %(message)s'
    formatter = MyFormatter(fmt=FORMAT, datefmt='%Y-%m-%d %H:%M:%S.%f')
    console.setFormatter(formatter)
    logger.addHandler(console)
    logger.setLevel(logging.INFO)      # Default level

# Create the helper function
INFO = logger.info
DEBUG = logger.debug
CRIT = logger.critical
WARN = logger.warning

def terminate_existing(port):
    searchcmd = "teralynx -p " + str(port)
    proc = subprocess.Popen(["pgrep", "-f", searchcmd],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate()

    # Terminate all the pids we found
    pidlist = stdout.split()
    for pid in pidlist:
        os.kill(int(pid), signal.SIGKILL)

def get_node_temp(node):
    # Get the node temp
    INFO("Capturing ASIC temparature...")
    attr_list = (ifcs_attr_t * 5)()
    for attr in attr_list:
        rc = ifcs_attr_t_init(pointer(attr))

    # Read all 5 sensors
    attr_list[0].id = IFCS_NODE_ATTR_MASTER_LAST_TEMP
    attr_list[1].id = IFCS_NODE_ATTR_REMOTE0_LAST_TEMP
    attr_list[2].id = IFCS_NODE_ATTR_REMOTE1_LAST_TEMP
    attr_list[3].id = IFCS_NODE_ATTR_REMOTE2_LAST_TEMP
    attr_list[4].id = IFCS_NODE_ATTR_REMOTE3_LAST_TEMP

    actual_count = ctypes.c_uint32()
    rc = ifcs_node_attr_get(node, 5, pointer(attr_list), pointer(actual_count))
    if rc != IFCS_SUCCESS:
        INFO("Failed to get master temp last, rc %d" % rc)

    INFO("ASIC master temp  %f C" % attr_list[0].value.flt)
    INFO("ASIC remote0 temp %f C" % attr_list[1].value.flt)
    INFO("ASIC remote1 temp %f C" % attr_list[2].value.flt)
    INFO("ASIC remote2 temp %f C" % attr_list[3].value.flt)
    INFO("ASIC remote3 temp %f C" % attr_list[4].value.flt)

def record_asic_temp(node, enable):
    global asic_temp_thread
    if enable:
        # Create the thread, start temp polling
        asic_temp_thread = TimerThread(interval=15, userFn=get_node_temp)
        asic_temp_thread.start()
    else:
        # Disable the thread during SDK deinit
        if asic_temp_thread:
            asic_temp_thread.cancel()


def init_ifcs(cfgfile=None, returnrc=False, bootmode=IFCS_BOOT_COLD, logfilename = '',\
              nodeJoin = True, nodeEnable =  True, icm_portmap = True, nosMode = False):

    try:
        if pytest.config.getoption("--api_mode"):
            nodeJoin = False
            nodeEnable = False
    except:
        pass
    #Initialize IFC Systems (allocates memory, ....)
    INFO( "Initializing IFCS, mode: %d" % bootmode)
    if not cfgfile:
        workspace = os.environ.get('WORKSPACE')
        config_file ="configs/yaml/model/inno.config.yaml"
        if pytest.config.getoption("--multi_ib_bitmap"):
            config_file = config_file + ".multi_ib"
        cfgfile = workspace + '/ifcs/' + config_file
    INFO( "cfgfile=%s" % cfgfile)
    nodes = c_uint32(0)
    if not logfilename:
        try:
            frameindex = 1
            curframe = inspect.currentframe()
            frames = inspect.getouterframes(curframe)
            while frameindex <= 8:
                logfilename = ntpath.basename(frames[frameindex][1][0:-3])
                if logfilename.startswith('test_'):
                    break
                else:
                    frameindex+=1
            if frameindex == 8:
                logfilename = 'test_init'
        except:
            logfilename = 'test_init'

    # Remove all '/' in the config file names and replace with -
    logfilename = logfilename.replace('/', '-')
    logfilename = logfilename.replace('.', '-')
    # If the length of the log filename is greater than 200
    # we need to truncate at 200 chars
    if len(logfilename) > 200:
        logfilename = logfilename[:200]
        INFO("Log filename truncated to: " + logfilename)

    if pytest.config.getoption("--netdev_single"):
        if os.getenv("IFCS_TARGET")!='device':
            INFO( "Netdev tests are only supported in device. Continue without this option.")
        else:
            if not cfgfile.endswith('.yaml'):
                INFO( "Netdev test is only supported for yaml based config")
                os._exit(90)
            config_file = open(cfgfile, "r")
            netdev_cfgfile = "/tmp/nd.yaml"
            config_nd_file = open(netdev_cfgfile, "w")
            for line in config_file:
              off = line.find("desc_count")
              if off != -1:
                 line += ' '*off
                 line += "netdev: \"true\"\n"
                 config_nd_file.write(line)
              else:
                  off = line.find("txring:")
                  if off != -1:
                      ntag = ' '*off
                      ntag += "netdev:\n"
                      ntag += ' '*off
                      ntag += "- auto_create: \"yes\"\n"
                      ntag += ' '*(off+2)
                      ntag += "multi_interface: \"no\"\n"
                      config_nd_file.write(ntag)
                      config_nd_file.write(line)
                  else:
                      config_nd_file.write(line)
            config_file.close()
            config_nd_file.close()
            cfgfile = netdev_cfgfile

            INFO( "Netdev test enabled. Config file is %s" % cfgfile)
    rc = 0
    if not nosMode:
        rc = ifcs_init(cfgfile, logfilename, bootmode, pointer(nodes))

        # Does the caller want to deal with init_ifcs failures?
        if returnrc:
            return rc
        assert rc == 0, "Error: Failure to initialize IFCS [rc = " +  str(rc) + "]"
        assert nodes.value != 0, "Error: No Innovium Switch Devices configured [nodes = "+ str(nodes) + "]"
        INFO( "Nodes Discovered: %d" % nodes.value)
        INFO( "IFCS LOG LOCATION:: %s" % (os.getenv("II_ROOT") + "/" + logfilename))

    # log level can be set via config file -
    # to IFCS_LOG_LEVEL_INFO to log all FATAL, ERROR, WARN and INFO messages

    # set up Log Trace module/level
    ifcslt_level = pytest.config.getoption("--ifcslt_level")
    ifcslt_modlist = pytest.config.getoption("--ifcslt_mod")

    logtracelevel = IFCS_DEBUG_LEVEL_OFF
    logtracemods = []

    if ifcslt_level:
        levelname = 'IFCS_DEBUG_LEVEL_%s'%(ifcslt_level.upper())
        logtracelevel = globals()[levelname]

    if ifcslt_modlist:
        logtracemods = ifcslt_modlist.split(',')
        for i in range(len(logtracemods)):
            modname = logtracemods[i]
            ifcsmodstr = 'IFCS_MOD_%s'%(modname.upper())
            ifcsmod = globals()[ifcsmodstr]
            rc = ifcs_debug_level_set(0, ifcsmod, logtracelevel)
            if rc != IFCS_SUCCESS:
                print('Failed to set log trace for mod ' + ifcsmodstr)

    if nodeJoin:
        #Join a node to IFCS
        for node in range(nodes.value):
            if (bootmode == IFCS_BOOT_COLD):
                if os.environ.get('IFCS_TARGET') == 'modeltest':
                    rc = ifcs_node_join(node, bootmode)
                    assert rc == 0, "Error: Innovium Node join failed [rc = " + str(rc) + "]"
                    INFO( "Node %d Initialized" % node)
                else:
                    #bypass bug 8030 in loopback test
                    if os.getenv("IFCS_TARGET")=='device':
                        try:
                            rc = ifcs_node_create(node, 0, None)
                        except:
                            INFO( "Node %d create failed in loopback test" % node)
                            os._exit(88)
                        if rc != IFCS_SUCCESS:
                            INFO( "Node %d create failed in loopback test" % node)
                            os._exit(88)
                    else:
                        rc = ifcs_node_create(node, 0, None)
                    assert rc == 0, "Error: Innovium Node join failed [rc = " + str(rc) + "]"
                    INFO( "Node %d Initialized" % node)

                    if nodeEnable:
                        if not pytest.config.getoption("--l2vni_stats_runtime"):
                            l2vni_statcount = pytest.config.getoption("--l2vni_stats_enable")
                            if l2vni_statcount:
                                enable_l2vni_stats_during_nodeinit(node, str(l2vni_statcount).upper())
                        if not pytest.config.getoption("--l3intf_stats_runtime"):
                            l3intf_statcount = pytest.config.getoption("--l3intf_stats_enable")
                            if l3intf_statcount:
                                enable_l3intf_stats_during_nodeinit(node, str(l3intf_statcount).upper())

                        # In model, stats poll interval of 5 secs not enough
                        if os.environ.get('IFCS_TARGET') == 'swdevsim':
                            if pytest.config.getoption("--l2vni_stats_enable") or pytest.config.getoption("--l3intf_stats_enable"):
                                stats_attr = ifcs_attr_t()
                                rc = ifcs_attr_t_init(pointer(stats_attr))
                                assert rc == IFCS_SUCCESS
                                stats_attr.id = IFCS_NODE_ATTR_STATS_POLL_INTERVAL
                                if pytest.config.getoption("--multi_ib_bitmap"):
                                    stats_attr.value.u64 = 20000
                                else:
                                    stats_attr.value.u64 = 10000
                                ret = ifcs_node_attr_set(node, 1, pointer(stats_attr))

                        #node_attr = ifcs_attr_t()
                        attr_list = (ifcs_attr_t * 30)()
                        for attr in attr_list:
                            rc = ifcs_attr_t_init(pointer(attr))
                            assert rc == IFCS_SUCCESS
                        attr_count = 0
                        #enable boot-time node attributes
                        if pytest.config.getoption("--ilpm_enable"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_ILPM_ENABLE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        if pytest.config.getoption("--ilpm_ext_enable"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_ILPM_EXTENDED_ENABLE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1


                        if pytest.config.getoption("--nos_learn_age_mode"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_L2_ENTRY_NOS_LEARN_AGE_MODE)
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        if pytest.config.getoption("--force_delete_enable"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_FORCE_DELETE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        if pytest.config.getoption("--flat_ecmp"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_ECMP_HIERARCHICAL_ENABLE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_FALSE);
                            attr_count += 1

                        if pytest.config.getoption("--egrsflow"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_EGRESS_SFLOW_ENABLE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        tmcpuq =  pytest.config.getoption("--tm_cpu_queue")
                        if tmcpuq:
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_TRAFFIC_MONITOR_CPU_QUEUE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), int(tmcpuq));
                            attr_count += 1

                        tmtc =  pytest.config.getoption("--tm_tc")
                        if tmtc:
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_TRAFFIC_MONITOR_TC);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), int(tmtc));
                            attr_count += 1

                        if pytest.config.getoption("--l2term_mode_loose"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_INTF_OUTER_L2_TERM_MODE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        aging_interval =  pytest.config.getoption("--aging_interval")
                        if aging_interval:
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_L2_ENTRY_AGING_INTERVAL);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), int(aging_interval));
                            attr_count += 1

                        if pytest.config.getoption("--igmp_based_fwd"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_IGMP_BASED_FWD_ENABLE);
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        if pytest.config.getoption("--forward_profile_type"):
                            profile = pytest.config.getoption("--forward_profile_type")
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_FORWARD_PROFILE);
                            ifcs_attr_t_value_u32_set(pointer(attr_list[attr_count]), globals()['IFCS_FORWARD_PROFILE_ID_PROFILE_{0}'.format(profile.upper())]);
                            attr_count += 1

                        if pytest.config.getoption("--multicast_lag_resolution_enable"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_MULTICAST_LAG_RESOLUTION_ENABLE)
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        if pytest.config.getoption("--multicast_lag_resolution_enable"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_MULTICAST_LAG_RESOLUTION_ENABLE)
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1
                        if pytest.config.getoption("--ipt_enable"):
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_IPT_ENABLE)
                            ifcs_attr_t_value_data_set(pointer(attr_list[attr_count]), IFCS_BOOL_TRUE);
                            attr_count += 1

                        if pytest.config.getoption("--flow_control_source_mac"):
                            pfc_smac = ifcs_mac_t()
                            # Configure 00:02:03:04:05:06
                            pfc_smac[0] = 0
                            pfc_smac[1] = 2
                            pfc_smac[2] = 3
                            pfc_smac[3] = 4
                            pfc_smac[4] = 5
                            pfc_smac[5] = 6
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_FLOW_CONTROL_FRAMES_SOURCE_MAC_ADDRESS);
                            ifcs_attr_t_value_mac_set(pointer(attr_list[attr_count]), pfc_smac)
                            attr_count += 1

                        hw_hashtable_seed = pytest.config.getoption("--hw_hashtable_seed")
                        if not hw_hashtable_seed and os.getenv('test_seed'):
                            hw_hashtable_seed = int(os.getenv('test_seed'))
                        if hw_hashtable_seed:
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_HW_HASHTABLE_SEED)
                            ifcs_attr_t_value_u32_set(pointer(attr_list[attr_count]),
                                                      int(hw_hashtable_seed));
                            attr_count += 1

                        #set entropy_seed= test_seed
                        if os.getenv('test_seed'):
                            entropy_seed = int(os.getenv('test_seed'))
                            ifcs_attr_t_id_set(pointer(attr_list[attr_count]), IFCS_NODE_ATTR_ENTROPY_SEED)
                            ifcs_attr_t_value_u32_set(pointer(attr_list[attr_count]), entropy_seed);
                            attr_count += 1

                        if attr_count:
                            rc = ifcs_node_attr_set(node, attr_count, pointer(attr_list[0]));
                            assert rc == IFCS_SUCCESS
                        node_attr = ifcs_attr_t()
                        rc = ifcs_attr_t_init(pointer(node_attr))
                        attr_count = 0
                        ifcs_attr_t_id_set(pointer(node_attr), IFCS_NODE_ATTR_ENABLE);
                        ifcs_attr_t_value_data_set(pointer(node_attr), IFCS_BOOL_TRUE);
                        attr_count += 1
                        rc = ifcs_node_attr_set(node, attr_count, pointer(node_attr));
                        assert rc == IFCS_SUCCESS

                        INFO( "Node %d enabled" % node)

                        # Disable mac learning on device test
                        if os.getenv("IFCS_TARGET")=='device':
                            if not pytest.config.getoption("l2_learn"):
                                disable_mac_learning(node)

                        # Record the ASIC temp
                        if pytest.config.getoption("--record_temp"):
                            INFO("Starting temperature recording thread")
                            record_asic_temp(node, True)

            # If devport to IB:IBport map needed, setup after node join
            if icm_portmap and bootmode==IFCS_BOOT_COLD:
                icm_portmap_init()

    if  nosMode and bootmode==IFCS_BOOT_COLD:
        icm_portmap_init()

    if pytest.config.getoption("--netdev_single") and os.getenv("IFCS_TARGET")=='device':
        from ifcs_packet_util import netdev_init
        ifname = "inno0"
        os.system('echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6')
        os.system('ifconfig inno0 up')
        netdev_init(ifname)

    return nodes.value

def enable_l2vni_stats_during_nodeinit(node, statcount = None):
    if statcount == None:
        INFO("enable_l2vni_stats_during_nodeinit - stat not enabled")
        return
    if pytest.config.getoption("--l2vni_stats_runtime"):
        if statcount == '4K' or statcount == '4K_ALL':
            attr = ifcs_attr_t()
            flex_stats_attr = ifcs_flex_stats_attributes_t()
            ifcs_flex_stats_attributes_t_init(pointer(flex_stats_attr))
            ifcs_flex_stats_attributes_t_number_of_counters_set(pointer(flex_stats_attr), 4096)
            attr.id = IFCS_NODE_ATTR_INGRESS_L2VNI_STATS_CONFIG
            ifcs_attr_t_value_flex_stats_attributes_set(pointer(attr), pointer(flex_stats_attr))
            ret = ifcs_node_attr_set(node, 1, pointer(attr))
            assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"

    # Ingress L2VNI STATS
    if statcount == '1K' or statcount == '4K':
        INFO("enable_l2vni_stats_during_nodeinit - enable ingress statcount " + str(statcount))
        attr = ifcs_attr_t()
        attr.id = IFCS_NODE_ATTR_INGRESS_L2VNI_STATS_MODE;
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_L2VNI_STATS_COUNT_MODE_UC_MC_BC)
        ret = ifcs_node_attr_set(node, 1, pointer(attr))
        assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"
    elif statcount == '1K_ALL' or statcount == '4K_ALL':
        INFO("enable_l2vni_stats_during_nodeinit - enable ingress statcount " + str(statcount))
        attr = ifcs_attr_t()
        attr.id = IFCS_NODE_ATTR_INGRESS_L2VNI_STATS_MODE;
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_L2VNI_STATS_COUNT_MODE_ALL)
        ret = ifcs_node_attr_set(node, 1, pointer(attr))
        assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"
    else:
        INFO("enable_l2vni_stats_during_nodeinit - unsupported statcount " + str(statcount))
        INFO("valid statcount use: '1K or '4K'")
        assert 0, "invalid statcount specified"
    if not pytest.config.getoption("--l2vni_stats_runtime"):
        if statcount == '4K' or statcount == '4K_ALL':
            attr = ifcs_attr_t()
            flex_stats_attr = ifcs_flex_stats_attributes_t()
            ifcs_flex_stats_attributes_t_init(pointer(flex_stats_attr))
            ifcs_flex_stats_attributes_t_number_of_counters_set(pointer(flex_stats_attr), 4096)
            attr.id = IFCS_NODE_ATTR_INGRESS_L2VNI_STATS_CONFIG
            ifcs_attr_t_value_flex_stats_attributes_set(pointer(attr), pointer(flex_stats_attr))
            ret = ifcs_node_attr_set(node, 1, pointer(attr))
            assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"

    # Egress L2VNI STATS
    if pytest.config.getoption("--l2vni_stats_runtime"):
        if statcount == '4K' or statcount == '4K_ALL':
            attr = ifcs_attr_t()
            flex_stats_attr = ifcs_flex_stats_attributes_t()
            ifcs_flex_stats_attributes_t_init(pointer(flex_stats_attr))
            ifcs_flex_stats_attributes_t_number_of_counters_set(pointer(flex_stats_attr), 4096)
            attr.id = IFCS_NODE_ATTR_EGRESS_L2VNI_STATS_CONFIG
            ifcs_attr_t_value_flex_stats_attributes_set(pointer(attr), pointer(flex_stats_attr))
            ret = ifcs_node_attr_set(node, 1, pointer(attr))
            assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"

    if statcount == '1K' or statcount == '4K':
        INFO("enable_l2vni_stats_during_nodeinit - enable egress statcount " + str(statcount))
        attr = ifcs_attr_t()
        attr.id = IFCS_NODE_ATTR_EGRESS_L2VNI_STATS_MODE;
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_L2VNI_STATS_COUNT_MODE_UC_ONLY)
        ret = ifcs_node_attr_set(node, 1, pointer(attr))
        assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"
    elif statcount == '1K_ALL' or statcount == '4K_ALL':
        INFO("enable_l2vni_stats_during_nodeinit - enable egress statcount " + str(statcount))
        attr = ifcs_attr_t()
        attr.id = IFCS_NODE_ATTR_INGRESS_L2VNI_STATS_MODE;
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_L2VNI_STATS_COUNT_MODE_ALL)
        ret = ifcs_node_attr_set(node, 1, pointer(attr))
        assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"
    if not pytest.config.getoption("--l2vni_stats_runtime"):
        if statcount == '4K' or statcount == '4K_ALL':
            attr = ifcs_attr_t()
            flex_stats_attr = ifcs_flex_stats_attributes_t()
            ifcs_flex_stats_attributes_t_init(pointer(flex_stats_attr))
            ifcs_flex_stats_attributes_t_number_of_counters_set(pointer(flex_stats_attr), 4096)
            attr.id = IFCS_NODE_ATTR_EGRESS_L2VNI_STATS_CONFIG
            ifcs_attr_t_value_flex_stats_attributes_set(pointer(attr), pointer(flex_stats_attr))
            ret = ifcs_node_attr_set(node, 1, pointer(attr))
            assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"

def enable_l3intf_stats_during_nodeinit(node, statcount = None):
    if statcount == None:
        INFO("enable_l2vni_stats_during_nodeinit - stat not enabled")
        return
    if pytest.config.getoption("--l3intf_stats_runtime"):
        if statcount == '4K':
            attr = ifcs_attr_t()
            flex_stats_attr = ifcs_flex_stats_attributes_t()
            ifcs_flex_stats_attributes_t_init(pointer(flex_stats_attr))
            ifcs_flex_stats_attributes_t_number_of_counters_set(pointer(flex_stats_attr), 4096)
            attr.id = IFCS_NODE_ATTR_INGRESS_L3INTF_STATS_CONFIG
            ifcs_attr_t_value_flex_stats_attributes_set(pointer(attr), pointer(flex_stats_attr))
            ret = ifcs_node_attr_set(node, 1, pointer(attr))
            assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"

    if statcount == '1K' or statcount == '4K':
        INFO("enable_l3intf_stats_during_nodeinit - enable statcount " + str(statcount))
        attr = ifcs_attr_t()
        attr.id = IFCS_NODE_ATTR_INGRESS_L3INTF_STATS_MODE
        attr.value.u32 = globals()['IFCS_L3IIF_STATS_COUNT_MODE_UC_ONLY']
        ret = ifcs_node_attr_set(node, 1, pointer(attr))
        assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"
    else:
        INFO("enable_l3intf_stats_during_nodeinit - unsupported statcount " + str(statcount))
        INFO("valid statcount use: '1K or '4K'")
        assert 0, "invalid statcount specified"

    if not pytest.config.getoption("--l3intf_stats_runtime"):
        if statcount == '4K':
            flex_stats_attr = ifcs_flex_stats_attributes_t()
            ifcs_flex_stats_attributes_t_init(pointer(flex_stats_attr))
            ifcs_flex_stats_attributes_t_number_of_counters_set(pointer(flex_stats_attr), 4096)
            attr.id = IFCS_NODE_ATTR_INGRESS_L3INTF_STATS_CONFIG
            ifcs_attr_t_value_flex_stats_attributes_set(pointer(attr), pointer(flex_stats_attr))
            ret = ifcs_node_attr_set(node, 1, pointer(attr))
            assert ret == IFCS_SUCCESS, "switch attr set for flex stats: ret = [" + str(ret) + "]"

def deinit_ifcs(num_nodes, shutmode=IFCS_SHUTDOWN_TYPE_COLD):
    INFO( "Shutting down IFCS, mode: %d" % shutmode)

    if pytest.config.getoption("--netdev_single") and os.getenv("IFCS_TARGET")=='device':
            from ifcs_packet_util import netdev_deinit
            netdev_deinit()

    if (pytest.config.getoption("--record_temp") and
        shutmode == IFCS_SHUTDOWN_TYPE_COLD):
        record_asic_temp(0, False)

    ret = ifcs_deinit(shutmode)
    if ret != IFCS_SUCCESS and ret != IFCS_UNINIT:
        assert 0, "Error: Failure shutting down IFCS [rc = " + str(ret) + "]" + str(stack_str) + ";"
    return ret

def warmboot_ifcs_snapshot():
    ret = ifcs_status_t()
    attr = ifcs_attr_t()
    attr_get = ifcs_attr_t()
    attr.id = IFCS_NODE_ATTR_WB_SNAPSHOT_NOW
    attr.value.u8 = 1
    ret = ifcs_node_attr_set(0, 1, pointer(attr))
    assert ret == IFCS_SUCCESS, "Unable to take WB snapshot, rc: " + str(ret)

def get_filtered_md5(file):
    # Zero out certain attributes like link_status, oper_state in the wb-dump and return the md5
    # Reason to do this: The link status might change between the warmboots and we want to ignore it

    # TODO: Have a suppression list of attribute hierarchy; apply the override on all the objects for all
    # entries in the suppression list
    with open(file) as f:
        data = json.load(f)
        for i in range (0, len(data["nodes"]["0"]["devport"]["devportdso"])):
            data["nodes"]["0"]["devport"]["devportdso"][i]["link_status"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["oper_state"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["link_sm"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pi_fine_tune_continuos"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pi_sd_filter_en"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["an_ld_bp_tech_ability"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pi_dfe_tune_complete.count"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pi_dfe_tune_complete.arr"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["link_up_cnt"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["link_down_cnt"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["link_up_ts"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["link_down_ts"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["link_status"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["fault_status"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pcs_link"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["mac_local_fault"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["mac_remote_fault"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pcs_rx_hi_ber_sts"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pcs_rx_hi_ser_sts"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["signal_ok"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pi_signal_detected"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pi_sig_det_delay_ts"] = 0
            data["nodes"]["0"]["devport"]["devportdso"][i]["tl_devport_objects"]["0"]["pi_sig_det_delay_ts_size"] = 0


        data["nodes"]["0"]["node"]["nodedso"][0]["master_last_temp"] = 0
        data["nodes"]["0"]["node"]["nodedso"][0]["remote0_last_temp"] = 0
        data["nodes"]["0"]["node"]["nodedso"][0]["remote1_last_temp"] = 0
        data["nodes"]["0"]["node"]["nodedso"][0]["remote2_last_temp"] = 0
        data["nodes"]["0"]["node"]["nodedso"][0]["remote3_last_temp"] = 0
        if pytest.config.getoption("--ignore_acl_wb"):
            # In certain cases like PFCWD where sysport is added to ACL upon link-up, if link flaps between warmboots,
            # the state changes in ACL and md5 will differ; ignoring ACL WB state if the test passes this option
            data["nodes"]["0"]["acl"] = 0
            data["nodes"]["0"]["queue"]["pfcwd_queue_acl_info"] = 0

        md5 = hashlib.md5(json.dumps(data, sort_keys=False)).hexdigest()
        return md5

def wb_ifcs(in_nodes, wb_cfgfile=None, clear_counter = True, logfile = ''):
    try:
        curframe = inspect.currentframe()
        frames = inspect.getouterframes(curframe)
        executionLine=frames[1][1].split('/')[-1],frames[1][2],frames[1][3]
    except:
        executionLine='Failed-to-get-line-info'

    ret = ifcs_status_t()

    if clear_counter == True:
        for node in range(in_nodes):
            # clear all since model doesnt do clear on read
            ifcs_sysport_stats_clear_all(node, 0, None, None, None, None)

    startTime = time.time()
    INFO("Initiating ifcs_deinit with IFCS_SHUTDOWN_TYPE_WARM")
    ret = deinit_ifcs(in_nodes, shutmode=IFCS_SHUTDOWN_TYPE_WARM)
    assert (ret == IFCS_SUCCESS)
    deinitEndTime = time.time()
    deinitTime = deinitEndTime - startTime

    WBDF = os.environ.get('IFCS_WB_FILE')
    if not WBDF:
        WBDF = WBDUMPFILE

    # Assert it has a valid checksum
    pre_md5 = get_filtered_md5( WBDF )
    assert(len(pre_md5) == 32)
    INFO("MD5 Checksum of %s: %s" % (WBDF, pre_md5));
    with open(WBDF) as f:
        linesWbdf=len(f.readlines())

    INFO("Initiating ifcs_init with IFCS_BOOT_WARM");
    out_nodes = init_ifcs(cfgfile=wb_cfgfile, bootmode=IFCS_BOOT_WARM, logfilename = logfile);
    initEndTime = time.time()
    initTime = initEndTime - deinitEndTime

    from ifcs_packet_util import ifcs_cpu_packet_register_callback
    # FIXME: Needs to be fixed for multichip
    if in_nodes==0:
       in_nodes=1
    for node in range(in_nodes):
        ifcs_cpu_packet_register_callback(node)

    syncEndTime = time.time()
    syncTime = syncEndTime - initEndTime

    # Reinitialize stats dict
    if clear_counter == True:
        for node in range(in_nodes):
            # clear all since model doesnt do clear on read
            ifcs_sysport_stats_clear_all(node, 0, None, None, None, None)

    ''' Import model server at the appropriate location to avoid ICM init '''
    import model_server
    model_server.exp_stats_dict = {}

    wbTime = syncEndTime - startTime

    INFO("%s Warmboot completed, total time(secs) [deinit/init/sync_callback] [lines in wb]: %.2f [%.2f/%.2f/%.2f] %s"\
                                                          % (executionLine, wbTime, deinitTime, initTime, syncTime, linesWbdf));
    #assert (in_nodes == out_nodes)
    INFO("Removing %s file" % WBDF)
    os.system('cp {0} {0}-before.json'.format(WBDF))
    os.unlink(WBDF)

    INFO("Initiating on demand snapshot");
    for node in range(in_nodes):
        ret = im_nmgr_wb_snapshot(node)
        assert ret == IFCS_SUCCESS, "Unable to take WB snapshot, rc: " + str(ret)

    # Assert it has a valid checksum
    post_md5 = get_filtered_md5( WBDF )
    assert(len(post_md5) == 32)     # checksum length is 32 characters
    INFO("MD5 Checksum of second dump file %s: %s" % (WBDF, post_md5));

    # FIX-ME:Validate that before and after checksum are the same
    try:
        assert(pre_md5 == post_md5)
    except:
        os.system('diff {0}-before.json {0}'.format(WBDF))
        assert 0
    os.unlink('{0}-before.json'.format(WBDF))

def empty_warmboot_init(in_nodes, num_init=1):
    WBDF = os.environ.get('IFCS_WB_FILE')
    #create_file = subprocess.Popen(["touch", WBDF],
    #    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    #stdout, stderr = create_file.communicate()

    #de-init first
    ret = deinit_ifcs(in_nodes, shutmode=IFCS_SHUTDOWN_TYPE_WARM)
    assert (ret == IFCS_SUCCESS)

    #move file
    move_file = subprocess.Popen(["mv", WBDF, WBDF+'.tmp'],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = move_file.communicate()

    #create empty file
    create_file = subprocess.Popen(["touch", WBDF],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = create_file.communicate()

    #boot with empty file
    err_flag = 1
    try:
        out_nodes = init_ifcs(bootmode=IFCS_BOOT_WARM);
    except Exception as e:
        if str(e).find('rc = '+str(IFCS_CONFIG)) > 0:
            err_flag = 0
            pass
        else:
            raise Exception('Incorrect Error code returned by IFCS')
    assert err_flag == 0, "Empty warmboot file should generate correct error code"

    #remove empty file
    remove_file = subprocess.Popen(["rm", WBDF],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = remove_file.communicate()

    #move back the correct file now
    move_file = subprocess.Popen(["mv", WBDF+'.tmp', WBDF],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = move_file.communicate()

def corrupted_warmboot_init():
    num_lines_to_insert = 10
    offset_from_eof = 100
    WBDF = os.environ.get('IFCS_WB_FILE')
    f = open(WBDF, 'r')
    contents = f.readlines()
    f.close()
    num_lines = len(contents)
    for indx in range(num_lines_to_insert):
        if (num_lines - offset_from_eof) >= 0:
            contents.insert(num_lines-offset_from_eof, "This is a line\n")
        else:
            contents.insert(num_lines, "This is a line\n")
    f = open(WBDF, 'w')
    contents = "".join(contents)
    f.write(contents)
    f.close()

    #boot with corrupted warmboot file
    err_flag = 1
    try:
        out_nodes = init_ifcs(bootmode=IFCS_BOOT_WARM);
    except Exception as e:
        if str(e).find('rc = '+str(IFCS_CONFIG)) > 0:
            err_flag = 0
            pass
        else:
            raise Exception('Incorrect Error code returned by IFCS')
    assert err_flag == 0, "Corrupted warmboot file should generate correct error code"

def warmboot_init_no_file():
    WBDF = os.environ.get('IFCS_WB_FILE')
    #remove existing file
    remove_file = subprocess.Popen(["rm", "-f", WBDF],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = remove_file.communicate()
    #boot with no warmboot snapshot file
    err_flag = 1
    try:
        out_nodes = init_ifcs(bootmode=IFCS_BOOT_WARM);
    except Exception as e:
        if str(e).find('rc = '+str(IFCS_CONFIG)) > 0:
            err_flag = 0
            pass
        else:
            raise Exception('Incorrect Error code returned by IFCS')

def getTestFileName():

    logfilename=""
    try:
        frameindex = 1
        curframe = inspect.currentframe()
        frames = inspect.getouterframes(curframe)
        while frameindex <= 8:
            logfilename = ntpath.basename(frames[frameindex][1][0:-3])
            if logfilename.startswith('test_'):
                break
            else:
                frameindex+=1
        if frameindex == 8:
            logfilename = 'test_init'
    except:
        logfilename = 'test_init'

    return logfilename

def getIfcsLogfile():

    logfilename=""
    try:
        frameindex = 1
        curframe = inspect.currentframe()
        frames = inspect.getouterframes(curframe)
        while frameindex <= 8:
            logfilename = ntpath.basename(frames[frameindex][1][0:-3])
            if logfilename.startswith('test_'):
                break
            else:
                frameindex+=1
        if frameindex == 8:
            logfilename = 'test_init'
    except:
        logfilename = 'test_init'

    logfileFullPath = ""
    run_dir = os.getenv("II_ROOT");
    if run_dir == None:
        instance = os.getenv("II_INSTANCE");
        if instance == None:
            instance = "0";
        user = os.getenv("USER");
        if user == None:
            user = os.getenv("USERNAME")
            if user == NULL:
                user = "default";
        run_dir = "/tmp/ii-{0}-{1}".format(user, instance)
    logfileFullPath = run_dir + "/log/{0}.log".format(logfilename)
    INFO( "Ifcs Logfile name: %s" % logfileFullPath )
    return logfileFullPath

def prepareRegEx(eventList):
    reList = []
    for key in eventList.keys():
        reList.append(re.compile(key))
    return reList

def processIfcsLogfile(fnameList, after):
    afterObj = None
    if after:
        afterObj = datetime.datetime.strptime(after, '%H:%M:%S')

    lines = []  # Result to return
    for fname in fnameList:
        INFO( "Loading file: %s" % fname )
        try:
            f = open(fname, 'r')
        except:
            INFO( "Unable to open file: %s" % fname)
            continue

        # Start loading the lines from the file, look only for lines with dates
        for line in f:
            datepart = line[7:22]
            #print "'%s' : '%s'" % (datepart, content)
            try :
                dateObj = datetime.datetime.strptime(datepart, '%H:%M:%S.%f')
            except:
                try:
                    dateObj = datetime.datetime.strptime(datepart, '%H:%M:%S:%f')
                except:
                    continue

            # If an afer time is specificed, only save those lines
            if afterObj and dateObj < afterObj:
                continue

            content = (line[23:-1]).strip()
            data = {
                'date' : dateObj,
                'line' : content
            }
            lines.append(data)
        f.close()

    return lines

def deltaTmStr(delta):
    sec = delta.seconds
    return "%02d:%02d.%06d" % (sec/60, sec%60, delta.microseconds)

def printIfcsLogfileResults(results):

    dashes = '-'*75
    INFO( "Loading file: %s" % dashes )
    INFO( "%15s %13s %13s : %s" % ('WallClock', 'DeltaStart', 'DeltaPrev', 'Event'))
    INFO( "Loading file: %s" % dashes )
    startTime = None
    prevTime = None
    for entry in results:
        now = entry['date']
        line = entry['line']
        ltype = entry['type']
        if not startTime:
            startTime = now
        if not prevTime:
            prevTime = now
        deltaStart =  now - startTime
        deltaPrev =  now - prevTime
        delStart = deltaTmStr(deltaStart);
        delPrev = deltaTmStr(deltaPrev);
        prevTime = now
        INFO( "%15s %13s %13s : %s      %s" % (str(now)[11:], delStart, delPrev, line[:60], ltype))

    INFO( "Loading file: %s" % dashes )

def matchPatterns(fileData,eventList):

    result=[]
    fwdData = sorted(fileData, key=itemgetter('date'))
    revData = sorted(fileData, key=itemgetter('date'), reverse=True)

    # Prepare the list of compiled keys
    reList = prepareRegEx(eventList)
    # Search for the entries in the eventList list
    for lidx, entry in enumerate(fwdData):
        for ridx, regex in enumerate(reList):
            if regex.search(entry['line']):
                data = {
                    'date' : entry['date'],
                    'line' : entry['line'],
                    'type' : '',
                }
                #reList.pop(ridx)
                result.append(data)
                break

    return result

def analyzeIfcsLogfile(logfile,eventList,after=None):
    result = []
    fileData = processIfcsLogfile(logfile,after)
    INFO('Searching for patterns')
    result = matchPatterns(fileData,eventList)
    # Sort the data by time
    INFO('Printing results')
    sortedData = sorted(result, key=itemgetter('date'), reverse=False)
    printIfcsLogfileResults(sortedData)

def dump_ecc_stats(node_id=0):

        ecc_node_stat = ifcs_ecc_node_stats_t()

        ifcs_node_ecc_stats(node_id, pointer(ecc_node_stat ))
        INFO( "%10s:%8s, %10s:%8s, %10s:%8s, %10s:%8s, %10s:%8s" % (
            "TOTAL", str(ecc_node_stat.total_count),
            "TYPE_CE", str(ecc_node_stat.type_ce_count),
            "TYPE_UE", str(ecc_node_stat.type_ue_count),
            "TYPE_TREE", str(ecc_node_stat.type_tree_count),
            "TYPE_INV", str(ecc_node_stat.type_invalid_count)))

        INFO( "%10s:%8s, %10s:%8s, %10s:%8s, %10s:%8s, %10s:%8s" % (
            "RATELIMIT", str(ecc_node_stat.rate_limit_hit_count),
            "CLS_INFO", str(ecc_node_stat.class_info_count),
            "CLS_ALARM", str(ecc_node_stat.class_alarm_count),
            "CLS_FATAL", str(ecc_node_stat.class_fatal_count),
            "CLS_INV", str(ecc_node_stat.class_invalid_count)))

def dump_hashtable_stats(node_id, fullpen):

    # Allocate space to get hash table stats
    hashtable = hm_table_t();
    memset(pointer(hashtable), 0, (sizeof(hashtable)))

    # Get raw data from the full pen hash table
    rc = hashtable_data(node_id, fullpen, pointer(hashtable))

    # Get name of the pen
    penstring = c_char_p(" " * 64)
    node_get_pen_name(0, fullpen, penstring, 64)
    penstr = str(penstring.value)

    percententries = float(hashtable.hte_nentries)
    percentslots = float(hashtable.hte_nentries_slots)
    if hashtable.hte_total_slots > 0:
        percententries = (percententries * 100) / hashtable.hte_total_slots
        percentslots = (percentslots * 100) / hashtable.hte_total_slots
    else:
        percententries = 0.0
        percentslots = 0.0

    INFO( "Stats for hash table: %s" % penstr)
    INFO( "Config: %13s:%8d, %13s:%8d, %13s:%8d" % ("nBanks", hashtable.hte_nbanks,
            "nBuckets", hashtable.hte_nbuckets,
            "nSlots", hashtable.hte_nslots))

    INFO( "Config: %13s:%8d, %13s:%8d, %13s:%8d" % ("Total Slots", hashtable.hte_total_slots,
            "Slots/Bank", hashtable.hte_total_slots_per_bank,
            "Max Checks", hashtable.hte_max_checks))

    INFO( "Usage : %13s:%8d (%5.2f%%), %13s:%8d (%5.2f%%)" % ("Total Entries", hashtable.hte_nentries, percententries,
        "Slots", hashtable.hte_nentries_slots, percentslots))

    INFO( "")

    INFO( "API   : %13s:%8ld, %13s:%8ld, %13s:%8ld, %13s:%8ld" % ("Creates/Ins", hashtable.hte_stats.ts_api_creates,
            "InsertTry", hashtable.hte_stats.ts_api_creates_try,
            "Updates", hashtable.hte_stats.ts_api_updates,
            "Deletes", hashtable.hte_stats.ts_api_deletes))

    INFO( "Stats : %13s:%8ld, %13s:%8ld, %13s:%8ld, %13s:%8ld" % ("Ins CBS", hashtable.hte_stats.ts_ins_cbs,
            "Ins w/Move", hashtable.hte_stats.ts_ins_move,
            "Last Checks", hashtable.hte_stats.ts_last_op_checks,
            "Last Moves", hashtable.hte_stats.ts_last_op_moves))

    INFO( "Stats : %13s:%8ld, %13s:%8ld, %13s:%8ld, %13s:%8ld" % ("Create Fail", hashtable.hte_stats.ts_ins_fails,
            "Total Checks", hashtable.hte_stats.ts_checks,
            "Total Moves", hashtable.hte_stats.ts_moves,
            "Updates", hashtable.hte_stats.ts_updates))

    sbuf = "Stats : "
    for sidx in range(1, 5):

        sbuf1 = "%dw-Fail" % sidx
        sbuf2 = "%13s:%8d, " % (sbuf1, hashtable.hte_stats.ts_ins_fails_bysize[sidx])
        sbuf += sbuf2
    INFO( sbuf )

    INFO( "Stats : %13s:%8ld, %13s:%8ld, %13s:%8ld" % ("Key Lookups", hashtable.hte_stats.ts_key_gen,
            "NotFound", hashtable.hte_stats.ts_key_notfound,
            "HwErrors", hashtable.hte_stats.ts_key_hwerror))

    INFO( "" )
    INFO( "" )

def dump_all_hashtables(node_id):
    dump_hashtable_stats(node_id, IMT1003_FULL)
    dump_hashtable_stats(node_id, IMT2001_FULL)
    dump_hashtable_stats(node_id, IMT2002_FULL)
    dump_hashtable_stats(node_id, IMT3001_FULL)
    dump_hashtable_stats(node_id, IMT3002_FULL)
    dump_hashtable_stats(node_id, IMT3004_FULL)
    dump_hashtable_stats(node_id, IMT3005_FULL)
    dump_hashtable_stats(node_id, IMT3006_DB1_FULL)
    dump_hashtable_stats(node_id, IMT3007_DB1_FULL)
    dump_hashtable_stats(node_id, EMT1001_FULL)
    dump_hashtable_stats(node_id, EMT1002_FULL)

def dump_ilpm_stats(nodeid=0, dodump=True):
    if not pytest.config.getoption("--ilpm_enable"):
        return (None, None)

    ilpmstat = im_ilpm_stats_t()
    memset(pointer(ilpmstat), 0, (sizeof(ilpmstat)))
    rc = im_route_entry_get_ilpm_stats(nodeid, pointer(ilpmstat))
    assert rc == IFCS_SUCCESS, "Unable to get ILPM stats: rc = [" + str(rc) + "]"

    sbuf  = "ILPM Stats"
    sbuf += "\n"
    sbuf += "       Config: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("ptbl_mode", ilpmstat.ptable_mode,
                                                           "nbanks", ilpmstat.ptable_nbanks,
                                                           "nbuckets", ilpmstat.ptable_nbuckets)

    sbuf += "       Config: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("ncolors", ilpmstat.ptable_ncolors_per_bucket,
                                                           "nslots", ilpmstat.ptable_narrow_slots_per_bucket,
                                                           "wslots", ilpmstat.ptable_wide_slots_per_bucket)

    sbuf += "       Config: %12s:%8ld, %12s:%8ld\n" % ("sz_v4_v6_64", ilpmstat.lpm_size_v4_v6_64,
                                                "sz_v6_128", ilpmstat.lpm_size_v6_128)

    sbuf += "          API: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("create", ilpmstat.route_ncreates,
                                                           "delete", ilpmstat.route_ndeletes,
                                                           "update", ilpmstat.route_nupdates)

    sbuf += "          API: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("createF", ilpmstat.route_ncreate_fails,
                                                           "deleteF", ilpmstat.route_ndelete_fails,
                                                           "updateF", ilpmstat.route_nupdate_fails)

    sbuf += "       v4Trie: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("subtries", ilpmstat.ipv4_num_subtries,
                                                                  "vsubtries", ilpmstat.ipv4_num_virtual_subtries,
                                                                  "nodes", ilpmstat.ipv4_num_trie_nodes)

    sbuf += "       v4Trie: %12s:%8ld, %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("real_nodes", ilpmstat.ipv4_num_real_nodes,
                                                                             "virt_nodes", ilpmstat.ipv4_num_virtual_nodes,
                                                                             "virt->real", ilpmstat.ipv4_num_vnode_to_real,
                                                                             "real->virt", ilpmstat.ipv4_num_real_to_vnode)

    sbuf += "       v6Trie: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("subtries", ilpmstat.ipv6_num_subtries,
                                                                  "vsubtries", ilpmstat.ipv6_num_virtual_subtries,
                                                                  "nodes", ilpmstat.ipv6_num_trie_nodes)

    sbuf += "       v6Trie: %12s:%8ld, %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("real_nodes", ilpmstat.ipv6_num_real_nodes,
                                                                             "virt_nodes", ilpmstat.ipv6_num_virtual_nodes,
                                                                             "virt->real", ilpmstat.ipv6_num_vnode_to_real,
                                                                             "real->virt", ilpmstat.ipv6_num_real_to_vnode)

    sbuf += "         TCAM: %12s:%8ld, %12s:%8ld\n" % ("v4_v6_64", ilpmstat.tcam_rows_in_use_v4_v6_64,
                                                "v6_128", ilpmstat.tcam_rows_in_use_v6_128)

    sbuf += "       pTable: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("buckets", ilpmstat.num_buckets_in_use,
                                                           "colors", ilpmstat.num_colors_in_use,
                                                           "slots", ilpmstat.num_slots_in_use)

    sbuf += "       Action: %12s:%8ld, %12s:%8ld, %12s:%8ld \n" % ("splits", ilpmstat.num_splits,
                                                                   "merges", ilpmstat.num_merges,
                                                                   "moves", ilpmstat.num_moves)

    sbuf += "       Action: %12s:%8ld, %12s:%8ld, %12s:%8ld\n" % ("splitsF", ilpmstat.num_split_fails,
                                                                  "mergesF", ilpmstat.num_merge_fails,
                                                                  "movesF", ilpmstat.num_move_fails)

    if dodump:
        INFO(sbuf)
    return ilpmstat

#def get_ipv6_da_route_hw_index(nodeId, prfx, mask, l3vni_handle):
#    rt = ifcs_route_entry_key_t()
#    rt.key.ip_dest_l3vni.l3vni = l3vni_handle
#    rt.key.ip_dest_l3vni.ip_dest.addr.ipv6 = prfx
#    rt.key.ip_dest_l3vni.ip_dest.mask.ipv6 = mask
#    rt.key.ip_dest_l3vni.ip_dest.addr_family = IFCS_IP_ADDR_FAMILY_IPV6
#    hw_index = ctypes.c_uint32()
#    ret = stub_route_get_hw_index(nodeId, pointer(rt), pointer(hw_index))
#    assert ret == IFCS_SUCCESS, "Route get hw index failed"
#    #print "hw_index: " + str(hw_index.value)
#    fid     = (hw_index.value & 0xf0000000) >> 28
#    bkt_id  = (hw_index.value & 0x0fffff00) >> 8
#    slot_id = (hw_index.value & 0x000000ff)
#    return (fid, bkt_id, slot_id)
#    #print "fid: " + str(fid) + " bkt_id: " + str(bkt_id) + " slot_id: " + str(slot_id)
#    return (fid, bkt_id, slot_id)

def print_node_ecc_stats(node_id):

    # Cause Pen/Field and Source Pen field
    cpenstr = c_char_p(" " * 128)
    cfldstr = c_char_p(" " * 128)
    spenstr = c_char_p(" " * 128)

    eccnp = ecc_node_stats_t();
    ecc_node_data(node_id, pointer(eccnp))

    # Get overall NODE statistics
    INFO( "ECCH Type : Node:%2d, %8s:%5ld, %8s:%5ld, %8s:%5ld, %8s:%5ld" % (node_id,
             "PEN/F", eccnp.es_pfcount,
             "CE", eccnp.es_type_ce,
             "UE", eccnp.es_type_ue,
             "INV", eccnp.es_type_invalid))

    INFO( "ECCH Class: Node:%2d, %8s:%5ld, %8s:%5ld, %8s:%5ld, %8s:%5ld" % (node_id,
             "INFO", eccnp.es_class_info,
             "ALARM", eccnp.es_class_alarm,
             "FATAL", eccnp.es_class_fatal,
             "INVLD", eccnp.es_class_invalid))

    # Get per PEN/Field stats
    eccp = (ecc_pen_stats_t * eccnp.es_pfcount)()
    ecc_node_pen_data(node_id, eccnp.es_pfcount, pointer(eccp))
    for index in xrange(eccnp.es_pfcount):

        entry = eccp[index]
        node_get_pen_name(0, entry.eps_entry.err_pname, cpenstr, 128)
        node_get_pen_name(0, entry.eps_src_pname, spenstr, 128)
        node_get_pen_field_name(0, entry.eps_entry.err_fname, cfldstr, 128)

        INFO("ECCH SOURCE : COUNT: %6ld, %s, CAUSE: %s:%s" % (
            entry.eps_count, spenstr.value,
            cpenstr.value, cfldstr.value))

        for eindex in xrange(entry.eps_fcount):
            errentry = entry.eps_fails[eindex]

            if errentry.err_count:
                classstr = "INVALID"
                if errentry.err_class == INTR_CLASS_INFO:  classstr = "INFO";
                if errentry.err_class == INTR_CLASS_ALARM: classstr = "ALARM";
                if errentry.err_class == INTR_CLASS_FATAL: classstr = "FATAL";

                typestr = "INVALID"
                if errentry.err_type == INTR_TYPE_ECC_CE:  typestr = "ECC_CE";
                if errentry.err_type == INTR_TYPE_ECC_UE:  typestr = "ECC_UE";

                INFO("    ERR_IDX : COUNT: %6ld, IDX: %6ld (0x%5x), CLASS: %7s, TYPE: %7s" % (
                    errentry.err_count,
                    errentry.err_index, errentry.err_index,
                    classstr, typestr))

# For a given bitmap, return a list with set bits locations
def get_setbits_indexlist(n):
    loc = 0
    bitlocations = []
    while n:
        if(n&1):
            bitlocations.append(loc)
        loc = loc + 1
        n = n>>1
    return bitlocations

def get_ib_from_devport(devport):
    global portmap
    global map_count
    for i in range(0,map_count):
        if portmap[i].port == devport:
            if pytest.config.getoption("--log_verbose"):
                print ("get_ib_from_devport: devport %d ib %d" %(devport, portmap[i].ib))
            return portmap[i].ib
    #devport not present in portmap list.
    INFO("get_ib_from_devport: devport %d not found in portmap" % (devport))
    return -1

def get_ibport_from_devport(devport):
    global portmap
    global map_count
    for i in range(0,map_count):
        if portmap[i].port == devport:
            if pytest.config.getoption("--log_verbose"):
                print ("get_ibport_from_devport: devport %d ibport %d" %(devport, portmap[i].ibport))
            return portmap[i].ibport
    #devport not present in portmap list.
    INFO("get_ibport_from_devport: devport %d not found in portmap" % (devport))
    return -1

def update_all_dev_ports(devport):
    global multi_ib_bitmap
    global all_active_ibs
    global portmap
    global map_count
    global valid_dev_ports_list
    global all_dev_ports

    portinfo = im_devport_info_t()

    # See which IBs are enabled
    if multi_ib_bitmap == 0:
        # Zero IB case, enable only Zero IB
        ibs_enabled_list = [0]
    else:
        # Multi IB case, get enabled IBs list
        ibs_enabled_list = get_setbits_indexlist(multi_ib_bitmap)

    ret = im_devport_info_get(0, devport, pointer(portinfo))
    if ret == IFCS_SUCCESS:
        all_dev_ports.append(devport)
        if (portinfo.pi_type == IFCS_DEVPORT_TYPE_RECIRC):
            return
        if pytest.config.getoption("--lb_test") or portinfo.pi_ib in ibs_enabled_list:
            if portinfo.pi_ib not in all_active_ibs:
                all_active_ibs.append(portinfo.pi_ib)
            if pytest.config.getoption("--log_verbose"):
                INFO("ICM port map init: devport %d, ib:ibport=%d:%d" % (devport, portinfo.pi_ib, portinfo.pi_ibport))
            portmap[map_count].port = devport
            portmap[map_count].ib = portinfo.pi_ib
            portmap[map_count].ibport = portinfo.pi_ibport
            map_count += 1
            # Note: Assuming CPU dev port is 0 and skipping it in valid dev ports.
            if devport != 0:
                valid_dev_ports_list.append(devport)
        else:
            if pytest.config.getoption("--log_verbose"):
                INFO("ICM port map init: IB DISABLED devport %d, ib:ibport=%d:%d" % (devport, portinfo.pi_ib, portinfo.pi_ibport))
    if multi_ib_bitmap:
        ret = icm_portmap_set(0, map_count, portmap)
        if ret:
            INFO("ICM port map int failed ret %d" % (ret))
            return ret
        else:
            INFO("ICM port map init success")

PRINT_DP_FUNC = CFUNCTYPE(UNCHECKED(None), ifcs_node_id_t, ifcs_devport_t, c_uint32, POINTER(ifcs_attr_t), POINTER(None))

def py_print_dp_func(node_id, devport, attr_count, attr_list, user_data):
    update_all_dev_ports(devport)

print_dp_fn_cb = PRINT_DP_FUNC(py_print_dp_func)

# Set devport to ib:ibport mapping in ICM
def icm_portmap_init():
    global valid_dev_ports_list
    global map_count

    map_count = 0
    valid_dev_ports_list[:] = []

    devport_count = ctypes.c_uint32()

    rc = ifcs_devport_get_all(0, 0, 0, print_dp_fn_cb, 0, pointer(devport_count))
    assert IFCS_STATUS_REASON(rc) == IFCS_SUCCESS

def ifcs_route_entry_key_map_fill(l3vni, addr_family, ip, mask):
    key = ifcs_route_entry_key_map_t()
    key.ip_dest_l3vni.l3vni = l3vni.getHandle()
    key.ip_dest_l3vni.ip_dest.addr_family = addr_family
    if addr_family == IFCS_IP_ADDR_FAMILY_IPV4:
        key.ip_dest_l3vni.ip_dest.addr.ipv4 = ip
        key.ip_dest_l3vni.ip_dest.mask.ipv4 = mask
    else:
        key.ip_dest_l3vni.ip_dest.addr.ipv6 = ip
        key.ip_dest_l3vni.ip_dest.mask.ipv6 = mask
    return key

def getAllrecircport(nodeId):
    def myCallback(node_id, arg, attr_count, attr_list, user_data):

        devport = arg

        devport_list.append(devport)
    devport_list = []

    callback_type = CFUNCTYPE(
        UNCHECKED(None),
        ifcs_node_id_t,
        ifcs_devport_t,
        c_uint32,
        POINTER(ifcs_attr_t),
        POINTER(None))
    callback = callback_type(myCallback)

    try:
        attr = ifcs_attr_t()
        ifcs_attr_t_init(pointer(attr))
        ifcs_attr_t_id_set(pointer(attr), IFCS_DEVPORT_ATTR_TYPE)
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_DEVPORT_TYPE_RECIRC)
        rc = ifcs_devport_get_all(nodeId, 1, pointer(attr), callback, 0, 0)
        if rc != IFCS_SUCCESS:
            ERROR("Failed to get all recirc devport rc: %d" %(rc))
    except Exception as e:
        ERROR(" Failed to get all recirc devports : %d" %(rc))
        raise e
    return devport_list

def getAlldevport(nodeId):
    def myCallback(node_id, arg, attr_count, attr_list, user_data):

        devport = arg

        devport_list.append(devport)
    devport_list = []

    callback_type = CFUNCTYPE(
        UNCHECKED(None),
        ifcs_node_id_t,
        ifcs_devport_t,
        c_uint32,
        POINTER(ifcs_attr_t),
        POINTER(None))
    callback = callback_type(myCallback)

    try:
        attr = ifcs_attr_t()
        ifcs_attr_t_init(pointer(attr))
        ifcs_attr_t_id_set(pointer(attr), IFCS_DEVPORT_ATTR_TYPE)
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_DEVPORT_TYPE_ETH)
        rc = ifcs_devport_get_all(nodeId, 1, pointer(attr), callback, 0, 0)
        if rc != IFCS_SUCCESS:
            ERROR("Failed to get all eth devport rc: %d" %(rc))
        ifcs_attr_t_init(pointer(attr))
        ifcs_attr_t_id_set(pointer(attr), IFCS_DEVPORT_ATTR_TYPE)
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_DEVPORT_TYPE_CPU)
        rc = ifcs_devport_get_all(nodeId, 1, pointer(attr), callback, 0, 0)
        if rc != IFCS_SUCCESS:
            ERROR("Failed to get all cpu devport rc: %d" %(rc))
        ifcs_attr_t_init(pointer(attr))
        ifcs_attr_t_id_set(pointer(attr), IFCS_DEVPORT_ATTR_TYPE)
        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_DEVPORT_TYPE_AUX)
        rc = ifcs_devport_get_all(nodeId, 1, pointer(attr), callback, 0, 0)
        if rc != IFCS_SUCCESS:
            ERROR("Failed to get all aux devport rc: %d" %(rc))
    except Exception as e:
        ERROR(" Failed to get all devports : %d" %(rc))
        raise e
    return devport_list

def clear_devport_stats(nodeId=0):
    port_list = getAlldevport(nodeId)
    max_list = IFCS_DEVPORT_STATS_ID_MAX_COUNT
    max_list = max_list - 1
    statsIdList = (max_list * ifcs_devport_stats_id_t)()
    for stats in range(max_list):
        statsIdList[stats] = stats
    for port in port_list:
        if port == 0:
            continue # port zero is cpu count, only clearing devport port
        rc = IFCS_STATUS_REASON(
            ifcs_devport_stats_clear(
                nodeId,port,max_list,
                pointer(statsIdList))
            )
        if rc != IFCS_SUCCESS:
            assert 0, "Clear stats failed for port: {}".format(port)

def clear_cpuport_stats(nodeId=0):
    # Pick the Stats Id which applies to CPU port
    cpu_stats_id_list = range(2) + range(9,21) + [47] + range(63,66) + range(72,84) + [106]
    statsIdList = (len(cpu_stats_id_list) * ifcs_devport_stats_id_t)()
    for i in range(len(cpu_stats_id_list)):
        statsIdList[i] = cpu_stats_id_list[i]
    port = 0
    rc = IFCS_STATUS_REASON(ifcs_devport_stats_clear(nodeId,port,len(cpu_stats_id_list),
                              pointer(statsIdList)))
    if rc != IFCS_SUCCESS:
        assert 0, "Clear stats failed for port: {}".format(port)

def clear_cpu_queue_stats(nodeId=0):
    statIdList = (1 * ifcs_cpu_queue_stats_id_t)()
    index = 0
    for cpu_queue in range(48):
        for index in range(IFCS_QUEUE_STATS_ID_MAX_COUNT):
            statIdList[0] = index
            if index == IFCS_QUEUE_STATS_ID_TOTAL_USE_COUNT:
                continue
            rc = IFCS_STATUS_REASON(
                 ifcs_cpu_queue_stats_clear(
                 nodeId,
                 cpu_queue,
                 1,
                 pointer(statIdList)))
            if rc != IFCS_SUCCESS:
                assert 0, "Stats Clear Failed rc: {0}".format(rc)

def getAlll2_entry(nodeId, l2vni_hdl=None, sysport_hdl=None, entry_type=None, key_type='mac_l2vni', mac_addr=None, mask=None):
    def convert_mac_str_to_ctype_arr(macStr):
        bytes = macStr.split(":")
        mac_arr = (long(bytes[0], 16), long(bytes[1], 16), long(bytes[2], 16),
                  long(bytes[3], 16), long(bytes[4], 16), long(bytes[5], 16))
        arr = (c_uint8 * 6)()
        arr = (ctypes.c_uint8 * len(mac_arr))(*mac_arr)
        return arr

    def myCallback(node_id, arg, attr_count, attr_list, user_data):

        l2_entry_list.append(arg)
    l2_entry_list = []

    callback_type = CFUNCTYPE(
        UNCHECKED(None),
        ifcs_node_id_t,
        POINTER(ifcs_l2_entry_key_t),
        c_uint32,
        POINTER(ifcs_attr_t),
        POINTER(None))
    callback = callback_type(myCallback)

    try:
        filter_attr_list = (ifcs_attr_t * 2)()
        filter_attr_count = 0
        if sysport_hdl:
            filter_attr_list[filter_attr_count].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
            filter_attr_list[filter_attr_count].value.handle = sysport_hdl
            filter_attr_count += 1
        if entry_type:
            filter_attr_list[filter_attr_count].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
            filter_attr_list[filter_attr_count].value.u32 = globals()['IFCS_L2_ENTRY_TYPE_%s'%entry_type.upper()]
            filter_attr_count += 1
        if filter_attr_count == 0 :
            filter_attr_list = 0

        l2_entry = ifcs_l2_entry_key_t()
        rc = ifcs_l2_entry_key_t_init(pointer(l2_entry))
        assert rc == IFCS_SUCCESS
        if key_type == 'mac_only':
            rc = ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry), IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY)
            assert rc == IFCS_SUCCESS
            rc = ifcs_l2_entry_key_t_mac_only_set(pointer(l2_entry), l2_entry.key.mac_only)
            assert rc == IFCS_SUCCESS
            if mac_addr:
                rc = ifcs_l2_entry_key_mac_only_t_mac_addr_set(pointer(l2_entry.key.mac_only), convert_mac_str_to_ctype_arr(mac_addr))
                assert rc == IFCS_SUCCESS
            if mask:
                mask_str = hex(int('1'*mask+'0'*(48-mask),2))[2::]
                mac_mask = ":".join(a+b for a,b in zip(mask_str[::2],mask_str[1::2]))
                rc = ifcs_l2_entry_key_mac_only_t_mac_mask_set(pointer(l2_entry.key.mac_only), convert_mac_str_to_ctype_arr(mac_mask))
                assert rc == IFCS_SUCCESS
            l2_entry_p = pointer(l2_entry)
        elif key_type == 'mac_l2vni':
            rc = ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry), IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
            assert rc == IFCS_SUCCESS
            rc = ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry), l2_entry.key.mac_l2vni)
            assert rc == IFCS_SUCCESS
            if mac_addr:
                rc = ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni), convert_mac_str_to_ctype_arr(mac_addr))
                assert rc == IFCS_SUCCESS
            if l2vni_hdl:
                rc = ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni), l2vni_hdl)
                assert rc == IFCS_SUCCESS
            l2_entry_p = pointer(l2_entry)
        elif key_type == 'sg_l2vni':
            rc = ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry), IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI)
            assert rc == IFCS_SUCCESS
            rc = ifcs_l2_entry_key_t_ip_sg_l2vni_set(pointer(l2_entry), l2_entry.key.ip_sg_l2vni)
            assert rc == IFCS_SUCCESS
            if l2vni_hdl:
                rc = ifcs_l2_entry_key_ip_sg_l2vni_t_l2vni_set(pointer(l2_entry.key.ip_sg_l2vni), l2vni_hdl)
                assert rc == IFCS_SUCCESS
            l2_entry_p = pointer(l2_entry)
        elif key_type == 'starg_l2vni':
            rc = ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry), IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI)
            assert rc == IFCS_SUCCESS
            rc = ifcs_l2_entry_key_t_ip_starg_l2vni_set(pointer(l2_entry), l2_entry.key.ip_starg_l2vni)
            assert rc == IFCS_SUCCESS
            if l2vni_hdl:
                rc = ifcs_l2_entry_key_ip_starg_l2vni_t_l2vni_set(pointer(l2_entry.key.ip_starg_l2vni), l2vni_hdl)
                l2_entry_p = pointer(l2_entry)
        else:
            l2_entry_p = 0

        rc = ifcs_l2_entry_get_all(
            nodeId, l2_entry_p, filter_attr_count, filter_attr_list, callback, 0, None)

        if rc != IFCS_SUCCESS:
            INFO("Failed to get all l2_entry rc: {0}".format(rc))
    except Exception as e:
        INFO(" Failed to get all l2entries : {0} ".format(e))
        raise e
#    else:
#        mac_list = []
#        for l2_entry_item in l2_entry_list:
#            l2_entry = l2_entry_item.contents
#            if l2_entry.key_type == IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY:
#                mac_addr = "%02x:%02x:%02x:%02x:%02x:%02x" % (l2_entry.key.mac_only.mac_addr[0],
#				l2_entry.key.mac_only.mac_addr[1],l2_entry.key.mac_only.mac_addr[2],
#				l2_entry.key.mac_only.mac_addr[3],l2_entry.key.mac_only.mac_addr[4],
#				l2_entry.key.mac_only.mac_addr[5])
#                mac_list.append(mac_addr)
#            elif l2_entry.key_type == IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI:
#                mac_addr = "%02x:%02x:%02x:%02x:%02x:%02x" % (l2_entry.key.mac_l2vni.mac_addr[0],
#				l2_entry.key.mac_l2vni.mac_addr[1],l2_entry.key.mac_l2vni.mac_addr[2],
#				l2_entry.key.mac_l2vni.mac_addr[3],l2_entry.key.mac_l2vni.mac_addr[4],
#				l2_entry.key.mac_l2vni.mac_addr[5])
#                mac_list.append(mac_addr)
#        if len(mac_list) == len(l2_entry_list):
#            l2_entry_list = mac_list
#
    return l2_entry_list


def set_l2_entry_aging_interval(nodeId,aging_interval):
    attr = ifcs_attr_t()
    attr_count = 1
    ifcs_attr_t_init(pointer(attr))
    ifcs_attr_t_id_set(pointer(attr), IFCS_NODE_ATTR_L2_ENTRY_AGING_INTERVAL);
    ifcs_attr_t_value_data_set(pointer(attr), int(aging_interval));
    rc = ifcs_node_attr_set(nodeId, attr_count, pointer(attr));
    if rc != IFCS_SUCCESS:
        ERROR("Failed to set the l2 entry aging interval")

def get_l2_entry_aging_interval(nodeId):
    attr = ifcs_attr_t()
    attr.id = IFCS_NODE_ATTR_L2_ENTRY_AGING_INTERVAL
    actual_count = ctypes.c_uint32()
    rc = ifcs_node_attr_get(nodeId, 1, pointer(attr), pointer(actual_count))
    if rc != IFCS_SUCCESS:
        ERROR("Failed to get the l2 entry aging interval")
    aging_interval = attr.value.u32
    return aging_interval

def set_l2_entry_learn_db_aging_interval(nodeId,aging_interval):
    attr = ifcs_attr_t()
    attr_count = 1
    ifcs_attr_t_init(pointer(attr))
    ifcs_attr_t_id_set(pointer(attr), IFCS_NODE_ATTR_L2_ENTRY_LEARN_DB_AGING_INTERVAL);
    ifcs_attr_t_value_data_set(pointer(attr), int(aging_interval));
    rc = ifcs_node_attr_set(nodeId, attr_count, pointer(attr));
    if rc != IFCS_SUCCESS:
        ERROR("Failed to set the l2 entry learn db aging interval")

def get_l2_entry_learn_db_aging_interval(nodeId):
    attr = ifcs_attr_t()
    attr.id = IFCS_NODE_ATTR_L2_ENTRY_LEARN_DB_AGING_INTERVAL
    actual_count = ctypes.c_uint32()
    rc = ifcs_node_attr_get(nodeId, 1, pointer(attr), pointer(actual_count))
    if rc != IFCS_SUCCESS:
        ERROR("Failed to get the l2 entry learn db aging interval")
    aging_interval = attr.value.u32
    return aging_interval

def get_forward_profile_type(nodeId):
    attr = ifcs_attr_t()
    attr.id = IFCS_NODE_ATTR_FORWARD_PROFILE
    actual_count = ctypes.c_uint32()
    rc = ifcs_node_attr_get(nodeId, 1, pointer(attr), pointer(actual_count))
    if rc != IFCS_SUCCESS:
        ERROR("Failed to get forward profile type")
    fwd_profile_type = attr.value.u32
    if fwd_profile_type == IFCS_FORWARD_PROFILE_ID_PROFILE_A:
        return "PROFILE_A"
    elif fwd_profile_type == IFCS_FORWARD_PROFILE_ID_PROFILE_B:
        return "PROFILE_B"
    elif fwd_profile_type == IFCS_FORWARD_PROFILE_ID_PROFILE_C:
        return "PROFILE_C"
    else:
        return "UNKNOWN_PRFILE"


def verify_consistent_hash(orig_slot_location, new_slot_location,nexthop,ifcsobjs):
    assertflag = False
    position = []
    for i in orig_slot_location:
        if i not in new_slot_location:
            assertflag = True
            position.append(i)
    if assertflag:
        print ("Next hop: {0} not found in following slots:{1}".format(nexthop,position))
        assert assertflag == False, "some next hops not found in expected slots"

def get_nexthop_slot_positions(orig_array,nexthop,ifcsobjs):
    slots = np.array(orig_array)
    hdl = ifcsobjs['Nexthop'][nexthop].getHandle()
    nexthop_slots = OrderedDict()
    ii = np.where(slots == hdl)[0]
    #nxt_index = {nexthop : ii}
    #nexthop_slots.update(next_index)
    return ii


def get_pkt_type_from_mac(dst):
    #UC = Unicast, unknown unicast, MC = Muliticast, BC= broadcast
    dst_mac=dst.split(':')
    if dst_mac[0] == '01':
      #L2 = 01:*, IPV4 Multicast mac = 01:00:5e:*
       return 'MC'
    elif dst_mac[0] == '33' and dst_mac[1] == '33':
       #IPV6 Multicast mac if mac = 33:33:*
       return 'MC'
    elif len(set(dst_mac)) == 1 and dst_mac[0].upper() == 'FF':
       return 'BC'
    else:
       return 'UC'

def get_pkt_type_from_ip(pkt):
    #UC = Unicast, unknown unicast, MC = Muliticast, BC= broadcast
    if pkt.haslayer('IP') and pkt.haslayer('IPv6'):
        if pkt.getlayer('IP').haslayer('IPv6'):
            pkt_type='ipv4'
        else:
            pkt_type='ipv6'
    elif pkt.haslayer('IP'):
        pkt_type='ipv4'
    elif pkt.haslayer('IPv6'):
        pkt_type='ipv6'

    if pkt_type=='ipv4':
        dst_ip_octets=pkt.getlayer('IP').dst.split('.')
        if 224 <= int(dst_ip_octets[0]) <=239:
            return 'IPV4MC'
        elif int(dst_ip_octets[0]) == 255 and int(dst_ip_octets[1]) == 255 \
                and int(dst_ip_octets[2]) == 255 and int(dst_ip_octets[3]) == 255:
            return 'IPV4BC'
        else:
            return 'IPV4UC'
    elif pkt_type=='ipv6':
        dst_ip_octets=pkt.getlayer('IPv6').dst.split(':')
        if dst_ip_octets[0].startswith('ff') or dst_ip_octets[0].startswith('FF'):
            return 'IPV6MC'
        else:
            return 'IPV6UC'
    return None

#verify drop counters on sysport
#ifcsobjs: ifcs_objects
#sp_list: list of keys of sysport obj
#stat_list: list of drop stats to be verified
#count: expected stats count
def verify_sysport_stats(ifcsobjs, sp_list=None, stat_list=None, count=0):

    stats_array = [
       "IPV4_PKTS_RX" ,"IPV4_BYTES_RX"
       ,"IPV4_UCAST_PKTS_RX" ,"IPV4_UCAST_BYTES_RX"
       ,"IPV4_MCAST_PKTS_RX" ,"IPV4_MCAST_BYTES_RX"
       ,"IPV4_BCAST_PKTS_RX" ,"IPV4_BCAST_BYTES_RX"
       ,"IPV4_NON_UCAST_PKTS_RX" ,"IPV4_NON_UCAST_BYTES_RX"
       ,"IPV4_HEADER_ERRS_PKTS_RX" ,"IPV4_ADDR_ERRS_PKTS_RX"
       ,"IPV4_PKTS_TX" ,"IPV4_BYTES_TX"
       ,"IPV4_UCAST_PKTS_TX" ,"IPV4_UCAST_BYTES_TX"
       ,"IPV4_MCAST_PKTS_TX" ,"IPV4_MCAST_BYTES_TX"
       ,"IPV4_BCAST_PKTS_TX" ,"IPV4_BCAST_BYTES_TX"
       ,"IPV4_NON_UCAST_PKTS_TX" ,"IPV4_NON_UCAST_BYTES_TX"
       ,"IPV6_PKTS_RX" ,"IPV6_BYTES_RX"
       ,"IPV6_UCAST_PKTS_RX" ,"IPV6_UCAST_BYTES_RX"
       ,"IPV6_MCAST_PKTS_RX" ,"IPV6_MCAST_BYTES_RX"
       ,"IPV6_NON_UCAST_PKTS_RX" ,"IPV6_NON_UCAST_BYTES_RX"
       ,"IPV6_HEADER_ERRS_PKTS_RX" ,"IPV6_ADDR_ERRS_PKTS_RX"
       ,"IPV6_PKTS_TX" ,"IPV6_BYTES_TX"
       ,"IPV6_UCAST_PKTS_TX" ,"IPV6_UCAST_BYTES_TX"
       ,"IPV6_MCAST_PKTS_TX" ,"IPV6_MCAST_BYTES_TX"
       ,"IPV6_NON_UCAST_PKTS_TX" ,"IPV6_NON_UCAST_BYTES_TX"
       ,"MPLS_PKTS_RX" ,"MPLS_BYTES_RX"
       ,"MPLS_UCAST_PKTS_RX" ,"MPLS_MCAST_BYTES_RX"
       ,"MPLS_PKTS_TX" ,"MPLS_BYTES_TX"
       ,"MPLS_UCAST_PKTS_TX" ,"MPLS_UCAST_BYTES_TX"
       ,"MPLS_MCAST_PKTS_TX" ,"MPLS_MCAST_BYTES_TX"
       ,"MPLS_NON_UCAST_PKTS_TX" ,"MPLS_NON_UCAST_BYTES_TX"
       ,"DROP_AFT_CHECK_FAIL"  ,"DROP_EGR_BRTTL_CHECK_FAIL"
       ,"DROP_EGR_HW_ERR_1" ,"DROP_EGR_INTF_CHECK_FAIL"
       ,"DROP_EGR_L2MTU_CHECK_FAIL" ,"DROP_EGR_VNI_STI_CHECK_FAIL"
       ,"DROP_FWD_L2_HDR_ERR"  ,"DROP_FWD_L2_LKUP_MISS"
       ,"DROP_FWD_L2_SRC_MISS_MOVE"  ,"DROP_FWD_L3_HDR_ERR"
       ,"DROP_FWD_L3_LKUP_MISS"  ,"DROP_FWD_L3_NOT_ENABLED"
       ,"DROP_FWD_L3_TTL_CHECK_FAIL"  ,"DROP_ING_DLP_DROP"
       ,"DROP_ING_FWD_OBJ_ERR"  ,"DROP_ING_HW_ERR"
       ,"DROP_ING_L2_INTF_CHECK_FAIL"  ,"DROP_ING_PROG_ERR"
       ,"DROP_ING_SPANNING_TREE_DROP" ,"DROP_ING_VNI_MEMBERSHIP_DROP"
       ,"DROP_L3MTU_CHECK_FAIL"   ,"DROP_TTERM_L2L3_HDR_ERR"
       ,"DROP_TTERM_TTL_CHECK_FAIL"  ,"DROP_TTERM_VNID_LKUP_FAIL",
       "DROP_ING_USER_DROP"
    ]
    time.sleep(3)
    rc=ifcs_node_stats_sync(0)
    assert rc == IFCS_SUCCESS

    if not sp_list:
        sp_list = ifcsobjs['Sysport'].keys()
    if not stat_list:
        stat_list = stats_array
    else:
        stat_list = [s.upper() for s in stat_list]
        assert all(x in stats_array for x in stat_list), 'stat_list contains invalid sysport stats_id'

    for sp in sp_list:
        sp_obj = ifcsobjs['Sysport'][sp]
        stats = sp_obj.stats_get(stat_list)
        for i in range(len(stats)):
            assert stats[i]==count, 'stats: {0} on sysport {1}, expected: {2}, actual: {3}'\
                .format(stat_list[i], sp, count, stats[i])

#L2VNI stats test update in infra
def update_l2vni_stats(port,l2vni,num_packets=1,total_len=102,direction='rx',mac_type='UC'):
    import model_server
    #Port will be used later to get the l2vni on that port. in case of ingress, egress map, default_cvid on port etc..
    if isinstance(l2vni,(int,long)):
        l2vni_hdl = IFCS_HANDLE_L2VNI(l2vni)
    else:
        #l2vni should be a vlan.
        return
    model_server.l2vni_stats_for[l2vni_hdl] = l2vni
    if direction == 'rx':

        if l2vni_hdl in model_server.L2VNI_STATS_RX_PACKETS:
            model_server.L2VNI_STATS_RX_PACKETS[l2vni_hdl] += num_packets
            model_server.L2VNI_STATS_RX_BYTES[l2vni_hdl] += total_len
        else:
            model_server.L2VNI_STATS_RX_PACKETS[l2vni_hdl] = num_packets
            model_server.L2VNI_STATS_RX_BYTES[l2vni_hdl] = total_len

        if mac_type == 'UC':
            if l2vni_hdl in model_server.L2VNI_STATS_RX_UC_PACKETS:
                model_server.L2VNI_STATS_RX_UC_PACKETS[l2vni_hdl] += num_packets
                model_server.L2VNI_STATS_RX_UC_BYTES[l2vni_hdl] += total_len
            else:
                model_server.L2VNI_STATS_RX_UC_PACKETS[l2vni_hdl] = num_packets
                model_server.L2VNI_STATS_RX_UC_BYTES[l2vni_hdl] = total_len
        if mac_type == 'BC':
            if l2vni_hdl in model_server.L2VNI_STATS_RX_BC_PACKETS:
                model_server.L2VNI_STATS_RX_BC_PACKETS[l2vni_hdl] += num_packets
                model_server.L2VNI_STATS_RX_BC_BYTES[l2vni_hdl] += total_len
            else:
                model_server.L2VNI_STATS_RX_BC_PACKETS[l2vni_hdl] = num_packets
                model_server.L2VNI_STATS_RX_BC_BYTES[l2vni_hdl] = total_len
        if mac_type == 'MC':
            if l2vni_hdl in model_server.L2VNI_STATS_RX_MC_PACKETS:
                model_server.L2VNI_STATS_RX_MC_PACKETS[l2vni_hdl] += num_packets
                model_server.L2VNI_STATS_RX_MC_BYTES[l2vni_hdl] += total_len
            else:
                model_server.L2VNI_STATS_RX_MC_PACKETS[l2vni_hdl] = num_packets
                model_server.L2VNI_STATS_RX_MC_BYTES[l2vni_hdl] = total_len


    if direction == 'tx':
        if l2vni_hdl in model_server.L2VNI_STATS_TX_PACKETS:
            model_server.L2VNI_STATS_TX_PACKETS[l2vni_hdl] += num_packets
            model_server.L2VNI_STATS_TX_BYTES[l2vni_hdl] += total_len
        else:
            model_server.L2VNI_STATS_TX_PACKETS[l2vni_hdl] = num_packets
            model_server.L2VNI_STATS_TX_BYTES[l2vni_hdl] = total_len
        if mac_type == 'UC':
            if l2vni_hdl in model_server.L2VNI_STATS_TX_UC_PACKETS:
                model_server.L2VNI_STATS_TX_UC_PACKETS[l2vni_hdl] += num_packets
                model_server.L2VNI_STATS_TX_UC_BYTES[l2vni_hdl] += total_len
            else:
                model_server.L2VNI_STATS_TX_UC_PACKETS[l2vni_hdl] = num_packets
                model_server.L2VNI_STATS_TX_UC_BYTES[l2vni_hdl] = total_len
        if mac_type == 'BC':
            if l2vni_hdl in model_server.L2VNI_STATS_TX_BC_PACKETS:
                model_server.L2VNI_STATS_TX_BC_PACKETS[l2vni_hdl] += num_packets
                model_server.L2VNI_STATS_TX_BC_BYTES[l2vni_hdl] += total_len
            else:
                model_server.L2VNI_STATS_TX_BC_PACKETS[l2vni_hdl] = num_packets
                model_server.L2VNI_STATS_TX_BC_BYTES[l2vni_hdl] = total_len
        if mac_type == 'MC':
            if l2vni_hdl in model_server.L2VNI_STATS_TX_MC_PACKETS:
                model_server.L2VNI_STATS_TX_MC_PACKETS[l2vni_hdl] += num_packets
                model_server.L2VNI_STATS_TX_MC_BYTES[l2vni_hdl] += total_len
            else:
                model_server.L2VNI_STATS_TX_MC_PACKETS[l2vni_hdl] = num_packets
                model_server.L2VNI_STATS_TX_MC_BYTES[l2vni_hdl] = total_len
#L3intf stats test update in infra
def update_l3intf_stats(port,pkt_mac,l3intf_hdl,num_packets=1,total_len=102,direction='rx',pkt_ip_type='UC'):
    import model_server
    if direction == 'rx':

        if l3intf_hdl in model_server.L3INTF_STATS_RX_PACKETS:
            model_server.L3INTF_STATS_RX_PACKETS[l3intf_hdl] += num_packets
            model_server.L3INTF_STATS_RX_BYTES[l3intf_hdl] += total_len
        else:
            model_server.L3INTF_STATS_RX_PACKETS[l3intf_hdl] = num_packets
            model_server.L3INTF_STATS_RX_BYTES[l3intf_hdl] = total_len

        if pkt_ip_type in ['IPV4UC','IPV6UC']:
            if l3intf_hdl in model_server.L3INTF_STATS_RX_UC_PACKETS:
                model_server.L3INTF_STATS_RX_UC_PACKETS[l3intf_hdl] += num_packets
                model_server.L3INTF_STATS_RX_UC_BYTES[l3intf_hdl] += total_len
            else:
                model_server.L3INTF_STATS_RX_UC_PACKETS[l3intf_hdl] = num_packets
                model_server.L3INTF_STATS_RX_UC_BYTES[l3intf_hdl] = total_len

#Flex counter stats test update in infra
def update_mcast_route_stats(port,mr_key,mcast_route_hdl,num_packets=1,total_len=102,direction='rx',pkt_ip_type='UC'):
    import stats_globals
    if direction == 'rx':

        if mcast_route_hdl in stats_globals.MCAST_ROUTE_STATS_RX_PACKETS:
            stats_globals.MCAST_ROUTE_STATS_RX_PACKETS[mcast_route_hdl] += num_packets
            stats_globals.MCAST_ROUTE_STATS_RX_BYTES[mcast_route_hdl] += total_len
        else:
            stats_globals.MCAST_ROUTE_STATS_RX_PACKETS[mcast_route_hdl] = num_packets
            stats_globals.MCAST_ROUTE_STATS_RX_BYTES[mcast_route_hdl] = total_len

        if pkt_ip_type in ['IPV4MC','IPV6MC']:
            if mcast_route_hdl in stats_globals.MCAST_ROUTE_STATS_RX_UC_PACKETS:
                stats_globals.MCAST_ROUTE_STATS_RX_UC_PACKETS[mcast_route_hdl] += num_packets
                stats_globals.MCAST_ROUTE_STATS_RX_UC_BYTES[mcast_route_hdl] += total_len
            else:
                stats_globals.MCAST_ROUTE_STATS_RX_UC_PACKETS[mcast_route_hdl] = num_packets
                stats_globals.MCAST_ROUTE_STATS_RX_UC_BYTES[mcast_route_hdl] = total_len

def api_log_replay(log_file=None):
    if not log_file:
        log_file = get_apidata_name()
        log_file_name = os.path.basename(log_file)
        os.system("cp -f "+"{0} ./{1}".format(log_file, log_file_name))
    #enable API logs for debugging
    attr = ifcs_attr_t()
    ifcs_attr_t_id_set(pointer(attr), IFCS_NODE_ATTR_API_LOG_ENABLE)
    ifcs_attr_t_value_data_set(pointer(attr), IFCS_BOOL_TRUE)
    ifcs_node_attr_set(0, 1, pointer(attr))
    #replay the actions.
    ret = im_log_rec_params_restore(log_file_name, ifcs_api_replay_cb_t(im_api_replay), 1)
    time.sleep(5)
    assert ret == IFCS_SUCCESS,\
           "Could not replay api"
    os.system("rm -rf {0} > /dev/null".format(log_file_name))

def replace_lag_members(Lag1,Lag2_mbrs,member_type='secondary',expRc=IFCS_SUCCESS):
    attr = (1 * ifcs_attr_t)()
    ifcs_attr_t_init(pointer(attr))
    ifcs_attr_t_id_set(pointer(attr), IFCS_LAG_MEMBER_ATTR_TYPE)
    ifcs_attr_t_value_u32_set(pointer(attr), globals()['IFCS_LAG_MEMBER_TYPE_{0}'.format(member_type.upper())])
    Lag1.replaceMembers(Lag2_mbrs, attrCount=1, attrList=attr,expRc=expRc)
    if expRc == IFCS_SUCCESS:
        verify_lag_member_type(Lag1,member_type)

def add_lag_members(Lag1,sysportList,member_type='primary',expRc=IFCS_SUCCESS):
    attr = (1 * ifcs_attr_t)()
    ifcs_attr_t_init(pointer(attr))
    ifcs_attr_t_id_set(pointer(attr), IFCS_LAG_MEMBER_ATTR_TYPE)
    ifcs_attr_t_value_u32_set(pointer(attr), globals()['IFCS_LAG_MEMBER_TYPE_{0}'.format(member_type.upper())])
    Lag1.addMembers(sysportList, attrCount=1, attrList=attr,expRc=expRc)
    if expRc == IFCS_SUCCESS:
        verify_lag_member_type(Lag1,member_type)

def verify_lag_member_type(lag,exp_member_type):
    for member in lag.getMembers():
        assert lag.getMemberType(member) == globals()['IFCS_LAG_MEMBER_TYPE_{0}'.format(exp_member_type.upper())]

def remove_lag_members(Lag1,sysportList,expRc=IFCS_SUCCESS):
    Lag1.removeMembers(sysportList,expRc=expRc)


def verifySecondaryLagHdls(sysport_list,exp_lag_list):
    for sysport in sysport_list:
        if len(exp_lag_list) == 0:
            sec_lag_list = sysport.getSecondaryLagList(expRc=IFCS_SUCCESS)
        else:
            sec_lag_list = sysport.getSecondaryLagList()
        assert len(exp_lag_list) == len(sec_lag_list)
        if len(exp_lag_list) == 0:
            continue
        for i in range(len(exp_lag_list)):
            assert sec_lag_list[i].getHandle() == exp_lag_list[i].getHandle()

def get_mc_mdg_resolved_port(ifcsobjs,mdg):
    sysport_map = OrderedDict()

    for sp in ifcsobjs['Sysport']:
        sp_num = int(sp.replace("SP",""))
        sysport_map[ifcsobjs['Sysport'][sp].getHandle()] = sp_num

    mc_dest_list = []
    mc_dest_list = ifcsobjs['MdgNexthopMembers'][mdg].getMc_dests()
    if not mc_dest_list:
        return -1
    selected_lag_port_list = []
    for mc_dest in mc_dest_list:
        attr = ifcs_attr_t()
        attr_count = ctypes.c_uint32()
        ifcs_attr_t_id_set(pointer(attr), IFCS_MDG_MC_DEST_ATTR_SELECTED_LAG_MEMBER)
        rc = ifcs_mdg_mc_dest_attr_get(0, ifcsobjs['MdgNexthopMembers'][mdg].getHandle(), \
                                      mc_dest.getHandle(), \
                                      1, pointer(attr), pointer(attr_count))
        assert rc == IFCS_SUCCESS, "Unable to get attributes. Ret:" + str(rc)
        selected_lag_hdl = attr.value.handle
        selected_lag_port = sysport_map[selected_lag_hdl]
        selected_lag_port_list.append(selected_lag_port-1)

    if len(selected_lag_port_list) > 1:
        return ",".join(str(x) for x in selected_lag_port_list)
    else:
        return selected_lag_port_list[0]


  # 
def main():
    num_nodes = init_ifcs()
    deinit_ifcs(num_nodes)

def setLogLevelInfo():
    '''Set Log level'''
    logger.setLevel(logging.INFO)

if __name__ == "__main__":
    main()
