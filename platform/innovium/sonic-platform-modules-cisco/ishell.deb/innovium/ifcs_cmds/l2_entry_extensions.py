
#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
# *-----------------------------------------------------------------------------

import copy
from ctypes import *
from cli_types import *
from itertools import *
from time import *
from ifcs_ctypes import *
from ifcs_ctypes import *
from l2_entry import *
from print_table import PrintTable

key_type_dict = {
    IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI : "mac_l2vni",
    IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI : "ip_sp_l2vni",
    IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI : "ip_starg_l2vni",
    IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY : "mac_only",
}

def get_mac_addr_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY:
        return (mac_addr_to_str(l2_entry.contents.key.mac_only.mac_addr))
    else:
        return (mac_addr_to_str(l2_entry.contents.key.mac_l2vni.mac_addr))

def get_mac_mask_from_l2_entry(l2_entry):
    return (mac_addr_to_str(l2_entry.contents.key.mac_only.mac_mask))

def get_group_ip_addr_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        if l2_entry.contents.key.ip_starg_l2vni.group.addr_family == IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_sg_l2vni.group.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_sg_l2vni.group.addr.ipv6))
    else:
        if l2_entry.contents.key.ip_starg_l2vni.group.addr_family == IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_starg_l2vni.group.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_starg_l2vni.group.addr.ipv6))

def get_source_ip_addr_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        if l2_entry.contents.key.ip_sg_l2vni.source.addr_family == IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_sg_l2vni.source.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_sg_l2vni.source.addr.ipv6))
    else:
        if l2_entry.contents.key.ip_starg_l2vni.source.addr_family == IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        l2_entry.contents.key.ip_starg_l2vni.source.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    l2_entry.contents.key.ip_starg_l2vni.source.addr.ipv6))

def get_l2vni_from_l2_entry(l2_entry):
    if l2_entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        return (l2_entry.contents.key.ip_sg_l2vni.l2vni)
    elif l2_entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI:
        return (l2_entry.contents.key.ip_starg_l2vni.l2vni)
    elif l2_entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI:
        return (l2_entry.contents.key.mac_l2vni.l2vni)
    else:
        return 0

def get_key_from_l2_entry(entry):
    source = " * "
    group = " * "
    mac_addr = " * "
    mac_mask = " * "
    if entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_IP_SG_L2VNI:
        source = get_source_ip_addr_from_l2_entry(entry)
        group = get_group_ip_addr_from_l2_entry(entry)
    elif entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_IP_STARG_L2VNI:
        group = get_group_ip_addr_from_l2_entry(entry)
    elif entry.contents.key_type == IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI:
        mac_addr = get_mac_addr_from_l2_entry(entry)
    else:
        mac_addr = get_mac_addr_from_l2_entry(entry)
        mac_mask = get_mac_mask_from_l2_entry(entry)

    return source, group, mac_addr, mac_mask


def show_l2_entry_extension_brief(args, l2_entry):
    log_dbg(1, " Inside extension brief show")

    def myCallback(node_id, arg, attr_count, attr_list, user_data):
        l2_attr_dict = {}
        for i in range(attr_count):
            if attr_list[i].id == IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY:
                l2_attr_dict['fwd_policy'] = attr_list[i].value.fwd_policy
            elif attr_list[i].id == IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY:
                l2_attr_dict['ctc_policy'] = attr_list[i].value.ctc_policy
            elif attr_list[i].id == IFCS_L2_ENTRY_ATTR_HITBIT:
                l2_attr_dict['hitbit'] = attr_list[i].value.u32
            elif attr_list[i].id == IFCS_L2_ENTRY_ATTR_USER_COOKIE:
                l2_attr_dict['user_cookie'] = attr_list[i].value.u32
            elif attr_list[i].id == IFCS_L2_ENTRY_ATTR_ENTRY_TYPE:
                l2_attr_dict['entry_type'] = attr_list[i].value.u32
            elif attr_list[i].id == IFCS_L2_ENTRY_ATTR_ENTRY_DEST:
                l2_attr_dict['entry_dest'] = attr_list[i].value.handle

        l2_entry_list.append((arg, attr_count, copy.deepcopy(l2_attr_dict)))
    l2_entry_list = []

    callback_type = CFUNCTYPE(
        UNCHECKED(None),
        ifcs_node_id_t,
        POINTER(ifcs_l2_entry_key_t),
        c_uint32,
        POINTER(ifcs_attr_t),
        POINTER(None))
    callback = callback_type(myCallback)

    try:
        rc = ifcs_l2_entry_get_all(
            l2_entry.cli.node_id, 0, 0, 0, callback, 0, None)
        if rc != IFCS_SUCCESS:
            log_err(
                "Failed to get all l2_entry rc: {0}".format(
                    convert_error_code_to_string(rc)))
    except Exception as e:
        log_err(" Failed to get all l2entries : {0} ".format(e))
        raise e

    table = PrintTable()

    field_names = [
        'key_type',
        'mac_addr',
        'mac_mask',
        'source',
        'group',
        'l2vni',
        'entry_dest',
        'entry_type',
        'fwd_policy',
        'ctc_policy',
        'user_cookie',
        'hitbit']
    table.add_row(field_names)

    all_l2_entry = l2_entry_list
    print "Total l2_entry count: {0} ".format(len(all_l2_entry))
    for entry in all_l2_entry:
        row = []
        key_type = key_type_dict[entry[0].contents.key_type]
        source, group, mac_addr, mac_mask = get_key_from_l2_entry(entry[0])

        attr_count = entry[1]
        attr_dict = entry[2]
        for i in range(attr_count):
            fwd_policy = l2_entry.handle_to_str(attr_dict['fwd_policy'].pp_drop_reason), l2_entry.enum_to_str('fwd_action', attr_dict['fwd_policy'].fwd_action)
            ctc_policy = l2_entry.handle_to_str(attr_dict['ctc_policy'].trap_handle), l2_entry.enum_to_str('copy_to_cpu', attr_dict['ctc_policy'].ctc_action)
            cookie = attr_dict['user_cookie']
            hitbit = attr_dict['hitbit']
            entrydest = l2_entry.handle_to_str(attr_dict['entry_dest'])
            entrytype = l2_entry.enum_to_str('entry_type', attr_dict['entry_type'])
        l2vni = l2_entry.handle_to_str(get_l2vni_from_l2_entry(entry[0]))
        row.append(key_type)
        row.append(mac_addr)
        row.append(mac_mask)
        row.append(source)
        row.append(group)
        row.append(l2vni)
        row.append(entrydest)
        row.append(entrytype)
        row.append(fwd_policy)
        row.append(ctc_policy)
        row.append(cookie)
        row.append(hitbit)
        table.add_row(row)
    table.print_table(brief=True)
    table.reset_table()
    print "Total l2_entry count: {0} \n".format(len(all_l2_entry))

    return
