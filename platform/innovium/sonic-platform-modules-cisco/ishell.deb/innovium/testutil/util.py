#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import itertools
import bincopy

def hexdump(a):
    b = bytearray(a)
    addr = 0
    for group in itertools.izip_longest(*[iter(b)]*16):
        print "{:04x}: ".format(addr),
        addr += 16
        for val in group:
            if val is not None:
                print "{:02x}".format(val),
        print

def hexdump_ascii(a):
    binfile = bincopy.BinFile()
    binfile.add_binary(a, 0)
    print binfile.as_hexdump()

def fmt_num(num, suffix='', base=1000):
    num = float(num)
    units = ['','K','M','G','T']
    for unit in units:
        if abs(num) < base or unit == units[-1]:
            return "%3.3f%s%s" % (num, unit, suffix)
        num /= base
