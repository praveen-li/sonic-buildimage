#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import bincopy
from utils.compat_util import *
from verbosity import log

def hexdump(a):
    b = bytearray(a)
    addr = 0
    for group in compat_izip_longest(*[iter(b)]*16):
        log("{:04x}: ".format(addr),)
        addr += 16
        for val in group:
            if val is not None:
                log("{:02x}".format(val),)
        log("")

def hexdump_ascii(a):
    binfile = bincopy.BinFile()
    binfile.add_binary(a, 0)
    log(binfile.as_hexdump())

def fmt_num(num, suffix='', base=1000):
    num = float(num)
    units = ['','K','M','G','T']
    for unit in units:
        if abs(num) < base or unit == units[-1]:
            return "%3.3f%s%s" % (num, unit, suffix)
        num /= base
