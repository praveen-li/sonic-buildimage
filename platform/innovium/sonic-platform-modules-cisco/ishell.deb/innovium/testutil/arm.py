#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

# Utility functions for loading/running code on ARM
import threading
import time
import sys
import datetime

from testutil import pci
from testutil import mid
from testutil import bincopy
from verbosity import log

TCMA_ARM_OFFSET = 0x00000000  # Address of TCMA in ARM space
TCMB_ARM_OFFSET = 0x00800000  # Address of TCMB in ARM space

TCMA_MSN_OFFSET = 0x08000000  # Address of TCMA in MSN space
TCMB_MSN_OFFSET = 0x08800000  # Address of TCMB0 on in MSN space

TCMA_SIZE = 0x00040000
TCMB_SIZE = 0x00080000

class FirmwareTimeoutExeception(Exception):
    pass

def reset_is_active():
    return (pci.read_fields('MCU0_CNFG')['reset_f'] == 0)  # active low

def reset_clear():
    pci.write_fields('MCU0_CNFG', reset_f=1)

def reset_set():
    pci.write_fields('MCU0_CNFG', reset_f=0)

def sysreset_is_active():
    return (pci.read_fields('MCU0_CNFG1')['sysporeset_f'] == 0)  # active low

def sysreset_clear():
    pci.write_fields('MCU0_CNFG1', sysporeset_f=1)

def sysreset_set():
    pci.write_fields('MCU0_CNFG1', sysporeset_f=0)

def dbgreset_is_active():
    return (pci.read_fields('MCU0_CNFG1')['presetdbg_f'] == 0)

def dbgreset_clear():
    pci.write_fields('MCU0_CNFG1', presetdbg_f=1)

def dbgreset_set():
    pci.write_fields('MCU0_CNFG1', presetdbg_f=0)

def halt_is_active():
    return (pci.read_fields('MCU0_CNFG')['halt_f'] == 1)  # active high

def halt_set():
    pci.write_fields('MCU0_CNFG', halt_f=1)

def halt_clear():
    pci.write_fields('MCU0_CNFG', halt_f=0)

def is_unsafe():
    # check to see if the block is in reset
    #return not(sysreset_is_active() && reset_is_active())
    return (sysreset_is_active() or reset_is_active())

def stop():
    sysreset_clear()
    halt_set()
    reset_set()
    reset_clear()

def map_arm_to_msn(addr):
    if addr >= TCMA_ARM_OFFSET and addr < TCMA_ARM_OFFSET + TCMA_SIZE:
        return addr - TCMA_ARM_OFFSET + TCMA_MSN_OFFSET
    if addr >= TCMB_ARM_OFFSET and addr < TCMB_ARM_OFFSET + TCMB_SIZE:
        return addr - TCMB_ARM_OFFSET + TCMB_MSN_OFFSET
    raise ValueError('ARM Address 0x{:08x} not mapped to a TCM'.format(addr))

def read8(addr, count):
    return mid.read8(map_arm_to_msn(addr), count)

def write8(addr, val_list):
    mid.write8(map_arm_to_msn(addr), val_list)

def read32(addr, count):
    return mid.read32(map_arm_to_msn(addr), count)

def write32(addr, val_list):
    mid.write32(map_arm_to_msn(addr), val_list)

def read64(addr, count):
    return mid.read64(map_arm_to_msn(addr), count)

def write64(addr, val_list):
    mid.write64(map_arm_to_msn(addr), val_list)

def load(filename):
    # hardware init of memory, wait 32usec (x2 for safety)
    pci.write_fields('MCU_MEM_INIT', mcu1_f=1)
    time.sleep(0.32) # XXX 1/5000 speed in EMULATION

    binfile = bincopy.BinFile()
    if filename.lower().endswith('ihex'):
        binfile.add_ihex_file(filename)
    else:
        binfile.add_srec_file(filename)

    if is_unsafe():
        # core not running, go to reset/halted state to avoid bus fault/hang
        stop()

    for seg_base, seg_top, seg_data in binfile.iter_segments():
        mid.write8(map_arm_to_msn(seg_base), seg_data)

old_head = 0;
exitFlag = False
threads = []

class logThread (threading.Thread):
    def __init__(self, threadID, name, sleepTime):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.sleepTime = sleepTime

    def run(self):
        global old_head
        global exitFlag
        log(":Start MCU Logging:")
        log_size = read32(0x800404, 1)[0]
        write32(0x800404, [0x0])
        old_head = read32(0x00800400, 1)[0]
        while not exitFlag:
            # check for program reloads
            check_size = read32(0x800404, 1)[0]
            if check_size:
                #print("check_size:%u" % (check_size))
                write32(0x800404, [0x0])
                log_size = check_size
                old_head = 0
            #check for new log text
            cur_head = read32(0x800400, 1)[0]
            #print("head:%u old:%u" % (cur_head, old_head))
            if (cur_head != old_head):
                count = cur_head - old_head
                if (count < 0):
                    count += log_size
                if ((old_head + count) > log_size):
                    #print("wrap:%u" % (log_size - old_head))
                    buf = read8(0x00800408 + old_head, log_size - old_head)
                    outstr = "".join(list(map(chr, buf)))
                    old_head = 0
                    count = cur_head - old_head
                else:
                    outstr = ""
                #print("log:%u" % (count))
                buf = read8(0x00800408 + old_head, count)
                outstr += "".join(list(map(chr, buf)))
                outstr = sub_in_timestamps(outstr)
                sys.stdout.write(outstr)
                sys.stdout.flush()
                old_head = cur_head

            time.sleep(self.sleepTime)
        log(":Ending MCU Logging:")

def log_start():
    global print_timestamp_start
    global threads
    global exitFlag
    print_timestamp_start = datetime.datetime.now()

    if not threads:
        exitFlag = False
        thread = logThread(1, "MCU Logging Thread", .25)
        thread.start()
        threads.append(thread)

def log_stop():
    global threads
    global exitFlag
    exitFlag = True
    tempThreads = threads
    for t in tempThreads:
        #print("MCU join")
        t.join()
        threads.remove(t)

def sub_in_timestamps(s):
    SOH = '\001'  # prints timestamp
    STX = '\002'  # sets "start" timestamp value
    ETX = '\003'  # prints current time - "start" timestamp value

    curtime = datetime.datetime.now()
    a = s.replace(SOH, str(curtime))
    # deal with the fact that we might get <STX>xxx<ETX> or <ETX><STX> in one blob

    global print_timestamp_start
    b_list = []
    for x in a.split(ETX):
        if STX in x:
            print_timestamp_start = curtime
            b_list.append(x.replace(STX,''))
        else:
            b_list.append(x)
        b_list.append(str(curtime - print_timestamp_start))

    # we'll have an extra 'timediff' on the end of the list, so trim it:
    return "".join(b_list[:-1])

def get_existing_log():
    log_size = read32(0x00800404, 1)[0]
    cur_head = read32(0x00800400, 1)[0]
    buf = read8(0x00800408, cur_head)
    outstr = "".join(list(map(chr,buf)))
    return outstr

def mbox_len(num):
    mbox_cidx_reg = 'MB_CIDX_%d' % num
    mbox_pidx_reg = 'MB_PIDX_%d' % num
    cidx = pci.read_fields(mbox_cidx_reg)['idx_f']
    pidx = pci.read_fields(mbox_pidx_reg)['idx_f']
    if pidx < cidx:
        pidx += (2 << 6)
    return pidx - cidx

def mbox_is_empty(num):
    return mbox_len(num) == 0

def mbox_is_full(num):
    return mbox_len(num) == (1<<6)

def mbox_read(num):
    mbox_rdata = 'MB_RDATA_%d' % num
    out = []
    for i in range(0, mbox_len(num)):
        out.append(pci.read_fields(mbox_rdata)['data_f'])
    return out

def mbox_write(num, data):
    mbox_cidx = 'MB_CIDX_%d' % num
    mbox_pidx = 'MB_PIDX_%d' % num
    mbox_wdata = 'MB_WDATA_%d' % num
    if not isinstance(data, list):
        data = [data]

    for d in data:
        iterations = 0
        while mbox_is_full(num):
            iterations += 1
            if iterations > 100000:
                raise(FirmwareTimeoutExeception('MBOX Full'))
        pci.write_fields(mbox_wdata, data_f=d)
