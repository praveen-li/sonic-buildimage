#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2019
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

# Filename: penrw.py

from __future__ import print_function
try:
    import __builtin__
except ImportError:
    import builtins as __builtin__
import datetime
def print(*args, **kwargs):
    __builtin__.print(str(datetime.datetime.now()) + ": ", end="")
    return __builtin__.print(*args, **kwargs)

from ctypes import *
from ifcs_ctypes import *
from utils.compat_util import *

class ifcs_exception(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)


def write_pen(pen_id, index, fldlst, indir_cmd=ISN_CMD_HASH_RSVD15, ib=0):
    """ Direct Write to One PEN Entry """
    buf = (c_ubyte * 256)()
    pen_str = c_char_p(b" " * 32)
    fld_str = c_char_p(b" " * 32)
    # Get Information About the PEN
    peninfo = get_pen_info(pen_id)
    rc = node_get_pen_name(0, pen_id, pen_str, 32)
    assert rc == IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    # gather field information
    nflds, fldinfo = get_flds_from_peninfo(pen_id, peninfo)

    print ("=== Writing to %s,  Index 0x%x: " %(pen_str.value, index))
    entry = tentry_new(pen_id, -1, -1)

    # Go through each field and call tentry_set_item
    for elem in range (len(fldlst)):
        if (len(fldlst[elem]) == 2) :
            set_pen_fld(nflds, fldinfo, pen_id, pen_str, fldlst[elem], entry)
        else:
            set_pen_sfld(nflds, fldinfo, pen_id, pen_str, fldlst[elem], entry)

    # Now write the entry into PEN.
    pentype = c_int(0)
    penacc  = c_int(0)
    node    = 0

    rc = node_get_pen_type_acc(node, int(pen_id), byref(pentype), byref(penacc))
    assert rc == IFCS_SUCCESS, "PEN get type/acc failed: rc = " + str(rc)

    if (pentype.value & PEN_TYPE_HASH) :
        hash_fn    = 0
        bktmd      = c_int(0)
        hash_index = c_int(0)
        hash_index.value = index

        if (indir_cmd == ISN_CMD_HASH_RSVD15) :
            # Fixme: For now, I am assuming that this means that no hash command was
            # specified by function call. Default to write
            hash_cmd = ISN_CMD_HASH_WRITE
        else :
            # Use value specified by function call
            hash_cmd = indir_cmd

        rc = node_isn_pen_hash_cmd (node, ib, int(pen_id), hash_cmd, hash_fn, byref(hash_index), byref(bktmd), entry)
        assert ((rc == IFCS_SUCCESS) or (rc == IFCS_ENTRY_REPLACED)), "PEN " + str(pen_str.value) + " : Hash command failed: rc = " + str(rc)

    elif (pentype.value & PEN_TYPE_ILPM) :
        hash_fn    = 0
        bktmd      = c_int(0)
        hash_index = c_int(0)
        hash_index.value = index
        hash_cmd = ISN_CMD_HASH_WRITE

        rc = node_isn_pen_ilpm_cmd (node, ib, int(pen_id), hash_cmd, byref(hash_index), byref(bktmd), entry)
        assert ((rc == IFCS_SUCCESS) or (rc == IFCS_ENTRY_REPLACED)), "PEN " + str(pen_str.value) + " : ILPM command failed: rc = " + str(rc)


    elif ((pentype.value & PEN_TYPE_TCAM) or (pentype.value & PEN_TYPE_ABB_TCAM)) :
        if (penacc.value):
            tcam_index = c_int(0)
            tcam_index.value = index

            if (indir_cmd == ISN_CMD_HASH_RSVD15) :
                # For now, I am assuming that this means that no tcam command was
                # specified by function call
                tcam_cmd = ISN_CMD_TCAM_WRITE
            else :
                # Use value specified by function call
                tcam_cmd = indir_cmd

            rc = node_isn_pen_tcam_cmd(node, ib, int(pen_id), tcam_cmd, byref(tcam_index), entry)
            assert rc == IFCS_SUCCESS, "PEN " + str(pen_str.value) + " : TCAM command failed: rc = " + str(rc)
        else :
            hints = 0
            rc = node_isn_pen_write(node, ib, int(pen_id), index, hints, entry)
            assert rc == IFCS_SUCCESS, "PEN " + str(pen_str.value) + " : Write failed: rc = " + str(rc)
    else :
        hints = 0
        rc = node_isn_pen_write(node, ib, int(pen_id), index, hints, entry)
        assert rc == IFCS_SUCCESS, "PEN " + str(pen_str.value) + " : Write failed: rc = " + str(rc)

    tentry_free(entry)

#------------------------------------------
def read_direct_pen_and_check(pen_id, index, fldlst, fldinfo):

        tmplst = []
        tmplst = read_pen(pen_id, index, tmplst, 0)
        rd_fld_map = {}
        for i in range(len(tmplst)):
            rd_fld_map[tmplst[i][0]] = tmplst[i][1]

        wr_fld_map = {}
        for i in range(len(fldlst)):
            wr_fld_map[fldlst[i][0]] = fldlst[i][1]

        name = {}
        for i in range(len(fldinfo)):
                my_str = c_char_p(b" " * 32)
                node_get_pen_field_name(0, fldinfo[i].fname, my_str, 32)
                name[fldinfo[i].fname] = my_str.value

        for k, v in rd_fld_map.items():
            if ( k in wr_fld_map ):
                if( type(v) is int ):
                    if ( v != wr_fld_map[k]):
                        print ('\t ***ERROR*** : ', name[k], 'mismatches written value')
                else:
                    foo = zip(v, wr_fld_map[k])
                    for rval, wval in foo:
                        if( rval != wval ):
                            print ('\t ***ERROR*** : ', name[k], 'mismatches written value')

            else:
                pass
                # comment out because it cannot handle subfield
                #if( type(v) is int and v != 0 ):
                #    print 'ERROR:', name[k], 'is expected to be 0'


def set_pen_fld(nflds, fldinfo, pen_id, pen_str, fld_elem, entry):

    buf = (c_ubyte * 256)()
    fld_str = c_char_p(b" " * 32)
    fld_id = fld_elem[0]

    # Get field name
    rc = node_get_pen_field_name(0, fld_id, fld_str, 32)
    assert rc == IFCS_SUCCESS, "Couldnt get name for field id " + str(fld_id)

    # Get width of field
    fld_width = get_fld_width(nflds, fldinfo, pen_id, fld_id)

    # based on width of field, call tentry_set_item with appropriate arguments
    if (fld_width == -1):
        assert 0, "Error: Field " + str(fld_str.value) + " does not exist in pen " + str(pen_str.value)

    if (fld_width <= 32) :
        fld_val       = c_int(0)
        fld_val.value = int(fld_elem[1])
        print ("    %s : 0x%x " %(fld_str.value, fld_val.value))
        rc = tentry_set_item(0, pen_id, fld_id, TENTRY_FLD_TYPE_UINT32, \
                             entry, pointer(fld_val))
        assert rc == IFCS_SUCCESS, "PEN tentry set failed: rc = " + str(rc)
    else :
        nbytes = compat_division((fld_width + 7), 8)
        for n in range(nbytes):
            buf[n] = int(fld_elem[1][n])
        print ("    %s : " %(fld_str.value) , [hex(i) for i in fld_elem[1]])
        rc = tentry_set_item(0, pen_id, fld_id, TENTRY_FLD_TYPE_ANY, \
                            entry, compat_pointer(buf, c_ubyte))
        assert rc == IFCS_SUCCESS, "PEN tentry set failed: rc = " + str(rc)
    #

def set_pen_sfld(nflds, fldinfo, pen_id, pen_str, fld_elem, entry):
    if (len(fld_elem) < 4) :
        assert 0, "Incorrect specification of efield assignment for Pen " + pen_str.value

    mfld_str = c_char_p(b" " * 32)
    sfld_str = c_char_p(b" " * 32)

    mfld    = fld_elem[0]
    rc = node_get_pen_field_name(0, mfld, mfld_str, 32)
    assert rc == IFCS_SUCCESS, "Couldnt get name for field id " + str(mfld)

    if (fld_elem[1] == "mk"):
        mk = 1
    elif (fld_elem[1] == "epd"):
        mk = 0
    else :
        assert 0, "Pen " + pen_str.value + ": Write to Field " + mfld_str.value + ": Must use \"mk\" or \"epd\" to specify field assignments"

    prof    = fld_elem[2]

    for j in range(3, len(fld_elem)):
        sfld = fld_elem[j][0]

        # Get sfield name
        rc = node_get_pen_field_name(0, sfld, sfld_str, 32)
        assert rc == IFCS_SUCCESS, "Couldnt get name for field id " + str(sfld)

        # Get sfield width
        sfld_width = get_sfld_width(nflds, fldinfo, pen_id, pen_str, mfld, mfld_str, mk, prof, sfld, sfld_str)

        # Based on width of sfield, call tentry_set_efield_item with appropriate arguments
        if (sfld_width <= 32) :
            fld_val       = c_int(0)
            fld_val.value = int(fld_elem[j][1])
            print ("    %s : 0x%x " %(sfld_str.value, fld_val.value))
            rc = tentry_set_efield_item(0, pen_id, mfld, mk,       \
                                 sfld, prof, TENTRY_FLD_TYPE_UINT32, \
                                 entry, pointer(fld_val))
            assert rc==IFCS_SUCCESS, "tentry_set_efield_item failed for " + sfld_str.value + " rc = " + str(rc)
        else :
            buf = (c_ubyte * 256)()
            nbytes = compat_division((sfld_width + 7), 8)
            for n in range(nbytes):
                buf[n] = int(fld_elem[j][1][n])
            print ("    %s : " %(sfld_str.value) , [hex(i) for i in fld_elem[j][1]])
            rc = tentry_set_efield_item(0, pen_id, mfld, mk,          \
                                sfld, prof, TENTRY_FLD_TYPE_ANY,      \
                                entry, compat_pointer(buf, c_ubyte))
            assert rc==IFCS_SUCCESS, "tentry_set_efield_item failed for " + sfld_str.value + " rc = " + str(rc)



#------------------------------------------

def read_pen(pen_id, index, fldlst=[], indir_cmd=ISN_CMD_HASH_RSVD15, ib=0):
    """ Direct Read of One PEN Entry """
    pen_str = c_char_p(b" " * 32)
    entry = tentry_new(pen_id, -1, -1)

    # Get Information About the PEN
    peninfo = get_pen_info(pen_id)
    rc = node_get_pen_name(0, pen_id, pen_str, 32)
    assert rc == IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    # gather field information
    nflds, fldinfo = get_flds_from_peninfo(pen_id, peninfo)

    # Read the PEN
    pentype = c_int(0)
    penacc  = c_int(0)
    node    = 0
    rc = node_get_pen_type_acc(0, int(pen_id), byref(pentype), byref(penacc))
    assert rc == IFCS_SUCCESS, "PEN get type/acc failed: rc = " + str(rc)

    if (pentype.value & PEN_TYPE_HASH) :
        hash_fn    = 0
        bktmd      = c_int(0)
        hash_index = c_int(0)
        hash_index.value = index

        if (indir_cmd == ISN_CMD_HASH_RSVD15) :
            # Fixme: For now, I am assuming that this means that no hash command was
            # specified by function call. Default to read
            hash_cmd = ISN_CMD_HASH_READ
        else :
            # Use value specified by function call
            hash_cmd = indir_cmd

        rc = node_isn_pen_hash_cmd (node, ib, int(pen_id), hash_cmd, hash_fn, byref(hash_index), byref(bktmd), entry)
        assert ((rc == IFCS_SUCCESS)or(rc == IFCS_ENTRY_REPLACED)), "PEN " + str(pen_str.value) + " : Hash command failed: rc = " + str(rc)


    elif (pentype.value & PEN_TYPE_ILPM) :
        hash_fn    = 0
        bktmd      = c_int(0)
        hash_index = c_int(0)
        hash_index.value = index
        hash_cmd = ISN_CMD_HASH_READ

        rc = node_isn_pen_ilpm_cmd (node, ib, int(pen_id), hash_cmd, byref(hash_index), byref(bktmd), entry)
        assert ((rc == IFCS_SUCCESS)), "PEN " + str(pen_str.value) + " : ILPM command failed: rc = " + str(rc)

    elif ((pentype.value & PEN_TYPE_TCAM) or (pentype.value & PEN_TYPE_ABB_TCAM)) :
        if (penacc.value):
            tcam_index = c_int(0)
            tcam_index.value = index

            if (indir_cmd == ISN_CMD_HASH_RSVD15) :
                # For now, I am assuming that this means that no tcam command was
                # specified by function call. Default to Read
                tcam_cmd = ISN_CMD_TCAM_READ
            else :
                # Use value specified by function call
                tcam_cmd = indir_cmd

            rc = node_isn_pen_tcam_cmd(node, ib, int(pen_id), tcam_cmd, byref(tcam_index), entry)
            assert rc == IFCS_SUCCESS, "PEN " + str(pen_str.value) + " : TCAM command failed: rc = " + str(rc)
        else :
            hints = 0
            rc = node_isn_pen_read(node, ib, int(pen_id), index, hints, entry)
            assert rc == IFCS_SUCCESS, "PEN " + str(pen_str.value) + " : Read failed: rc = " + str(rc)
    else :
        hints = 0
        rc = node_isn_pen_read(node, ib, int(pen_id), index, hints, entry)
        assert rc == IFCS_SUCCESS, "PEN " + str(pen_str.value) + " : Read failed: rc = " + str(rc)


    # print ("=== Read from %s,  Index %d: " %(pen_str.value, index))

    # Populate the fldlst
    fldlst = gen_fldlst_from_tentry(pen_id, nflds, fldinfo, entry, 0)
    tentry_free(entry)
    return fldlst

#------------------------------------------

def write_penlist(penlist) :
    """ Direct Write to a list of PEN Elements """
    buf = (c_ubyte * 256)()
    pen_str = c_char_p(b" " * 32)
    fld_str = c_char_p(b" " * 32)

    for pen_id in penlist:
        # gather pen-related information
        entry = tentry_new(pen_id, -1, -1)
        nflds, fldinfo = get_flds_from_pen_id(pen_id)

        rc = node_get_pen_name(0, pen_id, pen_str, 32)
        assert rc == IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

        print ("=== Writing to %s === " %pen_str.value)

        for idx in penlist[pen_id]:
            print ("  Index %d : " %idx)
            fldlst = penlist[pen_id][idx]
            tentry_clear(entry)

            for elem in range (len(fldlst)):
                fld_id = penlist[pen_id][idx][elem][0]

                # Figure out width of field being written
                fld_width = get_fld_width(nflds, fldinfo, pen_id, fld_id);

                # Get field name to make prints readable
                rc = node_get_pen_field_name(0, fld_id, fld_str, 32)
                assert rc == IFCS_SUCCESS, "Couldnt get name for field id " + str(fld_id)

                # based on width of field, call appropriate tentry function
                if (fld_width == -1):
                    print ("\t ***ERROR*** : Field " + fld_str.value + " does not exist in pen " + pen_str.value)
                    return

                if (fld_width <= 32):
                    fld_val       = c_int(0)
                    fld_val.value = int(penlist[pen_id][idx][elem][1])
                    print ("    %s : %d " %(fld_str.value, fld_val.value))
                    rc = tentry_set_item(0, pen_id, fld_id, TENTRY_FLD_TYPE_UINT32, \
                                         entry, pointer(fld_val))
                    assert rc == IFCS_SUCCESS, "PEN tentry set failed: rc = " + str(rc)
                else :
                    nbytes = compat_division((fld_width + 7), 8)
                    for n in range(nbytes):
                        buf[n] = int(penlist[pen_id][idx][elem][1][n])
                    print ("    %s : " %(fld_str.value) , [hex(i) for i in penlist[pen_id][idx][elem][1]])
                    rc = tentry_set_item(0, pen_id, fld_id, TENTRY_FLD_TYPE_ANY, \
                                        entry, compat_pointer(buf, c_ubyte))
                    assert rc == IFCS_SUCCESS, "PEN tentry set failed: rc = " + str(rc)


            hints = 0
            rc = node_isn_pen_write(0, 0, int(pen_id), idx, hints, entry)
            assert rc == IFCS_SUCCESS, "PEN Direct Index Write failed: rc = " + str(rc)
        tentry_free(entry)


def reset_pen(pen_id, default=[]) :

   tdepth = c_int(0)
   tentry_table_num_entries(pen_id, pointer(tdepth))
   for index in range(0,tdepth.value) :
      rc = write_pen(pen_id, index, default)

# ---- UTILS ---- #

# Given a pen_id, return info on that pen
def get_pen_info(pen_id) :
    peninfo = pen_t()
    node_get_pen_info(0, pen_id, pointer(peninfo))
    return peninfo


# Given a pen_id, this function returns number of fields in the PEN and
# field information for each field
def get_flds_from_pen_id(pen_id):
    peninfo = get_pen_info(pen_id)
    nflds = c_int()
    nflds.value = peninfo.num_flds
    fldinfo = (pen_field_t * nflds.value)()
    try:
        node_get_pen_fields(0, pen_id, pointer(peninfo), byref(nflds), compat_pointer(fldinfo, pen_field_t))
    except Exception as ex:
        print (type(ex).__name__, ex.args)
    return nflds, fldinfo



# Given a pen_id, this function returns number of fields in the PEN and
# field information for each field
def get_flds_from_peninfo(pen_id, peninfo):
    nflds = c_int()
    nflds.value = peninfo.num_flds
    fldinfo = (pen_field_t * nflds.value)()
    rc = node_get_pen_fields(0, pen_id, pointer(peninfo), byref(nflds), compat_pointer(fldinfo, pen_field_t))
    assert rc == IFCS_SUCCESS, "Get PEN Fields Failed for Pen " + str(pen_id)
    return nflds, fldinfo


# Given a pen_id and a field_id, this function returns information about the field
def get_fld_info(pen_id, fld) :
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)) :
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"


# Given a pen_id and an array of its field info,
# this function returns information about the field
def get_fld_info_from_flds(nflds, fldinfo, pen_id, fld) :
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)) :
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"


# Given a pen_id and a field_id, this function returns width of the field
def get_fld_width(nflds, fldinfo, pen_id, fld) :
    fld_width = -1
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)) :
            fld_width = fldinfo[j].width
            break
    return fld_width


# Given a pen_id and a field_id, this function checks if the field exists in that pen
# Return value is 0 or 1, depending on whether field is found
def check_fld_present (pen_id, fld_id):
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if (fldinfo[j].fname == fld_id) :
            return 1
    return 0


# Given a pen_id and a tentry for that pen_id, this function returns
# a list of 2-tuples of (FieldName, Value)
def gen_fldlst_from_tentry(pen_id, nflds, fldinfo, entry, verbose):
    fld_str = c_char_p(b" " * 32)

    fldlst = []

    # Populate the fldlst
    for j in range(nflds.value):
        # Get field name to make prints readable
        rc = node_get_pen_field_name(0, fldinfo[j].fname, fld_str, 32)
        assert rc == IFCS_SUCCESS, "Couldnt get name for field id " + str(fld_id)

        if (fldinfo[j].width <= 32):
            rd_val = c_int(0)
            rc = tentry_get_item(0, pen_id, fldinfo[j].fname, TENTRY_FLD_TYPE_UINT32, \
                                 entry, pointer(rd_val))
            assert rc == IFCS_SUCCESS, "PEN " + str(pen_id) + ": Get Field " + str(fldinfo[j].fname) + " failed"
            fldlst.append([fldinfo[j].fname, rd_val.value])
            if verbose:
                print ("    %s : 0x%X " %(fld_str.value, rd_val.value))
        else:
            nbytes = compat_division((fldinfo[j].width + 7), 8)
            buf    = (c_ubyte * nbytes)()
            rc = tentry_get_item(0, pen_id, fldinfo[j].fname, TENTRY_FLD_TYPE_ANY, \
                                 entry, compat_pointer(buf, c_ubyte))
            assert rc == IFCS_SUCCESS, "PEN " + str(pen_id) + ": Get Field " + str(fldinfo[j].fname) + " failed"
            fldlst.append([fldinfo[j].fname, buf])
            if verbose:
                print ("    %s : " %(fld_str.value) , [hex(i) for i in buf])

    return fldlst


# Given a pen_id, and fld_id, this function prints all
# information regarding the field, including any MK profiles and EP profiles
def print_fld_info(pen_id, fld_id) :
    pen_str = c_char_p(b" " * 32)
    fld_str = c_char_p(b" " * 32)

    rc = node_get_pen_name(0, pen_id, pen_str, 32)
    assert rc == IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    fld_info = get_fld_info(pen_id, fld_id)
    rc = node_get_pen_field_name(0, fld_id, fld_str, 32)
    assert rc == IFCS_SUCCESS, "Couldnt get name for field id " + str(fld_id)

    print ("=== Info for PEN: %s, Field: %s ===" %(pen_str.value, fld_str.value))
    print ("- Field Width       = %d" %fld_info.width)
    print ("- Field Start Index = %d" %fld_info.start_idx)

    if (fld_info.mk == 1):
        print ("- Field contains a MatchKey")
        print ("   - Number of fields in MK_MENU   : %d" %fld_info.num_mk_menu_items)
        print ("   - Number of MK Profiles defined : %d" %fld_info.num_mk_profiles)
        for i in range(fld_info.num_mk_profiles):
            if (fld_info.mk_profile[i].num_fields == 0):
                continue
            print ("     MK Profile " + str(i) + " : ")
            print ("       NumFields = %d" %fld_info.mk_profile[i].num_fields)
            print ("       ProfileID = %d" %fld_info.mk_profile[i].profile_id)
            print ("       KeyLength = %d" %fld_info.mk_profile[i].key_length)
            print ("       MKAE      = %d" %fld_info.mk_profile[i].mkae)
            print ("       Fields: ")
            for j in range (fld_info.mk_profile[i].num_fields) :
                rc = node_get_pen_field_name(0, fld_info.mk_profile[i].fields[j].fname, fld_str, 32)
                assert rc == IFCS_SUCCESS, "PEN: Get field name failed"
                print ("          Field %d: %s , Width %d StartIndex in PEN =%d StartIndex in MK_MENU=%d" \
                        %(j, fld_str.value, fld_info.mk_profile[i].fields[j].width, \
                         fld_info.mk_profile[i].fields[j].start_idx,                \
                         fld_info.mk_profile[i].mk_menu_start[j]))

    if (fld_info.epp == 1):
        print ("  Field contains an EPD")
        print ("   - Number of fields in EPD_MENU   : %d" %fld_info.num_epd_menu_items)
        print ("   - Number of EPD Profiles defined : %d" %fld_info.num_ep_profiles)
        for i in range(fld_info.num_ep_profiles):
            if (fld_info.ep_profile[i].num_actions == 0):
                continue
            print ("     EP Profile " + str(i) + " : ")
            print ("        NumActions = %d" %fld_info.ep_profile[i].num_actions)
            print ("        TotalWidth = %d" %fld_info.ep_profile[i].profile_width)
            print ("        Actions: ")
            for j in range (fld_info.ep_profile[i].num_actions) :
                rc = node_get_pen_field_name(0, fld_info.ep_profile[i].ep_profiles[j].fname, fld_str, 32)
                assert rc == IFCS_SUCCESS, "PEN: Get field name failed"
                print ("           Action %d: %s , Width %d  StartIndex=%d" \
                        %(j, fld_str.value, fld_info.ep_profile[i].ep_profiles[j].width, \
                          fld_info.ep_profile[i].ep_profiles[j].start_idx))


# Given a PEN ID, Field ID and Sub-Field ID, this function returns the length of the sub-field
def get_sfld_width(nflds, fldinfo, pen_id, pen_str,  mfld, mfld_str, mk, prof, sfld, sfld_str) :
    # Get info on the main field
    mfld_info = get_fld_info_from_flds(nflds, fldinfo, pen_id, mfld)
    if (mk == 1):  # sfld is in one of the MatchKey profiles
        for j in range (mfld_info.mk_profile[prof].num_fields):
            if (mfld_info.mk_profile[prof].fields[j].fname == sfld) :
                return mfld_info.mk_profile[prof].fields[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + ": Could not find field " + sfld_str.value + " in mk_id = " + str(prof)

    else :         # sfld is in one of the EPD profiles
        for j in range (mfld_info.ep_profile[prof].num_actions):
            if (mfld_info.ep_profile[prof].ep_profiles[j].fname == sfld) :
                return mfld_info.ep_profile[prof].ep_profiles[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + ": Could not find field " + sfld_str.value + " in epp = " + str(prof)


version = '0.1'

# End of pen.py
