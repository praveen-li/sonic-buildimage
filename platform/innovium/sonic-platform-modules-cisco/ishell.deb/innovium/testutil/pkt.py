#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ifcs_ctypes import *
import struct


def get_dtm_discard_count():
    drop_count = 0

    return drop_count

def ldh_vf2(ib, ib_port, queue):
    dlp = (ib << 6) | ib_port
    return struct.pack("!6BLH", 1 << 1, 2,
                dlp >> 5, (dlp & 0x1f) << 3, (queue << 4), 0, 0, 0)

def ldh_vf1(sibp):
    if sibp is None:
        return struct.pack("!2B3HL", 0, 1, 0, 0, 0, 0)
    else:
        return struct.pack("!2B3HL", 0, 1, 1, sibp<<10, 0, 0)

def ldh_vf0(ib, ib_port, ssp, queue):
    slp = (ib << 6) | ib_port
    return struct.pack("!8BL", 1 << 1, 0, slp >> 5, (slp & 0x1f) << 3,
                       (ssp >> 3), (ssp & 0x07) << 5, 0, queue << 1,
                       0)

def ether_hdr_no_vlan(dmac, smac, ethertype = 0x0800):
    return dmac + smac + struct.pack("!H", ethertype)

def ether_hdr(dmac, smac, vlan=0, pcp=0, dei=0, ethertype=0x0800):
    return dmac + smac + struct.pack("!HHH", 0x8100, (pcp << 13) | (dei << 12) | vlan, ethertype)

def ip_hdr(saddr, daddr, len, ttl=100, proto=17):
    return struct.pack("!BBHHHBBHLL", (5 << 4) | 4, 0,
                       len, 0, 0, ttl, proto, 0, saddr, daddr)
