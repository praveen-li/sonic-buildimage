#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import cmd
import shlex
import sys
import os
import code
import string
from ctypes import *
from ifcs_ctypes import *
from verbosity import *
from cmdmgr import CmdMgr
from print_table import PrintTable

def run_script(arg):
    try:
        module = __import__(arg)
        reload(module)
        module.main()
    except Exception as e:
        print(e)
        return e
    del module

class IvmShell():
    def __init__(self):
        self.invocation_count =  0
        self.ivm_shell_help   =  " This is an interactive python interpreter console. \n", \
                                 " You can import your custom python modules or scripts from here. \n"
        self.ivm_banner_help  =  " Type \"help()\" for more information, \"exit() \" or \"quit() \" to return to Innovium command shell."
        self.ivm_banner       =  " Innovium Interactive Python Console, %s on %s\n %s" % (sys.version, sys.platform, self.ivm_banner_help)
        self.ivm_shell_locals =  {
                                        "exit"      : self.raise_sys_exit,
                                        "quit"      : self.raise_sys_exit,
                                        "help"      : self.print_cli_help,
                                        "count"     : self.print_cli_count,
                                        "countadd"  : self.set_cli_count,
                                        "rshell"    : self.start_rshell
                                 }

    def raise_sys_exit(self):
        raise SystemExit

    def print_cli_help(self):
        print self.ivm_shell_help

    def print_cli_count(self):
        print self.invocation_count

    def set_cli_count(self):
        self.invocation_count = self.invocation_count + 1
        return self.invocation_count

    def do_interact(self):
        try:
            code.interact(local=self.ivm_shell_locals,banner=self.ivm_banner)
        except SystemExit:
            self.invocation_count = self.invocation_count + 1
            return
    def start_rshell(self):
        from ifcscshell import main
        from threading import Thread
        import os; os.environ['IFCS_INNO_CLI_PORT'] = str(7105)
        cli_thread = Thread(target=main, args=())
        cli_thread.daemon = True
        cli_thread.start()

class CLI(cmd.Cmd):
    def __init__(self):
        global ifcs_error
        cmd.Cmd.__init__(self, completekey='tab')
        self.ivmshell = None
        self.cmdqueue = []
        self.sourceobjects = []
        self.sourcenames = []
        self.history = []
        self.redirect_fd = None
        ifcs_error = 0

    def error(self):
        global ifcs_error
        ifcs_error = 1

    def do_history(self, arg):
        for line,num in zip(self.history,range(len(self.history))):
            if line:
                print str(num) + "  " + line
        print " Type the # next to the command you wish to re-run\n"

    def do_quit(self, arg):
        # quit gracefully
        return True

    def do_console(self, arg):
        self.ivmshell = IvmShell()
        self.ivmshell.do_interact()

    def do_source(self, arg):
        if arg in self.sourcenames:
            print "Recursive source command to file %s from file %s" % (arg, self.sourcenames[-1])
            print "   Trace of source files:"
            for i in self.sourcenames:
                print "      " + i
            self.sourcenames = []
            self.sourceobjects = []
            return 0

        try:
            f = open(arg, 'r')
            self.sourceobjects.append(f)
            self.sourcenames.append(arg)
        except:
            print "Invalid source filename - " + arg
            self.sourcenames = []
            self.sourceobjects = []
            return -1

        if self.remote_mode is True:
            if not self.cmdqueue:
                while True:
                    if not self.sourceobjects:
                        break

                    line = self.sourceobjects[-1].readline()
                    if line:
                        self.onecmd(line)
                    else:
                        self.sourceobjects.pop().close()

        return 0

    def do_redirect(self, arg):

        # help strings
        usage_help = " Usage: \n \tredirect /path-to-file/file"
        stop_help  = " (type \"redirect stop\" to stop redirecting)."

        # Check for a valid file name
        if arg is '':
            print usage_help
            return

        # check if that file already exists.
        if os.path.exists(arg):
            print " File " + arg + " exists!"
            return

        if "stop" not in arg and self.redirect_fd:
            # 
            print " Already redirecting. " + stop_help
            return
        elif "stop" in arg and self.redirect_fd:
            """
                stop redirecting case
                we check for stop ahead of time because open will succeed
                even if the file was already opened before.
                So, in the try block: redirect stop will end up opening a file 'stop'
             """
            self.redirect_fd.close()
            self.redirect_fd = None
            print " Stopped redirecting."
            return
        elif "stop" in arg and self.redirect_fd is None:
            # 
            print " Redirect not started."
            print usage_help
            return

        # Try to open the file in arg
        try:
            f = open(arg,'w')
            self.redirect_fd = f
            print " Redirecting to " + arg + stop_help
        except Exception, e:
            print " Failed to start redirecting: %s " %e
            return

    def do_exit(self, arg):
        return True

    def do_deinit(self, arg):
        if self.remote_mode is True:
            print "Not supported in remote shell"
            return
        print "De-initializing IFCS..."
        ifcs_deinit(IFCS_SHUTDOWN_TYPE_COLD)
        return True

    def do_replay(self, arg):
        if self.remote_mode is True:
            print "Not supported in remote shell"
            return
        im_log_rec_params_restore(arg, ifcs_api_replay_cb_t(im_api_replay), 1)
        return

    def do_run(self, arg):
        if self.remote_mode is True:
            line = "run " + arg
            return self.run_remote_shell_command(line)
        else:
            try:
                print "Executing " + arg
                run_script(arg)
            except Exception as e:
                print (e)

    def do_shell(self, arg):
        os.system(arg)

    def do_clear(self, arg):
        os.system("clear")

    def emptyline(self):
        im_log_flush()  # flush log buffer (for testing/debug)
        pass

    def precmd(self, line):
        return line

    def filecompletions(self, line, text):
        self.completions = []
        try:
            prev = re.sub(r'%s$' % text, '', line)
            dir = os.path.dirname(prev)
            pfn = os.path.basename(prev)
        except:
            return

        if dir == "":
            dir = "./"

        for j in os.listdir(dir):
            if j.startswith(pfn + text):
                match = re.sub(r'^%s' % pfn, '', j)
                if os.path.isdir(dir + "/" + j):
                    match = match + '/'
                self.completions.append(match)

    def check_and_paginate(self, line):
        paginate        = False
        per_print_lines = 0
        if not 'filter' in line:
            return line, per_print_lines, paginate

        if not 'more' in line:
            return line, per_print_lines, paginate

        self.rows, self.columns = os.popen('stty size', 'r').read().split()
        self.rows       = int(self.rows)
        self.columns    = int(self.columns)

        args            = line.split()
        paginate        = True
        per_print_lines  = self.rows - 10
        if per_print_lines <= 0:
            paginate = False
        args = args[:-2]
        line = " ".join(args)
        return line, per_print_lines, paginate

    def receive_response(self):
        # 
        return_buf = ''
        recv_size = 102400
        current_size = 0
        actual_size = 0
        total_size = 0
        while True:
            # 
            recv_data = self.remote_port.recv(recv_size)

            # 
            try:
                return_buf += recv_data.split(':::')[1]
                total_size = int(recv_data.split(':::')[0])
                current_size = len(recv_data.split(':::')[1])
            except:
                # 
                return_buf += recv_data
                current_size = len(recv_data)

            # 
            actual_size += current_size
            if actual_size < total_size:
                continue
            else:
                break

        return return_buf

    def check_and_display(self, return_buf, per_print_lines, paginate):
        if self.redirect_fd:
            self.redirect_fd.write(return_buf)

        if paginate:
            return_buf_lines = return_buf.split('\n')
            if len(return_buf_lines) < per_print_lines:
                print return_buf
            else:
                i = 0
                while i < len(return_buf_lines):
                    print '\n'.join(return_buf_lines[i:i + per_print_lines])
                    raw_input()
                    i += per_print_lines
        else:
            print return_buf

    def run_remote_shell_command(self, line):
        # 
        line, per_print_lines, paginate = self.check_and_paginate(line)

        # 
        self.remote_port.send(line)

        # 
        return_buf = self.receive_response()

        # 
        self.check_and_display(return_buf, per_print_lines, paginate)


    def default(self, wholeline):
        global ifcs_error
        rc = None
        lines = wholeline.split(';')
        for line in lines:
            try:
                arg_list = shlex.split(line)
            except Exception as e:
                log_err(e.message)
                return line

            #find command
            if self.check_for_help_in_args(line):
                try:
                    self.cmdmgr.find_cmd(arg_list[0]).help(line)
                except BaseException:
                    pass
            else:
                if self.remote_mode is True:
                    return self.run_remote_shell_command(line)
                else:
                    cmd_class = self.cmdmgr.find_cmd(arg_list[0])
                    try:
                        ifcs_error = 0;
                        self.stdout.write("\n")
                        self.stdout.flush()
                        rc = cmd_class.run_cmd(line)
                        self.stdout.flush()
                        self.history.append(line)
                        assert ifcs_error == 0
                    except:
                        # See if we're trying to run something from history
                        try:
                            run_id = int(line)
                            self.onecmd(self.history[run_id])
                        except:
                            log_err("Command error : type help for commands list and help")
                            if self.sourceobjects:
                                # Stop processing sourcefiles
                                print "Error in line: " + line
                                print "Source file processing aborted due to command error"
                                self.sourceobjects = []
                                self.sourcenames = []
            return rc

    def postcmd(self, stop, line):
        # stop will be True on graceful exit
        if stop is True:
            return stop

        if not self.cmdqueue:
            while True:
                if not self.sourceobjects:
                    break

                line = self.sourceobjects[-1].readline()
                if line:
                    self.cmdqueue.append(line)
                    break
                else:
                    self.sourceobjects.pop().close()

    def complete(self, text, state):
        if state == 0:
            import readline
            origline = readline.get_line_buffer()

            cmd, remline, line = self.parseline(origline.lstrip())
            if cmd is None:
                self.completions = self.cmdmgr.cmds.keys()

            elif cmd == text:
                self.completions = [j for j in self.cmdmgr.cmds.keys() if j.startswith(text)]
            elif cmd == 'source' or cmd == 'redirect':
                self.filecompletions(remline, text)

            else:
                try:
                    cmd_class = self.cmdmgr.find_cmd(cmd)
                    self.completions = cmd_class.subcomplete(text, remline)
                except IndexError:
                    self.completions = []

        self.completions.sort()

        try:
            return self.completions[state]
        except IndexError:
            return None

    ''' Parses the arguments to look for ? or help
        after cmd and subcmd
    '''
    def check_for_help_in_args(self, args):
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        if '?' in self.arg_list or 'help' in self.arg_list:
            return True
        else:
            return False

    def do_help(self, arg):
        table = PrintTable()
        table.set_justification('left')
        table.add_row(['Innovium CLI Shell Help Menu', 'Description'])
        table.add_row(['exit', 'Quit the Innovium shell '])
        table.add_row(['source', 'Source a command file with shell commands'])
        table.add_row(['redirect', 'Redirect outputs from a shell to a file'])
        table.add_row(['pen', 'Pen Access Commands'])
        table.add_row(['ifcs', 'IFCS Api Debug Commands'])
        table.add_row(['diagtest', 'Diagtest commands'])
        table.add_row(['console', 'Start an interactive Python Interpreter from within the shell'])
        table.add_row(['clear', 'Clear screen'])
        table.add_row(['run', 'Clear screen'])
 
        print
        table.print_table()
        table.reset_table()
        self.stdout.write("\n")
        self.stdout.flush()
