
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import argparse

class Command(object):
    def __init__(self):
        self.active_node = -1
        self.error = 1

    def clearError(self):
        err = self.error
        self.error = 0
        return err

    def run(self, context, args):
        pass

class CmdMgr(object):
    def __init__(self):
        self.cmds = {}

    def __iter__(self):
        return iter(self.cmds.items())

    def add_cmd(self, name, cmd_class):
        self.cmds[name] = cmd_class

    def find_cmd(self, name):
        try:
            return self.cmds[name]
        except KeyError:
            return None
