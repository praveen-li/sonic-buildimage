#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ifcs_cli import IFCS_CLI
import sys
import os
import argparse

def main():
    intro = "\n\t\tInnovium Standalone Command Shell. \n\tType '?' or 'help' for help menu. Type 'quit' or 'exit' to exit shell."

    cli = IFCS_CLI(intro)
    parser = argparse.ArgumentParser(description="IFCS Shell",
                formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument('-c', '--config', dest='config', help="Config file to load")
    parser.add_argument('-i', '--input', dest='infile', nargs='*', help='space separated list of files to load')
    parser.add_argument('-C', '--cmd', dest='cmd', nargs='*', help='space separated list of commands to execute')
    parser.add_argument('-e', '--env', type=str, nargs='*',default=['switch'],help=' runtime environment for cli, set board, emulator or switch')

    args = parser.parse_args()
    if args.config:
        cli.config(args.config)
    else:
        cli.config(None)

    try:
        if args.env:
            cli.set_rt_env(args.env[0])
    except:
        print "Unsupported environment. Exiting.."
        return

    cli.init_cmds()

    if args.cmd:
        for aCmd in args.cmd:
            print "Executing Command: %s" % aCmd
            cli.onecmd(aCmd)

    if args.infile:
        for aFile in args.infile:
            cli.cmdqueue.append("source " + aFile)

    doQuit = False
    while doQuit != True:
        try:
            cli.cmdloop()
            doQuit = True
        except (KeyboardInterrupt, Exception) as e:
            print("%s\n" % str(e))


if __name__ == "__main__":
    main()
