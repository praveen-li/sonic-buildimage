#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import os
import sys
import socket
import select
import argparse
import errno
from threading import Thread
from ctypes import *
from ifcs_ctypes import *
from ifcs_cli import IFCS_CLI
from utils.compat_util import *
from verbosity import log

g_reserved_port = 7105
class InnoRemoteShell():
    def __init__(self, port=None, host=None, server=None):
        intro               = ''
        self.HOST           = 'localhost'
        self.PORT           = port
        self.SERVER         = server
        self.MAX_CLIENTS    = 5
        self.clientcount    = 0
        self.active_sockets = [] * self.MAX_CLIENTS
        self.open_client_sockets = [] * self.MAX_CLIENTS
        self.cli            = IFCS_CLI(intro)
        self.cli.set_rt_env('switch')
        self.cli.set_server_mode(True)
        self.cli.set_node_id(0)
        self.cli.init_cmds()
        self.no_shell_mode  = 0

    def set_noshell_mode(self, mode):
        self.no_shell_mode = mode

    def setup_modules(self):
        self.cli.onecmd("setup_modules")

    def create_inet_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            sock.shutdown(socket.RDWR)
            sock.close()

        # create the socket
        s_in = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set sock opt to not resue address
        s_in.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            # bind to the socket
            s_in.bind((self.HOST, self.PORT))
            log("Innovium shell server (inet): Successfully bound to port %d" % (self.PORT))
        except socket.error as msg:
            log('Innovium shell server: Bind failed with error: ' + str(msg[0]))
            return

        # listen to the socket
        s_in.listen(self.MAX_CLIENTS)
        log("Innovium shell server (inet): Listening for incoming shell clients")

        # append socket to active_sockets list
        self.active_sockets.append(s_in)


    def create_unix_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            sock.shutdown(socket.RDWR)
            sock.close()

        # make sure the socket doesn't already exist
        try:
            os.unlink(self.SERVER)
        except OSError:
            if os.path.exists(self.SERVER):
               log("Innovium shell server (ERROR): server already in use")
               return

        # create the socket
        s_in = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

        try:
            # bind to the socket
            s_in.bind(self.SERVER)
            log("Innovium shell server (unix): Successfully bound to server %s" % (self.SERVER))
        except socket.error as msg:
            log('Innovium shell server: Bind failed with error: ' + str(msg[0]))
            return

        # listen to the socket
        s_in.listen(self.MAX_CLIENTS)
        log("Innovium shell server (unix): Listening for incoming shell clients")

        # append socket to active_sockets list
        self.active_sockets.append(s_in)

    def clientthread(self, conn, addr, data_in):
        # duplicate sys.stdout
        self.cli.stdout = old_stdout = sys.stdout

        # replace sys.stdout with a string buffer
        sys.stdout = new_stdout = compat_StringIO()

        # account for third-party shells that have no prompt
        no_prompt = False

        if 'np' in data_in:
            no_prompt = True 
            data_in = data_in.split("np")[0]

        # execute the incoming command
        self.cli.onecmd(data_in)

        # retrieve the return buf
        reply = new_stdout.getvalue()

        new_stdout.close()
        # replace the original stdout
        sys.stdout = old_stdout

        # encode the reply length in the response
        if not self.no_shell_mode:
            reply = str(len(reply)) + ':::' + reply
        else:
            if no_prompt:
                reply = reply + "\n"
            else:
                reply = reply + "\nIVM:R>"

        # send the reply
        conn.sendall(compat_strToBytes(reply))

        # reset the no-prompt flag
        no_prompt = False

    def handle_exception(self, error):
        # handle error
        if type(error).__name__ == 'error':
            if error.errno == errno.EPIPE:
                log("Innovium shell server (WARNING): client has closed the connection before write finished")
            else:
                log("Innovium shell server (WARNING): " + error.strerror)
        else:
            log("Innovium shell server (ERROR): " + error.message)

        # restore the stdout
        sys.stdout = self.cli.stdout


    def communicate(self):
        # store open shell client sockets
        self.open_client_sockets = []

        # listen in on incoming socket connections
        while True:
            try:
                read_list, write_list, exception_list = select.select(self.active_sockets + self.open_client_sockets, [], [])

                # for a new shell client  accept the connection
                for current_socket in read_list:
                    if current_socket in self.active_sockets:
                        (new_socket, address) = current_socket.accept()

                        # store the incoming socket in open client sockets list
                        self.open_client_sockets.append(new_socket)

                        # if the client count exceeds max clients, send an error the client and  bail
                        if self.clientcount >= self.MAX_CLIENTS:
                            log("Innovium shell server: Max number of clients (%d) reached" % (self.MAX_CLIENTS))
                            error_msg = "Err: Max clients-%d" % (self.MAX_CLIENTS)
                            new_socket.send(error_msg)
                            self.open_client_sockets.remove(new_socket)
                            continue

                        if self.PORT:
                            log('Innovium shell server: Accepted shell client ' + address[0] + ':' + str(address[1]))
                        else:
                            log('Innovium shell server: Accepted shell client')

                        self.clientcount = self.clientcount + 1
                        if not self.no_shell_mode:
                            new_socket.send(compat_strToBytes('Success'))
                    else:
                        # recieve the cli command from the socket
                        try:
                            data = compat_bytesToStr(current_socket.recv(1024))
                        except:
                            data = ''
                            log("Something bad happened. Trying to close connection gracefully")

                        if len(data) == 0:
                            log("Innovium shell server: Closing client connection")
                            current_socket.close()
                            self.open_client_sockets.remove(current_socket)
                            self.clientcount = self.clientcount - 1
                        else:
                            # Execute and return the command
                            self.clientthread(current_socket, address, data)
            except (Exception, IOError, socket.error) as e:
                self.handle_exception(e)

def config_inet_server():
    # get the port
    global g_reserved_port
    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])
        log("Innovium shell server: Found IFCS_INNO_CLI_PORT: " + str(PORT))
    except:
        PORT = g_reserved_port
        log("Innovium shell server: IFCS_INNO_CLI_PORT not set.. assuming default port " + str(PORT))

    # for now HOST is always localhost
    HOST        = ''
    remoteShell = InnoRemoteShell(port=PORT, host=HOST)
    remoteShell.create_inet_socket()
    remoteShell.setup_modules()
    remoteShell.communicate()

def config_unix_server():
    # get the server address
    try:
        SERVER = os.environ['IFCS_INNO_CLI_SERVER']
        log("Innovium shell server: Found IFCS_INNO_CLI_SERVER: " + str(SERVER))
    except:
        log("Innovium shell server (ERROR): IFCS_INNO_CLI_SERVER not set.. defaulting to inet server ")
        config_inet_server()

    try:
        NOSHELL = int(os.environ['IFCS_INNO_CLI_SERVER_NOSHELL'])
        log("Innovium shell server: Found IFCS_INNO_CLI_SERVER_NOSHELL: " + str(NOSHELL))
    except:
        NOSHELL=0
        pass

    remoteShell = InnoRemoteShell(server=SERVER)
    remoteShell.create_unix_socket()
    remoteShell.set_noshell_mode(NOSHELL)
    remoteShell.setup_modules()
    remoteShell.communicate()

def main():
    # figure out type of server to spawn
    configure_method = 0

    config_serv_methods = {
        0  : config_inet_server,
        1  : config_inet_server,
        2  : config_unix_server,
    }

    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])

        # configure the inet server
        configure_method = 1
    except:
        try:
            SERVER = os.environ['IFCS_INNO_CLI_SERVER']

            # configure unix server
            configure_method = 2
        except:
            log("Innovium shell (ERROR) : IFCS_INNO_CLI_PORT / IFCS_INNO_CLI_SERVER not set.. defaulting to INET SERVER")

    try:
        config_serv_methods[configure_method]()
    except Exception as e:
        log("Innovium shell server : " + e.message)

if __name__ == "__main__":
    # get the host and port
    PORT = int(os.environ['IFCS_INNO_CLI_PORT'])
    remoteShell = InnoRemoteShell()
    remoteShell.create_socket()
    remoteShell.communicate()
