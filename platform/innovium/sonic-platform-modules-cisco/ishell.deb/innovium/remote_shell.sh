#!/bin/bash

#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
export PYTHONPATH=${PYTHONPATH}:./
export PYTHONPATH=${PYTHONPATH}:cmds/
export PYTHONPATH=${PYTHONPATH}:scripts/
export PYTHONPATH=${PYTHONPATH}:utils/
export PYTHONPATH=${PYTHONPATH}:pyctypes/
export PYTHONPATH=${PYTHONPATH}:../pyctypes/
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:./
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../install/lib/
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../lib/

# Help message
printhelp() {
    echo "Usage: $0 -r <remote port>"
    echo "       -r Start innovium cli in remote mode (inet)"
    echo "       -s Start innovium cli in remote mode (unix domain socket)"
    echo "       -h Show this message and exit"
}

# Set the environment
ENV="switch"

while getopts "C:r:s:" opt; do
    case $opt in
        r)
            PORT=$OPTARG
            ;;
        s)
            SERVER=$OPTARG
            ;;
	C)
	    CMD=$OPTARG
	    ;;
    esac
done


# Handle user options
if [ -n "$CMD" ]; then
    if [ $PORT ]; then
       CMD="python2.7 ifcsrshell.py -e $ENV -p $PORT -s \"$CMD\""
    elif [ $SERVER ]; then
       CMD="python2.7 ifcsrshell.py -e $ENV -u $SERVER -s \"$CMD\""
    else
       echo "Remote port / server not provided"
       printhelp
    fi
else
    if [ $PORT ]; then
       CMD="python2.7 ifcsrshell.py -e $ENV -p $PORT"
    elif [ $SERVER ]; then
       CMD="python2.7 ifcsrshell.py -e $ENV -u $SERVER"
    else
       echo "Remote port / server not provided"
       printhelp
    fi
fi

# Prepare file name
TIMESTAMP=$(date +"%b%d%Y_%H%M%S%3N")
FILE=ifcsrshell.$TIMESTAMP.log

# Start the shell
script -c "$CMD" ${FILE}

# Handle logging
$(cat ${FILE} >> ifcsrshell.log.bkup)
echo "Exiting shell, backup is ifcsrshell.log.bkup"
