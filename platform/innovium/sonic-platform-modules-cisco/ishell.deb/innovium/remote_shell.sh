#!/bin/bash

#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
export PYTHONPATH=${PYTHONPATH}:./
export PYTHONPATH=${PYTHONPATH}:cmds/
export PYTHONPATH=${PYTHONPATH}:scripts/
export PYTHONPATH=${PYTHONPATH}:utils/
export PYTHONPATH=${PYTHONPATH}:pyctypes/
export PYTHONPATH=${PYTHONPATH}:../pyctypes/
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:./
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../install/lib/
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../lib/

# Help message
printhelp() {
    echo "Usage: $0 -r <remote port>"
    echo "       -r Start innovium cli in remote mode (inet)"
    echo "       -s Start innovium cli in remote mode (unix domain socket)"
    echo "       -b Python version (2 or 3 )"
    echo "       -n No logging"
    echo "       -h Show this message and exit"
}

# Set the environment
ENV="switch"
NOLOG=0
PYVER=2

while getopts "C:r:s:nb:" opt; do
    case $opt in
        r)
            PORT=$OPTARG
            ;;
        s)
            SERVER=$OPTARG
            ;;
        C)
            CMD=$OPTARG
            ;;
        n)
            NOLOG=1
            ;;
        b)
            PYVER=$OPTARG
            ;;
    esac
done

# User should export PATH and LD_LIBRARY_PATH to point to bin and lib, respectively
if [ $PYVER == 2 ]; then
    PYTHON=python2.7
elif [ $PYVER == 3 ]; then
    PYTHON=python3.7
fi

# Handle user options
if [ -n "$CMD" ]; then
    if [ $PORT ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -p $PORT -s \"$CMD\""
    elif [ $SERVER ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -u $SERVER -s \"$CMD\""
    else
       echo "Remote port / server not provided"
       printhelp
    fi
else
    if [ $PORT ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -p $PORT"
    elif [ $SERVER ]; then
       CMD="$PYTHON ifcsrshell.py -e $ENV -u $SERVER"
    else
       echo "Remote port / server not provided"
       printhelp
    fi
fi

if [ $NOLOG == 1 ]; then
    bash -c "$CMD"
else
    # Prepare file name
    TIMESTAMP=$(date +"%b%d%Y_%H%M%S%3N")
    FILE=ifcsrshell.$TIMESTAMP.log

    # Start the shell
    script -c "$CMD" ${FILE}

    # Handle logging
    $(cat ${FILE} >> ifcsrshell.log.bkup)
    echo "Exiting shell, backup is ifcsrshell.log.bkup"
fi
