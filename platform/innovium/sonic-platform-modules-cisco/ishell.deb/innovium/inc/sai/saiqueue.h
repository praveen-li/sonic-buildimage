

#if !defined (__SAIQUEUE_H_)
#define __SAIQUEUE_H_

#include <saitypes.h>




typedef enum _sai_queue_type_t
{
    
    SAI_QUEUE_TYPE_ALL = 0x00000000,

    
    SAI_QUEUE_TYPE_UNICAST = 0x00000001,

    
    SAI_QUEUE_TYPE_MULTICAST = 0x00000002,

    
    SAI_QUEUE_TYPE_CUSTOM_RANGE_BASE = 0x10000000

} sai_queue_type_t;


typedef enum _sai_queue_attr_t
{
    
    SAI_QUEUE_ATTR_START = 0x00000000,

    

    
    SAI_QUEUE_ATTR_TYPE = SAI_QUEUE_ATTR_START,

    
    SAI_QUEUE_ATTR_PORT = 0x00000001,

    
    SAI_QUEUE_ATTR_INDEX = 0x00000002,

    
    SAI_QUEUE_ATTR_PARENT_SCHEDULER_NODE = 0x00000003,

    

    
    SAI_QUEUE_ATTR_WRED_PROFILE_ID = 0x00000004,

    
    SAI_QUEUE_ATTR_BUFFER_PROFILE_ID = 0x00000005,

    
    SAI_QUEUE_ATTR_SCHEDULER_PROFILE_ID = 0x00000006,

    
    SAI_QUEUE_ATTR_PAUSE_STATUS = 0x00000007,

    
    SAI_QUEUE_ATTR_ENABLE_PFC_DLDR = 0x00000008,

    
    SAI_QUEUE_ATTR_PFC_DLR_INIT = 0x00000009,

    
    SAI_QUEUE_ATTR_TAM_OBJECT,

    
    SAI_QUEUE_ATTR_END,

    
    SAI_QUEUE_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_QUEUE_ATTR_LOSSLESS_FLOOD_CONTROL_ENABLE,

    
    SAI_QUEUE_ATTR_CUSTOM_RANGE_END

} sai_queue_attr_t;


typedef enum _sai_queue_stat_t
{
    
    SAI_QUEUE_STAT_PACKETS = 0x00000000,

    
    SAI_QUEUE_STAT_BYTES = 0x00000001,

    
    SAI_QUEUE_STAT_DROPPED_PACKETS = 0x00000002,

    
    SAI_QUEUE_STAT_DROPPED_BYTES = 0x00000003,

    
    SAI_QUEUE_STAT_GREEN_PACKETS = 0x00000004,

    
    SAI_QUEUE_STAT_GREEN_BYTES = 0x00000005,

    
    SAI_QUEUE_STAT_GREEN_DROPPED_PACKETS = 0x00000006,

    
    SAI_QUEUE_STAT_GREEN_DROPPED_BYTES = 0x00000007,

    
    SAI_QUEUE_STAT_YELLOW_PACKETS = 0x00000008,

    
    SAI_QUEUE_STAT_YELLOW_BYTES = 0x00000009,

    
    SAI_QUEUE_STAT_YELLOW_DROPPED_PACKETS = 0x0000000a,

    
    SAI_QUEUE_STAT_YELLOW_DROPPED_BYTES = 0x0000000b,

    
    SAI_QUEUE_STAT_RED_PACKETS = 0x0000000c,

    
    SAI_QUEUE_STAT_RED_BYTES = 0x0000000d,

    
    SAI_QUEUE_STAT_RED_DROPPED_PACKETS = 0x0000000e,

    
    SAI_QUEUE_STAT_RED_DROPPED_BYTES = 0x0000000f,

    
    SAI_QUEUE_STAT_GREEN_WRED_DROPPED_PACKETS = 0x00000010,

    
    SAI_QUEUE_STAT_GREEN_WRED_DROPPED_BYTES = 0x00000011,

    
    SAI_QUEUE_STAT_YELLOW_WRED_DROPPED_PACKETS = 0x00000012,

    
    SAI_QUEUE_STAT_YELLOW_WRED_DROPPED_BYTES = 0x00000013,

    
    SAI_QUEUE_STAT_RED_WRED_DROPPED_PACKETS = 0x00000014,

    
    SAI_QUEUE_STAT_RED_WRED_DROPPED_BYTES = 0x00000015,

    
    SAI_QUEUE_STAT_WRED_DROPPED_PACKETS = 0x00000016,

    
    SAI_QUEUE_STAT_WRED_DROPPED_BYTES = 0x00000017,

    
    SAI_QUEUE_STAT_CURR_OCCUPANCY_BYTES = 0x00000018,

    
    SAI_QUEUE_STAT_WATERMARK_BYTES = 0x00000019,

    
    SAI_QUEUE_STAT_SHARED_CURR_OCCUPANCY_BYTES = 0x0000001a,

    
    SAI_QUEUE_STAT_SHARED_WATERMARK_BYTES = 0x0000001b,

    
    SAI_QUEUE_STAT_GREEN_WRED_ECN_MARKED_PACKETS = 0x0000001c,

    
    SAI_QUEUE_STAT_GREEN_WRED_ECN_MARKED_BYTES = 0x0000001d,

    
    SAI_QUEUE_STAT_YELLOW_WRED_ECN_MARKED_PACKETS = 0x0000001e,

    
    SAI_QUEUE_STAT_YELLOW_WRED_ECN_MARKED_BYTES = 0x0000001f,

    
    SAI_QUEUE_STAT_RED_WRED_ECN_MARKED_PACKETS = 0x00000020,

    
    SAI_QUEUE_STAT_RED_WRED_ECN_MARKED_BYTES = 0x00000021,

    
    SAI_QUEUE_STAT_WRED_ECN_MARKED_PACKETS = 0x00000022,

    
    SAI_QUEUE_STAT_WRED_ECN_MARKED_BYTES = 0x00000023,

    
    SAI_QUEUE_STAT_CUSTOM_RANGE_BASE = 0x10000000,

    
    SAI_QUEUE_STAT_LOSSLESS_FLOOD_CONTROL_PACKETS = SAI_QUEUE_STAT_CUSTOM_RANGE_BASE + 1,

    
    SAI_QUEUE_STAT_LOSSLESS_FLOOD_CONTROL_BYTES = SAI_QUEUE_STAT_CUSTOM_RANGE_BASE + 2,

} sai_queue_stat_t;


typedef enum _sai_queue_pfc_deadlock_event_type_t
{
    
    SAI_QUEUE_PFC_DEADLOCK_EVENT_TYPE_DETECTED,

    
    SAI_QUEUE_PFC_DEADLOCK_EVENT_TYPE_RECOVERED

} sai_queue_pfc_deadlock_event_type_t;


typedef struct _sai_queue_deadlock_notification_data_t
{
    
    sai_object_id_t queue_id;

    
    sai_queue_pfc_deadlock_event_type_t event;

    
    bool app_managed_recovery;

} sai_queue_deadlock_notification_data_t;


typedef sai_status_t (*sai_create_queue_fn)(
        _Out_ sai_object_id_t *queue_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_queue_fn)(
        _In_ sai_object_id_t queue_id);


typedef sai_status_t (*sai_set_queue_attribute_fn)(
        _In_ sai_object_id_t queue_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_queue_attribute_fn)(
        _In_ sai_object_id_t queue_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_queue_stats_fn)(
        _In_ sai_object_id_t queue_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_queue_stats_ext_fn)(
        _In_ sai_object_id_t queue_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_queue_stats_fn)(
        _In_ sai_object_id_t queue_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef void (*sai_queue_pfc_deadlock_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_queue_deadlock_notification_data_t *data);


typedef struct _sai_queue_api_t
{
    sai_create_queue_fn          create_queue;
    sai_remove_queue_fn          remove_queue;
    sai_set_queue_attribute_fn   set_queue_attribute;
    sai_get_queue_attribute_fn   get_queue_attribute;
    sai_get_queue_stats_fn       get_queue_stats;
    sai_get_queue_stats_ext_fn   get_queue_stats_ext;
    sai_clear_queue_stats_fn     clear_queue_stats;

} sai_queue_api_t;


#endif 
