

#if !defined (__SAIOBJECT_H_)
#define __SAIOBJECT_H_

#include <saitypes.h>
#include <saifdb.h>
#include <saimcastfdb.h>
#include <sail2mc.h>
#include <saiipmc.h>
#include <saineighbor.h>
#include <sairoute.h>
#include <saimpls.h>




typedef union _sai_object_key_entry_t
{
    
    sai_object_id_t           object_id;

    
    sai_fdb_entry_t           fdb_entry;

    
    sai_neighbor_entry_t      neighbor_entry;

    
    sai_route_entry_t         route_entry;

    
    sai_mcast_fdb_entry_t     mcast_fdb_entry;

    
    sai_l2mc_entry_t          l2mc_entry;

    
    sai_ipmc_entry_t          ipmc_entry;

    
    sai_inseg_entry_t         inseg_entry;

} sai_object_key_entry_t;


typedef struct _sai_object_key_t
{
    
    sai_object_key_entry_t key;

} sai_object_key_t;


typedef struct _sai_attr_capability_t
{
    
    bool create_implemented;

    
    bool set_implemented;

    
    bool get_implemented;
} sai_attr_capability_t;


sai_status_t sai_get_maximum_attribute_count(
        _In_ sai_object_id_t switch_id,
        _In_ sai_object_type_t object_type,
        _Out_ uint32_t *count);


sai_status_t sai_get_object_count(
        _In_ sai_object_id_t switch_id,
        _In_ sai_object_type_t object_type,
        _Out_ uint32_t *count);


sai_status_t sai_get_object_key(
        _In_ sai_object_id_t switch_id,
        _In_ sai_object_type_t object_type,
        _Inout_ uint32_t *object_count,
        _Inout_ sai_object_key_t *object_list);


sai_status_t sai_bulk_get_attribute(
        _In_ sai_object_id_t switch_id,
        _In_ sai_object_type_t object_type,
        _In_ uint32_t object_count,
        _In_ const sai_object_key_t *object_key,
        _Inout_ uint32_t *attr_count,
        _Inout_ sai_attribute_t **attr_list,
        _Inout_ sai_status_t *object_statuses);


sai_status_t sai_query_attribute_capability(
        _In_ sai_object_id_t switch_id,
        _In_ sai_object_type_t object_type,
        _In_ sai_attr_id_t attr_id,
        _Out_ sai_attr_capability_t *attr_capability);


sai_status_t sai_query_attribute_enum_values_capability(
        _In_ sai_object_id_t switch_id,
        _In_ sai_object_type_t object_type,
        _In_ sai_attr_id_t attr_id,
        _Inout_ sai_s32_list_t *enum_values_capability);


#endif 
