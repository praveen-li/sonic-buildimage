

#if !defined (__SAIBUFFER_H_)
#define __SAIBUFFER_H_

#include <saitypes.h>




typedef enum _sai_ingress_priority_group_attr_t
{
    
    SAI_INGRESS_PRIORITY_GROUP_ATTR_START,

    
    SAI_INGRESS_PRIORITY_GROUP_ATTR_BUFFER_PROFILE = SAI_INGRESS_PRIORITY_GROUP_ATTR_START,

    
    SAI_INGRESS_PRIORITY_GROUP_ATTR_PORT,

    
    SAI_INGRESS_PRIORITY_GROUP_ATTR_INDEX,

    
    SAI_INGRESS_PRIORITY_GROUP_ATTR_END,

    
    SAI_INGRESS_PRIORITY_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_INGRESS_PRIORITY_GROUP_ATTR_CUSTOM_RANGE_END

} sai_ingress_priority_group_attr_t;


typedef enum _sai_ingress_priority_group_stat_t
{
    
    SAI_INGRESS_PRIORITY_GROUP_STAT_PACKETS = 0x00000000,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_BYTES = 0x00000001,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_CURR_OCCUPANCY_BYTES = 0x00000002,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_WATERMARK_BYTES = 0x00000003,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_SHARED_CURR_OCCUPANCY_BYTES = 0x00000004,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_SHARED_WATERMARK_BYTES = 0x00000005,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_XOFF_ROOM_CURR_OCCUPANCY_BYTES = 0x00000006,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_XOFF_ROOM_WATERMARK_BYTES = 0x00000007,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_DROPPED_PACKETS = 0x00000008,

    
    SAI_INGRESS_PRIORITY_GROUP_STAT_CUSTOM_RANGE_BASE = 0x10000000

} sai_ingress_priority_group_stat_t;


typedef sai_status_t (*sai_create_ingress_priority_group_fn)(
        _Out_ sai_object_id_t *ingress_priority_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_ingress_priority_group_fn)(
        _In_ sai_object_id_t ingress_priority_group_id);


typedef sai_status_t (*sai_set_ingress_priority_group_attribute_fn)(
        _In_ sai_object_id_t ingress_priority_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_ingress_priority_group_attribute_fn)(
        _In_ sai_object_id_t ingress_priority_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_ingress_priority_group_stats_fn)(
        _In_ sai_object_id_t ingress_priority_group_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_ingress_priority_group_stats_ext_fn)(
        _In_ sai_object_id_t ingress_priority_group_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_ingress_priority_group_stats_fn)(
        _In_ sai_object_id_t ingress_priority_group_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef enum _sai_buffer_pool_type_t
{
    
    SAI_BUFFER_POOL_TYPE_INGRESS,

    
    SAI_BUFFER_POOL_TYPE_EGRESS,

} sai_buffer_pool_type_t;


typedef enum _sai_buffer_pool_threshold_mode_t
{
    
    SAI_BUFFER_POOL_THRESHOLD_MODE_STATIC,

    
    SAI_BUFFER_POOL_THRESHOLD_MODE_DYNAMIC,

} sai_buffer_pool_threshold_mode_t;


typedef enum _sai_buffer_pool_attr_t
{
    
    SAI_BUFFER_POOL_ATTR_START,

    
    SAI_BUFFER_POOL_ATTR_SHARED_SIZE = SAI_BUFFER_POOL_ATTR_START,

    
    SAI_BUFFER_POOL_ATTR_TYPE,

    
    SAI_BUFFER_POOL_ATTR_SIZE,

    
    SAI_BUFFER_POOL_ATTR_THRESHOLD_MODE,

    
    SAI_BUFFER_POOL_ATTR_XOFF_SIZE,

    
    SAI_BUFFER_POOL_ATTR_WRED_PROFILE_ID,

    
    SAI_BUFFER_POOL_ATTR_END,

    
    SAI_BUFFER_POOL_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_BUFFER_POOL_ATTR_CUSTOM_RANGE_END

} sai_buffer_pool_attr_t;


typedef enum _sai_buffer_pool_stat_t
{
    
    SAI_BUFFER_POOL_STAT_CURR_OCCUPANCY_BYTES = 0x00000000,

    
    SAI_BUFFER_POOL_STAT_WATERMARK_BYTES = 0x00000001,

    
    SAI_BUFFER_POOL_STAT_DROPPED_PACKETS = 0x00000002,

    
    SAI_BUFFER_POOL_STAT_GREEN_WRED_DROPPED_PACKETS = 0x00000003,

    
    SAI_BUFFER_POOL_STAT_GREEN_WRED_DROPPED_BYTES = 0x00000004,

    
    SAI_BUFFER_POOL_STAT_YELLOW_WRED_DROPPED_PACKETS = 0x00000005,

    
    SAI_BUFFER_POOL_STAT_YELLOW_WRED_DROPPED_BYTES = 0x00000006,

    
    SAI_BUFFER_POOL_STAT_RED_WRED_DROPPED_PACKETS = 0x00000007,

    
    SAI_BUFFER_POOL_STAT_RED_WRED_DROPPED_BYTES = 0x00000008,

    
    SAI_BUFFER_POOL_STAT_WRED_DROPPED_PACKETS = 0x00000009,

    
    SAI_BUFFER_POOL_STAT_WRED_DROPPED_BYTES = 0x0000000a,

    
    SAI_BUFFER_POOL_STAT_GREEN_WRED_ECN_MARKED_PACKETS = 0x0000000b,

    
    SAI_BUFFER_POOL_STAT_GREEN_WRED_ECN_MARKED_BYTES = 0x0000000c,

    
    SAI_BUFFER_POOL_STAT_YELLOW_WRED_ECN_MARKED_PACKETS = 0x0000000d,

    
    SAI_BUFFER_POOL_STAT_YELLOW_WRED_ECN_MARKED_BYTES = 0x0000000e,

    
    SAI_BUFFER_POOL_STAT_RED_WRED_ECN_MARKED_PACKETS = 0x0000000f,

    
    SAI_BUFFER_POOL_STAT_RED_WRED_ECN_MARKED_BYTES = 0x00000010,

    
    SAI_BUFFER_POOL_STAT_WRED_ECN_MARKED_PACKETS = 0x00000011,

    
    SAI_BUFFER_POOL_STAT_WRED_ECN_MARKED_BYTES = 0x00000012,

    
    SAI_BUFFER_POOL_STAT_XOFF_ROOM_CURR_OCCUPANCY_BYTES = 0x00000013,

    
    SAI_BUFFER_POOL_STAT_XOFF_ROOM_WATERMARK_BYTES = 0x00000014,

    
    SAI_BUFFER_POOL_STAT_CUSTOM_RANGE_BASE = 0x10000000

} sai_buffer_pool_stat_t;


typedef sai_status_t (*sai_create_buffer_pool_fn)(
        _Out_ sai_object_id_t *buffer_pool_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_buffer_pool_fn)(
        _In_ sai_object_id_t buffer_pool_id);


typedef sai_status_t (*sai_set_buffer_pool_attribute_fn)(
        _In_ sai_object_id_t buffer_pool_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_buffer_pool_attribute_fn)(
        _In_ sai_object_id_t buffer_pool_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_buffer_pool_stats_fn)(
        _In_ sai_object_id_t buffer_pool_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_buffer_pool_stats_ext_fn)(
        _In_ sai_object_id_t buffer_pool_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_buffer_pool_stats_fn)(
        _In_ sai_object_id_t buffer_pool_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef enum _sai_buffer_profile_threshold_mode_t
{
    
    SAI_BUFFER_PROFILE_THRESHOLD_MODE_STATIC,

    
    SAI_BUFFER_PROFILE_THRESHOLD_MODE_DYNAMIC,

} sai_buffer_profile_threshold_mode_t;


typedef enum _sai_buffer_profile_attr_t
{
    
    SAI_BUFFER_PROFILE_ATTR_START,

    
    SAI_BUFFER_PROFILE_ATTR_POOL_ID = SAI_BUFFER_PROFILE_ATTR_START,

    
    SAI_BUFFER_PROFILE_ATTR_RESERVED_BUFFER_SIZE,

    
    SAI_BUFFER_PROFILE_ATTR_BUFFER_SIZE = SAI_BUFFER_PROFILE_ATTR_RESERVED_BUFFER_SIZE,

    
    SAI_BUFFER_PROFILE_ATTR_THRESHOLD_MODE,

    
    SAI_BUFFER_PROFILE_ATTR_SHARED_DYNAMIC_TH,

    
    SAI_BUFFER_PROFILE_ATTR_SHARED_STATIC_TH,

    
    SAI_BUFFER_PROFILE_ATTR_XOFF_TH,

    
    SAI_BUFFER_PROFILE_ATTR_XON_TH,

    
    SAI_BUFFER_PROFILE_ATTR_XON_OFFSET_TH,

    
    SAI_BUFFER_PROFILE_ATTR_END,

    
    SAI_BUFFER_PROFILE_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_BUFFER_PROFILE_ATTR_CUSTOM_RANGE_END

} sai_buffer_profile_attr_t;


typedef sai_status_t (*sai_create_buffer_profile_fn)(
        _Out_ sai_object_id_t *buffer_profile_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_buffer_profile_fn)(
        _In_ sai_object_id_t buffer_profile_id);


typedef sai_status_t (*sai_set_buffer_profile_attribute_fn)(
        _In_ sai_object_id_t buffer_profile_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_buffer_profile_attribute_fn)(
        _In_ sai_object_id_t buffer_profile_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_buffer_api_t
{
    sai_create_buffer_pool_fn                       create_buffer_pool;
    sai_remove_buffer_pool_fn                       remove_buffer_pool;
    sai_set_buffer_pool_attribute_fn                set_buffer_pool_attribute;
    sai_get_buffer_pool_attribute_fn                get_buffer_pool_attribute;
    sai_get_buffer_pool_stats_fn                    get_buffer_pool_stats;
    sai_get_buffer_pool_stats_ext_fn                get_buffer_pool_stats_ext;
    sai_clear_buffer_pool_stats_fn                  clear_buffer_pool_stats;
    sai_create_ingress_priority_group_fn            create_ingress_priority_group;
    sai_remove_ingress_priority_group_fn            remove_ingress_priority_group;
    sai_set_ingress_priority_group_attribute_fn     set_ingress_priority_group_attribute;
    sai_get_ingress_priority_group_attribute_fn     get_ingress_priority_group_attribute;
    sai_get_ingress_priority_group_stats_fn         get_ingress_priority_group_stats;
    sai_get_ingress_priority_group_stats_ext_fn     get_ingress_priority_group_stats_ext;
    sai_clear_ingress_priority_group_stats_fn       clear_ingress_priority_group_stats;
    sai_create_buffer_profile_fn                    create_buffer_profile;
    sai_remove_buffer_profile_fn                    remove_buffer_profile;
    sai_set_buffer_profile_attribute_fn             set_buffer_profile_attribute;
    sai_get_buffer_profile_attribute_fn             get_buffer_profile_attribute;
} sai_buffer_api_t;


#endif 
