

#if !defined (__SAIUBURST_H_)
#define __SAIUBURST_H_

#include <saitypes.h>




typedef enum _sai_tam_microburst_stat_t
{
    
    SAI_TAM_MICROBURST_STAT_LAST_DURATION = 0x00000000,

    
    SAI_TAM_MICROBURST_STAT_LONGEST_DURATION = 0x00000001,

    
    SAI_TAM_MICROBURST_STAT_SHORTEST_DURATION = 0x00000002,

    
    SAI_TAM_MICROBURST_STAT_AVERAGE_DURATION = 0x00000003,

    
    SAI_TAM_MICROBURST_STAT_NUMBER = 0x00000004,

    
    SAI_TAM_MICROBURST_STAT_CUSTOM_RANGE_BASE = 0x10000000

} sai_tam_microburst_stat_t;


typedef enum _sai_tam_microburst_attr_t
{
    
    SAI_TAM_MICROBURST_ATTR_START,

    
    SAI_TAM_MICROBURST_ATTR_TAM_ID = SAI_TAM_MICROBURST_ATTR_START,

    
    SAI_TAM_MICROBURST_ATTR_STATISTIC,

    
    SAI_TAM_MICROBURST_ATTR_LEVEL_A,

    
    SAI_TAM_MICROBURST_ATTR_LEVEL_B,

    
    SAI_TAM_MICROBURST_ATTR_TRANSPORTER,

    
    SAI_TAM_MICROBURST_ATTR_STATS,

    
    SAI_TAM_MICROBURST_ATTR_END,

    
    SAI_TAM_MICROBURST_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_MICROBURST_ATTR_CUSTOM_RANGE_END

} sai_tam_microburst_attr_t;


typedef enum _sai_tam_histogram_attr_t
{
    
    SAI_TAM_HISTOGRAM_ATTR_START,

    
    SAI_TAM_HISTOGRAM_ATTR_TAM_ID = SAI_TAM_HISTOGRAM_ATTR_START,

    
    SAI_TAM_HISTOGRAM_ATTR_STAT_TYPE,

    
    SAI_TAM_HISTOGRAM_ATTR_BIN_BOUNDARY,

    
    SAI_TAM_HISTOGRAM_ATTR_RESOLUTION,

    
    SAI_TAM_HISTOGRAM_ATTR_CLEAR_MODE,

    
    SAI_TAM_HISTOGRAM_ATTR_TRANSPORTER,

    
    SAI_TAM_HISTOGRAM_ATTR_END,

    
    SAI_TAM_HISTOGRAM_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_HISTOGRAM_ATTR_CUSTOM_RANGE_END

} sai_tam_histogram_attr_t;


typedef sai_status_t (*sai_create_tam_microburst_fn)(
        _Out_ sai_object_id_t *tam_microburst_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_microburst_fn)(
        _In_ sai_object_id_t tam_microburst_id);


typedef sai_status_t (*sai_get_tam_microburst_attribute_fn)(
        _In_ sai_object_id_t tam_microburst_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_microburst_attribute_fn)(
        _In_ sai_object_id_t tam_microburst_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_create_tam_histogram_fn)(
        _Out_ sai_object_id_t *tam_histogram_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_histogram_fn)(
        _In_ sai_object_id_t tam_histogram_id);


typedef sai_status_t (*sai_set_tam_histogram_attribute_fn)(
        _In_ sai_object_id_t tam_histogram_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_tam_histogram_attribute_fn)(
        _In_ sai_object_id_t tam_histogram_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_tam_microburst_stats_fn)(
        _In_ sai_object_id_t tam_microburst_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_tam_microburst_stats_ext_fn)(
        _In_ sai_object_id_t tam_microburst_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_tam_microburst_stats_fn)(
        _In_ sai_object_id_t tam_microburst_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);

typedef struct _sai_uburst_api_t
{
    sai_create_tam_microburst_fn            create_tam_microburst;
    sai_remove_tam_microburst_fn            remove_tam_microburst;
    sai_set_tam_microburst_attribute_fn     set_tam_microburst_attribute;
    sai_get_tam_microburst_attribute_fn     get_tam_microburst_attribute;
    sai_get_tam_microburst_stats_fn         get_tam_microburst_stats;
    sai_get_tam_microburst_stats_ext_fn     get_tam_microburst_stats_ext;
    sai_clear_tam_microburst_stats_fn       clear_tam_microburst_stats;
    sai_create_tam_histogram_fn             create_tam_histogram;
    sai_remove_tam_histogram_fn             remove_tam_histogram;
    sai_set_tam_histogram_attribute_fn      set_tam_histogram_attribute;
    sai_get_tam_histogram_attribute_fn      get_tam_histogram_attribute;
} sai_uburst_api_t;


#endif 
