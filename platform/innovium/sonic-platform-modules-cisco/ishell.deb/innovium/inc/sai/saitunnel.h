

#if !defined (__SAITUNNEL_H_)
#define __SAITUNNEL_H_

#include <saitypes.h>




typedef enum _sai_tunnel_map_type_t
{
    
    SAI_TUNNEL_MAP_TYPE_OECN_TO_UECN = 0x00000000,

    
    SAI_TUNNEL_MAP_TYPE_UECN_OECN_TO_OECN = 0x00000001,

    
    SAI_TUNNEL_MAP_TYPE_VNI_TO_VLAN_ID = 0x00000002,

    
    SAI_TUNNEL_MAP_TYPE_VLAN_ID_TO_VNI = 0x00000003,

    
    SAI_TUNNEL_MAP_TYPE_VNI_TO_BRIDGE_IF = 0x00000004,

    
    SAI_TUNNEL_MAP_TYPE_BRIDGE_IF_TO_VNI = 0x00000005,

    
    SAI_TUNNEL_MAP_TYPE_VNI_TO_VIRTUAL_ROUTER_ID = 0x00000006,

    
    SAI_TUNNEL_MAP_TYPE_VIRTUAL_ROUTER_ID_TO_VNI = 0x00000007,

    
    SAI_TUNNEL_MAP_TYPE_CUSTOM_RANGE_BASE = 0x10000000

} sai_tunnel_map_type_t;

typedef enum _sai_tunnel_map_entry_attr_t
{
    
    SAI_TUNNEL_MAP_ENTRY_ATTR_START = 0x00000000,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_TUNNEL_MAP_TYPE = SAI_TUNNEL_MAP_ENTRY_ATTR_START,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_TUNNEL_MAP = 0x00000001,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_OECN_KEY = 0x00000002,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_OECN_VALUE = 0x00000003,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_UECN_KEY = 0x00000004,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_UECN_VALUE = 0x00000005,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_VLAN_ID_KEY = 0x00000006,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_VLAN_ID_VALUE = 0x00000007,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_VNI_ID_KEY = 0x00000008,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_VNI_ID_VALUE = 0x00000009,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_BRIDGE_ID_KEY = 0x0000000a,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_BRIDGE_ID_VALUE = 0x0000000b,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_VIRTUAL_ROUTER_ID_KEY = 0x0000000c,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_VIRTUAL_ROUTER_ID_VALUE = 0x0000000d,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_END,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TUNNEL_MAP_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_tunnel_map_entry_attr_t;


typedef enum _sai_tunnel_map_attr_t
{
    
    SAI_TUNNEL_MAP_ATTR_START = 0x00000000,

    
    SAI_TUNNEL_MAP_ATTR_TYPE = SAI_TUNNEL_MAP_ATTR_START,

    
    SAI_TUNNEL_MAP_ATTR_ENTRY_LIST,

    
    SAI_TUNNEL_MAP_ATTR_END,

    
    SAI_TUNNEL_MAP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TUNNEL_MAP_ATTR_CUSTOM_RANGE_END

} sai_tunnel_map_attr_t;


typedef sai_status_t (*sai_create_tunnel_map_fn)(
        _Out_ sai_object_id_t *tunnel_map_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tunnel_map_fn)(
        _In_ sai_object_id_t tunnel_map_id);


typedef sai_status_t (*sai_set_tunnel_map_attribute_fn)(
        _In_ sai_object_id_t tunnel_map_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_tunnel_map_attribute_fn)(
        _In_ sai_object_id_t tunnel_map_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_tunnel_type_t
{
    SAI_TUNNEL_TYPE_IPINIP,

    SAI_TUNNEL_TYPE_IPINIP_GRE,

    SAI_TUNNEL_TYPE_VXLAN,

    SAI_TUNNEL_TYPE_MPLS,

} sai_tunnel_type_t;


typedef enum _sai_tunnel_ttl_mode_t
{
    
    SAI_TUNNEL_TTL_MODE_UNIFORM_MODEL,

    
    SAI_TUNNEL_TTL_MODE_PIPE_MODEL

} sai_tunnel_ttl_mode_t;


typedef enum _sai_tunnel_dscp_mode_t
{
    
    SAI_TUNNEL_DSCP_MODE_UNIFORM_MODEL,

    
    SAI_TUNNEL_DSCP_MODE_PIPE_MODEL

} sai_tunnel_dscp_mode_t;


typedef enum _sai_tunnel_encap_ecn_mode_t
{
    
    SAI_TUNNEL_ENCAP_ECN_MODE_STANDARD,

    
    SAI_TUNNEL_ENCAP_ECN_MODE_USER_DEFINED

} sai_tunnel_encap_ecn_mode_t;


typedef enum _sai_tunnel_decap_ecn_mode_t
{
    
    SAI_TUNNEL_DECAP_ECN_MODE_STANDARD,

    
    SAI_TUNNEL_DECAP_ECN_MODE_COPY_FROM_OUTER,

    
    SAI_TUNNEL_DECAP_ECN_MODE_USER_DEFINED

} sai_tunnel_decap_ecn_mode_t;


typedef enum _sai_tunnel_attr_t
{
    
    SAI_TUNNEL_ATTR_START,

    
    SAI_TUNNEL_ATTR_TYPE = SAI_TUNNEL_ATTR_START,

    
    SAI_TUNNEL_ATTR_UNDERLAY_INTERFACE,

    
    SAI_TUNNEL_ATTR_OVERLAY_INTERFACE,

    

    
    SAI_TUNNEL_ATTR_ENCAP_SRC_IP,

    
    SAI_TUNNEL_ATTR_ENCAP_TTL_MODE,

    
    SAI_TUNNEL_ATTR_ENCAP_TTL_VAL,

    
    SAI_TUNNEL_ATTR_ENCAP_DSCP_MODE,

    
    SAI_TUNNEL_ATTR_ENCAP_DSCP_VAL,

    
    SAI_TUNNEL_ATTR_ENCAP_GRE_KEY_VALID,

    
    SAI_TUNNEL_ATTR_ENCAP_GRE_KEY,

    
    SAI_TUNNEL_ATTR_ENCAP_ECN_MODE,

    
    SAI_TUNNEL_ATTR_ENCAP_MAPPERS,

    

    
    SAI_TUNNEL_ATTR_DECAP_ECN_MODE,

    
    SAI_TUNNEL_ATTR_DECAP_MAPPERS,

    
    SAI_TUNNEL_ATTR_DECAP_TTL_MODE,

    
    SAI_TUNNEL_ATTR_DECAP_DSCP_MODE,

    
    SAI_TUNNEL_ATTR_TERM_TABLE_ENTRY_LIST,

    
    SAI_TUNNEL_ATTR_END,

    
    SAI_TUNNEL_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TUNNEL_ATTR_CUSTOM_RANGE_END

} sai_tunnel_attr_t;


typedef enum _sai_tunnel_stat_t
{
    
    SAI_TUNNEL_STAT_IN_OCTETS,

    
    SAI_TUNNEL_STAT_IN_PACKETS,

    
    SAI_TUNNEL_STAT_OUT_OCTETS,

    
    SAI_TUNNEL_STAT_OUT_PACKETS

} sai_tunnel_stat_t;


typedef sai_status_t (*sai_create_tunnel_fn)(
        _Out_ sai_object_id_t *tunnel_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tunnel_fn)(
        _In_ sai_object_id_t tunnel_id);


typedef sai_status_t (*sai_set_tunnel_attribute_fn)(
        _In_ sai_object_id_t tunnel_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_tunnel_attribute_fn)(
        _In_ sai_object_id_t tunnel_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_tunnel_stats_fn)(
        _In_ sai_object_id_t tunnel_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_tunnel_stats_ext_fn)(
        _In_ sai_object_id_t tunnel_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_tunnel_stats_fn)(
        _In_ sai_object_id_t tunnel_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef enum _sai_tunnel_term_table_entry_type_t
{
    
    SAI_TUNNEL_TERM_TABLE_ENTRY_TYPE_P2P,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_TYPE_P2MP,

} sai_tunnel_term_table_entry_type_t;


typedef enum _sai_tunnel_term_table_entry_attr_t
{
    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_START,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_VR_ID = SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_START,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_TYPE,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_DST_IP,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_SRC_IP,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_TUNNEL_TYPE,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_ACTION_TUNNEL_ID,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_END,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TUNNEL_TERM_TABLE_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_tunnel_term_table_entry_attr_t;


typedef sai_status_t (*sai_create_tunnel_term_table_entry_fn)(
        _Out_ sai_object_id_t *tunnel_term_table_entry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tunnel_term_table_entry_fn)(
        _In_ sai_object_id_t tunnel_term_table_entry_id);


typedef sai_status_t (*sai_set_tunnel_term_table_entry_attribute_fn)(
        _In_ sai_object_id_t tunnel_term_table_entry_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_tunnel_term_table_entry_attribute_fn)(
        _In_ sai_object_id_t tunnel_term_table_entry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_tunnel_map_entry_fn)(
        _Out_ sai_object_id_t *tunnel_map_entry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tunnel_map_entry_fn)(
        _In_ sai_object_id_t tunnel_map_entry_id);


typedef sai_status_t (*sai_set_tunnel_map_entry_attribute_fn)(
        _In_ sai_object_id_t tunnel_map_entry_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_tunnel_map_entry_attribute_fn)(
        _In_ sai_object_id_t tunnel_map_entry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_tunnel_api_t
{
    sai_create_tunnel_map_fn                     create_tunnel_map;
    sai_remove_tunnel_map_fn                     remove_tunnel_map;
    sai_set_tunnel_map_attribute_fn              set_tunnel_map_attribute;
    sai_get_tunnel_map_attribute_fn              get_tunnel_map_attribute;
    sai_create_tunnel_fn                         create_tunnel;
    sai_remove_tunnel_fn                         remove_tunnel;
    sai_set_tunnel_attribute_fn                  set_tunnel_attribute;
    sai_get_tunnel_attribute_fn                  get_tunnel_attribute;
    sai_get_tunnel_stats_fn                      get_tunnel_stats;
    sai_get_tunnel_stats_ext_fn                  get_tunnel_stats_ext;
    sai_clear_tunnel_stats_fn                    clear_tunnel_stats;
    sai_create_tunnel_term_table_entry_fn        create_tunnel_term_table_entry;
    sai_remove_tunnel_term_table_entry_fn        remove_tunnel_term_table_entry;
    sai_set_tunnel_term_table_entry_attribute_fn set_tunnel_term_table_entry_attribute;
    sai_get_tunnel_term_table_entry_attribute_fn get_tunnel_term_table_entry_attribute;
    sai_create_tunnel_map_entry_fn               create_tunnel_map_entry;
    sai_remove_tunnel_map_entry_fn               remove_tunnel_map_entry;
    sai_set_tunnel_map_entry_attribute_fn        set_tunnel_map_entry_attribute;
    sai_get_tunnel_map_entry_attribute_fn        get_tunnel_map_entry_attribute;

} sai_tunnel_api_t;


#endif 
