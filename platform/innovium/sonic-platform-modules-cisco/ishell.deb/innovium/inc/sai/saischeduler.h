

#if !defined (__SAISCHEDULER_H_)
#define __SAISCHEDULER_H_

#include <saitypes.h>




typedef enum _sai_scheduling_type_t
{
    
    SAI_SCHEDULING_TYPE_STRICT = 0x00000000,

    
    SAI_SCHEDULING_TYPE_WRR = 0x00000001,

    
    SAI_SCHEDULING_TYPE_DWRR = 0x00000002,

} sai_scheduling_type_t;


typedef enum _sai_scheduler_attr_t
{
    
    SAI_SCHEDULER_ATTR_START = 0x00000000,

    
    SAI_SCHEDULER_ATTR_SCHEDULING_TYPE = SAI_SCHEDULER_ATTR_START,

    
    SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT = 0x00000001,

    
    SAI_SCHEDULER_ATTR_METER_TYPE = 0x00000002,

    
    SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_RATE = 0x00000003,

    
    SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_BURST_RATE = 0x00000004,

    
    SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_RATE = 0x00000005,

    
    SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_BURST_RATE = 0x00000006,

    
    SAI_SCHEDULER_ATTR_END,

    
    SAI_SCHEDULER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_SCHEDULER_ATTR_CUSTOM_RANGE_END

} sai_scheduler_attr_t;


typedef sai_status_t (*sai_create_scheduler_fn)(
        _Out_ sai_object_id_t *scheduler_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_scheduler_fn)(
        _In_ sai_object_id_t scheduler_id);


typedef sai_status_t (*sai_set_scheduler_attribute_fn)(
        _In_ sai_object_id_t scheduler_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_scheduler_attribute_fn)(
        _In_ sai_object_id_t scheduler_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_scheduler_api_t
{
    sai_create_scheduler_fn        create_scheduler;
    sai_remove_scheduler_fn        remove_scheduler;
    sai_set_scheduler_attribute_fn set_scheduler_attribute;
    sai_get_scheduler_attribute_fn get_scheduler_attribute;

} sai_scheduler_api_t;


#endif 
