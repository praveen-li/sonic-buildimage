

#if !defined (__SAINEIGHBOR_H_)
#define __SAINEIGHBOR_H_

#include <saitypes.h>




typedef enum _sai_neighbor_entry_attr_t
{
    
    SAI_NEIGHBOR_ENTRY_ATTR_START,

    
    SAI_NEIGHBOR_ENTRY_ATTR_DST_MAC_ADDRESS = SAI_NEIGHBOR_ENTRY_ATTR_START,

    
    SAI_NEIGHBOR_ENTRY_ATTR_PACKET_ACTION,

    
    SAI_NEIGHBOR_ENTRY_ATTR_USER_TRAP_ID,

    
    SAI_NEIGHBOR_ENTRY_ATTR_NO_HOST_ROUTE,

    
    SAI_NEIGHBOR_ENTRY_ATTR_META_DATA,

    
    SAI_NEIGHBOR_ENTRY_ATTR_END,

    
    SAI_NEIGHBOR_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_NEIGHBOR_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_neighbor_entry_attr_t;


typedef struct _sai_neighbor_entry_t
{
    
    sai_object_id_t switch_id;

    
    sai_object_id_t rif_id;

    
    sai_ip_address_t ip_address;

} sai_neighbor_entry_t;


typedef sai_status_t (*sai_create_neighbor_entry_fn)(
        _In_ const sai_neighbor_entry_t *neighbor_entry,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_neighbor_entry_fn)(
        _In_ const sai_neighbor_entry_t *neighbor_entry);


typedef sai_status_t (*sai_set_neighbor_entry_attribute_fn)(
        _In_ const sai_neighbor_entry_t *neighbor_entry,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_neighbor_entry_attribute_fn)(
        _In_ const sai_neighbor_entry_t *neighbor_entry,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_all_neighbor_entries_fn)(
        _In_ sai_object_id_t switch_id);


typedef struct _sai_neighbor_api_t
{
    sai_create_neighbor_entry_fn        create_neighbor_entry;
    sai_remove_neighbor_entry_fn        remove_neighbor_entry;
    sai_set_neighbor_entry_attribute_fn set_neighbor_entry_attribute;
    sai_get_neighbor_entry_attribute_fn get_neighbor_entry_attribute;
    sai_remove_all_neighbor_entries_fn  remove_all_neighbor_entries;

} sai_neighbor_api_t;


#endif 
