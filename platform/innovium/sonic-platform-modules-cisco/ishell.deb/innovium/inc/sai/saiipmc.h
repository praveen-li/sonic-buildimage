

#if !defined (__SAIIPMC_H_)
#define __SAIIPMC_H_

#include <saitypes.h>




typedef enum _sai_ipmc_entry_type_t
{
    
    SAI_IPMC_ENTRY_TYPE_SG,

    
    SAI_IPMC_ENTRY_TYPE_XG,

} sai_ipmc_entry_type_t;


typedef struct _sai_ipmc_entry_t
{
    
    sai_object_id_t switch_id;

    
    sai_object_id_t vr_id;

    
    sai_ipmc_entry_type_t type;

    
    sai_ip_address_t destination;

    
    sai_ip_address_t source;
} sai_ipmc_entry_t;


typedef enum _sai_ipmc_entry_attr_t
{
    
    SAI_IPMC_ENTRY_ATTR_START,

    
    SAI_IPMC_ENTRY_ATTR_PACKET_ACTION = SAI_IPMC_ENTRY_ATTR_START,

    
    SAI_IPMC_ENTRY_ATTR_OUTPUT_GROUP_ID,

    
    SAI_IPMC_ENTRY_ATTR_RPF_GROUP_ID,

    
    SAI_IPMC_ENTRY_ATTR_END,

    
    SAI_IPMC_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_IPMC_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_ipmc_entry_attr_t;


typedef sai_status_t (*sai_create_ipmc_entry_fn)(
        _In_ const sai_ipmc_entry_t *ipmc_entry,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_ipmc_entry_fn)(
        _In_ const sai_ipmc_entry_t *ipmc_entry);


typedef sai_status_t (*sai_set_ipmc_entry_attribute_fn)(
        _In_ const sai_ipmc_entry_t *ipmc_entry,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_ipmc_entry_attribute_fn)(
        _In_ const sai_ipmc_entry_t *ipmc_entry,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_ipmc_api_t
{
    sai_create_ipmc_entry_fn                     create_ipmc_entry;
    sai_remove_ipmc_entry_fn                     remove_ipmc_entry;
    sai_set_ipmc_entry_attribute_fn              set_ipmc_entry_attribute;
    sai_get_ipmc_entry_attribute_fn              get_ipmc_entry_attribute;

} sai_ipmc_api_t;


#endif 
