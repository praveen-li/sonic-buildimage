

#if !defined (__SAIL2MC_H_)
#define __SAIL2MC_H_

#include <saitypes.h>




typedef enum _sai_l2mc_entry_type_t
{
    
    SAI_L2MC_ENTRY_TYPE_SG,

    
    SAI_L2MC_ENTRY_TYPE_XG,

} sai_l2mc_entry_type_t;


typedef struct _sai_l2mc_entry_t
{
    
    sai_object_id_t switch_id;

    
    sai_object_id_t bv_id;

    
    sai_l2mc_entry_type_t type;

    
    sai_ip_address_t destination;

    
    sai_ip_address_t source;
} sai_l2mc_entry_t;


typedef enum _sai_l2mc_entry_attr_t
{
    
    SAI_L2MC_ENTRY_ATTR_START,

    
    SAI_L2MC_ENTRY_ATTR_PACKET_ACTION = SAI_L2MC_ENTRY_ATTR_START,

    
    SAI_L2MC_ENTRY_ATTR_OUTPUT_GROUP_ID,

    
    SAI_L2MC_ENTRY_ATTR_END,

    
    SAI_L2MC_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_L2MC_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_l2mc_entry_attr_t;


typedef sai_status_t (*sai_create_l2mc_entry_fn)(
        _In_ const sai_l2mc_entry_t *l2mc_entry,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_l2mc_entry_fn)(
        _In_ const sai_l2mc_entry_t *l2mc_entry);


typedef sai_status_t (*sai_set_l2mc_entry_attribute_fn)(
        _In_ const sai_l2mc_entry_t *l2mc_entry,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_l2mc_entry_attribute_fn)(
        _In_ const sai_l2mc_entry_t *l2mc_entry,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_l2mc_api_t
{
    sai_create_l2mc_entry_fn                     create_l2mc_entry;
    sai_remove_l2mc_entry_fn                     remove_l2mc_entry;
    sai_set_l2mc_entry_attribute_fn              set_l2mc_entry_attribute;
    sai_get_l2mc_entry_attribute_fn              get_l2mc_entry_attribute;

} sai_l2mc_api_t;


#endif 
