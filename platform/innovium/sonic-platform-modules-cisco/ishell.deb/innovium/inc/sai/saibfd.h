

#if !defined (__SAIBFD_H_)
#define __SAIBFD_H_

#include <saitypes.h>




typedef enum _sai_bfd_session_type_t
{
    
    SAI_BFD_SESSION_TYPE_DEMAND_ACTIVE = 0,

    
    SAI_BFD_SESSION_TYPE_DEMAND_PASSIVE,

    
    SAI_BFD_SESSION_TYPE_ASYNC_ACTIVE,

    
    SAI_BFD_SESSION_TYPE_ASYNC_PASSIVE,

} sai_bfd_session_type_t;


typedef enum _sai_bfd_encapsulation_type_t
{
    
    SAI_BFD_ENCAPSULATION_TYPE_IP_IN_IP,

    
    SAI_BFD_ENCAPSULATION_TYPE_L3_GRE_TUNNEL,

} sai_bfd_encapsulation_type_t;


typedef enum _sai_bfd_session_state_t
{
    
    SAI_BFD_SESSION_STATE_ADMIN_DOWN,

    
    SAI_BFD_SESSION_STATE_DOWN,

    
    SAI_BFD_SESSION_STATE_INIT,

    
    SAI_BFD_SESSION_STATE_UP,

} sai_bfd_session_state_t;


typedef struct _sai_bfd_session_state_notification_t
{
    
    sai_object_id_t bfd_session_id;

    
    sai_bfd_session_state_t session_state;

} sai_bfd_session_state_notification_t;


typedef enum _sai_bfd_session_attr_t
{
    
    SAI_BFD_SESSION_ATTR_START,

    
    SAI_BFD_SESSION_ATTR_TYPE = SAI_BFD_SESSION_ATTR_START,

    
    SAI_BFD_SESSION_ATTR_HW_LOOKUP_VALID,

    
    SAI_BFD_SESSION_ATTR_VIRTUAL_ROUTER,

    
    SAI_BFD_SESSION_ATTR_PORT,

    
    SAI_BFD_SESSION_ATTR_LOCAL_DISCRIMINATOR,

    
    SAI_BFD_SESSION_ATTR_REMOTE_DISCRIMINATOR,

    
    SAI_BFD_SESSION_ATTR_UDP_SRC_PORT,

    
    SAI_BFD_SESSION_ATTR_TC,

    
    SAI_BFD_SESSION_ATTR_VLAN_TPID,

    
    SAI_BFD_SESSION_ATTR_VLAN_ID,

    
    SAI_BFD_SESSION_ATTR_VLAN_PRI,

    
    SAI_BFD_SESSION_ATTR_VLAN_CFI,

    
    SAI_BFD_SESSION_ATTR_VLAN_HEADER_VALID,

    
    SAI_BFD_SESSION_ATTR_BFD_ENCAPSULATION_TYPE,

    
    SAI_BFD_SESSION_ATTR_IPHDR_VERSION,

    
    SAI_BFD_SESSION_ATTR_TOS,

    
    SAI_BFD_SESSION_ATTR_TTL,

    
    SAI_BFD_SESSION_ATTR_SRC_IP_ADDRESS,

    
    SAI_BFD_SESSION_ATTR_DST_IP_ADDRESS,

    
    SAI_BFD_SESSION_ATTR_TUNNEL_TOS,

    
    SAI_BFD_SESSION_ATTR_TUNNEL_TTL,

    
    SAI_BFD_SESSION_ATTR_TUNNEL_SRC_IP_ADDRESS,

    
    SAI_BFD_SESSION_ATTR_TUNNEL_DST_IP_ADDRESS,

    
    SAI_BFD_SESSION_ATTR_SRC_MAC_ADDRESS,

    
    SAI_BFD_SESSION_ATTR_DST_MAC_ADDRESS,

    
    SAI_BFD_SESSION_ATTR_ECHO_ENABLE,

    
    SAI_BFD_SESSION_ATTR_MULTIHOP,

    
    SAI_BFD_SESSION_ATTR_CBIT,

    
    SAI_BFD_SESSION_ATTR_MIN_TX,

    
    SAI_BFD_SESSION_ATTR_MIN_RX,

    
    SAI_BFD_SESSION_ATTR_MULTIPLIER,

    
    SAI_BFD_SESSION_ATTR_REMOTE_MIN_TX,

    
    SAI_BFD_SESSION_ATTR_REMOTE_MIN_RX,

    
    SAI_BFD_SESSION_ATTR_STATE,

    
    SAI_BFD_SESSION_ATTR_END,

    
    SAI_BFD_SESSION_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_BFD_SESSION_ATTR_CUSTOM_RANGE_END

} sai_bfd_session_attr_t;


typedef enum _sai_bfd_session_stat_t
{
    
    SAI_BFD_SESSION_STAT_IN_PACKETS,

    
    SAI_BFD_SESSION_STAT_OUT_PACKETS,

    
    SAI_BFD_SESSION_STAT_DROP_PACKETS

} sai_bfd_session_stat_t;


typedef sai_status_t (*sai_create_bfd_session_fn)(
        _Out_ sai_object_id_t *bfd_session_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_bfd_session_fn)(
        _In_ sai_object_id_t bfd_session_id);


typedef sai_status_t (*sai_set_bfd_session_attribute_fn)(
        _In_ sai_object_id_t bfd_session_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_bfd_session_attribute_fn)(
        _In_ sai_object_id_t bfd_session_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_bfd_session_stats_fn)(
        _In_ sai_object_id_t bfd_session_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_bfd_session_stats_ext_fn)(
        _In_ sai_object_id_t bfd_session_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_bfd_session_stats_fn)(
        _In_ sai_object_id_t bfd_session_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef void (*sai_bfd_session_state_change_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_bfd_session_state_notification_t *data);


typedef struct _sai_bfd_api_t
{
    sai_create_bfd_session_fn            create_bfd_session;
    sai_remove_bfd_session_fn            remove_bfd_session;
    sai_set_bfd_session_attribute_fn     set_bfd_session_attribute;
    sai_get_bfd_session_attribute_fn     get_bfd_session_attribute;
    sai_get_bfd_session_stats_fn         get_bfd_session_stats;
    sai_get_bfd_session_stats_ext_fn     get_bfd_session_stats_ext;
    sai_clear_bfd_session_stats_fn       clear_bfd_session_stats;

} sai_bfd_api_t;


#endif 
