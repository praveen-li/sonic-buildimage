

#if !defined (__SAISTP_H_)
#define __SAISTP_H_

#include <saitypes.h>




typedef enum _sai_stp_port_state_t
{
    
    SAI_STP_PORT_STATE_LEARNING,

    
    SAI_STP_PORT_STATE_FORWARDING,

    
    SAI_STP_PORT_STATE_BLOCKING,

} sai_stp_port_state_t;


typedef enum _sai_stp_attr_t
{
    
    SAI_STP_ATTR_START,

    
    SAI_STP_ATTR_VLAN_LIST = SAI_STP_ATTR_START,

    
    SAI_STP_ATTR_BRIDGE_ID,

    
    SAI_STP_ATTR_PORT_LIST,

    
    SAI_STP_ATTR_END,

    
    SAI_STP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_STP_ATTR_CUSTOM_RANGE_END

} sai_stp_attr_t;


typedef enum _sai_stp_port_attr_t
{
    
    SAI_STP_PORT_ATTR_START,

    
    SAI_STP_PORT_ATTR_STP = SAI_STP_PORT_ATTR_START,

    
    SAI_STP_PORT_ATTR_BRIDGE_PORT,

    
    SAI_STP_PORT_ATTR_STATE,

    
    SAI_STP_PORT_ATTR_END,

    
    SAI_STP_PORT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_STP_PORT_ATTR_CUSTOM_RANGE_END

} sai_stp_port_attr_t;


typedef sai_status_t (*sai_create_stp_fn)(
        _Out_ sai_object_id_t *stp_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_stp_fn)(
        _In_ sai_object_id_t stp_id);


typedef sai_status_t (*sai_set_stp_attribute_fn)(
        _In_ sai_object_id_t stp_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_stp_attribute_fn)(
        _In_ sai_object_id_t stp_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_stp_port_fn)(
        _Out_ sai_object_id_t *stp_port_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_stp_port_fn)(
        _In_ sai_object_id_t stp_port_id);


typedef sai_status_t (*sai_set_stp_port_attribute_fn)(
        _In_ sai_object_id_t stp_port_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_stp_port_attribute_fn)(
        _In_ sai_object_id_t stp_port_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_stp_api_t
{
    sai_create_stp_fn               create_stp;
    sai_remove_stp_fn               remove_stp;
    sai_set_stp_attribute_fn        set_stp_attribute;
    sai_get_stp_attribute_fn        get_stp_attribute;
    sai_create_stp_port_fn          create_stp_port;
    sai_remove_stp_port_fn          remove_stp_port;
    sai_set_stp_port_attribute_fn   set_stp_port_attribute;
    sai_get_stp_port_attribute_fn   get_stp_port_attribute;
    sai_bulk_object_create_fn       create_stp_ports;
    sai_bulk_object_remove_fn       remove_stp_ports;
} sai_stp_api_t;


#endif 
