

#if !defined (__SAISAMPLEPACKET_H_)
#define __SAISAMPLEPACKET_H_

#include <saitypes.h>




typedef enum _sai_samplepacket_type_t
{
    
    SAI_SAMPLEPACKET_TYPE_SLOW_PATH,

} sai_samplepacket_type_t;


typedef enum _sai_samplepacket_mode_t
{
    
    SAI_SAMPLEPACKET_MODE_EXCLUSIVE,

    
    SAI_SAMPLEPACKET_MODE_SHARED,

} sai_samplepacket_mode_t;


typedef enum _sai_samplepacket_attr_t
{
    
    SAI_SAMPLEPACKET_ATTR_START,

    
    SAI_SAMPLEPACKET_ATTR_SAMPLE_RATE = SAI_SAMPLEPACKET_ATTR_START,

    
    SAI_SAMPLEPACKET_ATTR_TYPE,

    
    SAI_SAMPLEPACKET_ATTR_MODE,

    
    SAI_SAMPLEPACKET_ATTR_END,

    
    SAI_SAMPLEPACKET_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_SAMPLEPACKET_ATTR_CUSTOM_RANGE_END

} sai_samplepacket_attr_t;


typedef sai_status_t (*sai_create_samplepacket_fn)(
        _Out_ sai_object_id_t *samplepacket_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_samplepacket_fn)(
        _In_ sai_object_id_t samplepacket_id);


typedef sai_status_t (*sai_set_samplepacket_attribute_fn)(
        _In_ sai_object_id_t samplepacket_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_samplepacket_attribute_fn)(
        _In_ sai_object_id_t samplepacket_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_samplepacket_api_t
{
    sai_create_samplepacket_fn          create_samplepacket;
    sai_remove_samplepacket_fn          remove_samplepacket;
    sai_set_samplepacket_attribute_fn   set_samplepacket_attribute;
    sai_get_samplepacket_attribute_fn   get_samplepacket_attribute;

} sai_samplepacket_api_t;


#endif 
