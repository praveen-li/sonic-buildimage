

#if !defined (__SAIUDF_H_)
#define __SAIUDF_H_

#include <saitypes.h>




typedef enum _sai_udf_base_t
{
    
    SAI_UDF_BASE_L2,

    
    SAI_UDF_BASE_L3,

    
    SAI_UDF_BASE_L4,

} sai_udf_base_t;


typedef enum _sai_udf_attr_t
{
    
    SAI_UDF_ATTR_START,

    
    SAI_UDF_ATTR_MATCH_ID = SAI_UDF_ATTR_START,

    
    SAI_UDF_ATTR_GROUP_ID,

    
    SAI_UDF_ATTR_BASE,

    
    SAI_UDF_ATTR_OFFSET,

    
    SAI_UDF_ATTR_HASH_MASK,

    
    SAI_UDF_ATTR_END,

    
    SAI_UDF_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_UDF_ATTR_CUSTOM_RANGE_END

} sai_udf_attr_t;


typedef enum _sai_udf_match_attr_t
{
    
    SAI_UDF_MATCH_ATTR_START,

    
    SAI_UDF_MATCH_ATTR_L2_TYPE = SAI_UDF_MATCH_ATTR_START,

    
    SAI_UDF_MATCH_ATTR_L3_TYPE,

    
    SAI_UDF_MATCH_ATTR_GRE_TYPE,

    
    SAI_UDF_MATCH_ATTR_PRIORITY,

    
    SAI_UDF_MATCH_ATTR_END,

    
    SAI_UDF_MATCH_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_UDF_MATCH_ATTR_CUSTOM_RANGE_END

} sai_udf_match_attr_t;


typedef enum _sai_udf_group_type_t
{
    
    SAI_UDF_GROUP_TYPE_START,

    
    SAI_UDF_GROUP_TYPE_GENERIC = SAI_UDF_GROUP_TYPE_START,

    
    SAI_UDF_GROUP_TYPE_HASH,

    
    SAI_UDF_GROUP_TYPE_END

} sai_udf_group_type_t;


typedef enum _sai_udf_group_attr_t
{
    
    SAI_UDF_GROUP_ATTR_START,

    
    SAI_UDF_GROUP_ATTR_UDF_LIST = SAI_UDF_GROUP_ATTR_START,

    
    SAI_UDF_GROUP_ATTR_TYPE,

    
    SAI_UDF_GROUP_ATTR_LENGTH,

    
    SAI_UDF_GROUP_ATTR_END,

    
    SAI_UDF_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_UDF_GROUP_ATTR_CUSTOM_RANGE_END

} sai_udf_group_attr_t;


typedef sai_status_t (*sai_create_udf_fn)(
        _Out_ sai_object_id_t *udf_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_udf_fn)(
        _In_ sai_object_id_t udf_id);


typedef sai_status_t (*sai_set_udf_attribute_fn)(
        _In_ sai_object_id_t udf_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_udf_attribute_fn)(
        _In_ sai_object_id_t udf_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_udf_match_fn)(
        _Out_ sai_object_id_t *udf_match_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_udf_match_fn)(
        _In_ sai_object_id_t udf_match_id);


typedef sai_status_t (*sai_set_udf_match_attribute_fn)(
        _In_ sai_object_id_t udf_match_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_udf_match_attribute_fn)(
        _In_ sai_object_id_t udf_match_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_udf_group_fn)(
        _Out_ sai_object_id_t *udf_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_udf_group_fn)(
        _In_ sai_object_id_t udf_group_id);


typedef sai_status_t (*sai_set_udf_group_attribute_fn)(
        _In_ sai_object_id_t udf_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_udf_group_attribute_fn)(
        _In_ sai_object_id_t udf_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_udf_api_t
{
    sai_create_udf_fn               create_udf;
    sai_remove_udf_fn               remove_udf;
    sai_set_udf_attribute_fn        set_udf_attribute;
    sai_get_udf_attribute_fn        get_udf_attribute;
    sai_create_udf_match_fn         create_udf_match;
    sai_remove_udf_match_fn         remove_udf_match;
    sai_set_udf_match_attribute_fn  set_udf_match_attribute;
    sai_get_udf_match_attribute_fn  get_udf_match_attribute;
    sai_create_udf_group_fn         create_udf_group;
    sai_remove_udf_group_fn         remove_udf_group;
    sai_set_udf_group_attribute_fn  set_udf_group_attribute;
    sai_get_udf_group_attribute_fn  get_udf_group_attribute;

} sai_udf_api_t;


#endif 
