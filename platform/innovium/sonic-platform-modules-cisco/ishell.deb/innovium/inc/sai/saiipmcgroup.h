

#if !defined (__SAIIPMCGROUP_H_)
#define __SAIIPMCGROUP_H_

#include <saitypes.h>




typedef enum _sai_ipmc_group_attr_t
{
    
    SAI_IPMC_GROUP_ATTR_START,

    
    SAI_IPMC_GROUP_ATTR_IPMC_OUTPUT_COUNT = SAI_IPMC_GROUP_ATTR_START,

    
    SAI_IPMC_GROUP_ATTR_IPMC_MEMBER_LIST,

    
    SAI_IPMC_GROUP_ATTR_END,

    
    SAI_IPMC_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_IPMC_GROUP_ATTR_CUSTOM_RANGE_END

} sai_ipmc_group_attr_t;

typedef enum _sai_ipmc_group_member_attr_t
{
    
    SAI_IPMC_GROUP_MEMBER_ATTR_START,

    
    SAI_IPMC_GROUP_MEMBER_ATTR_IPMC_GROUP_ID = SAI_IPMC_GROUP_MEMBER_ATTR_START,

    
    SAI_IPMC_GROUP_MEMBER_ATTR_IPMC_OUTPUT_ID,

    
    SAI_IPMC_GROUP_MEMBER_ATTR_END,

    
    SAI_IPMC_GROUP_MEMBER_ATTR_CUSTOM_RANGE_START  = 0x10000000,

    
    SAI_IPMC_GROUP_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_ipmc_group_member_attr_t;


typedef sai_status_t (*sai_create_ipmc_group_fn)(
        _Out_ sai_object_id_t *ipmc_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_ipmc_group_fn)(
        _In_ sai_object_id_t ipmc_group_id);


typedef sai_status_t (*sai_set_ipmc_group_attribute_fn)(
        _In_ sai_object_id_t ipmc_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_ipmc_group_attribute_fn)(
        _In_ sai_object_id_t ipmc_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_ipmc_group_member_fn)(
        _Out_ sai_object_id_t *ipmc_group_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_ipmc_group_member_fn)(
        _In_ sai_object_id_t ipmc_group_member_id);


typedef sai_status_t (*sai_set_ipmc_group_member_attribute_fn)(
        _In_ sai_object_id_t ipmc_group_member_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_ipmc_group_member_attribute_fn)(
        _In_ sai_object_id_t ipmc_group_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_ipmc_group_api_t
{
    sai_create_ipmc_group_fn                    create_ipmc_group;
    sai_remove_ipmc_group_fn                    remove_ipmc_group;
    sai_set_ipmc_group_attribute_fn             set_ipmc_group_attribute;
    sai_get_ipmc_group_attribute_fn             get_ipmc_group_attribute;
    sai_create_ipmc_group_member_fn             create_ipmc_group_member;
    sai_remove_ipmc_group_member_fn             remove_ipmc_group_member;
    sai_set_ipmc_group_member_attribute_fn      set_ipmc_group_member_attribute;
    sai_get_ipmc_group_member_attribute_fn      get_ipmc_group_member_attribute;

} sai_ipmc_group_api_t;


#endif 
