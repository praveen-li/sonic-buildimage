

#if !defined (__SAITAM_H_)
#define __SAITAM_H_

#include <saitypes.h>




typedef enum _sai_tam_attr_t
{
    
    SAI_TAM_ATTR_START,

    
    SAI_TAM_ATTR_TELEMETRY_OBJECTS_LIST = SAI_TAM_ATTR_START,

    
    SAI_TAM_ATTR_EVENT_OBJECTS_LIST,

    
    SAI_TAM_ATTR_TAM_BIND_POINT_TYPE_LIST,

    
    SAI_TAM_ATTR_END,

    
    SAI_TAM_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_ATTR_CUSTOM_RANGE_END

} sai_tam_attr_t;


typedef sai_status_t (*sai_create_tam_fn)(
        _Out_ sai_object_id_t *tam_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_fn)(
        _In_ sai_object_id_t tam_id);


typedef sai_status_t (*sai_set_tam_attribute_fn)(
        _In_ sai_object_id_t tam_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_tam_attribute_fn)(
        _In_ sai_object_id_t tam_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef enum _sai_tam_tel_math_func_type_t
{
    
    SAI_TAM_TEL_MATH_FUNC_TYPE_NONE,

    
    SAI_TAM_TEL_MATH_FUNC_TYPE_GEO_MEAN,

    
    SAI_TAM_TEL_MATH_FUNC_TYPE_ALGEBRAIC_MEAN,

    
    SAI_TAM_TEL_MATH_FUNC_TYPE_AVERAGE,

    
    SAI_TAM_TEL_MATH_FUNC_TYPE_MODE,

    
    SAI_TAM_TEL_MATH_FUNC_TYPE_RATE,

} sai_tam_tel_math_func_type_t;


typedef enum _sai_tam_math_func_attr_t
{

    
    SAI_TAM_MATH_FUNC_ATTR_START,

    
    SAI_TAM_MATH_FUNC_ATTR_TAM_TEL_MATH_FUNC_TYPE = SAI_TAM_MATH_FUNC_ATTR_START,

    
    SAI_TAM_MATH_FUNC_ATTR_END,

    
    SAI_TAM_MATH_FUNC_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_MATH_FUNC_ATTR_CUSTOM_RANGE_END

} sai_tam_math_func_attr_t;


typedef sai_status_t (*sai_create_tam_math_func_fn)(
        _Out_ sai_object_id_t *tam_math_func_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_math_func_fn)(
        _In_ sai_object_id_t tam_math_func_id);


typedef sai_status_t (*sai_get_tam_math_func_attribute_fn)(
        _In_ sai_object_id_t tam_math_func_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_math_func_attribute_fn)(
        _In_ sai_object_id_t tam_math_func_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_event_threshold_unit_t
{
    
    SAI_TAM_EVENT_THRESHOLD_UNIT_NANOSEC = 0,

    
    SAI_TAM_EVENT_THRESHOLD_UNIT_USEC,

    
    SAI_TAM_EVENT_THRESHOLD_UNIT_MSEC,

    
    SAI_TAM_EVENT_THRESHOLD_UNIT_PERCENT
} sai_tam_event_threshold_unit_t;


typedef enum _sai_tam_event_threshold_attr_t
{

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_START,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_HIGH_WATERMARK = SAI_TAM_EVENT_THRESHOLD_ATTR_START,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_LOW_WATERMARK,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_LATENCY,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_RATE,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_ABS_VALUE,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_UNIT,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_END,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_EVENT_THRESHOLD_ATTR_CUSTOM_RANGE_END

} sai_tam_event_threshold_attr_t;


typedef sai_status_t (*sai_create_tam_event_threshold_fn)(
        _Out_ sai_object_id_t *tam_event_threshold_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_event_threshold_fn)(
        _In_ sai_object_id_t tam_event_threshold_id);


typedef sai_status_t (*sai_get_tam_event_threshold_attribute_fn)(
        _In_ sai_object_id_t tam_event_threshold_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_event_threshold_attribute_fn)(
        _In_ sai_object_id_t tam_event_threshold_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_telemetry_type_t
{
    
    SAI_TAM_TELEMETRY_TYPE_NE,

    
    SAI_TAM_TELEMETRY_TYPE_SWITCH,

    
    SAI_TAM_TELEMETRY_TYPE_FABRIC,

    
    SAI_TAM_TELEMETRY_TYPE_FLOW,
} sai_tam_telemetry_type_t;


typedef enum _sai_tam_tel_type_attr_t
{
    
    SAI_TAM_TEL_TYPE_ATTR_START,

    
    SAI_TAM_TEL_TYPE_ATTR_TAM_TELEMETRY_TYPE = SAI_TAM_TEL_TYPE_ATTR_START,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_PORT_STATS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_PORT_STATS_INGRESS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_PORT_STATS_EGRESS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_VIRTUAL_QUEUE_STATS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_OUTPUT_QUEUE_STATS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_MMU_STATS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_FABRIC_STATS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_FILTER_STATS,

    
    SAI_TAM_TEL_TYPE_ATTR_SWITCH_ENABLE_RESOURCE_UTILIZATION_STATS,

    
    SAI_TAM_TEL_TYPE_ATTR_FABRIC_Q,

    
    SAI_TAM_TEL_TYPE_ATTR_NE_ENABLE,

    
    SAI_TAM_TEL_TYPE_ATTR_DSCP_VALUE,

    
    SAI_TAM_TEL_TYPE_ATTR_MATH_FUNC,

    
    SAI_TAM_TEL_TYPE_ATTR_REPORT_ID,

    
    SAI_TAM_TEL_TYPE_ATTR_END,

    
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_RANGE_END
} sai_tam_tel_type_attr_t;


typedef sai_status_t (*sai_create_tam_tel_type_fn)(
        _Out_ sai_object_id_t *tam_tel_type_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_tel_type_fn)(
        _In_ sai_object_id_t tam_tel_type_id);


typedef sai_status_t (*sai_get_tam_tel_type_attribute_fn)(
        _In_ sai_object_id_t tam_tel_type_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_tel_type_attribute_fn)(
        _In_ sai_object_id_t tam_tel_type_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_report_type_t
{
    
    SAI_TAM_REPORT_TYPE_SFLOW,

    
    SAI_TAM_REPORT_TYPE_IPFIX,

    
    SAI_TAM_REPORT_TYPE_PROTO,

    
    SAI_TAM_REPORT_TYPE_THRIFT,

    
    SAI_TAM_REPORT_TYPE_JSON,

    
    SAI_TAM_REPORT_TYPE_P4_EXTN,

    
    SAI_TAM_REPORT_TYPE_HISTOGRAM,

    
    SAI_TAM_REPORT_TYPE_VENDOR_EXTN,
} sai_tam_report_type_t;


typedef enum _sai_tam_report_attr_t
{

    
    SAI_TAM_REPORT_ATTR_START,

    
    SAI_TAM_REPORT_ATTR_TYPE = SAI_TAM_REPORT_ATTR_START,

    
    SAI_TAM_REPORT_ATTR_HISTOGRAM_NUMBER_OF_BINS,

    
    SAI_TAM_REPORT_ATTR_HISTOGRAM_BIN_BOUNDARY,

    
    SAI_TAM_REPORT_ATTR_END,

    
    SAI_TAM_REPORT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_REPORT_ATTR_CUSTOM_RANGE_END

} sai_tam_report_attr_t;


typedef sai_status_t (*sai_create_tam_report_fn)(
        _Out_ sai_object_id_t *tam_report_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_report_fn)(
        _In_ sai_object_id_t tam_report_id);


typedef sai_status_t (*sai_get_tam_report_attribute_fn)(
        _In_ sai_object_id_t tam_report_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_report_attribute_fn)(
        _In_ sai_object_id_t tam_report_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_reporting_unit_t
{
    
    SAI_TAM_REPORTING_UNIT_SEC = 0,

    
    SAI_TAM_REPORTING_UNIT_MINUTE,

    
    SAI_TAM_REPORTING_UNIT_HOUR,

    
    SAI_TAM_REPORTING_UNIT_DAY

} sai_tam_reporting_unit_t;


typedef enum _sai_tam_telemetry_attr_t
{

    
    SAI_TAM_TELEMETRY_ATTR_START,

    
    SAI_TAM_TELEMETRY_ATTR_TAM_TYPE_LIST = SAI_TAM_TELEMETRY_ATTR_START,

    
    SAI_TAM_TELEMETRY_ATTR_COLLECTOR_LIST,

    
    SAI_TAM_TELEMETRY_ATTR_TAM_REPORTING_UNIT,

    
    SAI_TAM_TELEMETRY_ATTR_REPORTING_INTERVAL,

    
    SAI_TAM_TELEMETRY_ATTR_END,

    
    SAI_TAM_TELEMETRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_TELEMETRY_ATTR_CUSTOM_RANGE_END

} sai_tam_telemetry_attr_t;


typedef sai_status_t (*sai_create_tam_telemetry_fn)(
        _Out_ sai_object_id_t *tam_telemetry_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_telemetry_fn)(
        _In_ sai_object_id_t tam_telemetry_id);


typedef sai_status_t (*sai_get_tam_telemetry_attribute_fn)(
        _In_ sai_object_id_t tam_telemetry_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_telemetry_attribute_fn)(
        _In_ sai_object_id_t tam_telemetry_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_transport_type_t
{
    
    SAI_TAM_TRANSPORT_TYPE_NONE,

    
    SAI_TAM_TRANSPORT_TYPE_TCP,

    
    SAI_TAM_TRANSPORT_TYPE_UDP,

    
    SAI_TAM_TRANSPORT_TYPE_GRPC,

} sai_tam_transport_type_t;


typedef enum _sai_tam_transport_auth_type_t
{
    
    SAI_TAM_TRANSPORT_AUTH_TYPE_NONE,

    
    SAI_TAM_TRANSPORT_AUTH_TYPE_SSL,

    
    SAI_TAM_TRANSPORT_AUTH_TYPE_TLS

} sai_tam_transport_auth_type_t;


typedef enum _sai_tam_transport_attr_t
{

    
    SAI_TAM_TRANSPORT_ATTR_START,

    
    SAI_TAM_TRANSPORT_ATTR_TRANSPORT_TYPE = SAI_TAM_TRANSPORT_ATTR_START,

    
    SAI_TAM_TRANSPORT_ATTR_SRC_PORT,

    
    SAI_TAM_TRANSPORT_ATTR_DST_PORT,

    
    SAI_TAM_TRANSPORT_ATTR_TRANSPORT_AUTH_TYPE,

    
    SAI_TAM_TRANSPORT_ATTR_MTU,

    
    SAI_TAM_TRANSPORT_ATTR_END,

    
    SAI_TAM_TRANSPORT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_TRANSPORT_ATTR_CUSTOM_RANGE_END

} sai_tam_transport_attr_t;


typedef sai_status_t (*sai_create_tam_transport_fn)(
        _Out_ sai_object_id_t *tam_transport_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_transport_fn)(
        _In_ sai_object_id_t tam_transport_id);


typedef sai_status_t (*sai_get_tam_transport_attribute_fn)(
        _In_ sai_object_id_t tam_transport_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_transport_attribute_fn)(
        _In_ sai_object_id_t tam_transport_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_collector_attr_t
{

    
    SAI_TAM_COLLECTOR_ATTR_START,

    
    SAI_TAM_COLLECTOR_ATTR_SRC_IP = SAI_TAM_COLLECTOR_ATTR_START,

    
    SAI_TAM_COLLECTOR_ATTR_DST_IP,

    
    SAI_TAM_COLLECTOR_ATTR_LOCALHOST,

    
    SAI_TAM_COLLECTOR_ATTR_VIRTUAL_ROUTER_ID,

    
    SAI_TAM_COLLECTOR_ATTR_TRUNCATE_SIZE,

    
    SAI_TAM_COLLECTOR_ATTR_TRANSPORT,

    
    SAI_TAM_COLLECTOR_ATTR_DSCP_VALUE,

    
    SAI_TAM_COLLECTOR_ATTR_END,

    
    SAI_TAM_COLLECTOR_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_COLLECTOR_ATTR_CUSTOM_RANGE_END

} sai_tam_collector_attr_t;


typedef sai_status_t (*sai_create_tam_collector_fn)(
        _Out_ sai_object_id_t *tam_collector_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_collector_fn)(
        _In_ sai_object_id_t tam_collector_id);


typedef sai_status_t (*sai_get_tam_collector_attribute_fn)(
        _In_ sai_object_id_t tam_collector_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_collector_attribute_fn)(
        _In_ sai_object_id_t tam_collector_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_event_type_t
{

    
    SAI_TAM_EVENT_TYPE_FLOW_STATE,

    
    SAI_TAM_EVENT_TYPE_FLOW_WATCHLIST,

    
    SAI_TAM_EVENT_TYPE_FLOW_TCPFLAG,

    
    SAI_TAM_EVENT_TYPE_QUEUE_THRESHOLD,

    
    SAI_TAM_EVENT_TYPE_QUEUE_TAIL_DROP,

    
    SAI_TAM_EVENT_TYPE_PACKET_DROP,

    
    SAI_TAM_EVENT_TYPE_RESOURCE_UTILIZATION,
} sai_tam_event_type_t;


typedef enum _sai_tam_event_action_attr_t
{

    
    SAI_TAM_EVENT_ACTION_ATTR_START,

    
    SAI_TAM_EVENT_ACTION_ATTR_REPORT_TYPE = SAI_TAM_EVENT_ACTION_ATTR_START,

    
    SAI_TAM_EVENT_ACTION_ATTR_QOS_ACTION_TYPE,

    
    SAI_TAM_EVENT_ACTION_ATTR_END,

    
    SAI_TAM_EVENT_ACTION_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_EVENT_ACTION_ATTR_CUSTOM_RANGE_END

} sai_tam_event_action_attr_t;


typedef sai_status_t (*sai_create_tam_event_action_fn)(
        _Out_ sai_object_id_t *tam_event_action_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_event_action_fn)(
        _In_ sai_object_id_t tam_event_action_id);


typedef sai_status_t (*sai_get_tam_event_action_attribute_fn)(
        _In_ sai_object_id_t tam_event_action_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_event_action_attribute_fn)(
        _In_ sai_object_id_t tam_event_action_id,
        _In_ const sai_attribute_t *attr);


typedef enum _sai_tam_event_attr_t
{

    
    SAI_TAM_EVENT_ATTR_START,

    
    SAI_TAM_EVENT_ATTR_TYPE = SAI_TAM_EVENT_ATTR_START,

    
    SAI_TAM_EVENT_ATTR_ACTION_LIST,

    
    SAI_TAM_EVENT_ATTR_COLLECTOR_LIST,

    
    SAI_TAM_EVENT_ATTR_THRESHOLD,

    
    SAI_TAM_EVENT_ATTR_DSCP_VALUE,

    
    SAI_TAM_EVENT_ATTR_END,

    
    SAI_TAM_EVENT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_TAM_EVENT_ATTR_CUSTOM_RANGE_END

} sai_tam_event_attr_t;


typedef sai_status_t (*sai_create_tam_event_fn)(
        _Out_ sai_object_id_t *tam_event_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_tam_event_fn)(
        _In_ sai_object_id_t tam_event_id);


typedef sai_status_t (*sai_get_tam_event_attribute_fn)(
        _In_ sai_object_id_t tam_event_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_set_tam_event_attribute_fn)(
        _In_ sai_object_id_t tam_event_id,
        _In_ const sai_attribute_t *attr);


typedef void (*sai_tam_event_notification_fn)(
        _In_ sai_object_id_t tam_event_id,
        _In_ sai_size_t buffer_size,
        _In_ const void *buffer,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


sai_status_t sai_tam_telemetry_get_data(
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list,
        _Inout_ sai_size_t *buffer_size,
        _Out_ void *buffer);


typedef struct _sai_tam_api_t
{

    
    sai_create_tam_fn                         create_tam;
    sai_remove_tam_fn                         remove_tam;
    sai_set_tam_attribute_fn                  set_tam_attribute;
    sai_get_tam_attribute_fn                  get_tam_attribute;

    sai_create_tam_math_func_fn               create_tam_math_func;
    sai_remove_tam_math_func_fn               remove_tam_math_func;
    sai_set_tam_math_func_attribute_fn        set_tam_math_func_attribute;
    sai_get_tam_math_func_attribute_fn        get_tam_math_func_attribute;

    sai_create_tam_report_fn                  create_tam_report;
    sai_remove_tam_report_fn                  remove_tam_report;
    sai_set_tam_report_attribute_fn           set_tam_report_attribute;
    sai_get_tam_report_attribute_fn           get_tam_report_attribute;

    sai_create_tam_event_threshold_fn         create_tam_event_threshold;
    sai_remove_tam_event_threshold_fn         remove_tam_event_threshold;
    sai_set_tam_event_threshold_attribute_fn  set_tam_event_threshold_attribute;
    sai_get_tam_event_threshold_attribute_fn  get_tam_event_threshold_attribute;

    sai_create_tam_tel_type_fn                create_tam_tel_type;
    sai_remove_tam_tel_type_fn                remove_tam_tel_type;
    sai_set_tam_tel_type_attribute_fn         set_tam_tel_type_attribute;
    sai_get_tam_tel_type_attribute_fn         get_tam_tel_type_attribute;

    sai_create_tam_transport_fn               create_tam_transport;
    sai_remove_tam_transport_fn               remove_tam_transport;
    sai_set_tam_transport_attribute_fn        set_tam_transport_attribute;
    sai_get_tam_transport_attribute_fn        get_tam_transport_attribute;

    sai_create_tam_telemetry_fn               create_tam_telemetry;
    sai_remove_tam_telemetry_fn               remove_tam_telemetry;
    sai_set_tam_telemetry_attribute_fn        set_tam_telemetry_attribute;
    sai_get_tam_telemetry_attribute_fn        get_tam_telemetry_attribute;

    sai_create_tam_collector_fn               create_tam_collector;
    sai_remove_tam_collector_fn               remove_tam_collector;
    sai_set_tam_collector_attribute_fn        set_tam_collector_attribute;
    sai_get_tam_collector_attribute_fn        get_tam_collector_attribute;

    sai_create_tam_event_action_fn            create_tam_event_action;
    sai_remove_tam_event_action_fn            remove_tam_event_action;
    sai_set_tam_event_action_attribute_fn     set_tam_event_action_attribute;
    sai_get_tam_event_action_attribute_fn     get_tam_event_action_attribute;

    sai_create_tam_event_fn                   create_tam_event;
    sai_remove_tam_event_fn                   remove_tam_event;
    sai_set_tam_event_attribute_fn            set_tam_event_attribute;
    sai_get_tam_event_attribute_fn            get_tam_event_attribute;
} sai_tam_api_t;


#endif 
