

#if !defined (__SAISCHEDULERGROUP_H_)
#define __SAISCHEDULERGROUP_H_

#include <saitypes.h>




typedef enum _sai_scheduler_group_attr_t
{
    
    SAI_SCHEDULER_GROUP_ATTR_START = 0x00000000,

    
    SAI_SCHEDULER_GROUP_ATTR_CHILD_COUNT = SAI_SCHEDULER_GROUP_ATTR_START,

    
    SAI_SCHEDULER_GROUP_ATTR_CHILD_LIST = 0x00000001,

    
    SAI_SCHEDULER_GROUP_ATTR_PORT_ID = 0x00000002,

    
    SAI_SCHEDULER_GROUP_ATTR_LEVEL = 0x00000003,

    
    SAI_SCHEDULER_GROUP_ATTR_MAX_CHILDS = 0x00000004,

    
    SAI_SCHEDULER_GROUP_ATTR_SCHEDULER_PROFILE_ID = 0x00000005,

    
    SAI_SCHEDULER_GROUP_ATTR_PARENT_NODE = 0x00000006,

    
    SAI_SCHEDULER_GROUP_ATTR_END,

    
    SAI_SCHEDULER_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_SCHEDULER_GROUP_ATTR_CUSTOM_RANGE_END

} sai_scheduler_group_attr_t;


typedef sai_status_t (*sai_create_scheduler_group_fn)(
        _Out_ sai_object_id_t *scheduler_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_scheduler_group_fn)(
        _In_ sai_object_id_t scheduler_group_id);


typedef sai_status_t (*sai_set_scheduler_group_attribute_fn)(
        _In_ sai_object_id_t scheduler_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_scheduler_group_attribute_fn)(
        _In_ sai_object_id_t scheduler_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_scheduler_group_api_t
{
    sai_create_scheduler_group_fn          create_scheduler_group;
    sai_remove_scheduler_group_fn          remove_scheduler_group;
    sai_set_scheduler_group_attribute_fn   set_scheduler_group_attribute;
    sai_get_scheduler_group_attribute_fn   get_scheduler_group_attribute;

} sai_scheduler_group_api_t;


#endif 
