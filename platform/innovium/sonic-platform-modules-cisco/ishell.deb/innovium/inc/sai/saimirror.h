

#if !defined (__SAIMIRROR_H_)
#define __SAIMIRROR_H_

#include <saitypes.h>




typedef enum _sai_mirror_session_type_t
{
    
    SAI_MIRROR_SESSION_TYPE_LOCAL = 0,

    
    SAI_MIRROR_SESSION_TYPE_REMOTE,

    
    SAI_MIRROR_SESSION_TYPE_ENHANCED_REMOTE,

} sai_mirror_session_type_t;


typedef enum _sai_erspan_encapsulation_type_t
{
    
    SAI_ERSPAN_ENCAPSULATION_TYPE_MIRROR_L3_GRE_TUNNEL,

} sai_erspan_encapsulation_type_t;


typedef enum _sai_mirror_session_congestion_mode_t
{
    
    SAI_MIRROR_SESSION_CONGESTION_MODE_INDEPENDENT,

    
    SAI_MIRROR_SESSION_CONGESTION_MODE_CORRELATED,

} sai_mirror_session_congestion_mode_t;


typedef enum _sai_mirror_session_attr_t
{
    
    SAI_MIRROR_SESSION_ATTR_START,

    
    SAI_MIRROR_SESSION_ATTR_TYPE = SAI_MIRROR_SESSION_ATTR_START,

    
    SAI_MIRROR_SESSION_ATTR_MONITOR_PORT,

    
    SAI_MIRROR_SESSION_ATTR_TRUNCATE_SIZE,

    
    SAI_MIRROR_SESSION_ATTR_SAMPLE_RATE,

    
    SAI_MIRROR_SESSION_ATTR_CONGESTION_MODE,

    
    SAI_MIRROR_SESSION_ATTR_TC,

    
    SAI_MIRROR_SESSION_ATTR_VLAN_TPID,

    
    SAI_MIRROR_SESSION_ATTR_VLAN_ID,

    
    SAI_MIRROR_SESSION_ATTR_VLAN_PRI,

    
    SAI_MIRROR_SESSION_ATTR_VLAN_CFI,

    

    
    SAI_MIRROR_SESSION_ATTR_VLAN_HEADER_VALID,

    
    SAI_MIRROR_SESSION_ATTR_ERSPAN_ENCAPSULATION_TYPE,

    
    SAI_MIRROR_SESSION_ATTR_IPHDR_VERSION,

    
    SAI_MIRROR_SESSION_ATTR_TOS,

    
    SAI_MIRROR_SESSION_ATTR_TTL,

    
    SAI_MIRROR_SESSION_ATTR_SRC_IP_ADDRESS,

    
    SAI_MIRROR_SESSION_ATTR_DST_IP_ADDRESS,

    
    SAI_MIRROR_SESSION_ATTR_SRC_MAC_ADDRESS,

    
    SAI_MIRROR_SESSION_ATTR_DST_MAC_ADDRESS,

    
    SAI_MIRROR_SESSION_ATTR_GRE_PROTOCOL_TYPE,

    
    SAI_MIRROR_SESSION_ATTR_POLICER,

    
    SAI_MIRROR_SESSION_ATTR_END,

    
    SAI_MIRROR_SESSION_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_MIRROR_SESSION_ATTR_CUSTOM_RANGE_END

} sai_mirror_session_attr_t;


typedef sai_status_t (*sai_create_mirror_session_fn)(
        _Out_ sai_object_id_t *mirror_session_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_mirror_session_fn)(
        _In_ sai_object_id_t mirror_session_id);


typedef sai_status_t (*sai_set_mirror_session_attribute_fn)(
        _In_ sai_object_id_t mirror_session_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_mirror_session_attribute_fn)(
        _In_ sai_object_id_t mirror_session_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_mirror_api_t
{
    sai_create_mirror_session_fn            create_mirror_session;
    sai_remove_mirror_session_fn            remove_mirror_session;
    sai_set_mirror_session_attribute_fn     set_mirror_session_attribute;
    sai_get_mirror_session_attribute_fn     get_mirror_session_attribute;

} sai_mirror_api_t;


#endif 
