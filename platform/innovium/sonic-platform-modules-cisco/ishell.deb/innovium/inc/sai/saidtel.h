

#if !defined (__SAIDTEL_H_)
#define __SAIDTEL_H_

#include <saitypes.h>




typedef enum _sai_dtel_attr_t
{
    
    SAI_DTEL_ATTR_START,

    
    SAI_DTEL_ATTR_INT_ENDPOINT_ENABLE = SAI_DTEL_ATTR_START,

    
    SAI_DTEL_ATTR_INT_TRANSIT_ENABLE,

    
    SAI_DTEL_ATTR_POSTCARD_ENABLE,

    
    SAI_DTEL_ATTR_DROP_REPORT_ENABLE,

    
    SAI_DTEL_ATTR_QUEUE_REPORT_ENABLE,

    
    SAI_DTEL_ATTR_SWITCH_ID,

    
    SAI_DTEL_ATTR_FLOW_STATE_CLEAR_CYCLE,

    
    SAI_DTEL_ATTR_LATENCY_SENSITIVITY,

    
    SAI_DTEL_ATTR_SINK_PORT_LIST,

    
    SAI_DTEL_ATTR_INT_L4_DSCP,

    
    SAI_DTEL_ATTR_END,

    
    SAI_DTEL_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_DTEL_ATTR_CUSTOM_RANGE_END

} sai_dtel_attr_t;


typedef enum _sai_dtel_queue_report_attr_t
{
    
    SAI_DTEL_QUEUE_REPORT_ATTR_START,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_QUEUE_ID = SAI_DTEL_QUEUE_REPORT_ATTR_START,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_DEPTH_THRESHOLD,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_LATENCY_THRESHOLD,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_BREACH_QUOTA,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_TAIL_DROP,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_END,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_DTEL_QUEUE_REPORT_ATTR_CUSTOM_RANGE_END

} sai_dtel_queue_report_attr_t;


typedef enum _sai_dtel_int_session_attr_t
{
    
    SAI_DTEL_INT_SESSION_ATTR_START,

    
    SAI_DTEL_INT_SESSION_ATTR_MAX_HOP_COUNT = SAI_DTEL_INT_SESSION_ATTR_START,

    
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_SWITCH_ID,

    
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_SWITCH_PORTS,

    
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_INGRESS_TIMESTAMP,

    
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_EGRESS_TIMESTAMP,

    
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_QUEUE_INFO,

    
    SAI_DTEL_INT_SESSION_ATTR_END,

    
    SAI_DTEL_INT_SESSION_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_DTEL_INT_SESSION_ATTR_CUSTOM_RANGE_END

} sai_dtel_int_session_attr_t;


typedef enum _sai_dtel_report_session_attr_t
{
    
    SAI_DTEL_REPORT_SESSION_ATTR_START,

    
    SAI_DTEL_REPORT_SESSION_ATTR_SRC_IP = SAI_DTEL_REPORT_SESSION_ATTR_START,

    
    SAI_DTEL_REPORT_SESSION_ATTR_DST_IP_LIST,

    
    SAI_DTEL_REPORT_SESSION_ATTR_VIRTUAL_ROUTER_ID,

    
    SAI_DTEL_REPORT_SESSION_ATTR_TRUNCATE_SIZE,

    
    SAI_DTEL_REPORT_SESSION_ATTR_UDP_DST_PORT,

    
    SAI_DTEL_REPORT_SESSION_ATTR_END,

    
    SAI_DTEL_REPORT_SESSION_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_DTEL_REPORT_SESSION_ATTR_CUSTOM_RANGE_END

} sai_dtel_report_session_attr_t;


typedef enum _sai_dtel_event_type_t
{
    
    SAI_DTEL_EVENT_TYPE_FLOW_STATE,

    
    SAI_DTEL_EVENT_TYPE_FLOW_REPORT_ALL_PACKETS,

    
    SAI_DTEL_EVENT_TYPE_FLOW_TCPFLAG,

    
    SAI_DTEL_EVENT_TYPE_QUEUE_REPORT_THRESHOLD_BREACH,

    
    SAI_DTEL_EVENT_TYPE_QUEUE_REPORT_TAIL_DROP,

    
    SAI_DTEL_EVENT_TYPE_DROP_REPORT,

    SAI_DTEL_EVENT_TYPE_MAX

} sai_dtel_event_type_t;


typedef enum _sai_dtel_event_attr_t
{
    
    SAI_DTEL_EVENT_ATTR_START,

    
    SAI_DTEL_EVENT_ATTR_TYPE = SAI_DTEL_EVENT_ATTR_START,

    
    SAI_DTEL_EVENT_ATTR_REPORT_SESSION,

    
    SAI_DTEL_EVENT_ATTR_DSCP_VALUE,

    
    SAI_DTEL_EVENT_ATTR_END,

    
    SAI_DTEL_EVENT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_DTEL_EVENT_ATTR_CUSTOM_RANGE_END

} sai_dtel_event_attr_t;


typedef sai_status_t (*sai_create_dtel_fn)(
        _Out_ sai_object_id_t *dtel_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_dtel_fn)(
        _In_ sai_object_id_t dtel_id);


typedef sai_status_t (*sai_set_dtel_attribute_fn)(
        _In_ sai_object_id_t dtel_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_dtel_attribute_fn)(
        _In_ sai_object_id_t dtel_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_dtel_queue_report_fn)(
        _Out_ sai_object_id_t *dtel_queue_report_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_dtel_queue_report_fn)(
        _In_ sai_object_id_t dtel_queue_report_id);


typedef sai_status_t (*sai_set_dtel_queue_report_attribute_fn)(
        _In_ sai_object_id_t dtel_queue_report_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_dtel_queue_report_attribute_fn)(
        _In_ sai_object_id_t dtel_queue_report_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_dtel_int_session_fn)(
        _Out_ sai_object_id_t *dtel_int_session_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_dtel_int_session_fn)(
        _In_ sai_object_id_t dtel_int_session_id);


typedef sai_status_t (*sai_set_dtel_int_session_attribute_fn)(
        _In_ sai_object_id_t dtel_int_session_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_dtel_int_session_attribute_fn)(
        _In_ sai_object_id_t dtel_int_session_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_dtel_report_session_fn)(
        _Out_ sai_object_id_t *dtel_report_session_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_dtel_report_session_fn)(
        _In_ sai_object_id_t dtel_report_session_id);


typedef sai_status_t (*sai_set_dtel_report_session_attribute_fn)(
        _In_ sai_object_id_t dtel_report_session_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_dtel_report_session_attribute_fn)(
        _In_ sai_object_id_t dtel_report_session_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_dtel_event_fn)(
        _Out_ sai_object_id_t *dtel_event_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_dtel_event_fn)(
        _In_ sai_object_id_t dtel_event_id);


typedef sai_status_t (*sai_set_dtel_event_attribute_fn)(
        _In_ sai_object_id_t dtel_event_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_dtel_event_attribute_fn)(
        _In_ sai_object_id_t dtel_event_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

typedef struct _sai_dtel_api_t
{
    sai_create_dtel_fn                        create_dtel;
    sai_remove_dtel_fn                        remove_dtel;
    sai_set_dtel_attribute_fn                 set_dtel_attribute;
    sai_get_dtel_attribute_fn                 get_dtel_attribute;

    sai_create_dtel_queue_report_fn           create_dtel_queue_report;
    sai_remove_dtel_queue_report_fn           remove_dtel_queue_report;
    sai_set_dtel_queue_report_attribute_fn    set_dtel_queue_report_attribute;
    sai_get_dtel_queue_report_attribute_fn    get_dtel_queue_report_attribute;

    sai_create_dtel_int_session_fn            create_dtel_int_session;
    sai_remove_dtel_int_session_fn            remove_dtel_int_session;
    sai_set_dtel_int_session_attribute_fn     set_dtel_int_session_attribute;
    sai_get_dtel_int_session_attribute_fn     get_dtel_int_session_attribute;

    sai_create_dtel_report_session_fn         create_dtel_report_session;
    sai_remove_dtel_report_session_fn         remove_dtel_report_session;
    sai_set_dtel_report_session_attribute_fn  set_dtel_report_session_attribute;
    sai_get_dtel_report_session_attribute_fn  get_dtel_report_session_attribute;

    sai_create_dtel_event_fn                  create_dtel_event;
    sai_remove_dtel_event_fn                  remove_dtel_event;
    sai_set_dtel_event_attribute_fn           set_dtel_event_attribute;
    sai_get_dtel_event_attribute_fn           get_dtel_event_attribute;

} sai_dtel_api_t;


#endif 
