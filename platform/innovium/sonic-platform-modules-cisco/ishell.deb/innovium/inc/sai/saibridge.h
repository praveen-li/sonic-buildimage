

#if !defined (__SAIBRIDGE_H_)
#define __SAIBRIDGE_H_

#include <saitypes.h>




typedef enum _sai_bridge_port_fdb_learning_mode_t
{
    
    SAI_BRIDGE_PORT_FDB_LEARNING_MODE_DROP,

    
    SAI_BRIDGE_PORT_FDB_LEARNING_MODE_DISABLE,

    
    SAI_BRIDGE_PORT_FDB_LEARNING_MODE_HW,

    
    SAI_BRIDGE_PORT_FDB_LEARNING_MODE_CPU_TRAP,

    
    SAI_BRIDGE_PORT_FDB_LEARNING_MODE_CPU_LOG,

    
    SAI_BRIDGE_PORT_FDB_LEARNING_MODE_FDB_NOTIFICATION,

} sai_bridge_port_fdb_learning_mode_t;


typedef enum _sai_bridge_port_type_t
{
    
    SAI_BRIDGE_PORT_TYPE_PORT,

    
    SAI_BRIDGE_PORT_TYPE_SUB_PORT,

    
    SAI_BRIDGE_PORT_TYPE_1Q_ROUTER,

    
    SAI_BRIDGE_PORT_TYPE_1D_ROUTER,

    
    SAI_BRIDGE_PORT_TYPE_TUNNEL,

} sai_bridge_port_type_t;


typedef enum _sai_bridge_port_tagging_mode_t
{
    
    SAI_BRIDGE_PORT_TAGGING_MODE_UNTAGGED,

    
    SAI_BRIDGE_PORT_TAGGING_MODE_TAGGED,

} sai_bridge_port_tagging_mode_t;


typedef enum _sai_bridge_port_attr_t
{
    
    SAI_BRIDGE_PORT_ATTR_START,

    
    SAI_BRIDGE_PORT_ATTR_TYPE = SAI_BRIDGE_PORT_ATTR_START,

    
    SAI_BRIDGE_PORT_ATTR_PORT_ID,

    
    SAI_BRIDGE_PORT_ATTR_TAGGING_MODE,

    
    SAI_BRIDGE_PORT_ATTR_VLAN_ID,

    
    SAI_BRIDGE_PORT_ATTR_RIF_ID,

    
    SAI_BRIDGE_PORT_ATTR_TUNNEL_ID,

    
    SAI_BRIDGE_PORT_ATTR_BRIDGE_ID,

    
    SAI_BRIDGE_PORT_ATTR_FDB_LEARNING_MODE,

    
    SAI_BRIDGE_PORT_ATTR_MAX_LEARNED_ADDRESSES,

    
    SAI_BRIDGE_PORT_ATTR_FDB_LEARNING_LIMIT_VIOLATION_PACKET_ACTION,

    
    SAI_BRIDGE_PORT_ATTR_ADMIN_STATE,

    
    SAI_BRIDGE_PORT_ATTR_INGRESS_FILTERING,

    
    SAI_BRIDGE_PORT_ATTR_EGRESS_FILTERING,

    
    SAI_BRIDGE_PORT_ATTR_ISOLATION_GROUP,

    
    SAI_BRIDGE_PORT_ATTR_END,

    
    SAI_BRIDGE_PORT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_BRIDGE_PORT_ATTR_CUSTOM_RANGE_END

} sai_bridge_port_attr_t;


typedef enum _sai_bridge_port_stat_t
{
    
    SAI_BRIDGE_PORT_STAT_IN_OCTETS,

    
    SAI_BRIDGE_PORT_STAT_IN_PACKETS,

    
    SAI_BRIDGE_PORT_STAT_OUT_OCTETS,

    
    SAI_BRIDGE_PORT_STAT_OUT_PACKETS

} sai_bridge_port_stat_t;


typedef sai_status_t (*sai_create_bridge_port_fn)(
        _Out_ sai_object_id_t *bridge_port_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_bridge_port_fn)(
        _In_ sai_object_id_t bridge_port_id);


typedef sai_status_t (*sai_set_bridge_port_attribute_fn)(
        _In_ sai_object_id_t bridge_port_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_bridge_port_attribute_fn)(
        _In_ sai_object_id_t bridge_port_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_bridge_port_stats_fn)(
        _In_ sai_object_id_t bridge_port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_bridge_port_stats_ext_fn)(
        _In_ sai_object_id_t bridge_port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_bridge_port_stats_fn)(
        _In_ sai_object_id_t bridge_port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef enum _sai_bridge_type_t
{
    
    SAI_BRIDGE_TYPE_1Q,

    
    SAI_BRIDGE_TYPE_1D,

} sai_bridge_type_t;


typedef enum _sai_bridge_flood_control_type_t
{
    
    SAI_BRIDGE_FLOOD_CONTROL_TYPE_SUB_PORTS,

    
    SAI_BRIDGE_FLOOD_CONTROL_TYPE_NONE,

    
    SAI_BRIDGE_FLOOD_CONTROL_TYPE_L2MC_GROUP,

} sai_bridge_flood_control_type_t;


typedef enum _sai_bridge_attr_t
{
    
    SAI_BRIDGE_ATTR_START,

    
    SAI_BRIDGE_ATTR_TYPE = SAI_BRIDGE_ATTR_START,

    
    SAI_BRIDGE_ATTR_PORT_LIST,

    
    SAI_BRIDGE_ATTR_MAX_LEARNED_ADDRESSES,

    
    SAI_BRIDGE_ATTR_LEARN_DISABLE,

    
    SAI_BRIDGE_ATTR_UNKNOWN_UNICAST_FLOOD_CONTROL_TYPE,

    
    SAI_BRIDGE_ATTR_UNKNOWN_UNICAST_FLOOD_GROUP,

    
    SAI_BRIDGE_ATTR_UNKNOWN_MULTICAST_FLOOD_CONTROL_TYPE,

    
    SAI_BRIDGE_ATTR_UNKNOWN_MULTICAST_FLOOD_GROUP,

    
    SAI_BRIDGE_ATTR_BROADCAST_FLOOD_CONTROL_TYPE,

    
    SAI_BRIDGE_ATTR_BROADCAST_FLOOD_GROUP,

    
    SAI_BRIDGE_ATTR_END,

    
    SAI_BRIDGE_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_BRIDGE_ATTR_CUSTOM_RANGE_END

} sai_bridge_attr_t;


typedef enum _sai_bridge_stat_t
{
    
    SAI_BRIDGE_STAT_IN_OCTETS,

    
    SAI_BRIDGE_STAT_IN_PACKETS,

    
    SAI_BRIDGE_STAT_OUT_OCTETS,

    
    SAI_BRIDGE_STAT_OUT_PACKETS

} sai_bridge_stat_t;


typedef sai_status_t (*sai_create_bridge_fn)(
        _Out_ sai_object_id_t *bridge_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_bridge_fn)(
        _In_ sai_object_id_t bridge_id);


typedef sai_status_t (*sai_set_bridge_attribute_fn)(
        _In_ sai_object_id_t bridge_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_bridge_attribute_fn)(
        _In_ sai_object_id_t bridge_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_get_bridge_stats_fn)(
        _In_ sai_object_id_t bridge_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_get_bridge_stats_ext_fn)(
        _In_ sai_object_id_t bridge_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);


typedef sai_status_t (*sai_clear_bridge_stats_fn)(
        _In_ sai_object_id_t bridge_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);


typedef struct _sai_bridge_api_t
{
    sai_create_bridge_fn                create_bridge;
    sai_remove_bridge_fn                remove_bridge;
    sai_set_bridge_attribute_fn         set_bridge_attribute;
    sai_get_bridge_attribute_fn         get_bridge_attribute;
    sai_get_bridge_stats_fn             get_bridge_stats;
    sai_get_bridge_stats_ext_fn         get_bridge_stats_ext;
    sai_clear_bridge_stats_fn           clear_bridge_stats;
    sai_create_bridge_port_fn           create_bridge_port;
    sai_remove_bridge_port_fn           remove_bridge_port;
    sai_set_bridge_port_attribute_fn    set_bridge_port_attribute;
    sai_get_bridge_port_attribute_fn    get_bridge_port_attribute;
    sai_get_bridge_port_stats_fn        get_bridge_port_stats;
    sai_get_bridge_port_stats_ext_fn    get_bridge_port_stats_ext;
    sai_clear_bridge_port_stats_fn      clear_bridge_port_stats;
} sai_bridge_api_t;


#endif 
