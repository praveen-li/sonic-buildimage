

#if !defined (__SAI_H_)
#define __SAI_H_

#include "saiacl.h"
#include "saibridge.h"
#include "saibuffer.h"
#include "saifdb.h"
#include "saihash.h"
#include "saihostif.h"
#include "saiipmcgroup.h"
#include "saiipmc.h"
#include "sail2mcgroup.h"
#include "sail2mc.h"
#include "sailag.h"
#include "saimcastfdb.h"
#include "saimirror.h"
#include "saimpls.h"
#include "saineighbor.h"
#include "sainexthopgroup.h"
#include "sainexthop.h"
#include "saiobject.h"
#include "saipolicer.h"
#include "saiport.h"
#include "saiqosmap.h"
#include "saiqueue.h"
#include "sairoute.h"
#include "sairouterinterface.h"
#include "sairpfgroup.h"
#include "saisamplepacket.h"
#include "saischedulergroup.h"
#include "saischeduler.h"
#include "saisegmentroute.h"
#include "saistatus.h"
#include "saistp.h"
#include "saiswitch.h"
#include "saitam.h"
#include "saitunnel.h"
#include "saitypes.h"
#include "saiudf.h"
#include "saivirtualrouter.h"
#include "saivlan.h"
#include "saiwred.h"
#include "saidtel.h"
#include "saibfd.h"
#include "saiisolationgroup.h"




typedef enum _sai_api_t
{
    SAI_API_UNSPECIFIED      =  0, 
    SAI_API_SWITCH           =  1, 
    SAI_API_PORT             =  2, 
    SAI_API_FDB              =  3, 
    SAI_API_VLAN             =  4, 
    SAI_API_VIRTUAL_ROUTER   =  5, 
    SAI_API_ROUTE            =  6, 
    SAI_API_NEXT_HOP         =  7, 
    SAI_API_NEXT_HOP_GROUP   =  8, 
    SAI_API_ROUTER_INTERFACE =  9, 
    SAI_API_NEIGHBOR         = 10, 
    SAI_API_ACL              = 11, 
    SAI_API_HOSTIF           = 12, 
    SAI_API_MIRROR           = 13, 
    SAI_API_SAMPLEPACKET     = 14, 
    SAI_API_STP              = 15, 
    SAI_API_LAG              = 16, 
    SAI_API_POLICER          = 17, 
    SAI_API_WRED             = 18, 
    SAI_API_QOS_MAP          = 19, 
    SAI_API_QUEUE            = 20, 
    SAI_API_SCHEDULER        = 21, 
    SAI_API_SCHEDULER_GROUP  = 22, 
    SAI_API_BUFFER           = 23, 
    SAI_API_HASH             = 24, 
    SAI_API_UDF              = 25, 
    SAI_API_TUNNEL           = 26, 
    SAI_API_L2MC             = 27, 
    SAI_API_IPMC             = 28, 
    SAI_API_RPF_GROUP        = 29, 
    SAI_API_L2MC_GROUP       = 30, 
    SAI_API_IPMC_GROUP       = 31, 
    SAI_API_MCAST_FDB        = 32, 
    SAI_API_BRIDGE           = 33, 
    SAI_API_TAM              = 34, 
    SAI_API_SEGMENTROUTE     = 35, 
    SAI_API_MPLS             = 36, 
    SAI_API_DTEL             = 37, 
    SAI_API_BFD              = 38, 
    SAI_API_ISOLATION_GROUP  = 39, 
    SAI_API_MAX              = 40, 
} sai_api_t;


typedef enum _sai_log_level_t
{
    
    SAI_LOG_LEVEL_DEBUG            = 0,

    
    SAI_LOG_LEVEL_INFO             = 1,

    
    SAI_LOG_LEVEL_NOTICE           = 2,

    
    SAI_LOG_LEVEL_WARN             = 3,

    
    SAI_LOG_LEVEL_ERROR            = 4,

    
    SAI_LOG_LEVEL_CRITICAL         = 5

} sai_log_level_t;

typedef const char* (*sai_profile_get_value_fn)(
        _In_ sai_switch_profile_id_t profile_id,
        _In_ const char *variable);

typedef int (*sai_profile_get_next_value_fn)(
        _In_ sai_switch_profile_id_t profile_id,
        _Out_ const char **variable,
        _Out_ const char **value);


typedef struct _sai_service_method_table_t
{
    
    sai_profile_get_value_fn        profile_get_value;

    
    sai_profile_get_next_value_fn   profile_get_next_value;

} sai_service_method_table_t;


sai_status_t sai_api_initialize(
        _In_ uint64_t flags,
        _In_ const sai_service_method_table_t *services);


sai_status_t sai_api_query(
        _In_ sai_api_t api,
        _Out_ void **api_method_table);


sai_status_t sai_api_uninitialize(void);


sai_status_t sai_log_set(
        _In_ sai_api_t api,
        _In_ sai_log_level_t log_level);


sai_object_type_t sai_object_type_query(
        _In_ sai_object_id_t object_id);


sai_object_id_t sai_switch_id_query(
        _In_ sai_object_id_t object_id);


sai_status_t sai_dbg_generate_dump(
        _In_ const char *dump_file_name);


#endif 
