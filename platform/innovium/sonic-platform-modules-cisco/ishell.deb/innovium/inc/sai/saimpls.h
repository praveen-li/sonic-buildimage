

#if !defined (__SAIMPLS_H_)
#define __SAIMPLS_H_

#include <saitypes.h>




typedef enum _sai_inseg_entry_attr_t
{
    
    SAI_INSEG_ENTRY_ATTR_START,

    
    SAI_INSEG_ENTRY_ATTR_NUM_OF_POP = SAI_INSEG_ENTRY_ATTR_START,

    
    SAI_INSEG_ENTRY_ATTR_PACKET_ACTION,

    
    SAI_INSEG_ENTRY_ATTR_TRAP_PRIORITY,

    
    SAI_INSEG_ENTRY_ATTR_NEXT_HOP_ID,

    
    SAI_INSEG_ENTRY_ATTR_END,

    
    SAI_INSEG_ENTRY_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_INSEG_ENTRY_ATTR_CUSTOM_RANGE_END

} sai_inseg_entry_attr_t;


typedef struct _sai_inseg_entry_t
{
    
    sai_object_id_t switch_id;

    
    sai_label_id_t label;

} sai_inseg_entry_t;


typedef sai_status_t (*sai_create_inseg_entry_fn)(
        _In_ const sai_inseg_entry_t *inseg_entry,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_inseg_entry_fn)(
        _In_ const sai_inseg_entry_t *inseg_entry);


typedef sai_status_t (*sai_set_inseg_entry_attribute_fn)(
        _In_ const sai_inseg_entry_t *inseg_entry,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_inseg_entry_attribute_fn)(
        _In_ const sai_inseg_entry_t *inseg_entry,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_mpls_api_t
{
    sai_create_inseg_entry_fn                      create_inseg_entry;
    sai_remove_inseg_entry_fn                      remove_inseg_entry;
    sai_set_inseg_entry_attribute_fn               set_inseg_entry_attribute;
    sai_get_inseg_entry_attribute_fn               get_inseg_entry_attribute;

} sai_mpls_api_t;


#endif 
