

#if !defined (__SAINEXTHOPGROUP_H_)
#define __SAINEXTHOPGROUP_H_

#include <saitypes.h>




typedef enum _sai_next_hop_group_type_t
{
    
    SAI_NEXT_HOP_GROUP_TYPE_ECMP,

    
    SAI_NEXT_HOP_GROUP_TYPE_PROTECTION,

    

} sai_next_hop_group_type_t;


typedef enum _sai_next_hop_group_member_configured_role_t
{
    
    SAI_NEXT_HOP_GROUP_MEMBER_CONFIGURED_ROLE_PRIMARY,

    
    SAI_NEXT_HOP_GROUP_MEMBER_CONFIGURED_ROLE_STANDBY,

} sai_next_hop_group_member_configured_role_t;


typedef enum _sai_next_hop_group_member_observed_role_t
{
    
    SAI_NEXT_HOP_GROUP_MEMBER_OBSERVED_ROLE_ACTIVE,

    
    SAI_NEXT_HOP_GROUP_MEMBER_OBSERVED_ROLE_INACTIVE,

} sai_next_hop_group_member_observed_role_t;


typedef enum _sai_next_hop_group_attr_t
{
    
    SAI_NEXT_HOP_GROUP_ATTR_START,

    
    SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_COUNT = SAI_NEXT_HOP_GROUP_ATTR_START,

    
    SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_MEMBER_LIST,

    
    SAI_NEXT_HOP_GROUP_ATTR_TYPE,

    
    SAI_NEXT_HOP_GROUP_ATTR_SET_SWITCHOVER,

    
    SAI_NEXT_HOP_GROUP_ATTR_END,

    
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_RANGE_END

} sai_next_hop_group_attr_t;

typedef enum _sai_next_hop_group_member_attr_t
{
    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_START,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_NEXT_HOP_GROUP_ID = SAI_NEXT_HOP_GROUP_MEMBER_ATTR_START,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_NEXT_HOP_ID,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_WEIGHT,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_CONFIGURED_ROLE,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_OBSERVED_ROLE,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_MONITORED_OBJECT,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_END,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_CUSTOM_RANGE_START  = 0x10000000,

    
    SAI_NEXT_HOP_GROUP_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_next_hop_group_member_attr_t;


typedef sai_status_t (*sai_create_next_hop_group_fn)(
        _Out_ sai_object_id_t *next_hop_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_next_hop_group_fn)(
        _In_ sai_object_id_t next_hop_group_id);


typedef sai_status_t (*sai_set_next_hop_group_attribute_fn)(
        _In_ sai_object_id_t next_hop_group_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_next_hop_group_attribute_fn)(
        _In_ sai_object_id_t next_hop_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef sai_status_t (*sai_create_next_hop_group_member_fn)(
        _Out_ sai_object_id_t *next_hop_group_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);


typedef sai_status_t (*sai_remove_next_hop_group_member_fn)(
        _In_ sai_object_id_t next_hop_group_member_id);


typedef sai_status_t (*sai_set_next_hop_group_member_attribute_fn)(
        _In_ sai_object_id_t next_hop_group_member_id,
        _In_ const sai_attribute_t *attr);


typedef sai_status_t (*sai_get_next_hop_group_member_attribute_fn)(
        _In_ sai_object_id_t next_hop_group_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);


typedef struct _sai_next_hop_group_api_t
{
    sai_create_next_hop_group_fn               create_next_hop_group;
    sai_remove_next_hop_group_fn               remove_next_hop_group;
    sai_set_next_hop_group_attribute_fn        set_next_hop_group_attribute;
    sai_get_next_hop_group_attribute_fn        get_next_hop_group_attribute;
    sai_create_next_hop_group_member_fn        create_next_hop_group_member;
    sai_remove_next_hop_group_member_fn        remove_next_hop_group_member;
    sai_set_next_hop_group_member_attribute_fn set_next_hop_group_member_attribute;
    sai_get_next_hop_group_member_attribute_fn get_next_hop_group_member_attribute;
    sai_bulk_object_create_fn                  create_next_hop_group_members;
    sai_bulk_object_remove_fn                  remove_next_hop_group_members;
} sai_next_hop_group_api_t;


#endif 
