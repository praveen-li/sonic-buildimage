# Copyright 2017 Amazon, LLC.  All rights reserved.
# This file corresponds to SDK version:12.14
import re
import time
import netaddr as ipaddr
from collections import namedtuple
import json
import socket
import argparse
import os
import sys
import time
import errno
import socket
import argparse
from StringIO import *
from six import string_types
from asic import AsicKeyedEntry, AsicL2Entry, AsicL3Entry, \
     AsicPortSamplingRateEntry, AsicLAGEntry, AsicPortInfo, \
     AsicEgressInterfaceEntry, AsicL3MultipathEntry, \
     AsicL3InterfaceEntry, AsicL3DefipEntry, AsicInterface, AsicIPNetworkKey, \
     MACAddress

def to_string(input):
    return " ".join([s for s in input])

class InvalidEntryError(Exception):
    pass

class DuplicateItemError(Exception):
    pass

class ItemNotFoundError(Exception):
    pass

class UnexpectedFormat(Exception):
    pass

class InvCommandBuilder:
    invcmd_path = ''

    #
    # TO BE IMPLEMENTED BY Inv
    # Fill corresponding commands to dump table contents
    #
    inv_portsamplingrate_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'sysport']
    inv_show_pmap = [invcmd_path, 'debugparser', 'ifcs', 'devport']
    inv_l2_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'l2_entry']
    inv_vlan_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'l2vni']
    inv_l3_egress_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'nexthop']
    inv_l3_table_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'route_entry', 'v4_host']
    inv_l3_defip_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'route_entry', 'v4_prefix']
    inv_l3_intf_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'intf']
    inv_l3_ip6route_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'route_entry', 'v6_prefix']
    inv_l3_ip6host_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'route_entry', 'v6_host']
    inv_lag_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'lag']
    inv_l3_multipath_show_cmd = [invcmd_path, 'debugparser', 'ifcs', 'ecmp']
    inv_show_counters_cmd = [invcmd_path, 'debugparser', 'ifcs', 'devport', 'counters']
    inv_show_ecc_counters_cmd = [invcmd_path, 'debugparser', 'ifcs', 'ecc']
    inv_port_status_cmd = [invcmd_path, 'debugparser', 'ifcs', 'devport']

    inv_l3_info_ecmp_group_cmd = [invcmd_path, 'debugparser', 'ifcs', 'ecmp', 'usage']
    inv_l3_info_ecmp_path_cmd = [invcmd_path, 'debugparser', 'ifcs', 'ecmp', 'members', 'usage']
    inv_l3_info_ecmp_hash_cmd = [invcmd_path, 'debugparser', 'ifcs', 'l3', 'info', 'type=ecmp-hash'] # - NOTSUPPORTED since no separate hardware table
    inv_l3_info_interface_cmd = [invcmd_path, 'debugparser', 'ifcs', 'intf', 'usage']
    inv_l3_info_adjacency_cmd = [invcmd_path, 'debugparser', 'ifcs', 'nexthop', 'usage']
    inv_l3_info_router_mac_cmd = [invcmd_path, 'debugparser', 'ifcs', 'l3', 'info', 'type=router-mac'] # - NOTSUPPORTED since no separate hardware table
    inv_l3_info_host_cmd = [invcmd_path, 'debugparser', 'ifcs', 'route_entry', 'usage', 'host']
    inv_l3_info_route_cmd = [invcmd_path, 'debugparser', 'ifcs', 'route_entry', 'usage', 'prefix']

    inv_l3_info_cmd_dict = {'ecmp_groups': inv_l3_info_ecmp_group_cmd, 'ecmp_paths': inv_l3_info_ecmp_path_cmd,
                            'ecmp_nexthops': inv_l3_info_ecmp_hash_cmd,
                            'interfaces': inv_l3_info_interface_cmd, 'nexthops': inv_l3_info_adjacency_cmd,
                            'router_macs': inv_l3_info_router_mac_cmd, 'hosts': inv_l3_info_host_cmd, 'routes': inv_l3_info_route_cmd}

    lag_show_cmd = to_string(inv_lag_show_cmd)
    multipath_show_cmd = to_string(inv_l3_multipath_show_cmd)
    egress_show_cmd = to_string(inv_l3_egress_show_cmd)
    defip_show_cmd = to_string(inv_l3_defip_show_cmd)
    table_show_cmd = to_string(inv_l3_table_show_cmd)
    intf_show_cmd = to_string(inv_l3_intf_show_cmd)
    ip6route_show_cmd = to_string(inv_l3_ip6route_show_cmd)
    ip6host_show_cmd = to_string(inv_l3_ip6host_show_cmd)
    portsamplingrate_show_cmd = to_string(inv_portsamplingrate_show_cmd)
    pmap_show_cmd = to_string(inv_show_pmap)
    vlan_show_cmd = to_string(inv_vlan_show_cmd)
    l2_show_cmd = to_string(inv_l2_show_cmd)
    show_counters_cmd = to_string(inv_show_counters_cmd)
    show_ecc_couters_cmd = to_string(inv_show_ecc_counters_cmd)

    l3_info_ecmp_group_cmd = to_string(inv_l3_info_ecmp_group_cmd)
    l3_info_ecmp_path_cmd = to_string(inv_l3_info_ecmp_path_cmd)
    l3_info_ecmp_hash_cmd = to_string(inv_l3_info_ecmp_hash_cmd)
    l3_info_interface_cmd = to_string(inv_l3_info_interface_cmd)
    l3_info_adjacency_cmd = to_string(inv_l3_info_adjacency_cmd)
    l3_info_router_mac_cmd = to_string(inv_l3_info_router_mac_cmd)
    l3_info_host_cmd = to_string(inv_l3_info_host_cmd)
    l3_info_route_cmd = to_string(inv_l3_info_route_cmd)

    l3_info_cmd_dict = {'ecmp_groups': l3_info_ecmp_group_cmd,
                        'ecmp_paths': l3_info_ecmp_path_cmd,
                        'ecmp_nexthops': l3_info_ecmp_hash_cmd,
                        'interfaces': l3_info_interface_cmd,
                        'nexthops': l3_info_adjacency_cmd,
                        'router-macs': l3_info_router_mac_cmd,
                        'hosts': l3_info_host_cmd,
                        'routes': l3_info_route_cmd}
    port_status_cmd = to_string(inv_port_status_cmd)

    def get_commands_list(self):
        return [self.l2_show_cmd,
                self.table_show_cmd,
                self.defip_show_cmd,
                self.intf_show_cmd,
                self.egress_show_cmd,
                self.ip6route_show_cmd,
                self.ip6host_show_cmd,
                self.lag_show_cmd,
                self.multipath_show_cmd,
                self.portsamplingrate_show_cmd,
                self.pmap_show_cmd,
                self.show_counters_cmd,
                self.show_ecc_couters_cmd,
                self.vlan_show_cmd,
                self.l3_info_ecmp_group_cmd,
                self.l3_info_ecmp_path_cmd,
                self.l3_info_ecmp_hash_cmd,
                self.l3_info_interface_cmd,
                self.l3_info_adjacency_cmd,
                self.l3_info_router_mac_cmd,
                self.l3_info_host_cmd,
                self.l3_info_route_cmd,
                ]

# Inv interface class derived from AsicInterface
class InvInterface(AsicInterface):
    def __init__(self, intf_str, admin_up=False, carrier=False, port_type='normal', portmap_dict={}):
        AsicInterface.__init__(self, intf_str, admin_up, carrier)
        self.portmap_dict = portmap_dict
        self._intf_num = int(intf_str, 0)
        self._port_type = port_type

# Inv IP Network key derived from AsicIPNetworkKey
class InvIPNetworkKey(AsicIPNetworkKey):
    def __init__(self, ip_dest, vrf = "0"):
        AsicIPNetworkKey.__init__(self, ip_dest, vrf)
        if not isinstance(ip_dest, ipaddr.IPNetwork):
            raise TypeError('ip_dest must be an instance of IPNetwork')
        self._ip_dest = ip_dest
        self._vrf = vrf

# Inv Reader base class
class InvReader(object):
    def __init__(self, connector):
        self._connector = connector

    def read(self):
        raise NotImplemented()

    def _get_output(self, cmd):
        s = self._connector.sudo_get_output(cmd)
        return json.loads(s)

#
# Inv L2 entry derived from AsicL2Entry
# Should contain mac, vlan, dest_intf, static and drop flags
#
class InvL2Entry(AsicL2Entry):
    def __init__(self, mac, vlan, dest_intf, static=None, drop=None):
        AsicL2Entry(mac, vlan, dest_intf, static, drop)
        self._mac = mac
        self._vlan = vlan
        if isinstance(dest_intf, InvInterface):
            self._dest_intf = dest_intf._intf_num
        else:
            self._dest_intf = str(dest_intf)
        self._static = static
        self._drop = drop

#
# Inv L2 Reader derived from InvReader
# Reads the inv L2 table and calls InvL2Parser to parse the output
#
class InvL2Reader(InvReader):
    def __init__(self, connector, portmap_dict):
        self.portmap_dict = portmap_dict
        super(InvL2Reader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l2_show_cmd)
        return InvL2Parser(self.portmap_dict).parse_output(output)

# Inv L2 Parser parses the inv L2 table output
class InvL2Parser(object):
    def __init__(self, portmap_dict):
        self.portmap_dict = portmap_dict

    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of InvL2Entry
        #for line in output.splitlines():
        new_output_list = []
        for entry in output["L2_entry"]:
            if self._validate_entry(entry) == True:
                new_output_list.append(entry)

        for entry in new_output_list:
            l2_entry = self._parse_l2_line(entry)
            yield l2_entry

    def _validate_entry(self, entry):
        # validates if entry is IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI and returnstrue or false
        if 'l2_entry_key._dirty_mac_l2vni' in entry.keys():
            key_type = entry['l2_entry_key._dirty_mac_l2vni']
        if key_type == 1:
            return True
        else:
            return False

    def _parse_l2_line(self, line):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in L2 table output and
        # converts it to InvL2Entry
        #
        # line in arg is actually a ifcsState dict with all info.
        # We need to get the following required values from it
        mac = None
        if 'key.mac_addr' in line.keys():
            mac_str = line['key.mac_addr']
            #mac_list = [mac_str[i:i+2] for i in range(0, len(mac_str), 2)]
            #mac_str = ":".join(mac_list)

            mac = MACAddress(mac_str)

        vid = None
        if 'key.l2vni' in line.keys():
            vid = line['key.l2vni']

        if 'entry_dest' in line.keys():
            port = str(line['entry_dest'])

        if 'port_type' in line.keys():
            port_type = line['port_type']

        interface = InvInterface(port, port_type=port_type, portmap_dict=self.portmap_dict)

        static = None
        if line['entry_type'] == 0: # 0 in ifcs is static
            static = True
        else:
            static = False

        drop = False
        if(line['fwd_action'][1]
                != 'FORWARD'): # 0 is forward, 1 is DROP in IFCS
            drop = True

        l2_entry = InvL2Entry(mac, vid, interface, static, drop)
        return l2_entry

#
# Inv L3 entry derived from AsicL3Entry
# Should contain ip_dest, egress_intf_index, multipath, lookup_class
#
class InvL3Entry(AsicL3Entry):
    def __init__(self, ip_dest, egress_intf_index, multipath = False, lookup_class=0):
        AsicL3Entry(ip_dest, egress_intf_index, multipath, lookup_class)
        if not isinstance(ip_dest, ipaddr.IPNetwork) or\
                not isinstance(egress_intf_index, int) or\
                not isinstance(lookup_class, int):
            raise TypeError("Arguments should be of type IPAddress, int, int")
        if not ip_dest.prefixlen == 32 and not ip_dest.prefixlen == 128:
            raise ValueError('L3 Table only supports host routes')
        self._ip_dest = ip_dest
        self._egress_intf_index = egress_intf_index
        self._multipath = multipath
        self._lookup_class = lookup_class

#
# Inv L3 Table Reader derived from InvReader
# Reads the inv L3 table and calls InvL3TableParser to parse the output
#
class InvL3TableReader(InvReader):
    def __init__(self, connector):
        super(InvL3TableReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l3_table_show_cmd)
        return  InvL3TableParser().parse_output(output)

# Inv L3 Table Parser parses the inv L3 table output
class InvL3TableParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of InvL3Entry
        for entry in output["Route_entry"]:
            l3_table_entry = self._parse_l3_table_line(entry)
            yield l3_table_entry

    def _parse_l3_table_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in L3 table output and
        # converts it to InvL3Entry
        #

        if 'ip_dest' in entry.keys():
            ip_dest = entry['ip_dest']

        if 'nexthop' in entry.keys():
            intf_index = entry['nexthop']

        if 'multipath' in entry.keys():
            multipath = entry['multipath']

        lookup_class = 0
        ip_dest = ipaddr.IPNetwork(ip_dest)
        l3_entry = InvL3Entry(ip_dest, intf_index, multipath, lookup_class)
        return l3_entry


#
# Inv L3 IPV6 Table Reader derived from InvReader
# Reads the inv L3 IPV6 table and calls InvL3IP6HostParser to parse the output
#
class InvL3IP6HostReader(InvReader):
    def __init__(self, connector):
        super(InvL3IP6HostReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l3_ip6host_show_cmd)
        return  InvL3IP6HostParser().parse_output(output)

# Inv L3 ip6 Table Parser parses the inv L3 ip6 table output
class InvL3IP6HostParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of InvL3Entry
        for entry in output["Route_entry"]:
            l3_table_entry = self._parse_l3_table_line(entry)
            yield l3_table_entry

    def _parse_l3_table_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in L3 table output and
        # converts it to InvL3Entry
        #
        if 'ip_dest' in entry.keys():
            ip_dest = entry['ip_dest']

        if 'nexthop' in entry.keys():
            intf_index = entry['nexthop']

        if 'multipath' in entry.keys():
            multipath = entry['multipath']

        lookup_class = 0
        ip_dest = ipaddr.IPNetwork(ip_dest)
        l3_entry = InvL3Entry(ip_dest, intf_index, multipath, lookup_class)
        return l3_entry

#
# Inv L3 Defip entry derived from AsicL3DefipEntry
# Should contain ip_dest, egress_intf_index, multipath, lookup_class and vrf
#
class InvL3DefipEntry(AsicL3DefipEntry):
    def __init__(self, ip_dest, egress_intf_index, multipath = False, lookup_class = 0, vrf = "0"):
        AsicL3DefipEntry(ip_dest, egress_intf_index, multipath, lookup_class, vrf)
        if not isinstance(ip_dest, ipaddr.IPNetwork) or\
                not isinstance(egress_intf_index, int) or\
                not isinstance(lookup_class, int):
            raise TypeError('Arguments should be of type IPAddress, int, int')
        self._ip_dest = ip_dest
        self._egress_intf_index = egress_intf_index
        self._multipath = multipath
        self._lookup_class = lookup_class
        self._vrf = vrf

#
# Inv L3 Defip Reader derived from InvReader
# Reads the inv L3 defip table and calls InvL3DefipParser to parse the output
#
class InvL3DefipReader(InvReader):
    def __init__(self, connector):
        super(InvL3DefipReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l3_defip_show_cmd)
        return InvL3DefipParser().parse_output(output)

# Inv L3 Defip Parser parses the inv L3 defip output
class InvL3DefipParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of InvL3DefipEntry
        for entry in output["Route_entry"]:
            l3_defip_entry = self._parse_l3_defip_line(entry)
            yield l3_defip_entry

    def _parse_l3_defip_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in L3 defip output and
        # converts it to InvL3DefipEntry
        #
        if 'nexthop' in entry.keys():
            intf_index = entry['nexthop']

        if 'ip_dest' in entry.keys():
            ip_dest = entry['ip_dest']

        if 'multipath' in entry.keys():
            multipath = entry['multipath']

        if 'l3vni' in entry.keys():
            vrf = entry['l3vni']

        if 'prefix_len' in entry.keys():
            prefix_len = entry['prefix_len']

        lookup_class = 0
        ip_dest = ipaddr.IPNetwork(ip_dest + '/' + str(prefix_len))
        l3_defip_entry = InvL3DefipEntry(ip_dest, intf_index, multipath, lookup_class, vrf)
        return l3_defip_entry


#
# Inv L3 IPV6 Reader derived from InvReader
# Reads the inv L3 ipv6 table and calls InvL3IP6RouteParser to parse the output
#
class InvL3IP6RouteReader(InvReader):
    def __init__(self, connector):
        super(InvL3IP6RouteReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l3_ip6route_show_cmd)
        return InvL3IP6RouteParser().parse_output(output)

# Inv L3 Defip IPv6 Parser parses the inv L3 defip IPv6 output
class InvL3IP6RouteParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of InvL3Entry
        for entry in output["Route_entry"]:
            l3_ip6route_entry = self._parse_l3_ip6route_line(entry)
            yield l3_ip6route_entry


    def _parse_l3_ip6route_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in L3 ip6route output and
        # converts it to InvL3DefipEntry
        #

        if 'nexthop' in entry.keys():
            intf_index = entry['nexthop']

        if 'ip_dest' in entry.keys():
            ip_dest = entry['ip_dest']

        if 'multipath' in entry.keys():
            multipath = entry['multipath']

        if 'l3vni' in entry.keys():
            vrf = entry['l3vni']

        if 'prefix_len' in entry.keys():
            prefix_len = entry['prefix_len']

        lookup_class = 0
        ip_dest = ipaddr.IPNetwork(ip_dest + '/' + str(prefix_len))
        l3_defip_entry = InvL3DefipEntry(ip_dest, intf_index, multipath, lookup_class, vrf)
        return l3_defip_entry


#
# Inv port sampling rate entry derived from AsicPortSamplingRateEntry
# Should contain interface_str, igress_samp_rate and egress_samp_rate
#
class InvPortSamplingRateEntry(AsicPortSamplingRateEntry):
    def __init__(self, interface_str, ingress_samp_rate, egress_samp_rate):
        AsicPortSamplingRateEntry(interface_str, ingress_samp_rate, egress_samp_rate)
        if not isinstance(ingress_samp_rate, int) or\
                  not isinstance(egress_samp_rate, int):
              raise TypeError("Ingress and Egress rates should be of type int")
        self._interface_str = interface_str
        self._ingress_samp_rate = ingress_samp_rate
        self._egress_samp_rate = egress_samp_rate

#
# Inv Port Sampling Rate Reader derived from InvReader
# Reads the inv port sampling rate table and calls InvPortSamplingRateParser to parse the output
#
class InvPortSamplingRateReader(InvReader):
    def __init__(self, connector):
        super(InvPortSamplingRateReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_portsamplingrate_show_cmd)
        return InvPortSamplingRateParser().parse_output(output)

# Inv Port Sampling Rate Parser parses the inv port sampling rate output
class InvPortSamplingRateParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of InvPortSamplingRateEntry
        for entry in output[0]['Sysport']:
            portsamplingrate_entry = self._parse_portsamplingrate_line(entry)
            yield portsamplingrate_entry

    def _parse_portsamplingrate_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in the port sampling table and
        # converts it to InvPortSamplingRateEntry
        #
        if 'sflow_ingress.sampling_rate' in entry:
            ingress_samp_rate = entry['sflow_ingress.sampling_rate']

        if 'sflow_egress.sampling_rate' in entry:
            egress_samp_rate  = entry['sflow_egress.sampling_rate']

        if 'obj.handle' in entry:
            interface_str = str(entry['obj.handle'])
        sampling_entry = InvPortSamplingRateEntry(interface_str, ingress_samp_rate, egress_samp_rate)
        return sampling_entry

#
# Inv L3 Interface entry derived from AsicL3InterfaceEntry
# Should contain vlan, src_mac, mtu and vrf
#
class InvL3InterfaceEntry(AsicL3InterfaceEntry):
    def __init__(self, vlan, src_mac, mtu, vrf = "0"):
        AsicL3InterfaceEntry(vlan, src_mac, mtu, vrf)
        if not isinstance(vlan, int) or\
                not isinstance(src_mac, MACAddress) or\
                not isinstance(mtu, int):
            raise TypeError('Need int, int, MACAddress,int for args')
        self._vlan = vlan
        self._src_mac = src_mac
        self._mtu = mtu
        self._vrf = vrf

#
# Inv L3 Interace Table Reader derived from InvReader
# Reads the inv L3 interface table and calls InvL3InterfaceParser to parse the output
#
class InvL3InterfaceReader(InvReader):
    def __init__(self, connector):
        super(InvL3InterfaceReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l3_intf_show_cmd)
        return InvL3InterfaceParser().parse_output(output)

# Inv L3 interface Parser parses the inv L3 interface table output
class InvL3InterfaceParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of (intf_index, InvL3InterfaceEntry)
        for entry in output:
            (intf_index, l3_intf_entry) = self._parse_l3_intf_line(entry)
            yield (intf_index, l3_intf_entry)

    def _parse_l3_intf_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in L3 Interface output and
        # converts it to InvL3InterfaceEntry
        #
        if 'intf_index' in entry.keys():
            intf_index = entry['intf_index']

        if 'src_mac' in entry.keys():
            mac = entry['src_mac']
            src_mac = MACAddress(mac)

        if 'mtu' in entry.keys():
            mtu = entry['mtu']

        if 'l3vni' in entry.keys():
            vrf = str(entry['l3vni'])

        if 'l2vni' in entry.keys():
            vlan = entry['l2vni']

        l3_intf_entry = InvL3InterfaceEntry(vlan, src_mac, mtu, vrf = vrf)
        return (intf_index, l3_intf_entry)

#
# Inv egress interface entry derived from AsicEgressInterfaceEntry
# Should contain l3_interface_index, egress_mac, inv_interface, port_type and flags
# Valid values for port_type are  'normal' for regular ports and 'cpu'
# Valid values for flags are 'drop', 'keep-ttl'
#
class InvEgressInterfaceEntry(AsicEgressInterfaceEntry):
    def __init__(self, l3_interface_index, egress_mac, inv_interface="", port_type="", flags=[]):
        AsicEgressInterfaceEntry(l3_interface_index, egress_mac, inv_interface, port_type, flags)
        self._l3_interface_index = int(l3_interface_index)
        self._egress_mac = MACAddress(str(egress_mac))
        if isinstance(inv_interface, InvInterface):
            self._inv_interface = inv_interface._intf_num
        else:
            self._inv_interface = str(inv_interface)
        self._port_type = port_type
        self._flags = flags

#
# Inv L3 Egress Table Reader derived from InvReader
# Reads the inv L3 egress table and calls InvL3EgressParser to parse the output
#
class InvL3EgressReader(InvReader):
    def __init__(self, connector, portmap_dict):
        self._portmap_dict = portmap_dict
        super(InvL3EgressReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l3_egress_show_cmd)
        return InvL3EgressParser(portmap_dict=self._portmap_dict).parse_output(output)

# Inv L3 Egress Parser parses the inv L3 egress table output
class InvL3EgressParser(object):
    def __init__(self, portmap_dict):
        self._portmap_dict = portmap_dict
        self.blackhole_l3_intf = 0

    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of (egress_index, InvEgressInterfaceEntry)
        count = 0
        for entry in output['Nexthop']:
            if entry['index_el.index'] < 129:
                continue
            (egress_index, egress_entry) = self._parse_l3_egress_line(entry)
            yield (egress_index, egress_entry)

    def _parse_l3_egress_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in l3 egress table output and
        # converts it to InvEgressInterfaceEntry
        #
        inv_interface = ''
        port_type = ''
        flags = []
        if 'intf' in entry.keys():
            l3_intf_index = entry['intf']

        if 'dest_mac' in entry.keys():
            egress_mac = entry['dest_mac']

        if 'obj.handle' in entry.keys():
            egress_index = entry['obj.handle']

        if 'port_type' in entry.keys():
            if (entry['ctc_policy'] == 'DISABLE' and entry['fwd_policy'] == 'DROP'):
                port_type = ''
                flags.append('drop')
            else:
                port_type = entry['port_type']

        if 'no_decrement_ttl' in entry.keys():
            if entry['no_decrement_ttl'] == 1:
                flags.append('keep_ttl')

        inv_interface = InvInterface(str(l3_intf_index), port_type=port_type, portmap_dict=self._portmap_dict)

        entry = InvEgressInterfaceEntry(l3_intf_index, egress_mac, inv_interface, port_type, flags)
        return (egress_index, entry)

#
# Inv Vlan Reader derived from InvReader
# Reads the inv vlan table and calls InvVlanParser to parse the output
#
class InvVlanReader(InvReader):
    def __init__(self, connector):
        super(InvVlanReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_vlan_show_cmd)
        return InvVlanParser().parse_output(output)

# Inv Vlan Parser parses the inv vlan table output
class InvVlanParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of (vlan id, ports part of that vlan)
        for entry in output[0]["L2vni"]:
            l2vni =  self._parse_vlan_line(entry)
            yield l2vni

    def _parse_vlan_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in vlan output and
        # returns vlan_id and the ports that are part of that vlan
        #
        vlandict = {}
        ports = []
        if 'obj.handle' in entry.keys():
            vlan_id = entry['obj.handle']

        if 'l2vni_member' in entry.keys():
            for item in entry['l2vni_member'].values():
                #print(item)
                ports.append(item['handle'])

        vlandict[int(vlan_id)] = ports
        return (vlandict)

#
# Inv L3 multipath entry derived from AsicL3MultipathEntry
# Should contain a set of egress_indices part of the given multipath
# For weighted egresses, replicate the egress times weight in egress_indices
#
class InvL3MultipathEntry(AsicL3MultipathEntry):
    def __init__(self, egress_indices = []):
        AsicL3MultipathEntry(egress_indices)
        self._egress_indices = tuple(egress_indices)

#
# Inv L3 Multipath Reader derived from InvReader
# Reads the inv L3 multipath table and calls InvL3MultipathParser to parse the output
#
class InvL3MultipathReader(InvReader):
    def read(self):
        output = self._get_output(InvCommandBuilder.inv_l3_multipath_show_cmd)
        return InvL3MultipathParser().parse_output(output)

# Inv L3 Multipath Table Parser parses the inv L3 multipath table output
class InvL3MultipathParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of ecmp_id and InvL3MultipathEntrys
        for entry in output[0]["Ecmp"]:
            ecmp_id, ecmp_entry = self._parse_l3_ecmp_line(entry)
            yield ecmp_id, ecmp_entry

    def _parse_l3_ecmp_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in l3 multipath table output and
        # converts it to InvL3MultipathEntry
        #
        egresses_tot = []

        if 'obj.handle' in entry.keys():
            ecmp_id = entry['obj.handle']

        if 'ecmp_member' in entry.keys():
            for item in entry['ecmp_member'].values():
                egresses_tot.append(item['handle'])

        ecmp_entry = InvL3MultipathEntry(egresses_tot)
        return (ecmp_id, ecmp_entry)

#
# Inv LAG entry derived from AsicLAGEntry
# Should contain lag_id and members that are part of that lag
#
class InvLAGEntry(AsicLAGEntry):
    def __init__(self, lag_id, members=[]):
        AsicLAGEntry(lag_id, members)
        self._lag_id = lag_id
        self._members = tuple(members)

#
# Inv Lag Reader derived from InvReader
# Reads the inv LAG table and calls InvLAGParser to parse the output
#
class InvLAGReader(InvReader):
    def __init__(self, connector):
        super(InvLAGReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_lag_show_cmd)
        return InvLAGParser().parse_output(output)

# Inv LAG Parser parses the inv LAG table output
class InvLAGParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of (lag_port, InvLAGEntry)
        for entry in output[0]["Lag"]:
            lag_port, lag_entry =  self._parse_lag_line(entry)
            yield lag_port, lag_entry

    def _parse_lag_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in inv lag table output and
        # converts it to (lag_port, InvLagEntry
        #
        port_list = []

        if 'index_el.index' in entry.keys():
            lag_id = entry['index_el.index']

        if 'lag_member' in entry.keys():
            for item in entry['lag_member'].values():
                port_list.append(item['handle'])

        if 'obj.handle' in entry.keys():
            lag_port = entry['obj.handle']

        lag_entry = InvLAGEntry(lag_id, port_list)
        return (lag_port, lag_entry)

#
# Inv counter entry
# Should contain hw_port and the values for the following stats:
# Rx Octets
# Rx Unicast packets
# Rx Broadcast packets
# Rx Multicast packets
# Rx Mac Control packets
# Rx Drop packets
# Rx Error packets
# Tx Octets
# Tx Unicast packets
# Tx Broadcast packets
# Tx Multicast packets
# Tx Mac Control packets
# Tx Drop packets
# Tx Error packets
#
class InvCountersEntry(object):
    def  __init__(self,
                  hw_port = None,
                  rx_octets = None,
                  rx_uc_pkts = None,
                  rx_bc_pkts = None,
                  rx_mc_pkts = None,
                  rx_mac_ctrl = None,
                  rx_drop_pkts = None,
                  rx_err_pkts = None,
                  tx_octets = None,
                  tx_uc_pkts = None,
                  tx_bc_pkts = None,
                  tx_mc_pkts = None,
                  tx_mac_ctrl = None,
                  tx_drop_pkts = None,
                  tx_err_pkts = None):

        self._hw_port = hw_port
        self._rx_octets = rx_octets
        self._rx_uc_pkts = rx_uc_pkts
        self._rx_bc_pkts = rx_bc_pkts
        self._rx_mc_pkts = rx_mc_pkts
        self._rx_mac_ctrl = rx_mac_ctrl
        self._rx_drop_pkts = rx_drop_pkts
        self._rx_err_pkts = rx_err_pkts
        self._tx_octets = tx_octets
        self._tx_uc_pkts = tx_uc_pkts
        self._tx_bc_pkts = tx_bc_pkts
        self._tx_mc_pkts = tx_mc_pkts
        self._tx_mac_ctrl = tx_mac_ctrl
        self._tx_drop_pkts = tx_drop_pkts
        self._tx_err_pkts = tx_err_pkts

#
# Inv Counters Reader derived from InvReader
# Reads the inv port counters and calls InvCountersParser to parse the output
#
class InvCountersReader(InvReader):
    def __init__(self, connector):
        super(InvCountersReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_show_counters_cmd)
        return InvCountersParser().parse_output(output)

# Inv Counters Parser parses the inv port counters output
class InvCountersParser(object):
    def parse_output(self, output):
        # Parses each line in the output and
        # returns a set of InvCountersEntry
        for entry in output[0]['DevportStats']:
            yield self._parse_line(entry)

    def _parse_line(self, entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in port counters output and
        # converts it to InvCountersEntry
        #
        if 'hw_port' in entry:
            hw_port = entry['hw_port']

        if 'rx_octets' in entry:
            rx_octets = entry['rx_octets']

        if 'rx_uc_pkts' in entry:
            rx_uc_pkts = entry['rx_uc_pkts']

        if 'rx_bc_pkts' in entry:
            rx_bc_pkts = entry['rx_bc_pkts']

        if 'rx_mc_pkts' in entry:
            rx_mc_pkts = entry['rx_mc_pkts']

        if 'rx_mac_ctrl' in entry:
            rx_mac_ctrl = entry['rx_mac_ctrl']

        if 'rx_drop_pkts' in entry:
            rx_drop_pkts = entry['rx_drop_pkts']

        if 'rx_err_pkts' in entry:
            rx_err_pkts = entry['rx_err_pkts']

        if 'tx_octets' in entry:
            tx_octets = entry['tx_octets']

        if 'tx_uc_pkts' in entry:
            tx_uc_pkts = entry['tx_uc_pkts']

        if 'tx_bc_pkts' in entry:
            tx_bc_pkts = entry['tx_bc_pkts']

        if 'tx_mc_pkts' in entry:
            tx_mc_pkts = entry['tx_mc_pkts']

        if 'tx_mac_ctrl' in entry:
            tx_mac_ctrl = entry['tx_mac_ctrl']

        if 'tx_drop_pkts' in entry:
            tx_drop_pkts = entry['tx_drop_pkts']

        if 'tx_err_pkts' in entry:
            tx_err_pkts = entry['tx_err_pkts']

        ctr_entry = InvCountersEntry(hw_port, rx_octets, rx_uc_pkts, rx_bc_pkts, rx_mc_pkts,
                                        rx_mac_ctrl, rx_drop_pkts, rx_err_pkts, tx_octets, tx_uc_pkts,
                                        tx_bc_pkts, tx_mc_pkts, tx_mac_ctrl, tx_drop_pkts, tx_err_pkts)
        return ctr_entry

#
# Inv counter entry
# Should contain stats for single and double bit error counts as well
# as corrected error counts
#
class InvECCCountersEntry(object):
    def  __init__(self,
                  single_err = None,
                  double_err = None,
                  correct = None):

        self._single_err = single_err
        self._double_err = double_err
        self._correct = correct
#
# Inv ECC Counters Reader derived from InvReader
# Reads the inv ECC counters and calls InvECCCountersParser to parse the output
#
class InvECCCountersReader(InvReader):
    def __init__(self, connector):
        super(InvECCCountersReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_show_ecc_counters_cmd)
        return InvECCCountersParser().parse_output(output)

# Inv ECC Counters Parser parses the inv ECC counters output
class InvECCCountersParser(object):
    def parse_output(self, output):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses ECC counter output and return InvECCCountersEntry
        #
        single = output[0]['Ecc']['TYPE_UE']
        double = output[0]['Ecc']['TYPE_CE']
        correct = output[0]['Ecc']['SW_FIXED_CE'] + output[0]['Ecc']['SW_FIXED_UE']
        ecc_ctr_entry = InvECCCountersEntry(single, double, correct)
        return ecc_ctr_entry

#
# Inv L3 Info Reader derived from InvReader
# Reads the inv L3 table usages and calls InvL3InfoParser to parse the output
#
class InvL3InfoReader(InvReader):
    def __init__(self, connector):
        super(InvL3InfoReader, self).__init__(connector)

    def read(self):
        l3_info = {}
        for resource, cmd in InvCommandBuilder.inv_l3_info_cmd_dict.items():
            if resource not in ['ecmp_groups', 'ecmp_paths', 'nexthops', 'hosts', 'routes', 'interfaces']:
                continue
            output = self._get_output(cmd)
            l3_info[resource] = InvL3InfoParser().parse_output(output)
        return l3_info

# Inv L3 Info Parser parses the inv L3 info output
class InvL3InfoParser(object):
    def read_output(self, output):
        l3_info = dict()
        for resource, cmd in InvCommandBuilder.l3_info_cmd_dict.items():
            l3_info[resource] = self.parse_output(output[cmd])
        return l3_info

    def parse_output(self, output):
        for entry in output[0].values():
            #
            # TO BE IMPLEMENTED BY Inv
            # Parse the usage of various L3 tables and provide the current and max values
            #
            #values_dict['curr'] = curr
            #values_dict['max'] = max
            return entry
        return None

class InvClearCounters(object):
    def __init__(self, connector):
        self.connector = connector

    def run(self):
        #
        # TO BE IMPLEMENTED BY Inv
        # Provide command to clear counters on all ports
        #
        output = self.connector.sudo_check_call(['invcmd', 'stat', 'clear'])

#
# Inv port info entry
# Should contain hw port number, speed, interface type, admin status,
# autoneg, eee, fec, flow_control, link_status, loopback and cutthrough status
#
class InvPortInfo(AsicPortInfo):
    def __init__(self,
                 hw_port = None,
                 speed = None,
                 interface = None,
                 admin_status = None,
                 autoneg = None,
                 eee = None,
                 fec = None,
                 flow_control = None,
                 link_status = None,
                 loopback = None,
                 cut_thru = None,
                 intf_type = None):

        self._hw_port       = hw_port
        self._speed         = speed
        self._interface     = interface
        self._admin_status  = admin_status
        self._autoneg       = autoneg
        self._eee           = eee
        self._fec           = fec
        self._flow_control  = flow_control
        self._link_status   = link_status
        self._cut_thru      = cut_thru
        self._loopback      = loopback
        self._intf_type     = intf_type

#
# Inv Port Status Reader derived from InvReader
# Reads the inv port table and calls InvPortStatusParser to parse the output
#
class InvPortStatusReader(InvReader):
    def __init__(self,connector):
        self._connector = connector
        super(InvPortStatusReader, self).__init__(connector)

    def read(self):
        output = self._get_output(InvCommandBuilder.inv_port_status_cmd)
        return InvPortStatusParser().parse_output(output)

# Inv Port Status Parser parses the inv port status output
class InvPortStatusParser(object):
    def parse_output(self,output):
        # Parses each line in the output and
        # returns a set of InvPortInfo
        for entry in output[0]["Devport"]:
            portinfo  = self.parse_line(entry)
            yield portinfo

    def parse_line(self,entry):
        #
        # TO BE IMPLEMENTED BY Inv
        # Parses a single line in inv port info output and
        # return InvPortInfo
        #
        eee = ''
        flow_control = ''
        if 'devport' in entry.keys():
            hw_port = entry['devport']

        if 'sysport' in entry.keys():
            interface = entry['sysport']

        if 'speed' in entry.keys():
            speed = entry['speed']

        if 'admin_state' in entry.keys():
            if entry['admin_state'] == 1:
                admin_status = 'UP'
            else:
                admin_status = 'DOWN'

        if 'link_status' in entry.keys():
            link_status = entry['link_status']

        if 'loopback' in entry.keys():
            loopback = entry['loopback']

        if 'auto_neg' in entry.keys():
            if entry['auto_neg'] == 1:
                autoneg = 'True'
            else:
                autoneg = 'False'

        if 'fec_mode' in entry.keys():
            fec = entry['fec_mode']

        if 'intf_type' in entry.keys():
            intf_type = entry['intf_type']

        if 'cut_through_enable' in entry.keys():
            if entry['cut_through_enable'] == 1:
                cut_thru = 'True'
            else:
                cut_thru = 'False'


        ret_val = InvPortInfo (hw_port, speed, interface, admin_status, autoneg, eee, fec, flow_control, link_status, loopback, cut_thru, intf_type)
        return ret_val
