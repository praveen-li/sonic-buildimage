#!/usr/bin/python

import os
import sys
import argparse
import time
import pdb
from cStringIO import StringIO
from ctypes import *
from ifcsshell import *
from ifcs_cli import *
#from utils.ifcsObjMgr import Devport
from ifcs_cmds.devport import Devport as Devport

nodeId = 0

def _run_cli_cmd(cli, cmd, debug_en):
    """
    Run the cmd over the CLI
    """

    # Supress any stdout from
    # aapl functions
    sys.stdout.flush()
    newstdout = os.dup(1)
    devnull = os.open('/dev/null', os.O_WRONLY)
    os.dup2(devnull, 1)
    os.close(devnull)
    sys.stdout = os.fdopen(newstdout, 'w')

    # Capture the stdout from
    # the CLI output
    old_stdout = sys.stdout
    sys.stdout.flush()
    sys.stdout = mystdout = StringIO()
    cli.onecmd(cmd)
    output = mystdout.getvalue()
    sys.stdout.flush()
    sys.stdout = old_stdout
    sys.stdout.flush()
    os.dup2(newstdout, 1)

    if debug_en:
        print("============================DEBUG START=======================================")
        print("CLI cmd: %s" % cmd)
        print("Output:")
        print("%s" % output)
        print("============================DEBUG END=========================================")

    return output

def _retune_lane(cli, dp, lane, debug_en):
    """
    Issue iCal and pCal on the lane
    """
    # Issue iCal and pCal on this lane
    #print("Issuing iCal on devport %d lane %d" %(dp, lane))
    ical_cmd = "diagtest serdes aapl %d %d \"aapl serdes -int 0xa 1\"" % (dp, lane)
    _run_cli_cmd(cli, ical_cmd, debug_en)
    ical_cmd = "diagtest serdes aapl %d %d \"aapl dfe -wait\"" % (dp, lane)
    _run_cli_cmd(cli, ical_cmd, debug_en)

    # Issue pCal and pCal on this lane
    #print("Issuing pCal on devport %d lane %d" %(dp, lane))
    pcal_cmd = "diagtest serdes aapl %d %d \"aapl -int 0xa 6\"" % (dp, lane)
    _run_cli_cmd(cli, pcal_cmd, debug_en)

def _check_tune_quality(cli, dp, lane, t06, t15, debug_en):
    """
    Using aapl determine the eye height
    """
    # Turn off temp bcast on both rings
    aapl_cmd = "diagtest serdes sbm 0xfd  \"aapl sbm -int 0x2C 0x0\""
    _run_cli_cmd(cli, aapl_cmd, debug_en)
    time.sleep(0.4)
    aapl_cmd = "diagtest serdes sbm 1:0xfd \"aapl sbm -int 0x2C 0x0\""
    _run_cli_cmd(cli, aapl_cmd, debug_en)
    time.sleep(0.4)

    aapl_cmd = "diagtest serdes aapl %d %d \"aapl eye -print-vbtc -nosbm -timeout 20000\" " % (dp, lane)
    output_vbtc  =  _run_cli_cmd(cli, aapl_cmd, debug_en)

    # Turn on temp bcast on both rings
    aapl_cmd = "diagtest serdes sbm 0xfd  \"aapl sbm -int 0x2C 0x1\""
    _run_cli_cmd(cli, aapl_cmd, debug_en)
    time.sleep(0.4)
    aapl_cmd = "diagtest serdes sbm 1:0xfd \"aapl sbm -int 0x2C 0x1\""
    _run_cli_cmd(cli, aapl_cmd, debug_en)
    time.sleep(0.4)

    # Parse the output to get the
    # eye height at 1e-15 BER
    for line in output_vbtc.split('\n'):
        if "Insufficient data to generate vertical bathtub information." in line:
            print(line)
            return False

        if "Eye height at 1e-06 BER" in line:
            val_str = line.split(':')[1][:-3].strip()
            val06 = int(val_str)
            print(line)

        if "Eye height at 1e-15 BER" in line:
            val_str = line.split(':')[1][:-3].strip()
            val15 = int(val_str)
            print(line)

    # If height less than threshold,
    # lane needs retune
    if (val06 > t06) and (val15 > t15):
        return True
    else:
        return False

def check_retune_links(cli, count, t06, t15, debug_en):
    """
    Check all lanes on all ports
    Retune links that are not optimally tune
    """

    #print("Retry count %d" % count)

    # Get all the devport objects
    devport_obj = Devport(cli)
    try:
        all_devports = devport_obj.getAlldevport()
    except BaseException:
        log_err(" Failed to get all devport")
        return

    all_devports = sorted(all_devports)

    for devport in all_devports:
        if devport == 0:
            continue

        # Check the verticle bath curve
        # output for tune quality.
        # Eye height at 1e-15 BER/0.5
        # should be greater than 25 mV
        num_lanes = devport_obj.getNumLanes(devport)
        for lane_num in range(num_lanes):
            retry_count = count
            print("\nGetting eye height for devport %d lane %d" % (devport, lane_num))
            status = _check_tune_quality(cli, devport, lane_num, t06, t15, debug_en)
            attempt = 1

            # Attempt retune in case of
            # bad eye height
            if status == False:
                while (retry_count):
                    print("Retuning devport %d lane %d...attempt %d" %(devport, lane_num, attempt))
                    _retune_lane(cli, devport, lane_num, debug_en)
                    attempt = attempt + 1

                    status = _check_tune_quality(cli, devport, lane_num, t06, t15, debug_en)
                    if status == True:
                        break

                    retry_count = retry_count - 1

                if retry_count == 0:
                    print("Failed to retune devport %d lane %d" %(devport, lane_num))


def main(argv):

    cli = IFCS_CLI()
    cli.set_rt_env('switch')
    cli.set_standalone(True)
    cli.init_cmds()
    cli.set_node_id(nodeId)

    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('-r', '--retry_count', type=int, default=10,
                            help='Retry count to retune a link')
        parser.add_argument('-t06', '--threshold06', type=int, default=140,
                            help='Eye height threshold at 1e-06 in mV')
        parser.add_argument('-t15', '--threshold15', type=int, default=25,
                            help='Eye height threshold at 1e-15 in mV')
        parser.add_argument('-d', '--debug', action='store_true',
                            help='Enable debug output')
        args = parser.parse_args(argv.split())

        print("Retry count:        %d" % args.retry_count)
        print("Threshold at 1e-06: %d" % args.threshold06)
        print("Threshold at 1e-15: %d" % args.threshold15)
        print("Debug:              %d" % args.debug)

        check_retune_links(cli, args.retry_count, args.threshold06,
                           args.threshold15, args.debug)
    except SystemExit as ex_arg:
        # Handle invalid args
        pass

    except Exception as ex:
        print("Error executing script!!!")
        print("%s" % str(ex))

if __name__ == "__main__":
    main()
