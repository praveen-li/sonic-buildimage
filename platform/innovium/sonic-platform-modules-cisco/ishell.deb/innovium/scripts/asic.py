# Copyright 2017 Amazon, LLC.  All rights reserved.
# Base class for asic keyed entry
import re
class AsicKeyedEntry:
    def __init__(self):
        pass

# Base class for asic l2 entry
class AsicL2Entry(object):
    def __init__(self, mac, vlan, dest_intf, static, drop):
        pass

# Base class for asic l2 entry
class AsicVlanEntry(object):
    def __init__(self, vlan_id, members):
        pass

# Base class for asic l3 entry
class AsicL3Entry(object):
    def __init__(self, ip_dest, egress_intf_index, multipath, lookup_class, vrf):
        pass

# Base class for asic port sampling rate entry
class AsicPortSamplingRateEntry(object):
    def __init__(self, interface_str, ingress_samp_rate, egress_samp_rate):
        pass

# Base class for asic lag entry
class AsicLAGEntry(object):
    def __init__(self, lag_id, members):
        pass

# Base class for asic port info
class AsicPortInfo(object):
    def __init__(self, hw_port, speed, interface, admin_status, autoneg, eee, fec,
                 flow_control, link_status, loopback, cut_thru):
        pass

# Base class for asic egress interface entry
class AsicEgressInterfaceEntry(object):
    def __init__(self, egress_entry_index, l3_interface_index, egress_mac, inv_interface, port_type, flags):
        pass

# Base class for asic l3 multipath entry
class AsicL3MultipathEntry(object):
    def __init__(self, ecmp_id, egress_indices):
        pass

# Base class for asic l3 interface entry
class AsicL3InterfaceEntry(object):
    def __init__(self, intf_index, vlan, src_mac, mtu, vrf):
        pass

# Base class for asic l3 defip entry
class AsicL3DefipEntry(object):
    def __init__(self, ip_dest, egress_intf_index, multipath, lookup_class, vrf):
        pass

# Base class for asic IP network key
class AsicIPNetworkKey:
    def __init__(self, ip_dest, vrf):
        pass

# Base class for asic interface
class AsicInterface():
    def __init__(self, intf_str, admin_up, carrier):
        pass

# Base class for mac object
class MACAddress(object):
    validation_re = re.compile('(?:[0-9a-f]{2}\:){5}[0-9a-f]{2}')

    def __init__(self, mac):
        if isinstance(mac, int):
            mac_str = self.mac_int_to_mac_str(mac)
        else:
            mac_str = mac
        mac_str = str(mac_str).lower()
        m = self.validation_re.match(mac_str)
        if not m or not m.group() == mac_str:
            raise ValueError("Need MAC address in the format 'xx:xx:xx:xx:xx:xx'")
        self.mac_str = mac_str
