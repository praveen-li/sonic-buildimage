##-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
#
#       @ File:-       test_l2.py
#i      @ Description:-
#               Sample script to setup l2 forwarding using python and IFCS apis.
#               It does the following:
#               a. Creates a vlan
#               b. Adds 2 sysports to the vlan as members.
#               c. Creates an STP instance and sets the vlan in forwarding mode.
#               d. Creates a basic Layer 2 entry with this vlan.
#       @ Prerequisites:-
#               1. CLI was started with a correct inno config file.
#               2. Node create was successful.
#       @ Usage:-
#               From the CLI prompt, type console to take you to the python
#               interpreter mode.
#                       e.g. IVM:0>console
#               Once in the console, import this file.
#                       e.g. >>>from test_l2 import *
#               Call the function setup_l2()
#                       e.g. >>>setup_l2()
#               Exit the console(python interpreter mode) by typing exit().
#               This will take you back to the cli prompt. Once in the cli,
#               use the l2vni, sysport, l2_entry ifcs cli commands to make
#               sure the setup_l2() call successfully created desired l2
#               objects.
# --------------------------------------------------------------------------------

import os
import sys
from ctypes import *
from ifcs_ctypes import *

# List of devports that will be part of the l2 configuration.
devport_list = [2,3]
mac_addr_t = c_uint8 * 6

def _get_sysport_handle_from_devport(devport):
    '''
        Utility function that takes a devport
        and returns the handle to its corresponding
        sysport
    '''
    attr = ifcs_attr_t()
    count  = ctypes.c_uint32()

    attr.id = IFCS_DEVPORT_ATTR_SYSPORT
    rc = ifcs_devport_attr_get(0, devport, 1, pointer(attr),
                               pointer(count))
    if rc != IFCS_SUCCESS:
        print "Failed to get sysport for devport %d" % devport
        return

    return attr.value.handle

def setup_l2():
    '''
        Initial declarations
    '''
    sysport_list = [] # Empty list for sysport handles
    stp_handle = ifcs_handle_t() # STP handle
    l2vni_handle = ifcs_handle_t()
    attr_count = 1
    attr = (attr_count * ifcs_attr_t)()
    member_attr_count = 0
    member_attr = ifcs_attr_t()
    '''
        Obtain sysport handles for devports in devport list
    '''
    for port in devport_list:
        sysport_list.append(_get_sysport_handle_from_devport(port))

    '''
        Create the STP instance. The stp create api
        takes (in this order): node_id, pointer to a handle, attribute count
        and pointer to the attributes list
    '''
    rc = ifcs_stp_create(0, pointer(stp_handle), 0, pointer(attr))
    if rc != IFCS_SUCCESS:
        print "Failed to create STP instance: %d" % rc

    print "Successfully created STP instance"
    '''
        Second, let's create a l2vni.
        This api takes the following attributes.
        node_id, pointer to a handle, attributes count, pointer to a list of attributes
    '''
    for vni in devport_list:
        l2vni_handle.value = IFCS_HANDLE_L2VNI(vni)
        rc = ifcs_l2vni_create(0,
                               pointer(l2vni_handle),
                               0,
                               pointer(attr))
        if rc != IFCS_SUCCESS:
            print "Failed to create l2vni %d :" % vni

        print "Successfully created l2vni %d" % vni

        '''
            Add the stp instance to this l2vni
        '''
        attr[0].id = IFCS_L2VNI_ATTR_STP_INSTANCE
        attr[0].value.handle = stp_handle
        rc = ifcs_l2vni_attr_set(0,
                                 l2vni_handle,
                                 1,
                                 pointer(attr))
        if rc != IFCS_SUCCESS:
            print "Failed to add stp instance to l2vni: " + ifcs_status_to_string(rc)

    member_count = len(sysport_list)
    member_list = (ifcs_handle_t * member_count)()

    stp_attr_count = 1
    stp_attr = (stp_attr_count * ifcs_attr_t)()
    stp_attr[0].id = IFCS_STP_PORT_ATTR_STP_STATE
    stp_attr[0].value.u32 = IFCS_STP_PORT_STATE_FORWARDING

    for port in range(len(sysport_list)):
        member_list[port] = sysport_list[port]
        rc = ifcs_stp_port_attr_set(0,
                                    stp_handle,
                                    member_list[port],
                                    stp_attr_count,
                                    pointer(stp_attr))
        if rc != IFCS_SUCCESS:
            print "Failed to set stp port state to forwarding: " + ifcs_status_to_string(rc)
        print "Successfully set stp state to forwarding for sysport %s" % hex(IFCS_HANDLE_SYSPORT(port))

    '''
        Add the 2 sysports to this l2vni as members
    '''
    for vni in devport_list:
        l2vni_handle = IFCS_HANDLE_L2VNI(vni)
        rc = ifcs_l2vni_member_add(0,
                                   l2vni_handle,
                                   member_count,
                                   pointer(member_list),
                                   member_attr_count,
                                   pointer(member_attr))
        if rc != IFCS_SUCCESS:
            print "Failed to add members to l2vni rc: " + ifcs_status_to_string(rc)

    print "Successfully added sysports to l2vni as members"

    '''
        Setup the l2 entry for mac,l2vni based forwarding
    '''
    for port in devport_list:
        l2_entry = ifcs_l2_entry_key_t()
        ifcs_l2_entry_key_t_init(pointer(l2_entry))
        mac_addr = mac_addr_t(0,0,0,0,0,0xaa)
        l2vni_hdl = IFCS_HANDLE_L2VNI(port)

        ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
        ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                l2_entry.key.mac_l2vni)
        ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                mac_addr)
        ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                l2vni_hdl)

        #l2_entry.key_type = IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
        #l2_entry.key.mac_l2vni.mac_addr = mac_addr_t(0,0,0,0,0,0xaa)
        #l2_entry.key.mac_l2vni.l2vni = IFCS_HANDLE_L2VNI(port)

        attr_count = 2
        l2_entry_attr = (attr_count * ifcs_attr_t)()
        l2_entry_attr[0].id = IFCS_L2_ENTRY_ATTR_ENTRY_DEST
        l2_entry_attr[0].value.handle = IFCS_HANDLE_SYSPORT(port)
        l2_entry_attr[1].id = IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
        l2_entry_attr[1].value.u32 = IFCS_L2_ENTRY_TYPE_STATIC
        rc = ifcs_l2_entry_create(0,
                                  pointer(l2_entry),
                                  attr_count,
                                  pointer(l2_entry_attr))
        if rc != IFCS_SUCCESS:
            print "Failed to create l2 entry for l2vni %d" % IFCS_HANDLE_L2VNI(port)

    print "Successfully created l2_entry"

def main():
    setup_l2()


if __name__ == '__main__':
    setup_l2()
