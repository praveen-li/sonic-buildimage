#!/bin/bash

#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
export PYTHONPATH=${PYTHONPATH}:./
export PYTHONPATH=${PYTHONPATH}:./cmds
export PYTHONPATH=${PYTHONPATH}:./ifcs_cmds
export PYTHONPATH=${PYTHONPATH}:./scripts
export PYTHONPATH=${PYTHONPATH}:./utils/
export PYTHONPATH=${PYTHONPATH}:./pyctypes/
export PYTHONPATH=${PYTHONPATH}:../pyctypes/
export LD_LIBRARY_PATH=.:${LD_LIBRARY_PATH}:../lib/
export LD_LIBRARY_PATH=.:${LD_LIBRARY_PATH}:./

printhelp() {
    echo "Usage: $0 -g -p -c <config_file> "
    echo "       -g Start boardCLI under GDB (optional)"
    echo "       -p Start boardCLI under PDB (optional)"
    echo "       -c Inno config file"
    echo "       -b Python major version (default: 2)"
    echo "       -h Show this message and exit"
}

CONFIGFILE=""
ENV="switch"
GDB=0
PDB=0
CMD=""
PYVER=2

while getopts "gdhc:e:b:" opt; do
    case $opt in
        h)
            printhelp
            exit 1
            ;;
        g)
            GDB=1
            ;;
        d)
            PDB=1
            ;;
        c)
            CONFIGFILE=$OPTARG
            ;;
        e)
            ENV=$OPTARG
            ;;
        b)
            PYVER=$OPTARG
            ;;
    esac
done

if [ -z "$CONFIGFILE" ]; then
    echo "config file not set"
    printhelp
    exit 1
fi

if [ ! -f "$CONFIGFILE" ]; then
    echo "Incorrect config file passed"
    printhelp
    exit 1
fi

if [ -e ifcsshell.log ]; then
    echo "moving ifcsshell.log to ifcsshell.log.bkp"
    mv ifcsshell.log ifcsshell.log.bkp
fi

# User should export PATH and LD_LIBRARY_PATH to point to bin and lib, respectively
if [ $PYVER == 2 ]; then
    PYTHON=python2.7
elif [ $PYVER == 3 ]; then
    PYTHON=python3.7
fi

if [ $GDB == 1 ]; then
   CMD="gdb --args ${PYTHON} ifcsshell.py -e $ENV -c $CONFIGFILE"
elif [ $PDB == 1 ]; then
   CMD="${PYTHON} -m pdb ifcsshell.py -e $ENV -c $CONFIGFILE"
else
   CMD="${PYTHON} ifcsshell.py -e $ENV -c $CONFIGFILE"
fi

script -c "$CMD" ifcsshell.log
