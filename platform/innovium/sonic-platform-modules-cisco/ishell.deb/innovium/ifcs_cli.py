#-------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------

import cmd
import cli
import sys
import os
from cmdmgr import CmdMgr
from verbosity import *
from ctypes import *
from ifcs_ctypes import *

class IFCS_CLI(cli.CLI):
    def __init__(self, intro=''):
        cli.CLI.__init__(self)
        self.supported_env  = ['board', 'emulator', 'switch']
        self.intro          = intro
        self.node_id        = None
        self.cmdmgr         = CmdMgr()
        self.num_nodes      = 0
        self.remote_mode    = False
        self.server_mode    = False
        self.debug_mode     = 0
        self.privilege_mode = 0
        self.standalone     = False
        self.ifcs_ctypes    = sys.modules['ifcs_ctypes']
        """
            For every new environment we intend to run the cli on, add
            a name for the environment here if we wish import a module
            specific to that environment
        """
        self.rt_env         = ''
        """
            Board is used for internal board development environment
            emulator is used for internal emulator environment
            switch is used in external environments.
        """
        self.set_prompt()

    def set_prompt(self):
        if not self.remote_mode:
            if self.node_id is None:
                self.prompt = 'IVM>'
            else:
                self.prompt = 'IVM:' + str(self.node_id) + '>'
        else:
            if self.node_id is None:
                self.prompt = 'IVM-R>'
            else:
                self.prompt = 'IVM-R:' + str(self.node_id) + '>'

    def set_server_mode(self, flag):
        self.server_mode = flag

    def set_remote(self, flag):
        self.remote_mode = flag
        self.set_prompt()

    def set_standalone(self, flag):
        self.standalone = flag

    def set_remote_port(self, port):
        self.remote_port = port

    def set_node_id(self, node_id):
        if node_id is None:
            self.node_id = None
            return
        elif (node_id < 0 or node_id > 16):
            log_err("Invalid node id {0}".format(node_id))
            return
        else:
            self.node_id = node_id
            log_dbg(1, "Node {0} set successfully".format(node_id))
            return

    def set_rt_env(self, env):
        if env in self.supported_env:
            self.rt_env = env
            log_dbg(1, "Setting CLI runtime environment to " + env)
        else:
            log_err("Environment " + env + " not supported")
            raise LookupError

    def config(self, configfile):
        nodes = c_int(0)

        boot = IFCS_BOOT_COLD
        try:
            if int(os.environ['WBRESTART']) == 1:
                boot = IFCS_BOOT_WARM
                print "Starting with WB restart IFCS_WB_FILE="+ os.environ['IFCS_WB_FILE']
        except:
            pass

        rc = ifcs_init(
            configfile if configfile else 0,
            "cli_sh",
            boot,
            pointer(nodes))
        if (rc == IFCS_SUCCESS):
            log_dbg(1, 'ifcs_init success')
        else:
            rc = ifcs_status_to_string(rc).split('.')
            rc = rc[len(rc) - 1]
            log_err('ifcs_init fail - rc = ' + rc)
            return
        log_dbg(1, str(self.num_nodes) + " Innovium nodes detected")
        self.num_nodes = nodes.value

        if (ifcs_log_level_set(IFCS_LOG_LEVEL_DEBUG) != IFCS_SUCCESS):
            log_err('ifcs log level set fail')

    def init_cmds(self):

        if not self.remote_mode and not self.standalone:
            return

        import pencmd
        import node
        import config
        import diagtest
        import pcicmd
        import port
        import pktcmd
         
        import verbosity
        import reloadcmd
        import errorcmd
        import privilege_mode
        import l2learn

        import blkpencmd

        import testutil.bincopy
        import testutil.util
        import testutil.pci
        import testutil.mid
         
        import testutil.pkt
        import ifcscmd
        import debug
    
        import vendor_debug

 
        self.cmdmgr.add_cmd("verbosity", verbosity.Verbosity(self))
        self.node = node.Node(self)
        self.cmdmgr.add_cmd("node", self.node)
        self.cmdmgr.add_cmd("pen", pencmd.Pen(self))
        self.cmdmgr.add_cmd("config", config.Config(self))
        self.cmdmgr.add_cmd("diagtest", diagtest.Diagtest(self))
        self.cmdmgr.add_cmd("port", port.Port(self))
        self.cmdmgr.add_cmd("pci", pcicmd.Pci(self))
        self.cmdmgr.add_cmd("pkt", pktcmd.Pkt(self))
 
        self.cmdmgr.add_cmd("privilege", privilege_mode.Privilege_mode(self))
        self.cmdmgr.add_cmd("reload", reloadcmd.ReloadCmd(self))
        self.cmdmgr.add_cmd("l2learn", l2learn.L2learn(self))

        self.cmdmgr.add_cmd("blkpen", blkpencmd.Blkpen(self))

        self.cmdmgr.add_cmd("errors", errorcmd.Errors(self))

        # Import environment specific modules and commands
        if self.rt_env == 'switch' or self.rt_env == 'emulator' or self.rt_env == 'board':
            self.cmdmgr.add_cmd("ifcs", ifcscmd.Ifcs(self))
            self.cmdmgr.add_cmd("debug", debug.Debug(self))
 
            self.cmdmgr.add_cmd("debugparser", vendor_debug.DebugParser(self))

        if self.rt_env == 'board':
            try:
                import board1
                self.cmdmgr.add_cmd("board1", board1.Board1(self))
            except BaseException:
                pass
