#!/bin/bash

#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2018
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
export PYTHONPATH=${PYTHONPATH}:./
export PYTHONPATH=${PYTHONPATH}:./cmds
export PYTHONPATH=${PYTHONPATH}:./scripts
export PYTHONPATH=${PYTHONPATH}:./utils/
export PYTHONPATH=${PYTHONPATH}:./pyctypes/
export PYTHONPATH=${PYTHONPATH}:../pyctypes/
export PYTHONPATH=${PYTHONPATH}:./testutil
export LD_LIBRARY_PATH=.:${LD_LIBRARY_PATH}:../lib/
export LD_LIBRARY_PATH=.:${LD_LIBRARY_PATH}:./

printhelp() {
    echo "Usage: $0 -c config_file [-g] [-p] [-b version]"
    echo "       -g Start inno_cli under GDB (optional)"
    echo "       -p Start inno_cli under PDB (optional)"
    echo "       -c IFCS config file (required)"
    echo "       -b Python major version (value: 2 or 3, default: 2)"
    echo "       -h Show this message and exit"
}

CONFIGFILE=""
ENV="switch"
GDB=0
PDB=0
CMD=""
PYVER=2

while getopts "gphc:e:b:" opt; do
    case $opt in
        h)
            printhelp
            exit 1
            ;;
        g)
            GDB=1
            ;;
        p)
            PDB=1
            ;;
        c)
            CONFIGFILE=$OPTARG
            ;;
        e)
            ENV=$OPTARG
            ;;
        b)
            PYVER=$OPTARG
            ;;
        *)
            printhelp
            exit 1
            ;;
    esac
done

shift $(($OPTIND - 1))
REM_ARGS="$@"
if [ ! -z $REM_ARGS ]; then
    echo "Invalid extra argument : $REM_ARGS"
    printhelp
    exit 1
fi

if [ -z "$CONFIGFILE" ]; then
    echo "Config file not set"
    printhelp
    exit 1
fi

if [ ! -f "$CONFIGFILE" ]; then
    echo "Config file does not exist"
    printhelp
    exit 1
fi

if [ -e ifcsshell.log ]; then
    echo "moving ifcsshell.log to ifcsshell.log.bkp"
    mv ifcsshell.log ifcsshell.log.bkp
fi

# User should export PATH and LD_LIBRARY_PATH to point to bin and lib, respectively
if [ $PYVER == 2 ]; then
    PYTHON=python2.7
elif [ $PYVER == 3 ]; then
    PYTHON=python3.7
else
    echo "Invalid value for -b option"
    printhelp
    exit 1
fi

PDB_OPT=""
if [ $PDB == 1 ]; then
   PDB_OPT="-m pdb"
fi
if [ $GDB == 1 ]; then
   CMD="gdb --args ${PYTHON} ${PDB_OPT} ifcsshell.py -e $ENV -c $CONFIGFILE"
elif [ $PDB == 1 ]; then
   CMD="${PYTHON} -m pdb ifcsshell.py -e $ENV -c $CONFIGFILE"
else
   CMD="${PYTHON} ifcsshell.py -e $ENV -c $CONFIGFILE"
fi

script -c "$CMD" ifcsshell.log
