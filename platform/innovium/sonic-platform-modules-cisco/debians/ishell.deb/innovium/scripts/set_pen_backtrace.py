#!/usr/bin/python

import os
import sys
import time
import argparse
from ctypes import *
from ifcsshell import *
from ifcs_cli import *
from verbosity import log
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('-n', '--node_id', type=int, default=0,
                        help='Node id')
    parser.add_argument('-l', '--backtrace_level', type=int, default=0,
                        help='Set pen backtrace log level')
    args = parser.parse_args(argv.split())

    nodeid = ifcs_ctypes.ifcs_node_id_t()
    nodeid = args.node_id
    level = ifcs_ctypes.im_pen_backtrace_level_t()
    if args.backtrace_level == 0:
         level.value = ifcs_ctypes.IM_PEN_BACKTRACE_LEVEL_OFF
    elif args.backtrace_level == 1:
         level.value = ifcs_ctypes.IM_PEN_BACKTRACE_LEVEL_1
    elif args.backtrace_level == 2:
         level.value = ifcs_ctypes.IM_PEN_BACKTRACE_LEVEL_2
    elif args.backtrace_level == 3:
         level.value = ifcs_ctypes.IM_PEN_BACKTRACE_LEVEL_3
    elif args.backtrace_level == 4:
         level.value = ifcs_ctypes.IM_PEN_BACKTRACE_LEVEL_4

    rc = ifcs_ctypes.im_log_pen_backtrace_level_set(nodeid, level)
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Error setting pen backtrace logging rc: {0}".format(
            convert_error_code_to_string(rc)))
    else:
        log("Success setting pen backtrace logging to level {0}".format(level.value))

    return

if __name__ == "__main__":
    main()
