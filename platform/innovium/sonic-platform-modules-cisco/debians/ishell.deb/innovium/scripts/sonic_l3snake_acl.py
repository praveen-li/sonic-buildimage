##-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------
#
#@ File:-       sonic_l3snake_acl.py
#@ Description:-
#               ACL config to edit destination ipv4 address of packet
#               It does the following:
#               a. Create ACLMatchProfile to match destination_ipv4_address and egress_l2_interface
#               b. Create AclActionProfile of packet edit
#               c. Create AclTable
#               d. On each sysport - p_x+1
#                  create AclMatch to match destination_ip_x and egress sysport p_x+1
#                  create AclPacketEdit to edit destination_ip_x to destination_ip_x+1
#                  create AclAction with AclPacketEdit
#                  create Ace with AclMatch and AclAction
#               e. create Acl
#               f. add Acl to AclTable
#               g. add Aces to Acl

import os
import sys
from ctypes import *
from ifcs_ctypes import *
from utils.compat_util import *
from verbosity import log

devport_list = compat_listrange(1,33)
num_ports = len(devport_list)
nodeId = 0
start_ip = '10.100.1.1'

def _get_sysport_handle_from_devport(devport):
    '''
        Utility function that takes a devport
        and returns the handle to its corresponding
        sysport
    '''
    attr = ifcs_attr_t()
    count  = ctypes.c_uint32()

    attr.id = IFCS_DEVPORT_ATTR_SYSPORT
    rc = ifcs_devport_attr_get(0, devport, 1, pointer(attr),
                               pointer(count))
    if rc != IFCS_SUCCESS:
        log("Failed to get sysport for devport %d" % devport)
        return

    return attr.value.handle

def incr_ip_addr(ip):
    '''
        increment third octect of ip address by 1
    '''
    ip_list = list(map(int,ip.split('.')))
    if ip_list[2]+1 == 256:
        ip_list[2] = 0
        ip_list[1] += 1
    else:
       ip_list[2] += 1
    return '.'.join(list(map(str,ip_list)))

def config_packet_edit_acl():
    '''
        Obtain sysport and devport handle list
    '''
    sp_list = [] # sysport handle list
    for port in devport_list:
        sp=_get_sysport_handle_from_devport(port)
        sp_list.append(sp)

    '''
        Create AclMatchProfile
    '''
    matchProfile = ifcs_handle_t()
    attrList = (ifcs_attr_t * 8)()
    for index in range(8):
        rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
        assert rc == IFCS_SUCCESS
    index = 0

    match_types = ifcs_u32_list_t()
    match_types.count = 2
    match_types.arr = (c_uint32 * match_types.count)()
    match_types.arr[0] = IFCS_ACL_MATCH_TYPE_DESTINATION_IPV4_ADDRESS
    match_types.arr[1] = IFCS_ACL_MATCH_TYPE_EGRESS_L2_INTERFACE
    attrList[index].id = IFCS_ACL_MATCH_PROFILE_ATTR_MATCH_TYPES
    attrList[index].value.u32_list = match_types
    index += 1

    direction = IFCS_ACL_DIRECTION_EGRESS
    attrList[index].id = IFCS_ACL_MATCH_PROFILE_ATTR_DIRECTION
    attrList[index].value.u32 = direction
    index += 1

    max_width = IFCS_ACL_MATCH_MAX_WIDTH_80_BITS
    attrList[index].id = IFCS_ACL_MATCH_PROFILE_ATTR_MAX_WIDTH
    attrList[index].value.u32 = max_width
    index += 1

    attrCount = index
    rc = IFCS_STATUS_REASON(
        ifcs_acl_match_profile_create(
            nodeId, pointer(matchProfile), attrCount, compat_pointer(attrList, ifcs_attr_t)))

    if rc != IFCS_SUCCESS:
        log("Failed to create ACL Match Profile: %d"%rc)
    else:
        log("Successfully created ACL Match Profile")

    #create AclActionProfile
    actionProfile = ifcs_handle_t()
    attrList = (ifcs_attr_t * 3)()
    for index in range(3):
        rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
        assert rc == IFCS_SUCCESS
    index = 0

    action_types = ifcs_u32_list_t()
    action_types.count = 1
    action_types.arr = (c_uint32 * action_types.count)()
    action_types.arr[0] = IFCS_ACL_ACTION_TYPE_PACKET_EDIT
    attrList[index].id = IFCS_ACL_ACTION_PROFILE_ATTR_ACTION_TYPES
    attrList[index].value.u32_list = action_types
    index += 1

    direction = IFCS_ACL_DIRECTION_EGRESS
    attrList[index].id = IFCS_ACL_ACTION_PROFILE_ATTR_DIRECTION
    attrList[index].value.u32 = direction
    index += 1

    attrCount = index
    rc = IFCS_STATUS_REASON(
        ifcs_acl_action_profile_create(
            nodeId, pointer(actionProfile), attrCount, compat_pointer(attrList, ifcs_attr_t)))

    if rc != IFCS_SUCCESS:
        log("Failed to create ACL Action Profile: %d"%rc)
    else:
        log("Successfully created ACL Action Profile")

    #create AclTable
    aclTable = ifcs_handle_t()
    attrList = (ifcs_attr_t * 13)()
    for index in range(13):
        rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
        assert rc == IFCS_SUCCESS
    index = 0

    attrList[index].id = IFCS_ACL_TABLE_ATTR_MATCH_PROFILE
    attrList[index].value.handle = matchProfile
    index += 1

    attrList[index].id = IFCS_ACL_TABLE_ATTR_ACTION_PROFILE
    attrList[index].value.handle = actionProfile
    index += 1

    direction = IFCS_ACL_DIRECTION_EGRESS
    attrList[index].id = IFCS_ACL_TABLE_ATTR_DIRECTION
    attrList[index].value.u32 = direction
    index += 1

    scope = IFCS_ACL_SCOPE_NODE

    #scope should be INNO_BLOCK on a Multi_IB device
    #scope = IFCS_ACL_SCOPE_PER_IB

    attrList[index].id = IFCS_ACL_TABLE_ATTR_SCOPE
    attrList[index].value.u32 = scope
    index += 1

    priority = 1
    attrList[index].id = IFCS_ACL_TABLE_ATTR_PRIORITY
    attrList[index].value.u32 = priority
    index += 1

    size = 256
    attrList[index].id = IFCS_ACL_TABLE_ATTR_SIZE
    attrList[index].value.u32 = size
    index += 1

    attrCount = index
    rc = IFCS_STATUS_REASON(
        ifcs_acl_table_create(
            nodeId,
            pointer(aclTable),
            attrCount,
            compat_pointer(attrList, ifcs_attr_t)))

    if rc != IFCS_SUCCESS:
        log("Failed to create ACL Table:%d"%rc)
    else:
        log("Successfully created ACL Table")


    #On each sysport (staring from second port):
        #create AclMatch to match destination_ip_addr and egress_l2_interface
        #create AclPacketEdit with incremented destination ipv4 address
        #create AclAction with AclPacketEdit
        #create Ace with AclMatch and AclAction
    aceList = []
    ip_addr = start_ip
    edited_ip_addr = incr_ip_addr(ip_addr)
    for sp in sp_list[1:]:
        dp = devport_list[sp_list.index(sp)]
        #create AclMatch1 to match destination_ipv4
        aclMatch1 = ifcs_handle_t()
        attrList = (ifcs_attr_t * 6)()
        for index in range(6):
            rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
            assert rc == IFCS_SUCCESS
        index = 0

        match_type = IFCS_ACL_MATCH_TYPE_DESTINATION_IPV4_ADDRESS
        attrList[index].id = IFCS_ACL_MATCH_ATTR_TYPE
        attrList[index].value.u32 = match_type
        index += 1

        value = ifcs_u8_list_t()
        value.count = 4
        value.arr = (c_uint8 * 4)()
        idx = 0
        for element in ip_addr.split("."):
             value.arr[idx] = int(element)
             idx += 1
        attrList[index].id = IFCS_ACL_MATCH_ATTR_VALUE
        attrList[index].value.u8_list = value
        index += 1

        attrList[index].id = IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
        attrList[index].value.handle = matchProfile
        index += 1

        attrCount = index
        rc = IFCS_STATUS_REASON(
            ifcs_acl_match_create(
                nodeId,
                pointer(aclMatch1),
                attrCount,
                compat_pointer(attrList, ifcs_attr_t)))

        if rc != IFCS_SUCCESS:
            log("failed to create AclMatch for port %d: %d"%(dp, rc))
        else:
            log("Successfully created AclMatch for port %d"%(dp))

        #create AclMatch2 to match egress_l2_interface
        aclMatch2 = ifcs_handle_t()
        attrList = (ifcs_attr_t * 6)()
        for index in range(6):
            rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
            assert rc == IFCS_SUCCESS
        index = 0

        match_type = IFCS_ACL_MATCH_TYPE_EGRESS_L2_INTERFACE
        attrList[index].id = IFCS_ACL_MATCH_ATTR_TYPE
        attrList[index].value.u32 = match_type
        index += 1

        attrList[index].id = IFCS_ACL_MATCH_ATTR_OBJECT
        attrList[index].value.handle = sp
        index += 1

        attrList[index].id = IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
        attrList[index].value.handle = matchProfile
        index += 1

        attrCount = index
        rc = IFCS_STATUS_REASON(
            ifcs_acl_match_create(
                nodeId,
                pointer(aclMatch2),
                attrCount,
                compat_pointer(attrList, ifcs_attr_t)))

        #create packet edit
        aclPacketEdit = ifcs_handle_t()
        attrList = (ifcs_attr_t * 3)()
        for index in range(3):
            rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
            assert rc == IFCS_SUCCESS
        index = 0

        type = IFCS_ACL_PACKET_EDIT_TYPE_SET_DESTINATION_IPV4
        attrList[index].id = IFCS_ACL_PACKET_EDIT_ATTR_TYPE
        attrList[index].value.u32 = type
        index += 1

        value = ifcs_u8_list_t()
        value.count = 4
        value.arr = (c_uint8 * 4)()
        ip_index = 0
        ip = incr_ip_addr
        for element in edited_ip_addr.split("."):
            value.arr[ip_index] = int(element)
            ip_index += 1
        attrList[index].id = IFCS_ACL_PACKET_EDIT_ATTR_VALUE
        attrList[index].value.u8_list = value
        index += 1

        attrCount = index
        rc = IFCS_STATUS_REASON(
            ifcs_acl_packet_edit_create(
                nodeId,
                pointer(aclPacketEdit),
                attrCount,
                compat_pointer(attrList, ifcs_attr_t)))

        if rc != IFCS_SUCCESS:
            log("failed to create AclPacketEdit for port %d: %d"%(dp, rc))
        else:
            log("Successfully created AclPacketEdit for port %d"%(dp))

        #create AclAction
        aclAction = ifcs_handle_t()
        attrList = (ifcs_attr_t * 5)()
        for index in range(5):
            rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
            assert rc == IFCS_SUCCESS
        index = 0

        action_type = IFCS_ACL_ACTION_TYPE_PACKET_EDIT
        attrList[index].id = IFCS_ACL_ACTION_ATTR_TYPE
        attrList[index].value.u32 = action_type
        index += 1

        attrList[index].id = IFCS_ACL_ACTION_ATTR_ACTION_PROFILE
        attrList[index].value.handle = actionProfile
        index += 1

        attrList[index].id = IFCS_ACL_ACTION_ATTR_OBJECT
        attrList[index].value.handle = aclPacketEdit
        index += 1

        attrCount = index
        rc = IFCS_STATUS_REASON(
            ifcs_acl_action_create(
                nodeId,
                pointer(aclAction),
                attrCount,
                compat_pointer(attrList, ifcs_attr_t)))

        if rc != IFCS_SUCCESS:
            log("failed to create AclAction for port %d: %d"%(dp, rc))
        else:
            log("Successfully created AclAction for port %d"%(dp))

        #create Ace with AclMatch and AclAction
        ace = ifcs_handle_t()
        attrList = (ifcs_attr_t * 6)()
        for index in range(6):
            rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
            assert rc == IFCS_SUCCESS
        index = 0

        priority = 1
        attrList[index].id = IFCS_ACE_ATTR_PRIORITY
        attrList[index].value.u32 = priority
        index += 1

        match_set = [aclMatch1, aclMatch2]
        attrList[index].id = IFCS_ACE_ATTR_MATCH_SET
        matchSetHandleList = ifcs_handle_list_t()
        matchSetHandleList.count = len(match_set)
        matchSetHandleList.list = (
            ifcs_handle_t * matchSetHandleList.count)()
        tindex = 0
        for element in match_set:
            matchSetHandleList.list[tindex] = element
            tindex += 1
        attrList[index].value.handle_list = matchSetHandleList
        index += 1

        action_set = [aclAction]
        attrList[index].id = IFCS_ACE_ATTR_ACTION_SET
        actionSetHandleList = ifcs_handle_list_t()
        actionSetHandleList.count = len(action_set)
        actionSetHandleList.list = (
            ifcs_handle_t * actionSetHandleList.count)()
        tindex = 0
        for element in action_set:
            actionSetHandleList.list[tindex] = element
            tindex += 1
        attrList[index].value.handle_list = actionSetHandleList
        index += 1

        attrCount = index
        rc = IFCS_STATUS_REASON(
            ifcs_ace_create(
                nodeId,
                pointer(ace),
                attrCount,
                compat_pointer(attrList, ifcs_attr_t)))

        if rc != IFCS_SUCCESS:
            log("failed to create ACE for port %d: %d"%(dp, rc))
        else:
            log("Successfully created ACE for port %d"%(dp))
            aceList.append(ace)

        ip_addr = edited_ip_addr
        edited_ip_addr = incr_ip_addr(ip_addr)

    #create Acl
    acl = ifcs_handle_t()
    attrList = (ifcs_attr_t * 6)()
    for index in range(6):
        rc = ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_attr_t, index))
        assert rc == IFCS_SUCCESS

    index = 0
    attrList[index].id = IFCS_ACL_ATTR_SCOPE
    attrList[index].value.u32 = scope
    index += 1
    attrCount = index

    rc = IFCS_STATUS_REASON(
        ifcs_acl_create(
            nodeId,
            pointer(acl),
            attrCount,
            compat_pointer(attrList, ifcs_attr_t)))

    if rc != IFCS_SUCCESS:
        log("failed to create ACL for port %d: %d"%(dp,rc))
    else:
        log("Successfully created ACL for port %d"%dp)

    #add Acl to AclTable
    aclhandleList = (ifcs_handle_t * 1)()
    aclhandleList[0] = acl
    memberCount = 1
    attrCount = 0
    attrList = None

    rc = IFCS_STATUS_REASON(
        ifcs_acl_table_acl_add(
            nodeId,
            aclTable,
            memberCount,
            compat_pointer(aclhandleList, ifcs_handle_t),
            attrCount,
            compat_pointer(attrList, ifcs_attr_t)))
    if rc != IFCS_SUCCESS:
        log("failed to add ACL to ACLTable: %d"%rc)
    else:
        log("Successfully added ACL to ACLTable")

    #add Aces to Acl
    acehandleList = (ifcs_handle_t * len(aceList))()
    for idx in compat_xrange(len(aceList)):
        acehandleList[idx] = aceList[idx]
    rc = IFCS_STATUS_REASON(
        ifcs_acl_ace_add(
            nodeId,
            acl,
            len(aceList),
            compat_pointer(acehandleList, ifcs_handle_t),
            0,
            None))
    if rc != IFCS_SUCCESS:
         log("failed to add ACEs to ACL:  %d"%rc)
    else:
         log("Successfully added ACEs to ACL")

def main():
    config_packet_edit_acl()
