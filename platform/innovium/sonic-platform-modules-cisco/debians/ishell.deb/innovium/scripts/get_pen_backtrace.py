#!/usr/bin/python

import os
import sys
import time
import argparse
from ctypes import *
from ifcsshell import *
from ifcs_cli import *
from verbosity import log
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('-n', '--node_id', type=int, default=0,
                        help='Node id')
    args = parser.parse_args(argv.split())

    nodeid = ifcs_ctypes.ifcs_node_id_t()
    nodeid = args.node_id
    level = ifcs_ctypes.im_pen_backtrace_level_t()

    rc = ifcs_ctypes.im_log_pen_backtrace_level_get(nodeid, compat_pointer(level, ifcs_ctypes.im_pen_backtrace_level_t))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log("Error getting pen backtrace logging rc: {0}".format(
            convert_error_code_to_string(rc)))
    else:
        log("Pen backtrace logging level = {0}".format(level.value))

    return

if __name__ == "__main__":
    main()
