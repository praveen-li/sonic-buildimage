/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2016
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */
#ifndef __ISAI_II_NMGR_H__
#define __ISAI_II_NMGR_H__

/**
 * @file isai_ii_mgr.h
 * @brief Innovium Internal Node Manager header file
 */

#include <pthread.h>

#include "isai_im_nmgr.h"

//#include "common/im_common.h"


#include "common/isai_im_modlockdef.h"

/* NMGR Node Control Structure */
typedef struct isai_ii_nmgr {
    isai_ii_mod_state_t                          init_state;                      ///< Node init/deinit state
    ifcs_node_id_t      node_id;                                             ///< Node Identifier
    isai_ii_modulevec_t *mod_vec[ISAI_II_NUM_MOD_LOCKS];                     ///< Mod vec sorted by prio

    pthread_mutex_t     module_locks[ISAI_II_NUM_MOD_LOCKS];                 ///< Normal module locks
    isai_ii_modlock_t   mod_lock[ISAI_II_NUM_MOD_LOCKS];                     ///< Normal lock bitmap

    uint32_t            mod_lock_count;                                      ///< Number of mod locks active */
} isai_ii_nmgr_t;


#endif /* __ISAI_II_NMGR_H__ */
