/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_fdb.h
 * @brief ISAI IM Include file for FDB module
 */


#ifndef __IFCS_SAI_FDB_H__
#define __IFCS_SAI_FDB_H__


#define ISAI_MODULE_LOCK_FDB    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_bridge.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_nexthop.h"
#include "ifcs_sai_neighbor.h"
#endif /* __IFCS_SAI_FDB_H__ */
