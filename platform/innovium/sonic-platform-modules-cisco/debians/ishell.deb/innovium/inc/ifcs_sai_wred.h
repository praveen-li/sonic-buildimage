/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_wred.h
 * @brief ISAI IM Include file for WRED module
 */


#ifndef __IFCS_SAI_WRED_H__
#define __IFCS_SAI_WRED_H__


#define ISAI_MODULE_LOCK_WRED    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_qos_common.h"
#include "ifcs_sai_acl.h"
#include "ifcs_sai_buffer.h"
#include "ifcs_sai_switch.h"
#endif /* __IFCS_SAI_WRED_H__ */
