/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2016
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file isai_im_modlockdef.h
 * @brief Module lock defines
 *
 */

#ifndef __ISAI_MODLOCKDEF_H__
#define __ISAI_MODLOCKDEF_H__

#include <stdint.h>

/*
 * Lock priorities - order matters for efficiency.  Routines should
 * generally avoid calling routines with higher lock priorities.
 * Lower number indicates lower priority.
 */

typedef enum isai_ii_mod_prio_e {
    ISAI_II_MOD_LOCK_PRIO_SWITCH          = 0,
    ISAI_II_MOD_LOCK_PRIO_QOS_COMMON      = 1,
    ISAI_II_MOD_LOCK_PRIO_BUFFER          = 2,
    ISAI_II_MOD_LOCK_PRIO_PORT            = 3,
    ISAI_II_MOD_LOCK_PRIO_QOSMAP          = 4,
    ISAI_II_MOD_LOCK_PRIO_HASH            = 5,
    ISAI_II_MOD_LOCK_PRIO_HOSTIF          = 6,
    ISAI_II_MOD_LOCK_PRIO_ISOLATION_GROUP = 7,
    ISAI_II_MOD_LOCK_PRIO_L2MC_GROUP      = 8,
    ISAI_II_MOD_LOCK_PRIO_LAG             = 9,
    ISAI_II_MOD_LOCK_PRIO_MIRROR          = 10,
    ISAI_II_MOD_LOCK_PRIO_NEIGHBOR        = 11,
    ISAI_II_MOD_LOCK_PRIO_NEXTHOP         = 12,
    ISAI_II_MOD_LOCK_PRIO_NEXTHOPGROUP    = 13,
    ISAI_II_MOD_LOCK_PRIO_POLICER         = 14,
    ISAI_II_MOD_LOCK_PRIO_DEBUG_COUNTER   = 15,
    ISAI_II_MOD_LOCK_PRIO_FDB             = 16,
    ISAI_II_MOD_LOCK_PRIO_QUEUE           = 17,
    ISAI_II_MOD_LOCK_PRIO_WRED            = 18,
    ISAI_II_MOD_LOCK_PRIO_ROUTERINTF      = 19,
    ISAI_II_MOD_LOCK_PRIO_ROUTER          = 20,
    ISAI_II_MOD_LOCK_PRIO_SAMPLEPACKET    = 21,
    ISAI_II_MOD_LOCK_PRIO_SCHEDULER       = 22,
    ISAI_II_MOD_LOCK_PRIO_SCHEDULER_GROUP = 23,
    ISAI_II_MOD_LOCK_PRIO_STP             = 24,
    ISAI_II_MOD_LOCK_PRIO_ACL             = 25,
    ISAI_II_MOD_LOCK_PRIO_TUNNEL          = 26,
    ISAI_II_MOD_LOCK_PRIO_VLAN            = 27,
    ISAI_II_MOD_LOCK_PRIO_BRIDGE          = 28,
    ISAI_II_MOD_LOCK_PRIO_ROUTE           = 29,
    ISAI_II_MOD_LOCK_PRIO_UDF             = 30,
    ISAI_II_NUM_MOD_LOCKS                 = 31,
} isai_ii_mod_prio_t;

typedef uint64_t isai_ii_modlock_t;

#endif /* __ISAI_MODLOCKDEF_H__ */
