/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_neighbor.h
 * @brief ISAI IM Include file for NEIGHBOR module
 */


#ifndef __IFCS_SAI_NEIGHBOR_H__
#define __IFCS_SAI_NEIGHBOR_H__


#define ISAI_MODULE_LOCK_NEIGHBOR    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_vlan.h"
#include "ifcs_sai_routerintf.h"
#include "ifcs_sai_nexthop.h"
#endif /* __IFCS_SAI_NEIGHBOR_H__ */
