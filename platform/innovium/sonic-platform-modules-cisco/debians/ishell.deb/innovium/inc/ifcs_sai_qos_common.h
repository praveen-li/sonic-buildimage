/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_qos_common.h
 * @brief ISAI IM Include file for QOS_COMMON module
 */


#ifndef __IFCS_SAI_QOS_COMMON_H__
#define __IFCS_SAI_QOS_COMMON_H__


#define ISAI_MODULE_LOCK_QOS_COMMON    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_buffer.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_queue.h"
#include "ifcs_sai_scheduler.h"
#include "ifcs_sai_wred.h"
#include "ifcs_sai_policer.h"
#endif /* __IFCS_SAI_QOS_COMMON_H__ */
