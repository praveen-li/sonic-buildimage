/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_port.h
 * @brief ISAI IM Include file for PORT module
 */


#ifndef __IFCS_SAI_PORT_H__
#define __IFCS_SAI_PORT_H__


#define ISAI_MODULE_LOCK_PORT    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_buffer.h"
#include "ifcs_sai_queue.h"
#include "ifcs_sai_qosmap.h"
#include "ifcs_sai_samplepacket.h"
#include "ifcs_sai_qos_common.h"
#include "ifcs_sai_isolation_group.h"
#include "ifcs_sai_scheduler_group.h"
#include "ifcs_sai_wred.h"
#include "ifcs_sai_mirror.h"
#include "ifcs_sai_policer.h"
#include "ifcs_sai_hostif.h"
#include "ifcs_sai_debug_counter.h"
#endif /* __IFCS_SAI_PORT_H__ */
