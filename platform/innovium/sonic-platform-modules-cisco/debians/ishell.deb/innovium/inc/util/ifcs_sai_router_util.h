/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_router_util.h
 * @brief ISAI Util Include file for ROUTER module
 */


#ifndef __IFCS_SAI_ROUTER_UTIL_H__
#define __IFCS_SAI_ROUTER_UTIL_H__

#include "util/ifcs_sai_router_util_dep.h"

/*
 * @brief Translates VR SAI object ID to L3VNI IFCS handle
 *
 * @param [out] ifcs_handle_p - Pointer to IFCS handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);


/*
 * @brief Translates L3VNI IFCS handle to SAI object ID
 *
 * @param [in]  ifcs_handle - IFCS handle
 * @param [out] object_id_p - Pointer to SAI object ID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_itos_xlate_oid(
    sai_object_id_t switch_oid,
    ifcs_handle_t   ifcs_handle,
    sai_object_id_t *object_id_p);


/**
 * @brief: Create virtual router
 *
 * @param [in] virtual_router_object_id_p    - Pointer to Router object
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                    - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */                               
extern sai_status_t
isai_im_virtual_router_create(sai_object_id_t       *virtual_router_object_id_p,
                              sai_object_id_t       switch_id,
                              uint32_t              attr_count,
                              const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove virtual router
 *                           
 * @param [in] virtual_router_object_id  - Router object id
 *
 * @return sai_status_t
 */
extern sai_status_t
isai_im_virtual_router_remove(
                  sai_object_id_t virtual_router_object_id);

#endif /* __IFCS_SAI_ROUTER_UTIL_H__ */
