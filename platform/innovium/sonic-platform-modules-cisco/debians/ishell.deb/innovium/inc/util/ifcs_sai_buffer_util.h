/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_buffer_util.h
 * @brief ISAI Util Include file for BUFFER module
 */


#ifndef __IFCS_SAI_BUFFER_UTIL_H__
#define __IFCS_SAI_BUFFER_UTIL_H__

#include "util/ifcs_sai_buffer_util_dep.h"

sai_status_t
isai_im_buffer_remove_ingress_priority_group(
    sai_object_id_t ingress_priority_group_object_id);

sai_status_t
isai_im_buffer_ingress_priority_group_default_attr_fill(
    isai_shim_qos_info_t *obj_p,
    sai_object_id_t      id);

sai_status_t
isai_im_buffer_profile_attr_stoi_queue(
    sai_object_id_t       buffer_profile,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp,
    bool                  is_create,
    bool                  *create_only_present,
    bool                  is_zero_buffer_profile,
    bool                  is_lossless);

sai_status_t
isai_im_buffer_profile_attr_stoi_ipg_bam(
    sai_object_id_t       buffer_profile,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp,
    sai_object_id_t       port_oid,
    bool                  is_create,
    bool                  *create_only_present,
    bool                  is_zero_buffer_profile);

sai_status_t
isai_im_buffer_profile_attr_stoi_ipg_ipps(
    sai_object_id_t       buffer_profile,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp,
    sai_object_id_t       port_oid,
    bool                  is_create,
    bool                  *create_only_present,
    bool                  is_zero_buffer_profile);

sai_status_t
isai_im_buffer_pool_get_pool_direction(sai_object_id_t        pool_oid,
                                       sai_buffer_pool_type_t *direction);

sai_status_t
isai_im_buffer_profile_attr_ipg_verify(
    sai_object_id_t       buffer_profile,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    bool                  is_create);

sai_status_t
isai_im_buffer_profile_attr_to_queue_verify(
    sai_object_id_t       buffer_profile,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    bool                  is_create);

sai_status_t
isai_im_buffer_port_stats_out_dropped_get(sai_object_id_t port_oid,
                                           uint64_t        *port_counter);

sai_status_t
isai_im_buffer_port_stats_out_dropped_clear(sai_object_id_t port_oid);

sai_status_t
isai_im_buffer_port_stats_in_dropped_get(sai_object_id_t port_oid,
                                          uint64_t        *port_counter);

sai_status_t
isai_im_buffer_port_stats_in_dropped_clear(sai_object_id_t port_oid);

sai_status_t
isai_im_buffer_ifcs_recirc_or_aux_port_setup(sai_object_id_t     switch_id,
                                             ifcs_devport_t      devport,
                                             switch_queue_type_t queue_type);

sai_status_t
isai_im_buffer_ifcs_recirc_or_aux_port_cleanup(sai_object_id_t switch_id,
                                               ifcs_devport_t  devport);

sai_status_t
isai_im_buffer_datapath_fp_cleanup(sai_object_id_t switch_id,
                                   sai_object_id_t port_oid);

sai_status_t
isai_im_buffer_datapath_cpu_port_cleanup(sai_object_id_t switch_id,
                                         sai_object_id_t port_oid);

sai_status_t
isai_im_buffer_datapath_cg_queue_cleanup(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_datapath_cleanup_aux_ports(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_datapath_cleanup_recirc_ports(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_datapath_buffer_partition_cleanup(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_datapath_tc_cleanup(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_is_ipg_queue_ready_on_port(sai_object_id_t port_oid,
                                          bool            *is_ready);

sai_status_t
isai_im_buffer_ipps_cm_create(sai_object_id_t switch_id,
                              sai_object_id_t port_oid);

sai_status_t
isai_im_buffer_dtm_queue_create(sai_object_id_t switch_id,
                                sai_object_id_t port_oid);

sai_status_t
isai_im_buffer_datapath_cpu_queue_create(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_datapath_cg_queue_create(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_datapath_setup_recirc_ports(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_datapath_setup_aux_ports(sai_object_id_t switch_id);

sai_status_t
isai_im_buffer_get_bam_buffer_partition_ll_inflight_size(ifcs_node_id_t node_id,
                                                         uint32_t       *ll_inflight_size_bytes_p);

sai_status_t
isai_im_buffer_partition_get_pool_size(sai_object_id_t buffer_pool_oid,
                                       uint32_t        *pool_size_p);

sai_status_t
isai_im_buffer_partition_get_xoff_size(sai_object_id_t buffer_pool_oid,
                                       uint32_t        *xoff_size_p);

sai_status_t
isai_im_buffer_is_lossy_or_loseless_info_from_hw(
    sai_object_id_t ipg_queue_bp_oid,
    bool            *is_lossless);

sai_status_t
isai_im_buffer_ifcs_sai_datapath_globals_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_buffer_is_ipg_or_queue_or_bprof_lossy_or_loseless(
    sai_object_id_t ipg_or_queue_oid,
    bool            *is_lossless);

sai_status_t
isai_im_buffer_ifcs_sai_shim_datapath_init(ifcs_node_id_t               node_id,
                                           ifcs_handle_t                sysport_hdl,
                                           isai_shim_qosmap_type_t      qm_type,
                                           isai_shim_qm_port_db_entry_t *port_qm_entry_p);

sai_status_t
isai_im_buffer_bam_queue_create_on_port(sai_object_id_t switch_id,
                                        sai_object_id_t port_oid,
                                        sai_object_id_t pg_oid,
                                        sai_object_id_t buffer_profile_oid);

sai_status_t
isai_im_buffer_dtm_partition_unallocated_reserved_info_get(
    sai_object_id_t buffer_profile_oid,
    ifcs_ib_t       ib,
    uint32_t        *dtm_partition_unallocated_reserved);

sai_status_t
isai_im_buffer_is_buffer_profile_lossy_or_lossless(
    sai_object_id_t buffer_profile_oid,
    bool            *is_lossless_p);



#endif /* __IFCS_SAI_BUFFER_UTIL_H__ */
