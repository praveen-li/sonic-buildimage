/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_nexthop_util.h
 * @brief ISAI Util Include file for NEXTHOP module
 */


#ifndef __IFCS_SAI_NEXTHOP_UTIL_H__
#define __IFCS_SAI_NEXTHOP_UTIL_H__

#include "util/ifcs_sai_nexthop_util_dep.h"
#include "ifcs_isai_ds.h"


/*
 * @brief Initializes next-hop module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_init(
    sai_switch_init_info_t *sai_switch_init_info_p);


/*
 * @brief Un-initializes next-hop module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);


/*
 * @brief Translates next-hop SAI object ID to IFCS handle
 *
 * @param [in]  sai_object_id - SAI object ID
 * @param [out] ifcs_handle_p - Pointer to IFCS handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);

/*
 * @brief Translates next-hop IFCS handle to SAI object ID
 *
 * @param [in]  node_id       - IFCS node ID
 * @param [in]  ifcs_handle   - IFCS handle
 * @param [in]  nh_type       - SAI type of next-hop
 * @param [in]  nh_id         - SAI nexthop id
 * @param [out] object_id_p   - Pointer to SAI object ID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_itos_xlate_oid(
    ifcs_node_id_t      node_id,
    ifcs_handle_t       ifcs_handle,
    sai_next_hop_type_t nh_type,
    uint16_t            nh_id,
    sai_object_id_t     *object_id_p);

/*
 * @brief Forms IFCS key
 *
 * @param [out]  ifcs_key_p     - Pointer to IFCS key
 * @param [in]   oid            - Object ID
 * @return sai_status_t
 */

extern sai_status_t
isai_im_nexthop_tunnel_form_ifcs_key(
    ifcs_isai_ds_tunnel_nexthop_t   *ifcs_key_p,
    sai_object_id_t                 oid);

/**
 * @brief Gets underlay next-hop handle for a given IP and L3VNI
 *        This is a temporary routine until IFCS support is available
 *
 * @param [in]  node_id     - IFCS node ID
 * @param [in]  ip_p        - Pointer to SAI IP address
 * @param [in]  l3vni       - IFCS L3VNI handle
 * @param [out] nh_handle_p - Pointer to IFCS next-hop handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_get_ulay_nh_hdl(
    const ifcs_node_id_t          node_id,
    const sai_ip_address_t *const ip_p,
    const ifcs_handle_t           l3vni,
    ifcs_handle_t                 *nh_handle_p,
    isai_tun_nhop_res_t           *tun_nhres_data_p);

/**
 * @brief Update tunnel next-hop in IFCS
 *
 * @param [in]  node_id         - IFCS node ID
 * @param [in]  tun_nh_oid      - Tunnel NH OID
 * @param [in]  nh_handle_old   - IFCS Underlay next-hop handle OID
 * @param [in]  nh_handle       - IFCS Underlay next-hop handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_update_tunnel_nh_in_ifcs(
    const ifcs_node_id_t  node_id,
    const sai_object_id_t tun_nh_oid,
    const ifcs_handle_t   nh_handle_old,
    const ifcs_handle_t   nh_handle);

/**
 * @brief Creates L2 VxLan tunnel next hop using bridge port oid
 *
 * @param [in]  node_id         - Node Id
 * @param [in]  bridge_port_id  - Bridge port Id
 * @param [in]  nexthop_ip      - Nexthop IP
 * @param [out] vxlan_nh_hdl_p  - Pointer to Vxlan Nexthop Handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_create_vxlan_l2_nexthop_using_bridge_port(
    ifcs_node_id_t        node_id,
    sai_object_id_t       bridge_port_id,
    uint8_t          nh_type,
    sai_ip_address_t      nexthop_ip,
    ifcs_handle_t    *out_port_p,
    ifcs_handle_t         *vxlan_nh_hdl_p);

/**
 * @brief Get tunnel nexthop handle and increment the ref count for the same.
 *
 * @param [in]  node_id         - Node Id
 * @param [in]  bridge_port_id  - Bridge port id
 * @param [in]  tun_nh_ip       - Tunnel nexthop ip address
 * @param [out] tun_nh_hdl_p    - Tunnel nexthop handle pointer
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_vxlan_get_tunnel_nh_hdl_and_inc_ref_count(
        ifcs_node_id_t      node_id,
        sai_object_id_t     bridge_port_id,
        uint8_t          nh_type,
        sai_ip_address_t    tun_nh_ip,
        ifcs_handle_t    *out_port_p,
        ifcs_handle_t       *tun_nh_hdl_p);

/**
 * @brief Delete a given vxlan tunnel nexthop
 *
 * Caller provides the handle for the  next-hop to be deleted
 * Decrement the both ref count and l2_ref_count for the tunnel nexthop
 * If the l2_ref_count is zero, remove the tunnel nexthop data store entry.
 *                 (this is to unsubscribe for the underlay notification)
 * If the ref_count become zero, remove nexthop entry from IFCS
 *            ( It meneans both l3 and l2 nexhop using the ifcs nexthop)
 *
 * @param [in] node_id         - Node id
 * @param [in] tnl_nh_hdl      - Tunnel nexthop handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_vxlan_cleanup_tunnel_next_hop(
    ifcs_node_id_t      node_id,
    uint8_t             nh_type,
    ifcs_handle_t       tnl_nh_hdl);

/**
 * @brief Get nexthop_ip and intf_handle for a give nexthop handle
 *
 * @param [in]  node_id        - Node Id
 * @param [in]  nh_hdl         - Nexthop handle
 * @param [out] nexthop_info_p - Pointer to nexthop info
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_get_nexthop_info(
    ifcs_node_id_t      node_id,
    ifcs_handle_t       nh_hdl,
    isai_shim_nexthop_info_t *nexthop_info_p);

/**
 * @brief Get tunnel next-hop db entry
 *
 * @param [in]  nh_oid        - Nexthop Object ID
 * @param [out] dir_p         - Direction
 * @param [out] tun_oid_p     - Pointer to tunnel object ID
 * @param [out] tun_nh_ip_p   - Pointer to tunnel next-hop IP
 * @param [out] tun_nh_oid_p  - Pointer to tunnel next-hop OID
 * @param [out] tun_nh_vnid_p - Pointer to tunnel nexthop VNID
 * @return sai_status_t
 */
sai_status_t
isai_im_nexthop_get_tunnel_db_entry(
    const sai_object_id_t          nh_oid,
    const sai_shim_nh_tunnel_dir_t *dir_p,
    const sai_object_id_t          *tun_oid_p,
    const sai_ip_address_t         *tun_nh_ip_p,
    const sai_object_id_t          *tun_nh_oid_p,
    const uint32_t                 *tun_nh_vnid_p);


/**
 * @brief Build VR-DB by walking on all Tunnel NHOPs
 *
 * @param [in]  node_id   - IFCS Node ID
 * @return sai_status_t
 */
sai_status_t
isai_im_nexthop_get_tunnh_cnt_in_vr(ifcs_node_id_t      node_id);


/**
 * @brief Get Tunnel NHs in a Given VR
 *
 * @param [in]  vr_oid   - Object ID of VR
 * @return sai_status_t
 */
sai_status_t
isai_im_nexthop_get_tunnel_nhs_in_vr(sai_object_id_t  vr_oid);

/**
 * @brief: Update Tunnel NH fileds in DS
 *
 * Currently iSAI caches previously Resolved data, which will
 * be used to compare future updates.
 *
 * @param [in]  node_id         - IFCS node ID
 * @param [in]  tun_nh_oid      - OID of Tunnel NH
 * @param [in]  nh_handle       - Underlay NH Hdl
 * @param [in]  res_ip_addr     - current resolved Prefix
 * @param [in]  res_ip_mask     - current resolved Mask
 */
sai_status_t
isai_im_nexthop_update_tun_nhres_in_ds(const ifcs_node_id_t  node_id,
                                       const sai_object_id_t tun_nh_oid,
                                       const ifcs_handle_t   nh_handle,
                                       sai_ip_address_t      res_ip_addr,
                                       sai_ip_address_t      res_ip_mask);

/**
 * @brief Process Ecmp member add/remove for VxLan tunnels
 *
 * @param [in]  node_id             - Node Id
 * @param [in]  ecmp_handle         - Ecmp handle
 * @param [in]  mem_handle          - Ecmp member handle
 * @param [in]  add                 - true for member add false for member remove
 * @return sai_status_t
 */
sai_status_t
isai_im_nexthop_process_ecmp_member_update_for_vxlan_tunnels(
                                              ifcs_node_id_t node_id,
                                              ifcs_handle_t  ecmp_handle,
                                              ifcs_handle_t  mem_handle,
                                              bool           add);
/*
 * @brief Set selected sysport in the tunnel nexthop handle data store
 *
 * @param [in]  node_id              - IFCS node id
 * @param [in]  nh_type              - Nexthop type
 * @param [in]  tnl_nh_ip            - tnl_nh_ip ID
 * @param [in]  mcast_selected_port  - Selected mcast port
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_tunnel_nh_hdl_ds_entry_set_selectd_port(
                                                ifcs_node_id_t   node_id,
                                                uint8_t          nh_type,
                                                sai_ip_address_t tnl_nh_ip,
                                                uint32_t         mcast_selected_port);

/*
 * @brief Cleanup underlay mcast nexthop
 *
 * @param [in] node_id         -  ifcs node id
 * @param [in] unicast_nh_hdl  -  unicast_nh_hdl [Key]
 * @param [out] mcast_nh_hdl_p  -  Mcast Nh handle pointer
 * @param [out] new_ref_count_p -  New ref count after increment/decrement operation
 * @return sai_status_t
 */
sai_status_t
isai_im_nexthop_cleanup_vxlan_underlay_mcast_nexthop(ifcs_node_id_t node_id,
                                               uint32_t       unicast_nh_hdl,
                                               uint32_t       *mcast_nh_hdl_p,
                                               uint32_t       *new_ref_count_p);

/**
 * @brief Get underlay or create underlay multicast nexthop
 *
 * @param [in] ucast_nh_handle    - Unicast nexthop handle
 * @param [in] nh_out_port_handle_p  - Pointer to underlay out_port handle
 * @param [in] mcast_nh_handle_p   - Pointer to mutlicast handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_vxlan_get_or_create_underlay_mcast_nexthop(ifcs_node_id_t node_id,
                                                ifcs_handle_t  ucast_nh_handle,
                                                ifcs_handle_t  *nh_out_port_handle_p,
                                                ifcs_handle_t  *mcast_nh_handle_p);
/*
 * @brief Get selected sysport in the tunnel nexthop handle data store
 *
 * @param [in]  node_id              - IFCS node id
 * @param [in]  nh_type              - Nexthop type
 * @param [in]  tnl_nh_ip            - tnl_nh_ip ID
 * @param [out] *selected_port_p     - Selected mcast port
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthop_tunnel_nexthop_handle_ds_entry_get_selected_port(
    ifcs_node_id_t   node_id,
    uint8_t          nh_type,
    sai_ip_address_t tnl_nh_ip,
    uint32_t         *selected_port_p);

#endif /* __IFCS_SAI_NEXTHOP_UTIL_H__ */
