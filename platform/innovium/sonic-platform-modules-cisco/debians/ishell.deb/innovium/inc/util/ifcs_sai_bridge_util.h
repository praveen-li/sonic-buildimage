/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_bridge_util.h
 * @brief ISAI Util Include file for BRIDGE module
 */


#ifndef __IFCS_SAI_BRIDGE_UTIL_H__
#define __IFCS_SAI_BRIDGE_UTIL_H__

#include "util/ifcs_sai_bridge_util_dep.h"

sai_status_t
isai_im_bridge_find_bridge_port(sai_object_id_t         bridge_port_oid,
                                  sai_shim_bridge_port_db_entry_t *bpkey);

sai_status_t
isai_im_bridge_get_bridge_port_type(sai_object_id_t bridge_port_oid,
                               uint32_t        *bp_type);

sai_status_t
isai_im_bridge_get_bridge_port_tunnel_id(sai_object_id_t    bridge_port_oid,
                               sai_object_id_t    *tunnel_id_p);

sai_status_t
isai_im_bridge_get_bridge_port_oid(sai_object_id_t bridge_oid,
                                   sai_object_id_t port_oid,
                                   sai_object_id_t *bridge_port_oid_p);

/**
 * @brief: Create Bridge
 *
 * @param [in] bridge_object_id_p            - Pointer to Bridge object
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                     - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_create(sai_object_id_t       *bridge_object_id_p,
                      sai_object_id_t       switch_id,
                      uint32_t              attr_count,
                      const sai_attribute_t *attr_list_p);

/**
 * @brief: Create Bridge Port
 *
 * @param [in] bridge_port_object_id_p       - Pointer to Bridge Port object
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                     - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_create(sai_object_id_t       *bridge_port_object_id_p,
                           sai_object_id_t       switch_id,
                           uint32_t              attr_count,
                           const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove Bridge Port
 *
 * @param [in] bridge_port_object_id         - Bridge object
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_remove(sai_object_id_t bridge_port_object_id);

/**
 * @brief: Bridge Port get IFCS handle from Bridge Port DS
 *
 * @param [in] bp_oid         - Bridge Port object id
 * @param [out] ifcs_hdl_p    - Pointer to IFCS handle
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_ds_get_ifcs_hdl(sai_object_id_t     bp_oid,
                                    ifcs_handle_t       *ifcs_hdl_p);

/**
 * @brief: Bridge Port get OID for given IFCS handle from Bridge Port DS
 *
 * @param [in] node_id        - IFCS Node id
 * @param [in] ifcs_hdl       - IFCS sysport/intf handle
 * @param [out] bp_oid_p      - Pointer to bridge_port oid
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_get_oid_ifcs_hdl(ifcs_node_id_t node_id,
                                     ifcs_handle_t     ifcs_hdl,
                                     sai_object_id_t   *bp_oid_p);
#endif /* __IFCS_SAI_BRIDGE_UTIL_H__ */
