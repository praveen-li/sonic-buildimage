/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_qosmap_util.h
 * @brief ISAI Util Include file for QOSMAP module
 */


#ifndef __IFCS_SAI_QOSMAP_UTIL_H__
#define __IFCS_SAI_QOSMAP_UTIL_H__

#include "util/ifcs_sai_qosmap_util_dep.h"



sai_status_t
isai_im_qosmap_pre_attach_process(ifcs_node_id_t node_id);

sai_status_t
isai_im_qosmap_qmg_init(ifcs_node_id_t         node_id,
                        sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_qosmap_qmg_deinit(ifcs_node_id_t           node_id,
                          sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_qosmap_qmg_port_create(sai_object_id_t       port_oid,
                          const sai_attribute_t *attr_list_p,
                          uint32_t              qosmap_attr_arr[],
                          uint32_t              qosmap_attr_count);

sai_status_t
isai_im_qosmap_qmg_port_set(sai_object_id_t port_oid,
                           sai_attribute_t *attr_p);

sai_status_t
isai_im_qosmap_qmg_port_get(sai_object_id_t port_oid,
                            sai_attribute_t *attr_p);


extern sai_status_t
isai_im_qosmap_qmhdl_hash_insert_item(ifcs_node_id_t             node_id,
                                      ifcs_handle_t              qm_handle,
                                      isai_shim_qmhdl_db_entry_t *qmhdl_entry_p);

extern sai_status_t
isai_im_qosmap_qmhdl_ref_count_inc(ifcs_node_id_t node_id,
                                   ifcs_handle_t  qmhdl);

/**
 * @brief: Retrieve QoS Map Attribute
 *
 * @param [in] qos_map_object_id            - QosMap object
 * @param [in] attr_count                   - Number of attributes
 * @param [in] attr_list_p                  - Pointer to List of attributes
 * @return sai_status_t
 *
 */                               
sai_status_t
isai_im_qosmap_attribute_get(sai_object_id_t qos_map_object_id,
                            uint32_t         attr_count,
                            sai_attribute_t  *attr_list_p);
#endif /* __IFCS_SAI_QOSMAP_UTIL_H__ */
