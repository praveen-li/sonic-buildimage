/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_queue_util.h
 * @brief ISAI Util Include file for QUEUE module
 */


#ifndef __IFCS_SAI_QUEUE_UTIL_H__
#define __IFCS_SAI_QUEUE_UTIL_H__

#include "util/ifcs_sai_queue_util_dep.h"


sai_status_t
isai_im_queue_remove(sai_object_id_t queue_object_id);

sai_status_t
isai_im_queue_default_attr(isai_shim_qos_info_t *obj_p,
                           sai_object_id_t      id);

sai_status_t
isai_im_queue_update_pfc_wd_egress_ace_for_port(sai_object_id_t queue_object_id,
                                                bool            ace_enable);

sai_status_t
isai_im_queue_default_attr_fill(ifcs_node_id_t       node_id,
                                isai_shim_qos_info_t *obj_p);

sai_status_t
isai_im_queue_flood_control_enable_get(sai_object_id_t queue_object_id,
                                       bool            *is_enable_p);

#endif /* __IFCS_SAI_QUEUE_UTIL_H__ */
