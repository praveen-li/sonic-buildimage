/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_lag_util.h
 * @brief ISAI Util Include file for LAG module
 */


#ifndef __IFCS_SAI_LAG_UTIL_H__
#define __IFCS_SAI_LAG_UTIL_H__

#include "util/ifcs_sai_lag_util_dep.h"

sai_status_t
isai_im_lag_set_untagged_vlan_attr_lag_db(const sai_object_id_t oid,
                                   bool                  vlan_enabled,
                                   uint16_t              untagged_vlan);

sai_status_t
isai_im_lag_get_untagged_vlan_attr_lag_db(const sai_object_id_t oid,
                                   bool                  *vlan_enabled_p,
                                   uint16_t              *untagged_vlan_p);

sai_status_t
isai_im_lag_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_lag_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_lag_add_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t  hdl,
                            uint32_t stp_hdl, uint32_t stp_port_state);

sai_status_t
isai_im_lag_get_lag_db_stp_state(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                        ifcs_handle_t   stp_hdl, uint32_t *stp_port_state_p);

sai_status_t
isai_im_lag_update_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                        ifcs_handle_t   stp_hdl, uint32_t stp_port_state);

sai_status_t
isai_im_lag_remove_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                            uint32_t stp_hdl);

sai_status_t
isai_im_lag_ds_get_lag_oid(ifcs_node_id_t node_id, ifcs_handle_t    lag_hdl,
                            sai_object_id_t *oid_p);
sai_status_t
isai_im_lag_ds_get_lag_hdl(sai_object_id_t  lag_oid, ifcs_handle_t  *lag_hdl_p);
#endif /* __IFCS_SAI_LAG_UTIL_H__ */
