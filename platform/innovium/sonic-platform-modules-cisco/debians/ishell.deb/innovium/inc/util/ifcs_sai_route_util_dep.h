/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_route_util_dep.h
 * @brief ISAI Util Dependency Include file for ROUTE module
 */


#ifndef __IFCS_SAI_ROUTE_UTIL_DEP_H__
#define __IFCS_SAI_ROUTE_UTIL_DEP_H__

#include "ifcs_sai_route.h"
#include "util/ifcs_sai_switch_util.h"
#include "util/ifcs_sai_routerintf_util.h"
#include "util/ifcs_sai_hostif_util.h"
#include "util/ifcs_sai_router_util.h"
#include "util/ifcs_sai_nexthop_util.h"
#include "util/ifcs_sai_nexthopgroup_util.h"
#include "util/ifcs_sai_tunnel_util.h"
#include "util/ifcs_sai_l2mc_group_util.h"
#endif /* __IFCS_SAI_ROUTE_UTIL_DEP_H__ */
