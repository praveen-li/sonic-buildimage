/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_udf_util.h
 * @brief ISAI Util Include file for UDF module
 */


#ifndef __IFCS_SAI_UDF_UTIL_H__
#define __IFCS_SAI_UDF_UTIL_H__

#include "util/ifcs_sai_udf_util_dep.h"

sai_status_t
isai_im_udf_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_udf_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_udf_get_udf_group_db_entry(sai_object_id_t         udf_group_oid,
                                   ifcs_sai_udf_group_ds_t *entry_p);

sai_status_t
isai_im_udf_alloc_fpf_cookie(ifcs_node_id_t   node_id,
                             bool             is_ingress,
                             uint8_t          *fpf_cookie_p);

sai_status_t
isai_im_udf_dealloc_fpf_cookie(ifcs_node_id_t   node_id,
                               bool             is_ingress,
                               uint8_t          fpf_cookie);

#endif /* __IFCS_SAI_UDF_UTIL_H__ */
