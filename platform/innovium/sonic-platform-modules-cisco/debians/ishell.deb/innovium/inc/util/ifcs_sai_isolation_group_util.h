/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_isolation_group_util.h
 * @brief ISAI Util Include file for ISOLATION_GROUP module
 */


#ifndef __IFCS_SAI_ISOLATION_GROUP_UTIL_H__
#define __IFCS_SAI_ISOLATION_GROUP_UTIL_H__

#include "util/ifcs_sai_isolation_group_util_dep.h"

sai_status_t
isai_im_isolation_group_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_isolation_group_get_isg_port_oid(sai_object_id_t *isg_oid_p);

sai_status_t
isai_im_isolation_group_port_set(ifcs_node_id_t   node_id,
                                        sai_object_id_t port_id,
                                        sai_attribute_t *attr_p);

#endif /* __IFCS_SAI_ISOLATION_GROUP_UTIL_H__ */
