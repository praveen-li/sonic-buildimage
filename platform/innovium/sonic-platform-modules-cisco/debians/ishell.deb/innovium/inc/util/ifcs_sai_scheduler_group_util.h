/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_scheduler_group_util.h
 * @brief ISAI Util Include file for SCHEDULER_GROUP module
 */


#ifndef __IFCS_SAI_SCHEDULER_GROUP_UTIL_H__
#define __IFCS_SAI_SCHEDULER_GROUP_UTIL_H__

#include "util/ifcs_sai_scheduler_group_util_dep.h"


/**
 * @brief Fill scheduler_group SAI attribute list
 *
 * Caller provides port-id and index.
 *
 * @param [in] port_id Port  object id
 * @param [in] index uin32_t 0 to 7
 * @param [in] attr_count_p                - Number of attributes
 * @param [in] attr_list_p                 - Attribute list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_group_attr_fill(
    sai_object_id_t port_id,
    uint32_t        index,
    uint32_t        *attr_count_p,
    sai_attribute_t *attr_list_p);

/**
 * @brief Delete a given scheduler_group
 *
 * Caller provides a scheduler_group  to be
 * deleted. If object_id exists, then it is deleted from the device.
 *
 * @param [in] scheduler_group_object_id - scheduler_group object_id
 * @return sai_status_t
 */

sai_status_t
isai_im_scheduler_group_remove(sai_object_id_t scheduler_group_object_id);


#endif /* __IFCS_SAI_SCHEDULER_GROUP_UTIL_H__ */
