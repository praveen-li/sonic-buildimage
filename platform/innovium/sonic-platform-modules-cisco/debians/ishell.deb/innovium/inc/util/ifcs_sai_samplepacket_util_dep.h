/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_samplepacket_util_dep.h
 * @brief ISAI Util Dependency Include file for SAMPLEPACKET module
 */


#ifndef __IFCS_SAI_SAMPLEPACKET_UTIL_DEP_H__
#define __IFCS_SAI_SAMPLEPACKET_UTIL_DEP_H__

#include "ifcs_sai_samplepacket.h"
#include "util/ifcs_sai_port_util.h"
#include "util/ifcs_sai_switch_util.h"
#endif /* __IFCS_SAI_SAMPLEPACKET_UTIL_DEP_H__ */
