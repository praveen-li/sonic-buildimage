/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_fdb_util.h
 * @brief ISAI Util Include file for FDB module
 */


#ifndef __IFCS_SAI_FDB_UTIL_H__
#define __IFCS_SAI_FDB_UTIL_H__

#include "util/ifcs_sai_fdb_util_dep.h"

sai_status_t
isai_im_fdb_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_fdb_deinit(sai_switch_deinit_info_t *sai_switch_deinit_info_p);

sai_status_t
isai_im_fdb_register_event_cb(isai_fdb_event_cb_t cb_p,
                           void                *user_data_p);

sai_status_t
isai_im_fdb_unregister_event_cb(isai_fdb_event_cb_t cb_p);

/**
 * @brief: Flush FDB Entries
 *
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                     - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_fdb_flush_entries(sai_object_id_t       switch_id,
                          uint32_t              attr_count,
                          const sai_attribute_t *attr_list_p);

sai_status_t
isai_im_fdb_pre_deinit(sai_switch_deinit_info_t  *switch_deinit_info_p);

/*
 * @brief Get FDB Trap handle
 *
 * @param [in] switch_id Switch object id
 * @param [out] fdb_trap_hdl  - Pointer FDB trap handle
 * @return sai_status_t
 */
sai_status_t
isai_im_fdb_trap_hdl_get(sai_object_id_t switch_id,
        ifcs_handle_t *fdb_trap_hdl_p);
#endif /* __IFCS_SAI_FDB_UTIL_H__ */
