/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_scheduler_util.h
 * @brief ISAI Util Include file for SCHEDULER module
 */


#ifndef __IFCS_SAI_SCHEDULER_UTIL_H__
#define __IFCS_SAI_SCHEDULER_UTIL_H__

#include "util/ifcs_sai_scheduler_util_dep.h"

/*
 * @brief Initialize defaults SAI attr for scheduler obj
 *
 * @param [in,out] obj_p        - Scheduler DSO object
 * @param [in] id        - Scheduler OID
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_default_attr(
    isai_shim_qos_info_t *obj_p,
    sai_object_id_t      id);

/*
 * @brief Fill defaults SAI attr for scheduler obj if user has not provided
 * those values.
 *
 * @param [in] id        -     node_Id
 * @param [in,out] obj_p        - Scheduler DSO object
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_default_attr_fill(ifcs_node_id_t       node_id,
                                    isai_shim_qos_info_t *obj_p);


/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in] switch_id        - Switch OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_attr_stoi(
    sai_object_id_t       switch_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);

/*
 * @brief Converts SAI attr to IFCS attr for scheduler obj for CPU queue
 *
 * @param [in] cpu_queue_id        - cpu_queue OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_cpu_q_attr_stoi(
    sai_object_id_t       cpu_queue_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);

/*
 * @brief Converts SAI attr to IFCS attr for scheduler obj for CPU port
 *
 * @param [in] port_id        - port OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_cpu_port_attr_stoi(
    sai_object_id_t       port_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);

/*
 * @brief Converts SAI attr to IFCS attr for scheduler obj for front panel port
 *
 * @param [in] port_id        - port OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_fp_port_attr_stoi(
    sai_object_id_t       port_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);



#endif /* __IFCS_SAI_SCHEDULER_UTIL_H__ */
