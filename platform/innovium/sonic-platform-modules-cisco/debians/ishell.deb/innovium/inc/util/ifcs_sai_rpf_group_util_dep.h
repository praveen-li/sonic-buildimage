/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_rpf_group_util_dep.h
 * @brief ISAI Util Dependency Include file for RPF_GROUP module
 */


#ifndef __IFCS_SAI_RPF_GROUP_UTIL_DEP_H__
#define __IFCS_SAI_RPF_GROUP_UTIL_DEP_H__

#include "ifcs_sai_rpf_group.h"
#include "util/ifcs_sai_switch_util.h"
#include "util/ifcs_sai_ipmc_util.h"
#endif /* __IFCS_SAI_RPF_GROUP_UTIL_DEP_H__ */
