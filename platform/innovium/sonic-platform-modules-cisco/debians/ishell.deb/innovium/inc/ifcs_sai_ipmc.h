/*
 *------------------------------------------------------------------------------
 * Copyright (c) Innovium, Inc., 2017
 *
 * This material is proprietary to Innovium. All rights reserved.
 * The methods and techniques described herein are considered trade secrets
 * and/or confidential. Reproduction or distribution, in whole or in part, is
 * forbidden except by express written permission of Innovium.
 *------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_ipmc.h
 * @brief ISAI IM Include file for IPMC module
 */


#ifndef __IFCS_SAI_IPMC_H__
#define __IFCS_SAI_IPMC_H__


#define ISAI_MODULE_LOCK_IPMC    1ULL


#include "isai_im_nmgr.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_ipmc_group.h"
#include "ifcs_sai_rpf_group.h"
#include "ifcs_sai_routerintf.h"
#endif /* __IFCS_SAI_IPMC_H__ */
