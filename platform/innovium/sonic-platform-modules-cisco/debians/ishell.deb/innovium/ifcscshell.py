#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import os
import sys
import socket
import select
import argparse
import errno
import datetime
from threading import Thread
from ctypes import *
from ifcs_ctypes import *
from ifcs_cli import IFCS_CLI
from utils.compat_util import *
from verbosity import log
from collections import OrderedDict, deque

g_reserved_port = 7105
class InnoRemoteShell():
    def __init__(self, port=None, host=None, server=None):
        intro               = ''
        self.HOST           = 'localhost'
        self.PORT           = port
        self.SERVER         = server
        self.MAX_CLIENTS    = 5
        self.clientcount    = 0
        self.active_sockets = [] * self.MAX_CLIENTS
        self.open_client_sockets = [] * self.MAX_CLIENTS
        self.cli            = IFCS_CLI(intro)
        self.cli.set_rt_env('switch')
        self.cli.set_server_mode(True)
        self.cli.set_server_object(self)
        self.cli.set_node_id(0)
        self.cli.init_cmds()
        self.no_shell_mode  = 0
        self.peak_client_count = self.clientcount
        self.peak_client_count_ts = datetime.datetime.now()
        self.client_reject_count = 0
        self.error_epipe_count = 0
        self.error_other_count = 0
        self.exception_count = 0
        self.MAX_ERROR_LOGS = 5
        self.error_logs = deque()

    def set_noshell_mode(self, mode):
        self.no_shell_mode = mode

    def setup_modules(self):
        try:
            self.cli.onecmd("setup_modules")
        except:
            server_msg = "Innovium shell server: Error in setup_modules : {}".format(sys.exc_info())
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg)
            # re-raise the exception as server cannot continue running
            raise

    def create_inet_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            sock.shutdown(socket.RDWR)
            sock.close()

        # create the socket
        s_in = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set sock opt to not resue address
        s_in.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            # bind to the socket
            s_in.bind((self.HOST, self.PORT))
            server_msg = "Innovium shell server (inet): Successfully bound to port %d" % (self.PORT)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
        except socket.error as msg:
            server_msg = 'Innovium shell server: Bind failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg)
            return

        # listen to the socket
        s_in.listen(self.MAX_CLIENTS)
        server_msg = "Innovium shell server (inet): Listening for incoming shell clients"
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)

        # append socket to active_sockets list
        self.active_sockets.append(s_in)


    def create_unix_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            sock.shutdown(socket.RDWR)
            sock.close()

        # make sure the socket doesn't already exist
        try:
            os.unlink(self.SERVER)
        except OSError as e:
            if os.path.exists(self.SERVER):
                server_msg = "Innovium shell server (ERROR): server already in use : {}".format(e)
                log(server_msg)
                log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg)
                return

        # create the socket
        s_in = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

        try:
            # bind to the socket
            s_in.bind(self.SERVER)
            server_msg = "Innovium shell server (unix): Successfully bound to server %s" % (self.SERVER)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
        except socket.error as msg:
            server_msg = 'Innovium shell server: Bind failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg)
            return

        # listen to the socket
        s_in.listen(self.MAX_CLIENTS)
        server_msg = "Innovium shell server (unix): Listening for incoming shell clients"
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)

        # append socket to active_sockets list
        self.active_sockets.append(s_in)

    def clientthread(self, conn, addr, data_in):
        # duplicate sys.stdout
        self.cli.stdout = old_stdout = sys.stdout

        # replace sys.stdout with a string buffer
        sys.stdout = new_stdout = compat_StringIO()

        # account for third-party shells that have no prompt
        no_prompt = False

        if 'np' in data_in:
            no_prompt = True
            data_in = data_in.split("np")[0]

        try:
            # execute the incoming command
            self.cli.onecmd(data_in)
        except:
            # retrieve the return buf
            reply = new_stdout.getvalue()

            new_stdout.close()
            # replace the original stdout
            sys.stdout = old_stdout

            # Append error message to client
            err_msg = "Error occurred when executing command : {}".format(sys.exc_info())
            reply = "{}\n{}".format(reply, err_msg)

            # encode the reply length in the response
            if not self.no_shell_mode:
                reply = str(len(reply)) + ':::' + reply
            else:
                if no_prompt:
                    reply = reply + "\n"
                else:
                    reply = reply + "\nIVM:R>"

            # send the reply and error message
            conn.sendall(compat_strToBytes(reply))

            # re-raise the exception so that server logs it
            raise

        # retrieve the return buf
        reply = new_stdout.getvalue()

        new_stdout.close()
        # replace the original stdout
        sys.stdout = old_stdout

        # encode the reply length in the response
        if not self.no_shell_mode:
            reply = str(len(reply)) + ':::' + reply
        else:
            if no_prompt:
                reply = reply + "\n"
            else:
                reply = reply + "IVM:R>\n"

        # send the reply
        conn.sendall(compat_strToBytes(reply))

        # reset the no-prompt flag
        no_prompt = False

    def handle_exception(self, error):
        # restore the stdout
        sys.stdout = self.cli.stdout

        # handle error
        if type(error).__name__ == 'error':
            if error.errno == errno.EPIPE:
                self.error_epipe_count += 1
                server_msg = "Innovium shell server (WARNING): client has closed the connection before write finished"
                log(server_msg)
                log_im_msg(IFCS_LOG_LEVEL_WARN, server_msg)
            else:
                self.error_other_count += 1
                server_msg = "Innovium shell server (WARNING): {}".format(error)
                log(server_msg)
                log_im_msg(IFCS_LOG_LEVEL_WARN, server_msg)
        else:
            self.exception_count += 1
            server_msg = "Innovium shell server (ERROR): {}".format(error)
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg)

    def communicate(self):
        # store open shell client sockets
        self.open_client_sockets = []

        # listen in on incoming socket connections
        while True:
            try:
                read_list, write_list, exception_list = select.select(self.active_sockets + self.open_client_sockets, [], [])

                # for a new shell client  accept the connection
                for current_socket in read_list:
                    if current_socket in self.active_sockets:
                        (new_socket, address) = current_socket.accept()

                        # store the incoming socket in open client sockets list
                        self.open_client_sockets.append(new_socket)

                        # if the client count exceeds max clients, send an error the client and  bail
                        if self.clientcount >= self.MAX_CLIENTS:
                            server_msg = "Innovium shell server: Max number of clients (%d) reached" % (self.MAX_CLIENTS)
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
                            error_msg = "Err: Max clients-%d" % (self.MAX_CLIENTS)
                            new_socket.send(compat_strToBytes(error_msg))
                            self.open_client_sockets.remove(new_socket)
                            self.client_reject_count += 1
                            self.save_error_log(
                                "Max number of clients (%d) reached" %
                                (self.MAX_CLIENTS))
                            continue

                        if self.PORT:
                            server_msg = 'Innovium shell server: Accepted shell client {}:{}'.format(address[0], address[1])
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
                        else:
                            server_msg = 'Innovium shell server: Accepted shell client'
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)

                        self.clientcount = self.clientcount + 1
                        if self.peak_client_count <= self.clientcount:
                            self.peak_client_count = self.clientcount
                            self.peak_client_count_ts = datetime.datetime.now()
                        if not self.no_shell_mode:
                            new_socket.send(compat_strToBytes('Success'))
                    else:
                        # recieve the cli command from the socket
                        try:
                            data = compat_bytesToStr(current_socket.recv(1024))
                        except:
                            data = ''
                            server_msg = "Something bad happened. Trying to close connection gracefully. error: {}".format(sys.exc_info())
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)

                        if len(data) == 0:
                            server_msg = "Innovium shell server: Closing client connection"
                            log(server_msg)
                            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
                            current_socket.close()
                            self.open_client_sockets.remove(current_socket)
                            self.clientcount = self.clientcount - 1
                        else:
                            # Execute and return the command
                            self.clientthread(current_socket, address, data)
            except (Exception, IOError, socket.error) as e:
                self.save_error_log("Exception: {}".format(sys.exc_info()))
                self.handle_exception(e)

    def save_error_log(self, msg):
        if len(self.error_logs) >= self.MAX_ERROR_LOGS:
            self.error_logs.popleft()
        self.error_logs.append(str(datetime.datetime.now()) + ": " + msg)

    def socket_to_str(self, sock, server=True):
        if COMPAT_PY3:
            return str(sock)
        try:
            if server:
                obj_repr = "<fd={}, family={}, type={} proto={}, laddr={}>".format(
                    sock.fileno(), sock.family, sock.type, sock.proto, sock.getsockname())
            else:
                obj_repr = "<fd={}, family={}, type={} proto={}, laddr={}, raddr={}>".format(
                    sock.fileno(), sock.family, sock.type, sock.proto, sock.getsockname(), sock.getpeername())
        except BaseException:
            obj_repr = str(sock)
        return obj_repr

    def get_server_stats(self):
        stats = OrderedDict()
        stats["Remote client count"] = self.clientcount
        idx = 0
        for sock in self.open_client_sockets:
            stats["Open client socket #{}".format(idx)] = self.socket_to_str(sock, False)
            idx += 1
        stats["Peak remote client count"] = self.peak_client_count
        stats["Latest peak remote client time"] = str(self.peak_client_count_ts)
        idx = 0
        for sock in self.active_sockets:
            stats["Server socket #{}".format(idx)] = self.socket_to_str(sock)
            idx += 1
        stats["Clients rejected due to limit"] = self.client_reject_count
        stats["Server errno.EPIPE count"] = self.error_epipe_count
        stats["Server other errno count"] = self.error_other_count
        stats["Server exception count"] = self.exception_count
        idx = 0
        for msg in self.error_logs:
            stats["Server last error #{}".format(idx)] = msg
            idx += 1
        return stats

    def clear_server_stats(self):
        self.peak_client_count = self.clientcount
        self.peak_client_count_ts = datetime.datetime.now()
        self.client_reject_count = 0
        self.error_epipe_count = 0
        self.error_other_count = 0
        self.exception_count = 0
        self.error_logs = deque()

def log_im_msg(level, msg):
    if level <= ILC.log_level:
        im_log(IM_LOG_USER_IFCS, level, compat_strToBytes("%s CLI: %s"), ITC.trace_str[ITA_NODE], compat_strToBytes(msg))

def config_inet_server():
    # get the port
    global g_reserved_port
    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_PORT: {}".format(PORT)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        PORT = g_reserved_port
        server_msg = "Innovium shell server: IFCS_INNO_CLI_PORT not set.. assuming default port {}".format(PORT)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)

    # for now HOST is always localhost
    HOST        = ''
    remoteShell = InnoRemoteShell(port=PORT, host=HOST)
    remoteShell.create_inet_socket()
    remoteShell.setup_modules()
    remoteShell.communicate()

def config_unix_server():
    # get the server address
    try:
        SERVER = os.environ['IFCS_INNO_CLI_SERVER']
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_SERVER: {}".format(SERVER)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        server_msg = "Innovium shell server (ERROR): IFCS_INNO_CLI_SERVER not set.. defaulting to inet server"
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
        config_inet_server()

    try:
        NOSHELL = int(os.environ['IFCS_INNO_CLI_SERVER_NOSHELL'])
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_SERVER_NOSHELL: {}".format(NOSHELL)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        NOSHELL=0
        pass

    remoteShell = InnoRemoteShell(server=SERVER)
    remoteShell.create_unix_socket()
    remoteShell.set_noshell_mode(NOSHELL)
    remoteShell.setup_modules()
    remoteShell.communicate()

def main():
    # figure out type of server to spawn
    configure_method = 0

    config_serv_methods = {
        0  : config_inet_server,
        1  : config_inet_server,
        2  : config_unix_server,
    }

    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])

        # configure the inet server
        configure_method = 1
    except:
        try:
            SERVER = os.environ['IFCS_INNO_CLI_SERVER']

            # configure unix server
            configure_method = 2
        except:
            server_msg = "Innovium shell (ERROR) : IFCS_INNO_CLI_PORT / IFCS_INNO_CLI_SERVER not set.. defaulting to INET SERVER"
            log(server_msg)
            log_im_msg(IFCS_LOG_LEVEL_DEBUG, server_msg)

    try:
        config_serv_methods[configure_method]()
    except Exception as e:
        server_msg = "Innovium shell server : {}".format(e)
        log(server_msg)
        log_im_msg(IFCS_LOG_LEVEL_ERROR, server_msg)

if __name__ == "__main__":
    # get the host and port
    PORT = int(os.environ['IFCS_INNO_CLI_PORT'])
    remoteShell = InnoRemoteShell()
    remoteShell.create_socket()
    remoteShell.communicate()
