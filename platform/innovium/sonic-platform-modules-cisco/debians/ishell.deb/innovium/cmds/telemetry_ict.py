#-------------------------------------------------------------------------------
# * Copyright (c) Innovium, Inc., 2017
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

from ifcs_types_util import *
import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from testutil import pci
from testutil import pkt
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
from utils.log_utils import raiseExpOnFail
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']
interface_to_sysport_teralynx7_1_map = {'eth1/1': '0x3e200001',
                                        'eth1/2': '0x3e200005',
                                        'eth1/3': '0x3e200009',
                                        'eth1/4': '0x3e20000d',
                                        'eth1/5': '0x3e200011',
                                        'eth1/6': '0x3e200015',
                                        'eth1/7': '0x3e200019',
                                        'eth1/8': '0x3e20001d',
                                        'eth1/9': '0x3e200021',
                                        'eth1/10': '0x3e200025',
                                        'eth1/11': '0x3e200029',
                                        'eth1/12': '0x3e20002d',
                                        'eth1/13': '0x3e200031',
                                        'eth1/14': '0x3e200035',
                                        'eth1/15': '0x3e200039',
                                        'eth1/16': '0x3e20003d',
                                        'eth1/17': '0x3e200041',
                                        'eth1/19': '0x3e200045',
                                        'eth1/19': '0x3e200049',
                                        'eth1/20': '0x3e20004d',
                                        'eth1/21': '0x3e200051',
                                        'eth1/22': '0x3e200055',
                                        'eth1/23': '0x3e200059',
                                        'eth1/24': '0x3e20005d',
                                        'eth1/25': '0x3e200061',
                                        'eth1/26': '0x3e200065',
                                        'eth1/27': '0x3e200069',
                                        'eth1/28': '0x3e20006d',
                                        'eth1/29': '0x3e200071',
                                        'eth1/30': '0x3e200075',
                                        'eth1/31': '0x3e200079',
                                        'eth1/32': '0x3e20007d',
                                        'eth1/33': '0x3e200081',
                                        'eth1/34': '0x3e200082',
                                       }

interface_to_sysport_teralynx7_2_map = {'eth1/1': '0x3e200001',
                                        'eth1/2': '0x3e200002',
                                        'eth1/3': '0x3e200003',
                                        'eth1/4': '0x3e200004',
                                        'eth1/5': '0x3e200005',
                                        'eth1/6': '0x3e200006',
                                        'eth1/7': '0x3e200007',
                                        'eth1/8': '0x3e200008',
                                        'eth1/9': '0x3e200009',
                                        'eth1/10': '0x3e20000a',
                                        'eth1/11': '0x3e20000b',
                                        'eth1/12': '0x3e20000c',
                                        'eth1/13': '0x3e20000d',
                                        'eth1/14': '0x3e20000e',
                                        'eth1/15': '0x3e20000f',
                                        'eth1/16': '0x3e200010',
                                        'eth1/17': '0x3e200011',
                                        'eth1/19': '0x3e200012',
                                        'eth1/19': '0x3e200013',
                                        'eth1/20': '0x3e200014',
                                        'eth1/21': '0x3e200015',
                                        'eth1/22': '0x3e200016',
                                        'eth1/23': '0x3e200017',
                                        'eth1/24': '0x3e200018',
                                        'eth1/25': '0x3e200019',
                                        'eth1/26': '0x3e20002a',
                                        'eth1/27': '0x3e20002b',
                                        'eth1/28': '0x3e20002c',
                                        'eth1/29': '0x3e20002d',
                                        'eth1/30': '0x3e20002e',
                                        'eth1/31': '0x3e20002f',
                                        'eth1/32': '0x3e200020',
                                        'eth1/33': '0x3e200021',
                                        'eth1/34': '0x3e200022',
                                        'eth1/35': '0x3e200023',
                                        'eth1/36': '0x3e200024',
                                        'eth1/37': '0x3e200025',
                                        'eth1/38': '0x3e200026',
                                        'eth1/39': '0x3e200027',
                                        'eth1/40': '0x3e200028',
                                        'eth1/41': '0x3e200029',
                                        'eth1/42': '0x3e20002a',
                                        'eth1/43': '0x3e20002b',
                                        'eth1/44': '0x3e20002c',
                                        'eth1/45': '0x3e20002d',
                                        'eth1/46': '0x3e20002e',
                                        'eth1/47': '0x3e20002f',
                                        'eth1/48': '0x3e200030',
                                        'eth1/49': '0x3e200031',
                                        'eth1/50': '0x3e200035',
                                        'eth1/51': '0x3e200039',
                                        'eth1/52': '0x3e20003d',
                                        'eth1/53': '0x3e200041',
                                        'eth1/54': '0x3e200045',
                                        'eth1/55': '0x3e200049',
                                        'eth1/56': '0x3e20004d',
                                       }

interface_to_sysport_teralynx7_3_map = {'eth1/1': '0x3e200001',
                                        'eth1/2': '0x3e200005',
                                        'eth1/3': '0x3e200009',
                                        'eth1/4': '0x3e20000d',
                                        'eth1/5': '0x3e200011',
                                        'eth1/6': '0x3e200015',
                                        'eth1/7': '0x3e200019',
                                        'eth1/8': '0x3e20001d',
                                        'eth1/9': '0x3e200021',
                                        'eth1/10': '0x3e200025',
                                        'eth1/11': '0x3e200029',
                                        'eth1/12': '0x3e20002d',
                                        'eth1/13': '0x3e200031',
                                        'eth1/14': '0x3e200035',
                                        'eth1/15': '0x3e200039',
                                        'eth1/16': '0x3e20003d',
                                        'eth2/1': '0x3e2000041',
                                        'eth2/2': '0x3e200045',
                                        'eth2/3': '0x3e200049',
                                        'eth2/4': '0x3e20004d',
                                        'eth2/5': '0x3e200051',
                                        'eth2/6': '0x3e200055',
                                        'eth2/7': '0x3e200059',
                                        'eth2/8': '0x3e20005d',
                                        'eth2/9': '0x3e200061',
                                        'eth2/10': '0x3e200065',
                                        'eth2/11': '0x3e200069',
                                        'eth2/12': '0x3e20006d',
                                        'eth2/13': '0x3e200071',
                                        'eth2/14': '0x3e200075',
                                        'eth2/15': '0x3e200079',
                                        'eth2/16': '0x3e20007d',
                                        'eth3/1': '0x3e200081',
                                        'eth3/2': '0x3e200085',
                                        'eth3/3': '0x3e200089',
                                        'eth3/4': '0x3e20008d',
                                        'eth4/1': '0x3e2000c1',
                                        'eth4/2': '0x3e2000c5',
                                        'eth4/3': '0x3e2000c9',
                                        'eth4/4': '0x3e2000cd',
                                        'eth4/5': '0x3e2000d1',
                                        'eth4/6': '0x3e2000d5',
                                        'eth4/7': '0x3e2000d9',
                                        'eth4/8': '0x3e2000dd',
                                        'eth4/9': '0x3e2000e1',
                                        'eth4/10': '0x3e2000e5',
                                        'eth4/11': '0x3e2000e9',
                                        'eth4/12': '0x3e2000ed',
                                        'eth4/13': '0x3e2000f1',
                                        'eth4/14': '0x3e2000f5',
                                        'eth4/15': '0x3e2000f9',
                                        'eth4/16': '0x3e2000fd',
                                        'eth5/1': '0x3e200101',
                                        'eth5/2': '0x3e200105',
                                        'eth5/3': '0x3e200109',
                                        'eth5/4': '0x3e20010d',
                                        'eth5/5': '0x3e200111',
                                        'eth5/6': '0x3e200115',
                                        'eth5/7': '0x3e200119',
                                        'eth5/8': '0x3e20011d',
                                        'eth5/9': '0x3e200121',
                                        'eth5/10': '0x3e200125',
                                        'eth5/11': '0x3e200129',
                                        'eth5/12': '0x3e20012d',
                                        'eth5/13': '0x3e200131',
                                        'eth5/14': '0x3e200135',
                                        'eth5/15': '0x3e200139',
                                        'eth5/16': '0x3e20013d',
                                        'eth6/1': '0x3e200141',
                                        'eth6/2': '0x3e200145',
                                        'eth6/3': '0x3e200149',
                                        'eth6/4': '0x3e20014d',
                                        'eth6/5': '0x3e200151',
                                        'eth6/6': '0x3e200155',
                                        'eth6/7': '0x3e200159',
                                        'eth6/8': '0x3e20015d',
                                        'eth6/9': '0x3e200161',
                                        'eth6/10': '0x3e200165',
                                        'eth6/11': '0x3e200169',
                                        'eth6/12': '0x3e20016d',
                                        'eth6/13': '0x3e200171',
                                        'eth6/14': '0x3e200175',
                                        'eth6/15': '0x3e200179',
                                        'eth6/16': '0x3e20018d',
                                        'eth7/1': '0x3e200191',
                                        'eth7/2': '0x3e200195',
                                        'eth7/3': '0x3e200199',
                                        'eth7/4': '0x3e20019d',
                                        'eth8/1': '0x3e2001c1',
                                        'eth8/2': '0x3e2001c5',
                                        'eth8/3': '0x3e2001c9',
                                        'eth8/4': '0x3e2001cd',
                                        'eth8/5': '0x3e2001d1',
                                        'eth8/6': '0x3e2001d5',
                                        'eth8/7': '0x3e2001d9',
                                        'eth8/8': '0x3e2001dd',
                                        'eth8/9': '0x3e2001e1',
                                        'eth8/10': '0x3e2001e5',
                                        'eth8/11': '0x3e2001e9',
                                        'eth8/12': '0x3e2001ed',
                                        'eth8/13': '0x3e2001f1',
                                        'eth8/14': '0x3e2001f5',
                                        'eth8/15': '0x3e2001f9',
                                        'eth8/16': '0x3e2001fd',
                                       }


class TelemetryICT(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create_instance'           : self.create_instance,
                         'delete_instance'           : self.delete_instance,
                         'help'                      : self.help,
                         '?'                         : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        self.telemetry_ict_instance_handle = 0
        self.telemetry_ict_dcdp_handle = 0
        self.telemetry_ict_collector_handle = 0
        self.telemetry_ict_collector_set_handle = 0
        self.handle = 0
        self.nodeId = 0
        self.deviceType = -1
        self.switchId = -1

    def get_sysport_from_interface(self, interface_string):
        if self.deviceType == ifcs_ctypes.IFCS_DEVICE_TYPE_TERALYNX7_1:
            if (int(self.switchId) >> 13) == 1:
                if interface_string not in interface_to_sysport_teralynx7_3_map:
                    return ifcs_ctypes.IFCS_PARAM
                else:
                    return interface_to_sysport_teralynx7_3_map[interface_string]
            else:
                if interface_string not in interface_to_sysport_teralynx7_1_map:
                    return ifcs_ctypes.IFCS_PARAM
                else:
                    return interface_to_sysport_teralynx7_1_map[interface_string]
        elif self.deviceType == ifcs_ctypes.IFCS_DEVICE_TYPE_TERALYNX7_2:
            if interface_string not in interface_to_sysport_teralynx7_2_map:
                return ifcs_ctypes.IFCS_PARAM
            else:
                return interface_to_sysport_teralynx7_2_map[interface_string]
        else:
            return ifcs_ctypes.IFCS_UNINIT


    def _create_(
            self,
            nodeId,
            type=None,
            ingressFunctionCreate=None,
            egressFunctionCreate=None,
            transitFunctionCreateAndEnable=None,
            identifierVxlanGpe=None,
            identifierProbeMarker=None,
            iptPacketTriggerType=None,
            iptPacketDscp=None,
            ictEgressCollectorSet=None,
            foniEnable=None,
            statsProfile=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        attrList = (ifcs_ctypes.ifcs_attr_t * 13)()
        for index in range(13):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if type is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_TYPE
            attrList[index].value.u32 = type
            index += 1
        if ingressFunctionCreate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_INGRESS_FUNCTION_CREATE
            attrList[index].value.data = ingressFunctionCreate
            index += 1
        if egressFunctionCreate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_EGRESS_FUNCTION_CREATE
            attrList[index].value.data = egressFunctionCreate
            index += 1
        if transitFunctionCreateAndEnable is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_TRANSIT_FUNCTION_CREATE_AND_ENABLE
            attrList[index].value.data = transitFunctionCreateAndEnable
            index += 1
        if identifierVxlanGpe is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_IDENTIFIER_VXLAN_GPE
            attrList[index].value.u32 = identifierVxlanGpe
            index += 1
        if identifierProbeMarker is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_IDENTIFIER_PROBE_MARKER
            attrList[index].value.u64 = identifierProbeMarker
            index += 1
        if iptPacketTriggerType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_IPT_PACKET_TRIGGER_TYPE
            attrList[index].value.u32 = iptPacketTriggerType
            index += 1
        if iptPacketDscp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_IPT_PACKET_DSCP
            attrList[index].value.u8_list = iptPacketDscp
            index += 1
        if ictEgressCollectorSet is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_ICT_EGRESS_COLLECTOR_SET
            attrList[index].value.handle = ictEgressCollectorSet
            index += 1
        if foniEnable is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_FONI_ENABLE
            attrList[index].value.data = foniEnable
            index += 1
        if statsProfile is not None:
            attrList[index].id = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_STATS_PROFILE
            attrList[index].value.u32 = statsProfile
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_telemetry_instance_create(
                    nodeId, pointer(handle), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Telemetry ICT Instance creation failed rc: {0}".format(rc))
            else:
                self.telemetry_ict_instance_handle = int(handle.value)
                #log("Telemetry ICT Instance handle= " + hex(handle.value))
            return rc

    def _collector_create_(
            self,
            nodeId,
            collectorType=None,
            direction=None,
            dcdp=None,
            localDestination=None,
            vizTc=None,
            rspanDot1qTpid=None,
            rspanDot1qVlan=None,
            rspanDot1qPri=None,
            rspanDot1qCfi=None,
            destMac=None,
            srcMac=None,
            srcIpFamily=None,
            srcIp=None,
            destIpFamily=None,
            destIp=None,
            dscp=None,
            ttl=None,
            ipv4DfFlag=None,
            dot1qVlan=None,
            sessionId=None,
            truncate=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        attrList = (ifcs_ctypes.ifcs_attr_t * 20)()
        for index in range(20):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_COLLECTOR_TYPE
            attrList[index].value.u32 = collectorType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if dcdp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DCDP
            attrList[index].value.handle = dcdp
            index += 1
        if localDestination is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_LOCAL_DESTINATION
            attrList[index].value.handle = localDestination
            index += 1
        if vizTc is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_VIZ_TC
            attrList[index].value.tc = vizTc
            index += 1
        if rspanDot1qTpid is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_TPID
            attrList[index].value.u16 = rspanDot1qTpid
            index += 1
        if rspanDot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_VLAN
            attrList[index].value.u16 = rspanDot1qVlan
            index += 1
        if rspanDot1qPri is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_PRI
            attrList[index].value.u8 = rspanDot1qPri
            index += 1
        if rspanDot1qCfi is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_CFI
            attrList[index].value.u8 = rspanDot1qCfi
            index += 1
        if destMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_MAC
            attrList[index].value.mac = destMac
            index += 1
        if srcMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_MAC
            attrList[index].value.mac = srcMac
            index += 1
        if srcIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_IP
            attrList[index].value.ip_addr = self.build_ipaddr(srcIp)
            index += 1
        if destIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_IP
            attrList[index].value.ip_addr = self.build_ipaddr(destIp)
            index += 1
        if dscp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DSCP
            attrList[index].value.u8 = dscp
            index += 1
        if ttl is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TTL
            attrList[index].value.u8 = ttl
            index += 1
        if ipv4DfFlag is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_IPV4_DF_FLAG
            attrList[index].value.u8 = ipv4DfFlag
            index += 1
        if dot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DOT1Q_VLAN
            attrList[index].value.u16 = dot1qVlan
            index += 1
        if sessionId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SESSION_ID
            attrList[index].value.u16 = sessionId
            index += 1
        if truncate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TRUNCATE
            attrList[index].value.u32 = truncate
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Telemetry ICT Collector creation failed rc: {0}".format(rc))
            else:
                self.telemetry_ict_collector_handle = int(handle.value)
                #log("Collector handle= " + hex(handle.value))
            return rc

    def _collector_set_create_(
            self,
            nodeId,
            collectorSetType=None,
            direction=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
        for index in range(4):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorSetType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_COLLECTOR_SET_TYPE
            attrList[index].value.u32 = collectorSetType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Telemetry ICT CollectorSet creation failed rc: {0}".format(rc))
            else:
                self.telemetry_ict_collector_set_handle = int(handle.value)
                #log("CollectorSet handle= " + hex(handle.value))
            return rc

    def _add_members_(
            self,
            collector_set_handle,
            memberList,
            attrList=None,
            memberCount=None,
            attrCount=None,
            expRc=None,
            customLog=None):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            if memberList is not None:
                memberCount = len(memberList)
            else:
                memberCount = 0
        if attrCount is None:
            if attrList is not None:
                attrCount = len(attrList)
            else:
                attrCount = 0
        if not attrList:
            attrList = None
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_add(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t),
                attrCount,
                attrList))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Telemetry ICT CollectorSet member add failed rc: {0}".format(rc))
        else:
            pass
        #    log("CollectorSet member add successful")
        return rc

    def _remove_members_(
            self,
            collector_set_handle,
            memberList,
            memberCount=None,
            expRc=None,
            customLog=None):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            memberCount = len(memberList)
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_remove(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Telemetry ICT CollectorSet member remove failed rc: {0}".format(rc))
        else:
            pass
            #log("CollectorSet member remove successful")
        return rc


    def run_cmd(self, args):
        log_dbg(1, "in Telemetry ICT run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "TelemetryICTKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "TelemetryICTValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None
    def _dcdp_create_(
            self,
            nodeId,
            sysport=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        attrList = (ifcs_ctypes.ifcs_attr_t * 2)()
        for index in range(2):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if sysport is not None:
            attrList[index].id = ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_SYSPORT
            attrList[index].value.handle = sysport
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_DUP_COPY_DEST_PORT_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_dup_copy_dest_port_create(
                    nodeId, pointer(handle), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("DupCopyDestPort creation failed rc: {0}".format(rc))
            else:
                self.telemetry_ict_dcdp_handle = int(handle.value)
                #log("DupCopyDestPort handle= " + hex(handle.value))
            return rc




    def create_instance(self, args):
        log_dbg(1, "in telemetry ICT instance create")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Telemetry ICT create', prog='telemetry', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-transit_fn', action="store", help='Enables/Disables the transit function 0(Disable) | 1(Enable)', required=True)
        requiredArgs.add_argument('-probe_marker', action="store", help='ICT Probe Marker (64-bit) in hex (0x...)', required=True)
        requiredArgs.add_argument('-egress_mirror_interface', action="store", help='Interface to send Mirrored ICT Probe packets', required=False)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            if len(self.arg_list) == 1 and self.arg_list[0] in ['-h', '--help']:
                return 0
            log('Create parse_args failed')
            return 1


        if self.telemetry_ict_instance_handle != 0:
            log("ICT Telemetry Instance already exist")
            return ifcs_ctypes.IFCS_INVAL

        actual_count = c_int()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE_TYPE
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Device Type get unsuccessful")
            return rc

        self.deviceType = out_attr.value.u32

        actual_count = c_int()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_SWITCH_ID
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Switch id get unsuccessful")
            return rc

        self.switchId = out_attr.value.u32


        # Get dest_port_handle
        if res.egress_mirror_interface is not None:
            dest_port_handle = int(self.get_sysport_from_interface(res.egress_mirror_interface), 0)
            try:
                rc = self._dcdp_create_(self.cli.node_id, sysport=dest_port_handle)
            except Exception as e:
                log(e.message)
            if rc:
                log("Telemetry ICT Span DCDP create failed rc: {0}".format(rc))
                return rc

            collectorType = ifcs_ctypes.IFCS_COLLECTOR_TYPE_SPAN

            try:
                rc = self._collector_create_(self.cli.node_id, collectorType=collectorType,
                                             direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_EGRESS,
                                             dcdp=self.telemetry_ict_dcdp_handle)
            except Exception as e:
                log(e.message)
            if rc:
                log("Telemetry ICT Span Collector create failed rc: {0}".format(rc))
                return rc

            rc  =  self._collector_set_create_(self.cli.node_id, collectorSetType=ifcs_ctypes.IFCS_COLLECTOR_TYPE_SPAN, direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_EGRESS)

            if rc:
                log("Telemetry ICT Span Collector set failed rc: {0}".format(rc))
                return rc

            rc = self._add_members_(self.telemetry_ict_collector_set_handle, [self.telemetry_ict_collector_handle])

            if rc:
                log("Telemetry ICT Span Collector set add member failed rc: {0}".format(rc))
                return rc

        return self._create_(self.cli.node_id, type=ifcs_ctypes.IFCS_TELEMETRY_INSTANCE_TYPE_ICT, transitFunctionCreateAndEnable = int(res.transit_fn), identifierProbeMarker = int(res.probe_marker,0), ictEgressCollectorSet=None if self.telemetry_ict_collector_set_handle == 0 else self.telemetry_ict_collector_set_handle)

    def _delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False):
        if bulk is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_telemetry_instance_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(
                        rc, 'telemetry_instance Delete failed')
        else:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_telemetry_instance_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(
                        rc, 'telemetry_instance Delete failed')

    def _dcdp_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False):
        if bulk is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_dup_copy_dest_port_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(
                        rc, 'dup_copy_dest_port Delete failed')
        else:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_dup_copy_dest_port_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(
                        rc, 'dup_copy_dest_port Delete failed')

    def _collector_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False):
        if bulk is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector Delete failed')
        else:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector Delete failed')


    def _collector_set_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False):
        if bulk is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector_set Delete failed')
        else:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector_set Delete failed')



    def delete_instance(self,args):
        self.nodeID = self.cli.node_id
        if self.telemetry_ict_instance_handle != 0:
            self.handle = self.telemetry_ict_instance_handle
            self._delete_()
        if self.telemetry_ict_collector_set_handle != 0:
            self._remove_members_(self.telemetry_ict_collector_set_handle, [self.telemetry_ict_collector_handle])
            self.handle = self.telemetry_ict_collector_set_handle
            self._collector_set_delete_()
        if self.telemetry_ict_collector_handle != 0:
            self.handle = self.telemetry_ict_collector_handle
            self._collector_delete_()
        if self.telemetry_ict_dcdp_handle != 0:
            self.handle = self.telemetry_ict_dcdp_handle
            self._dcdp_delete_()
        self.telemetry_ict_dcdp_handle = 0
        self.telemetry_ict_collector_set_handle = 0
        self.telemetry_ict_collector_handle = 0
        self.telemetry_ict_instance_handle = 0
        self.handle = 0
        return 0

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create_instance', 'Create Telemetry ICT instance'])
        table.add_row(['delete_instance', 'Delete Telemetry ICT instance'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        telemetry_ict_help_string = """
Usage::

    Type "config telemetry_ict <command>" followed by -h to see command's sub-options.
"""
        log(telemetry_ict_help_string)
