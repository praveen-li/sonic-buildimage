
#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2017
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

import sys
from verbosity import *
from cmdmgr import Command

# Command for reloading Python scripts

class ReloadCmd(Command):
    def __init__(self, cli):
        self.cli = cli
        super(ReloadCmd, self).__init__()

    def run_cmd(self, args):
        log_dbg(1, "in reloadcmd run")

        if args.strip() != "reload":
            log_dbg(1, "reload cmd called with non-zero arguments")
            return 1

        try:
            self.cli.init_cmds()
        except Exception as ex:
            log_dbg(
                1, "Exception in reload [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            log("Reload failed: {}".format(ex))
        except:
            log_dbg(
                1, "OtherError in reload [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            log("Reload failed")

        return 0
