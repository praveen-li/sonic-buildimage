
#-------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------

import shlex
import argparse
import sys
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import itertools
import time
import json
from collections import OrderedDict
ifcs_ctypes = sys.modules['ifcs_ctypes']

 


def gblcbfn(node_id):
    log("pen access GBL callback ...")


class penType(object):
    '''Base class that defines a PEN type'''

    def __init__(self, cli, pen_id):
        self.cli = cli
        self.pen_id = pen_id
        self.rw_entry = ifcs_ctypes.tentry_new(pen_id, -1, -1)
        ifcs_ctypes.tentry_clear(self.rw_entry)

    def __del__(self):
        ifcs_ctypes.tentry_free(self.rw_entry)
        return

    def parseArgs(self, cmd, arg_list):
        '''Parse Arguments for a given Command'''
        parser = argparse.ArgumentParser(prog="shell/ifcsshell.py")
        parser.add_argument('cmd')
        parser.add_argument('subcmd')
        parser.add_argument('ib')
        parser.add_argument('ib_id', default=0)

        is_pic_in_args = True if 'pic' == arg_list.split()[4] else False

        if is_pic_in_args:
            parser.add_argument('pic')
            parser.add_argument('pic_id', type=int, default=0)

        parser.add_argument('pen_name', type=str)

        if cmd == "write" or cmd == "modify":
            parser.add_argument('index', type=int)
            parser.add_argument("fld_val", nargs='*')

        if cmd == "read":
            parser.add_argument('index', type=int)
            parser.add_argument('n', nargs='?', type=int, default=1)
            parser.add_argument('filter', nargs='*')
            parser.add_argument(
                'filter_val',
                nargs='*',
                type=str,
                default=None)
            parser.add_argument("fields", nargs='*')

        if cmd == "dump":
            parser.add_argument('filter')
            parser.add_argument('filter_val', type=str, default=None)
            parser.add_argument("fields", nargs='*')

        parsed_res = parser.parse_args(arg_list.split())

        # node isn command for pic expects the pic id to
        # to be encoded within the ib_id, as there is no
        # seperate parameter for pic id.
        if is_pic_in_args:
            ib_id = (parsed_res.pic_id << 4) | int(parsed_res.ib_id)
            setattr(parsed_res, 'ib_id', ib_id)

        if parsed_res.ib_id == 'all':
            setattr(parsed_res, 'ib_id', 31)

        log_dbg(1, "parsed res " + str(parsed_res))
        return parsed_res

    def get_epp_fields(self, fldinfo):
        '''Get EPP Fields '''

        profile_pointer = self.get_epp()

        # Get the profile ID used
        rd_val = c_uint32(0)
        rc = ifcs_ctypes.tentry_get_item(
            0,
            self.pen_id,
            profile_pointer,
            ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
            self.rw_entry,
            pointer(rd_val))
        if rc == ifcs_ctypes.IFCS_NOTFOUND:
            # Some PENs don't have EPP Pointer fields, assume profile ID = 0
            rd_val.value = 0
        else:
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN tentry get(EPP) failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

        ep_profile_id = rd_val.value
        if ep_profile_id >= fldinfo.num_ep_profiles:
            log('EP Profile ID(' + str(ep_profile_id) + ') configured is greater than Num Profiles(' \
                + str(fldinfo.num_ep_profiles) + ')')
            return []

        # list of profiles
        ep_profile_list = cast(fldinfo.ep_profile, POINTER(ifcs_ctypes.ep_profile_list_t))

        # Configured Profile
        ep_profile = ep_profile_list[ep_profile_id]

        # Fields in the profile
        ep_fld = ep_profile.ep_profiles
        efld_val = []
        rd_val = c_uint32(0)
        for action in range(ep_profile.num_actions):
            # Get Field Name
            buflen = 64
            namebuf = create_string_buffer(buflen)
            rc = 0
            rc = ifcs_ctypes.node_get_pen_field_name(
                0, ep_fld[action].fname, ifcs_ctypes.String(namebuf), buflen)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN get field failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

            if (ep_fld[action].width <= 32):
                rc = ifcs_ctypes.tentry_get_efield_item(
                    0,
                    self.pen_id,
                    fldinfo.fname,
                    0,
                    ep_fld[action].fname,
                    ep_profile_id,
                    ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                    self.rw_entry,
                    pointer(rd_val))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("PEN tentry get failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                    return rc

                efld_val.append((compat_bytesToStr(namebuf.value), hex(rd_val.value)))
            else:
                buf = (c_ubyte * 256)(0)
                nbytes = compat_division((ep_fld[action].width + 7), 8)
                rc = ifcs_ctypes.tentry_get_efield_item(
                    0,
                    self.pen_id,
                    fldinfo.fname,
                    0,
                    ep_fld[action].fname,
                    ep_profile_id,
                    ifcs_ctypes.TENTRY_FLD_TYPE_ANY,
                    self.rw_entry,
                    compat_pointer(buf, c_ubyte))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("PEN tentry get failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                    return rc
                data = ":".join("{0:02x}".format(c) for c in buf[0:nbytes])
                efld_val.append((compat_bytesToStr(namebuf.value), data))
        return efld_val

    def get_mk_fields(self, fldinfo):
        '''Get MK Fields '''

        profile_pointer = self.get_mkid()

        # Get the profile ID used
        rd_val = c_uint32(0)
        rc = ifcs_ctypes.tentry_get_item(
            0,
            self.pen_id,
            profile_pointer,
            ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
            self.rw_entry,
            pointer(rd_val))
        if rc == ifcs_ctypes.IFCS_NOTFOUND:
            # Some PENs don't have MK Pointer fields, assume profile ID = 0
            rd_val.value = 0
        else:
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN tentry get(MKP) " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

        mk_profile_id = rd_val.value
        if mk_profile_id >= fldinfo.num_mk_profiles:
            log('MK Profile ID(' + str(mk_profile_id) + ') configured is greater than Num Profiles(' \
                + str(fldinfo.num_mk_profiles) + ')')
            return []

        # list of profiles
        mk_profile_list = cast(fldinfo.mk_profile, POINTER(ifcs_ctypes.mk_profile_list_t))

        # Configured Profile
        mk_profile = mk_profile_list[mk_profile_id]

        # Fields in the profile
        mk_fld = mk_profile.fields
        efld_val = []
        rd_val = c_uint32(0)
        for field in range(mk_profile.num_fields):
            # Get Field Name
            buflen = 64
            namebuf = create_string_buffer(buflen)
            rc = 0
            rc = ifcs_ctypes.node_get_pen_field_name(
                0, mk_fld[field].fname, ifcs_ctypes.String(namebuf), buflen)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN get field failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

            if (mk_fld[field].width <= 32):
                rc = ifcs_ctypes.tentry_get_efield_item(0, self.pen_id,
                                            fldinfo.fname, 1,
                                            mk_fld[field].fname, mk_profile_id,
                                            ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                                            self.rw_entry, pointer(rd_val))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("PEN tentry get failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                    return rc
                efld_val.append((compat_bytesToStr(namebuf.value), hex(rd_val.value)))
            else:
                buf = (c_ubyte * 256)(0)
                nbytes = compat_division((mk_fld[field].width + 7), 8)
                rc = ifcs_ctypes.tentry_get_efield_item(0, self.pen_id,
                                            fldinfo.fname, 1,
                                            mk_fld[field].fname, mk_profile_id,
                                            ifcs_ctypes.TENTRY_FLD_TYPE_ANY,
                                            self.rw_entry, compat_pointer(buf, c_ubyte))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("PEN tentry get failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                    return rc
                data = ":".join("{0:02x}".format(c) for c in buf[0:nbytes])
                efld_val.append((compat_bytesToStr(namebuf.value), data))
        return efld_val

    # Apply Filters
    def display_apply_filters(
            self,
            pen,
            fld_name,
            fld_val,
            default=None,
            filters=None):
        '''Apply Display Filters on the PEN, Fld_name
           Supported Filters:
           nz = Field with Zero Values filtered out
           nd = Field with Default Values filered out
           Returns True when Filtered out, False Otherwise
        '''
        if filters is None:
            return False

        if filters == 'nz':
            if isinstance(fld_val, int) and fld_val == 0:
                return True
            else:
                if not isinstance(fld_val, int):
                    if len([i for i in fld_val.split(
                            ":") if int(i, 16) != 0]) == 0:
                        return True
            return False

    def display_raw(self, ib, index, pentype='R'):
        '''Display hex dump of entries, sample below. This lines up with pendump_app

            0 : T :    373 :                         IMT20_MKC :      1 :     4 : 0x08133202 0x00000000 0x04008010 0x02000000
            0 : R :    125 :                         SIBP_ATTR :      0 :     1 : 0x00001000
        '''

        # Get pen name from the code
        buflen = 256
        namebuf = create_string_buffer(buflen)
        try:
            ifcs_ctypes.node_get_pen_name(
                0, self.pen_id, ifcs_ctypes.String(namebuf), buflen)
        except Exception as ex:
            # default to the penid if we run into some error
            namebuf.value = str(self.pen_id)

        # Find the last non-zero word or at least one word, tentry buffer is 128 words wide, unfortunately there
        # is no constant (#define) for it
        max_nzWordIndex = 0
        for idx in range(0, 128):
            if self.rw_entry.contents.buf[idx] != 0:
                max_nzWordIndex = idx

        # Save at least one value at the minimum
        max_nzWordIndex += 1

        # Prepare fixed part of the line
        linebuffer = "%2X : %1s : %6d : %33s : %6d : %6d :" % (ib, pentype, self.pen_id, namebuf.value, index, max_nzWordIndex)

        # Append the variable number of words
        for idx in range(0, max_nzWordIndex):
            linebuffer += " 0x%08x" % self.rw_entry.contents.buf[idx]

        # Output the line
        log(linebuffer)

    def display(self, type="col", filters=None, fields=None, display_buf=None):
        '''Display PEN contents for given set of fields'''

        nflds, fldinfo = self.get_flds_from_id(self.pen_id)

        fld_val = []
        jdata = OrderedDict()

        # Get the list of fields for this pen
        for j in range(nflds.value):
            try:
                pen_fldid, pen_fldname = self.get_fld_id_name_from_str(
                    fldinfo[j].fname)
            except Exception as ex:
                log("get_pen_field: ", type(ex).__name__, ex.args)
                return ifcs_ctypes.IFCS_NOTFOUND

            # Obtain Field Value
            rd_val = c_uint32(0)
            if (fldinfo[j].width <= 32):
                rc = ifcs_ctypes.tentry_get_item(
                    0,
                    self.pen_id,
                    fldinfo[j].fname,
                    ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                    self.rw_entry,
                    pointer(rd_val))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("PEN tentry get failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                    return rc
                data = int(rd_val.value)
            else:
                buf = (c_ubyte * 256)(0)
                nbytes = compat_division((fldinfo[j].width + 7), 8)
                rc = ifcs_ctypes.tentry_get_item(
                    0,
                    self.pen_id,
                    fldinfo[j].fname,
                    ifcs_ctypes.TENTRY_FLD_TYPE_ANY,
                    self.rw_entry,
                    compat_pointer(buf, c_ubyte))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("PEN tentry get failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                    return rc
                data = ":".join("{0:02x}".format(c) for c in buf[0:nbytes])
            fld_val.append((pen_fldname, data))

        display_only_flds = []
        # Check if user provided field-value matches the PEN contents
        if fields:
            # First Level Filter to skip PENs that don't match user provided
            # Field=Val constraints
            for i in range(len(fld_val)):
                try:
                    display_value = fields[fld_val[i][0]]
                    if display_value is not None:
                        try:
                            if str(fld_val[i][1]) != display_value:
                                return
                        except BaseException:
                            if str(fld_val[i][1]) is not display_value:
                                return
                except BaseException:
                    continue

            # Select only Fields that User want
            for i in range(len(fld_val)):
                try:
                    display_value = fields[fld_val[i][0]]
                    if display_value is None:
                        display_only_flds.append(fld_val[i][0])
                except BaseException:
                    continue

        # If user selected Fields then Trim the FLD value list to selected few
        if len(display_only_flds):
            for i in range(len(fld_val)):
                for j in range(len(display_only_flds)):
                    if display_only_flds[j] != fld_val[i][0]:
                        fld_val[i] = (None, None)
                        break

        # Apply non-Zero Filters
        for i in range(len(fld_val)):
            if fld_val[i][0] is not None:
                if self.display_apply_filters(
                        self.pen_id,
                        fld_val[i][0],
                        fld_val[i][1],
                        filters=filters) is True:
                    # Remove Fields from the List
                    fld_val[i] = (None, None)

        if type == "col":
            for i in range(len(fld_val)):
                if fld_val[i][0] is not None:
                    jdata[fld_val[i][0]] = fld_val[i][1]

        if type == "raw":
            for i in range(len(fld_val)):
                if fld_val[i][0] is not None:
                    jdata[fld_val[i][0]] = fld_val[i][1]

        if self.cli.redirect_fd:
            if display_buf is not None:
                self.cli.redirect_fd.write(display_buf)
            self.cli.redirect_fd.write(json.dumps(jdata, indent=4))

        if len(jdata):
            if display_buf is not None:
                log(display_buf)
            log(json.dumps(jdata, indent=4))
        else:
            return

 
        if self.cli.redirect_fd:
            self.cli.redirect_fd.write('\n')
        log('\n')
        return

    def setup(self, arg_list):
        '''Setup PEN for write/insert/delete/lookup operations'''
        nflds, fldinfo = self.get_flds_from_id(self.pen_id)
        while True:
            try:
                field = arg_list.pop(0)
            except BaseException:
                break
            try:
                value = arg_list.pop(0)
            except BaseException:
                return ifcs_ctypes.IFCS_SUCCESS
            try:
                penfld_id = self.get_fld_id_from_str(field)
            except Exception as ex:
                log(type(ex).__name__, ex.args)
                return ifcs_ctypes.IFCS_PARAM

            if (quiet() == 0):
                log("set", field, "=", value)
            if (penfld_id == ifcs_ctypes.FUNC_DISABLE_F):
                fn_dsb = int(value)

            # set the field using tentry API
            field_width = -1
            for j in range(nflds.value):
                if (fldinfo[j].fname == penfld_id):
                    field_width = fldinfo[j].width
                    break

            if (field_width == -1):
                log("Error: Field", field, "does not exist in pen", pen_name)
                return ifcs_ctypes.IFCS_SUCCESS

            # Field width
            if (field_width <= 32):
                wr_val = c_int(0)
                wr_val.value = int(value, 0)
                try:
                    rc = ifcs_ctypes.tentry_set_item(0, self.pen_id, penfld_id,
                                         ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                                         self.rw_entry, pointer(wr_val))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("PEN tentry set failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                        return rc
                except Exception as ex:
                    log("tentry_set: ", type(ex).__name__, ex.args)
                    return ifcs_ctypes.IFCS_PARAM
            else:
                nbytes = compat_division((field_width + 7), 8)
                try:
                    byteval = value.split(':')
                    assert len(
                        byteval) <= nbytes, "field value length too long"
                except Exception as ex:
                    log(type(ex).__name__, ex.args)
                    return ifcs_ctypes.IFCS_PARAM

                buf = (c_ubyte * 512)(0)
                for n in range(len(byteval)):
                    buf[n] = int(byteval[n], 16)

                rc = ifcs_ctypes.tentry_set_item(0, self.pen_id, penfld_id,
                                     ifcs_ctypes.TENTRY_FLD_TYPE_ANY,
                                     self.rw_entry, compat_pointer(buf, c_ubyte))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("PEN tentry set failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                    return rc

    # ----------
    # Pen helper
    # ----------
    def _id_name_from_str(self, pen_str):
        try:
            pen_id = int(pen_str)
            pen_name = pennum_str[pen_id]
        except ValueError:
            try:
                pen_id = penstr_num_dict[pen_str.upper()]
                pen_name = pen_str.upper()
            except KeyError:
                pen_id = -1
                pen_name = pen_str.upper()
                log('Invalid PEN name ' + pen_name)
        return pen_id, pen_name

    def _fld_id_name_from_str(self, penfld_str):
        try:
            penfld_id = int(penfld_str)
            field_name = penfldnum_str[penfld_id]
        except ValueError:
            try:
                penfld_id = penfldstr_num_dict[penfld_str.upper()]
                field_name = penfld_str.upper()
            except KeyError:
                penfld_id = -1
                field_name = penfld_str.upper()
                log('Invalid PEN field name ' + penfld_str)
        return penfld_id, field_name

    def _fld_id_from_str(self, penfld_str):
        try:
            penfld_id = int(penfld_str)
        except ValueError:
            try:
                penfld_id = penfldstr_num_dict[penfld_str.upper()]
            except KeyError:
                log('Invalid PEN field name ' + field_name)
                penfld_id = -1
        return penfld_id

    def get_area_id_name_from_str(self, area_str):
        buflen = 64
        namebuf = create_string_buffer(buflen)
        namebuf.value = b"unknown"
        area_name = c_char_p(compat_strToBytes(area_str)).value
        area_num = c_int()
        ifcs_ctypes.node_get_area_id(0, byref(area_num), area_name.upper())
        area_id = area_num.value
        if (area_id == -1):
            try:
                area_id = int(area_name)
            except ValueError:
                self.cli.error()
                log('Invalid area name ' + compat_bytesToStr(area_name))
                return
            # get the area name string
            try:
                ifcs_ctypes.node_get_area_name(0, area_id, ifcs_ctypes.String(namebuf), buflen)
            except Exception as ex:
                log(type(ex).__name__, ex.args)
                self.cli.error()
            area_name = namebuf.value
        return area_id, compat_bytesToStr(area_name)

    def get_id_name_from_str(self, pen_str):
        buflen = 64
        namebuf = create_string_buffer(buflen)
        namebuf.value = b"unknown"
        pen_name = c_char_p(compat_strToBytes(pen_str)).value
        pen_num = c_int()
        ifcs_ctypes.node_get_pen_id(0, byref(pen_num), pen_name.upper())
        pen_id = pen_num.value
        if (pen_id == -1):
            try:
                pen_id = int(pen_name)
            except ValueError:
                self.cli.error()
                log('Invalid PEN name ' + compat_bytesToStr(pen_name))
                return
            # get the pen name string
            try:
                ifcs_ctypes.node_get_pen_name(0, pen_id, ifcs_ctypes.String(namebuf), buflen)
            except Exception as ex:
                log(type(ex).__name__, ex.args)
                self.cli.error()
            pen_name = namebuf.value
        return pen_id, compat_bytesToStr(pen_name)

    def get_fld_id_name_from_str(self, penfld_id):
        buflen = 64
        namebuf = create_string_buffer(buflen)
        namebuf.value = b"unknown"
        try:
            penfld_id = int(penfld_id)
        except ValueError:
            self.cli.error()
            log('Invalid PEN field' + penfld_id)
            return
        # get the pen field name string
        try:
            ifcs_ctypes.node_get_pen_field_name(0, penfld_id, ifcs_ctypes.String(namebuf), buflen)
        except Exception as ex:
            self.cli.error()
            log(type(ex).__name__, ex.args)
        field_name = compat_bytesToStr(namebuf.value)
        return penfld_id, field_name

    def get_fld_id_from_str(self, penfld_str):
        field_name = c_char_p(compat_strToBytes(penfld_str)).value
        fld_num = c_int()
        ifcs_ctypes.node_get_pen_field_id(0, byref(fld_num), field_name.upper())
        penfld_id = fld_num.value
        if (penfld_id == -1):
            log('Invalid PEN field name ' + compat_bytesToStr(field_name))
        return penfld_id

    def get_flds_from_id(self, pen_id):
        peninfo = ifcs_ctypes.pen_t()
        ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
        nflds = c_uint()
        nflds.value = peninfo.num_flds
        fldinfo = (ifcs_ctypes.pen_field_t * nflds.value)()
        try:
            ifcs_ctypes.node_get_pen_fields(
                0,
                pen_id,
                pointer(peninfo),
                byref(nflds),
                compat_pointer(fldinfo, ifcs_ctypes.pen_field_t))
        except Exception as ex:
            self.cli.error()
            log(type(ex).__name__, ex.args)
        return nflds, fldinfo

    def is_pen_rd_clr(self, pen_id):
        peninfo = ifcs_ctypes.pen_t()
        ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
        pattr = peninfo.attributes
        if pattr & ifcs_ctypes.PA_CNTR:
            return True
        else:
            return False

class directIndexPen(penType):
    def __init__(self, cli, pen_id):
        super(directIndexPen, self).__init__(cli, pen_id)

    def read(self, arg_list):
        '''Direct Index Pen Read'''
        if (quiet() == 0):
            log("-> direct INDEX read")

        # Parse Arguments
        parsed_res = self.parseArgs("read", arg_list)

        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        index = parsed_res.index
        ib = int(parsed_res.ib_id)
        hints = 0
        rc = ifcs_ctypes.IFCS_SUCCESS

        peninfo = ifcs_ctypes.pen_t()
        rc = ifcs_ctypes.node_get_pen_info(0, self.pen_id, pointer(peninfo))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return rc

        '''
        if index > peninfo.num_entries and index > peninfo.size:
            log_err("Index " +
                    str(index) +
                    " out of range. Max range for this pen is " +
                    str(peninfo.num_entries))
            return ifcs_ctypes.IFCS_PARAM
        '''

        num_entries = parsed_res.n
        for i in range(num_entries):
            rc = ifcs_ctypes.node_isn_pen_read(
                0, int(ib), self.pen_id, index, hints, self.rw_entry)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

            if 'raw' in parsed_res.filter:
                self.display_raw(ib, index)
            else:
                buf = "[" + "IB(" + str(ib) + "):" + "ID(" + str(index) + ")]->"
                self.display(
                    filters=parsed_res.filter_val,
                    fields=display_flds,
                    display_buf=buf)
            index += 1
        return rc

    def readclear(self, arg_list):
        '''Direct Index Pen Read Clear'''
        if (quiet() == 0):
            log("-> direct INDEX read clear")

        # Parse Arguments
        parsed_res = self.parseArgs("read", arg_list)

        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        index = parsed_res.index
        ib = int(parsed_res.ib_id)
        hints = 0
        rc = ifcs_ctypes.IFCS_SUCCESS

        peninfo = ifcs_ctypes.pen_t()
        rc = ifcs_ctypes.node_get_pen_info(0, self.pen_id, pointer(peninfo))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return rc

        num_entries = parsed_res.n
        for i in range(num_entries):
            rc = ifcs_ctypes.node_isn_pen_read_clear(
                0, int(ib), self.pen_id, index, hints, self.rw_entry)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN read clear failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

            buf = "[" + "IB(" + str(ib) + "):" + "ID(" + str(index) + ")]->"
            self.display(
                filters=parsed_res.filter_val,
                fields=display_flds,
                display_buf=buf)
            index += 1
        return rc

    def dump(self, arg_list):
        '''Direct Index Pen Dump'''
        log_dbg(1, "In direct index pen dump")

        # Parse Arguments
        parsed_res = self.parseArgs("dump", arg_list)
        ib = int(parsed_res.ib_id)
        hints = 0
        rc = ifcs_ctypes.IFCS_SUCCESS

        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        # Get number of entries from the PEN
        peninfo = ifcs_ctypes.pen_t()
        rc = ifcs_ctypes.node_get_pen_info(0, self.pen_id, pointer(peninfo))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return rc

        num_entries = peninfo.num_entries
        for index in range(num_entries):
            ifcs_ctypes.tentry_clear(self.rw_entry)
            rc = ifcs_ctypes.node_isn_pen_read(
                0, int(ib), self.pen_id, index, hints, self.rw_entry)

            buf = "[" + "IB(" + str(ib) + "):" + "IDX(" + str(index) + ")]->"
            self.display(
                filters=parsed_res.filter_val,
                fields=display_flds,
                display_buf=buf)
        return rc

    def write(self, arg_list):
        '''Direct Index Pen Write'''

        # Parse Arguments
        parsed_res = self.parseArgs("write", arg_list)

        index = parsed_res.index
        ib = int(parsed_res.ib_id)
        hints = 0

        self.setup(parsed_res.fld_val)

        if (quiet() == 0):
            log("-> Direct INDEX write")

        rc = ifcs_ctypes.node_isn_pen_write(0, ib, self.pen_id, index, hints,
                                self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN write failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc
        return rc

    def modify(self, arg_list):
        '''Direct Index Pen Modify'''

        # Parse Arguments
        parsed_res = self.parseArgs("modify", arg_list)

        index = parsed_res.index
        ib = int(parsed_res.ib_id)
        hints = 0

        # Read the PEN
        rc = ifcs_ctypes.node_isn_pen_read(
            0, ib, self.pen_id, index, hints, self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        # Update the fields
        self.setup(parsed_res.fld_val)

        # Write to Update PEN
        rc = ifcs_ctypes.node_isn_pen_write(0, ib, self.pen_id, index, hints,
                                self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN write failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc
        return rc

    def get_epp(self):
        '''Get EPP Field '''
        return DATA_EPP_F


class bcamPen(directIndexPen):
    '''BCAM Index Pen'''

    def __init__(self, cli, pen_id):
        self.cli = cli
        super(bcamPen, self).__init__(cli, pen_id)

    def read(self, arg_list):
        return super(bcamPen, self).read(arg_list)

    def dump(self, arg_list):
        return super(bcamPen, self).dump(arg_list)

    def write(self, arg_list):
        return super(bcamPen, self).write(arg_list)

    def modify(self, arg_list):
        return super(bcamPen, self).modify(arg_list)


class directTcamPen(directIndexPen):
    '''Direct TCAM Pen'''

    def __init__(self, cli, pen_id):
        self.cli = cli
        super(directTcamPen, self).__init__(cli, pen_id)

    def read(self, arg_list):
        return super(directTcamPen, self).read(arg_list)

    def dump(self, arg_list):
        return super(directTcamPen, self).dump(arg_list)

    def write(self, arg_list):
        return super(directTcamPen, self).write(arg_list)

    def modify(self, arg_list):
        return super(directTcamPen, self).modify(arg_list)


class indirectIndexPen(directIndexPen):
    '''Indirect Index Pen'''

    def __init__(self, cli, pen_id):
        self.cli = cli
        super(indirectIndexPen, self).__init__(cli, pen_id)

    def get_epp(self):
        '''Get EPP Field '''
        return DATA_EPP_F

    def get_mkid(self):
        '''Get MK Field '''
        assert False, "Match Keys are not supported"

    def read(self, arg_list):
        return super(indirectIndexPen, self).read(arg_list)

    def dump(self, arg_list):
        return super(indirectIndexPen, self).dump(arg_list)

    def write(self, arg_list):
        return super(indirectIndexPen, self).write(arg_list)

    def modify(self, arg_list):
        return super(indirectIndexPen, self).modify(arg_list)


class ilpmPen(penType):
    def __init__(self, cli, pen_id):
        self.cli = cli
        super(ilpmPen, self).__init__(cli, pen_id)

    def parseArgs(self, cmd, arg_list):
        '''Parse Arguments for a given Command'''

        parser = argparse.ArgumentParser(prog="shell/ifcsshell.py")
        parser.add_argument('cmd')
        parser.add_argument('subcmd')
        parser.add_argument('ib')
        parser.add_argument('ib_id', type=int, default=0)

        parser.add_argument('pen_name')

        # For Read and Write get the actual Function, Bucket and Slot
        if cmd == "write" or cmd == "read" or cmd == "modify":
            parser.add_argument('fid', type=int)
            parser.add_argument('bid', type=int)
            parser.add_argument('sid', type=int)

        if cmd == "read":
            parser.add_argument('filter', nargs='?')
            parser.add_argument(
                'filter_val',
                nargs='?',
                type=str,
                default=None)
            parser.add_argument("fields", nargs='?')

        if cmd == "write" or cmd == "modify":
            parser.add_argument("fld_val", nargs='+')

        if cmd == "dump":
            parser.add_argument('filter')
            parser.add_argument('filter_val', type=str, default=None)
            parser.add_argument("fields", nargs='*')

        parsed_res = parser.parse_args(arg_list.split())

        return parsed_res

    def get_epp(self):
        '''Get EPP Field '''
        return ifcs_ctypes.ENTRY_EPP_F

    def get_mkid(self):
        '''Get MK Field '''
        return ifcs_ctypes.ENTRY_MKID_F

    def index(self, function, bucket, slot):
        '''Map Function ID, Bucket Id and Slot Id to Index'''
        return ifcs_ctypes.HASH_TO_INDEX(function, bucket, slot)

    def read(self, arg_list):

        # Parse Arguments
        parsed_res = self.parseArgs("read", arg_list)

        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        fid = parsed_res.fid
        bid = parsed_res.bid
        sid = parsed_res.sid
        ib = int(parsed_res.ib_id)

        if (quiet() == 0):
            log("-> ILPM read")

        index = self.index(fid, bid, sid)
        hash_fn = fid
        bktmd = c_uint(0)
        rtnid = c_uint(index)

        rc = ifcs_ctypes.node_isn_pen_ilpm_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_ILPM_READ,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN ILPM read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        buf = "[" + "IB(" + str(ib) + "):" + "F:(" + str(fid) + \
            ") B:(" + str(bid) + ") S:(" + str(sid) + ")]->"
        self.display(fields=display_flds, display_buf=buf)
        return rc

    def dump(self, arg_list):
        log_dbg(1, "In ilpm pen dump")
        # Parse Arguments
        parsed_res = self.parseArgs("dump", arg_list)
        ib = int(parsed_res.ib_id)

        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        # Get number of entries from the PEN
        peninfo = ifcs_ctypes.pen_t()
        rc = ifcs_ctypes.node_get_pen_info(0, self.pen_id, pointer(peninfo))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return rc

        if (peninfo.pen_prop):
            propinfo = ifcs_ctypes.pen_prop_t()
            ifcs_ctypes.node_get_pen_prop(
                0,
                self.pen_id,
                pointer(peninfo),
                pointer(propinfo))
            num_slots = propinfo.slots_per_bucket
            num_buckets = propinfo.size

        for fid in range(2):
            for bid in range(num_buckets):
                for sid in range(num_slots):
                    ifcs_ctypes.tentry_clear(self.rw_entry)
                    index = self.index(fid, bid, sid)
                    hash_fn = fid
                    bktmd = c_uint(0)
                    rtnid = c_uint(index)

                    rc = ifcs_ctypes.node_isn_pen_ilpm_cmd(0,
                                               ib,
                                               int(self.pen_id),
                                               ifcs_ctypes.ISN_CMD_ILPM_READ,
                                               pointer(rtnid),
                                               byref(bktmd),
                                               self.rw_entry)

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("PEN ILPM read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                        return rc

                    buf = "[" + "IB(" + str(ib) + "):" + "F:(" + str(fid) + \
                        ") B:(" + str(bid) + ") S:(" + str(sid) + ")]->"
                    self.display(
                        filters=parsed_res.filter_val,
                        fields=display_flds,
                        display_buf=buf)
        return rc

    def write(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect ILPM write")

        # Parse Arguments
        parsed_res = self.parseArgs("write", arg_list)

        fid = parsed_res.fid
        bid = parsed_res.bid
        sid = parsed_res.sid
        ib = parsed_res.ib_id

        index = self.index(fid, bid, sid)
        hash_fn = fid
        bktmd = c_uint(0)
        rtnid = c_uint(index)

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_ilpm_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_ILPM_WRITE,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN ILPM write failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        return rc

    def modify(self, arg_list):

        # Parse Arguments
        parsed_res = self.parseArgs("modify", arg_list)

        fid = parsed_res.fid
        bid = parsed_res.bid
        sid = parsed_res.sid
        ib = parsed_res.ib_id

        if (quiet() == 0):
            log("-> Indirect ILPM modify")

        index = self.index(fid, bid, sid)
        hash_fn = fid
        bktmd = c_uint(0)
        rtnid = c_uint(index)

        rc = ifcs_ctypes.node_isn_pen_ilpm_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_ILPM_READ,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN ILPM read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_ilpm_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_ILPM_WRITE,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN ILPM write failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc
        return rc


class hashPen(penType):
    '''Hash Pen Type'''

    def __init__(self, cli, pen_id):
        self.cli = cli
        super(hashPen, self).__init__(cli, pen_id)

    def parseArgs(self, cmd, arg_list):
        '''Parse Arguments for a given Command'''

        log_dbg(1, "hashPen: In parseArgs with cmd: " + cmd)
        parser = argparse.ArgumentParser(prog="shell/ifcsshell.py")
        parser.add_argument('cmd')
        parser.add_argument('subcmd')
        parser.add_argument('ib')
        parser.add_argument('ib_id', type=int, default=0)
        parser.add_argument('pen_name')

        # For Read and Write get the actual Function, Bucket and Slot
        if cmd == "write" or cmd == "read" or cmd == "modify":
            parser.add_argument('fid', type=int)
            parser.add_argument('bid', type=int)
            parser.add_argument('sid', type=int)

        # For Insert, delete, Lookup, need left or Right.
        if cmd == "insert" or cmd == "delete" or cmd == "lookup":
            parser.add_argument(
                '--fn',
                type=str,
                choices=[
                    'left',
                    'right',
                    'both'],
                help='Choice of function to insert')

        if cmd == "write" or cmd == "modify" or \
           cmd == "insert" or cmd == "delete" or \
           cmd == "lookup":
            parser.add_argument("fld_val", nargs='+')

        if cmd == "dump":
            parser.add_argument('filter')
            parser.add_argument('filter_val', type=str, default=None)
            parser.add_argument("fields", nargs='*')

        parsed_res = parser.parse_args(arg_list.split())

        return parsed_res

    def get_epp(self):
        '''Get EPP Field '''
        return ifcs_ctypes.ENTRY_EPP_F

    def get_mkid(self):
        '''Get MK Field '''
        return ifcs_ctypes.ENTRY_MKID_F

    def index(self, function, bucket, slot):
        '''Map Function ID, Bucket Id and Slot Id to Index'''
        return ifcs_ctypes.HASH_TO_INDEX(function, bucket, slot)

    def read(self, arg_list):

        # Parse Arguments
        parsed_res = self.parseArgs("read", arg_list)

        fid = parsed_res.fid
        bid = parsed_res.bid
        sid = parsed_res.sid
        ib = int(parsed_res.ib_id)

        if (quiet() == 0):
            log("-> Indirect HASH read")

        index = self.index(fid, bid, sid)
        hash_fn = fid
        bktmd = c_uint(0)
        rtnid = c_uint(index)

        rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_HASH_READ,
                                   hash_fn,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN Hash read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc
        log("[" + "IB(" + str(ib) + "):" + "F:(" + str(fid) + ") B:(" + str(bid) + ") S:(" + str(sid) + ")]->")
        self.display()
        return rc

    def dump(self, arg_list):
        log_dbg(1, "In hash pen dump")
        # Parse Arguments
        parsed_res = self.parseArgs("dump", arg_list)
        ib = int(parsed_res.ib_id)

        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        # Get number of entries from the PEN
        peninfo = ifcs_ctypes.pen_t()
        rc = ifcs_ctypes.node_get_pen_info(0, self.pen_id, pointer(peninfo))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return rc

        if (peninfo.pen_prop):
            propinfo = ifcs_ctypes.pen_prop_t()
            ifcs_ctypes.node_get_pen_prop(
                0,
                self.pen_id,
                pointer(peninfo),
                pointer(propinfo))
            num_slots = propinfo.slots_per_bucket
            num_buckets = propinfo.size
            if num_buckets == -1:
                num_buckets = propinfo.size_max

        for fid in range(2):
            for bid in range(num_buckets):
                for sid in range(num_slots):
                    ifcs_ctypes.tentry_clear(self.rw_entry)
                    index = self.index(fid, bid, sid)
                    hash_fn = fid
                    bktmd = c_uint(0)
                    rtnid = c_uint(index)

                    rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                               ib,
                                               int(self.pen_id),
                                               ifcs_ctypes.ISN_CMD_HASH_READ,
                                               hash_fn,
                                               pointer(rtnid),
                                               byref(bktmd),
                                               self.rw_entry)
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("PEN Hash dump failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                        return rc
                    buf = "[" + "IB(" + str(ib) + "):" + "F:(" + str(fid) + \
                        ") B:(" + str(bid) + ") S:(" + str(sid) + ")]->"
                    self.display(
                        filters=parsed_res.filter_val,
                        fields=display_flds,
                        display_buf=buf)
        return rc

    def write(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect HASH write")

        # Parse Arguments
        parsed_res = self.parseArgs("write", arg_list)

        fid = parsed_res.fid
        bid = parsed_res.bid
        sid = parsed_res.sid
        ib = parsed_res.ib_id

        index = self.index(fid, bid, sid)
        hash_fn = fid
        bktmd = c_uint(0)
        rtnid = c_uint(index)

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_HASH_WRITE,
                                   hash_fn,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN Hash write failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc
        return rc

    def modify(self, arg_list):

        # Parse Arguments
        parsed_res = self.parseArgs("modify", arg_list)

        fid = parsed_res.fid
        bid = parsed_res.bid
        sid = parsed_res.sid
        ib = parsed_res.ib_id

        if (quiet() == 0):
            log("-> Indirect HASH modify")

        index = self.index(fid, bid, sid)
        hash_fn = fid
        bktmd = c_uint(0)
        rtnid = c_uint(index)

        rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_HASH_READ,
                                   hash_fn,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN Hash read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_HASH_WRITE,
                                   hash_fn,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN Hash write failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc
        self.display()
        return rc

    def insert(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect HASH insert")

        # Parse Arguments
        parsed_res = self.parseArgs("insert", arg_list)

        fn = parsed_res.fn
        ib = int(parsed_res.ib_id)

        # Select Left or Right or Both Sides
        hash_fn = 0
        if fn == 'left':
            hash_fn = 1
        if fn == 'right':
            hash_fn = 2

        bktmd = c_uint(0)
        rtnid = c_uint(0)
        index = 0

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_HASH_INSERT,
                                   hash_fn,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN Hash insert failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        if (quiet() == 0):
            log("Insert: fid = 0x%x" % ifcs_ctypes.INDEX_TO_FID(rtnid.value))
            log("      : bid = 0x%x" % ifcs_ctypes.INDEX_TO_BID(rtnid.value))
            log("      : sid = 0x%x" % ifcs_ctypes.INDEX_TO_SID(rtnid.value))

        self.display()
        return rc

    def lookup(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect HASH lookup")

        # Parse Arguments
        parsed_res = self.parseArgs("lookup", arg_list)

        fn = parsed_res.fn
        ib = parsed_res.ib_id

        # Select Left or Right or Both Sides
        hash_fn = 0
        if fn == 'left':
            hash_fn = 1
        if fn == 'right':
            hash_fn = 2

        bktmd = c_uint(0)
        rtnid = c_uint(0)
        index = 0

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_HASH_LOOKUP,
                                   hash_fn,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc == ifcs_ctypes.IFCS_NOTFOUND:
            log('Key not found in the hash table')
            return rc

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN Hash lookup failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        if (quiet() == 0):
            log("Lookup: fid = 0x%x" % ifcs_ctypes.INDEX_TO_FID(rtnid.value))
            log("      : bid = 0x%x" % ifcs_ctypes.INDEX_TO_BID(rtnid.value))
            log("      : sid = 0x%x" % ifcs_ctypes.INDEX_TO_SID(rtnid.value))

        self.display()
        return rc

    def delete(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect HASH delete")

        # Parse Arguments
        parsed_res = self.parseArgs("delete", arg_list)

        fn = parsed_res.fn
        ib = parsed_res.ib_id

        # Select Left or Right or Both Sides
        hash_fn = 0
        if fn == 'left':
            hash_fn = 1
        if fn == 'right':
            hash_fn = 2

        bktmd = c_uint(0)
        rtnid = c_uint(0)
        index = 0

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_hash_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_HASH_DELETE,
                                   hash_fn,
                                   pointer(rtnid),
                                   byref(bktmd),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN Hash delete failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        if (quiet() == 0):
            log("Delete: fid = 0x%x" % ifcs_ctypes.INDEX_TO_FID(rtnid.value))
            log("      : bid = 0x%x" % ifcs_ctypes.INDEX_TO_BID(rtnid.value))
            log("      : sid = 0x%x" % ifcs_ctypes.INDEX_TO_SID(rtnid.value))
        return rc


class indirectTcamPen(penType):
    '''Indirect TCAM Pen Type'''

    def __init__(self, cli, pen_id):
        self.cli = cli
        super(indirectTcamPen, self).__init__(cli, pen_id)

    def parseArgs(self, cmd, arg_list):
        '''Parse Arguments for a given Command'''

        parser = argparse.ArgumentParser(prog="shell/ifcsshell.py")
        parser.add_argument('cmd')
        parser.add_argument('subcmd')
        parser.add_argument('ib')
        parser.add_argument('ib_id', type=int, default=0)
        parser.add_argument('pen_name')

        # For Read and Write get the Index
        if cmd == "write" or cmd == "read" or cmd == "modify":
            parser.add_argument('index', type=int)

        if cmd == "write" or cmd == "modify" or \
           cmd == "lookup":
            parser.add_argument("fld_val", nargs='+')

        if cmd == "read":
            parser.add_argument('filter', nargs='*')
            parser.add_argument(
                'filter_val',
                nargs='*',
                type=str,
                default=None)
            parser.add_argument("fields", nargs='*')

        if cmd == "dump":
            parser.add_argument('filter')
            parser.add_argument('filter_val', type=str, default=None)
            parser.add_argument("fields", nargs='*')

        parser.add_argument('n', nargs='?', type=int, default=1)
        parsed_res = parser.parse_args(arg_list.split())

        return parsed_res

    def get_epp(self):
        '''Get EPP Field '''
        return DATA_EPP_F

    def get_mkid(self):
        '''Get MK Field '''
        return KEY_MKID_F

    def read(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect TCAM read")

        # Parse Arguments
        parsed_res = self.parseArgs("read", arg_list)

        index = parsed_res.index
        ib = int(parsed_res.ib_id)

        # Display PEN Fields
        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        num_entries = parsed_res.n
        for i in range(num_entries):
            rtnid = c_uint(index)
            rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0,
                                       ib,
                                       int(self.pen_id),
                                       ifcs_ctypes.ISN_CMD_TCAM_READ,
                                       pointer(rtnid),
                                       self.rw_entry)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN TCAM read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

            if 'raw' in parsed_res.filter:
                self.display_raw(ib, index, 'T')
            else:
                buf = "[" + "IB(" + str(ib) + "):" + "ID(" + str(index) + ")]->"
                self.display(
                    filters=parsed_res.filter_val,
                    fields=display_flds,
                    display_buf=buf)
            index += 1
        return rc

    def dump(self, arg_list):
        log_dbg(1, "In Indirect tcam pen dump")

        # Parse Arguments
        parsed_res = self.parseArgs("dump", arg_list)
        ib = int(parsed_res.ib_id)
        hints = 0
        rc = ifcs_ctypes.IFCS_SUCCESS

        # Display PEN Fields
        display_flds = dict()
        if parsed_res.fields:
            for fld_val in parsed_res.fields:
                try:
                    fld, val = fld_val.split("=")
                    display_flds[fld] = val
                except BaseException:
                    fld = fld_val
                    display_flds[fld] = None

        # Get number of entries from the PEN
        peninfo = ifcs_ctypes.pen_t()
        rc = ifcs_ctypes.node_get_pen_info(0, self.pen_id, pointer(peninfo))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return rc

        num_entries = peninfo.num_entries

        if num_entries == 1:
            if (peninfo.pen_prop):
                propinfo = ifcs_ctypes.pen_prop_t()
                ifcs_ctypes.node_get_pen_prop(
                    0,
                    self.pen_id,
                    pointer(peninfo),
                    pointer(propinfo))
                num_entries = propinfo.size

        for index in range(num_entries):
            rtnid = c_uint(index)
            rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0,
                                       ib,
                                       int(self.pen_id),
                                       ifcs_ctypes.ISN_CMD_TCAM_READ,
                                       pointer(rtnid),
                                       self.rw_entry)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN TCAM read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc
            buf = "[" + "IB(" + str(ib) + "):" + "ID(" + str(index) + ")]->",
            self.display(
                filters=parsed_res.filter_val,
                fields=display_flds,
                display_buf=buf)
        return rc

    def write(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect TCAM write")

        # Parse Arguments
        parsed_res = self.parseArgs("write", arg_list)

        index = parsed_res.index
        ib = parsed_res.ib_id

        bktmd = c_uint(0)
        rtnid = c_uint(index)

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_TCAM_WRITE,
                                   pointer(rtnid),
                                   self.rw_entry)
        self.display()
        return rc

    def modify(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect TCAM modify")

        # Parse Arguments
        parsed_res = self.parseArgs("modify", arg_list)

        index = parsed_res.index
        ib = parsed_res.ib_id

        rtnid = c_uint(index)
        rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_TCAM_READ,
                                   pointer(rtnid),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN TCAM read failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_TCAM_WRITE,
                                   pointer(rtnid),
                                   self.rw_entry)
        self.display()
        return rc

    def lookup(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect TCAM/ABB lookup")

        # Parse Arguments
        parsed_res = self.parseArgs("lookup", arg_list)

        ib = parsed_res.ib_id

        rtnid = c_uint(0)
        index = 0

        # Update the fields
        self.setup(parsed_res.fld_val)

        rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_TCAM_LOOKUP,
                                   pointer(rtnid),
                                   self.rw_entry)
        if rc == ifcs_ctypes.IFCS_NOTFOUND:
            log('Key not found')
        else:
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("PEN TCAM lookup failed " + ifcs_ctypes.ifcs_status_to_string(rc))
                return rc

        self.display()
        return rc

    def flush(self, arg_list):
        if (quiet() == 0):
            log("-> Indirect TCAM/ABB flush")

        # Parse Arguments
        parsed_res = self.parseArgs("flush", arg_list)

        ib = parsed_res.ib_id

        rtnid = c_uint(0)
        index = 0

        rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0,
                                   ib,
                                   int(self.pen_id),
                                   ifcs_ctypes.ISN_CMD_TCAM_FLUSH,
                                   pointer(rtnid),
                                   self.rw_entry)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("PEN TCAM flush failed " + ifcs_ctypes.ifcs_status_to_string(rc))
            return rc
        return rc

# Class implements Pen related command


class Pen(Command):
    def __init__(self, cli):
        self.sub_cmds = {
            'read': self.read,
            'readclear': self.readclear,
            'write': self.write,
            'modify': self.modify,
            'insert': self.insert,
            'lookup': self.lookup,
            'delete': self.delete,
            'flush': self.flush,
            'dump': self.dump,
             
            'help': self.help,
            '?': self.help
        }
        self.cli = cli
        self.arg_list = []
        super(Pen, self).__init__()
        self.pen_names = []
        self.help_str = "pen:        PEN access commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)
        for pen_id in itertools.count():
            try:
                if (ifcs_ctypes.node_get_pen_name(0, pen_id, ifcs_ctypes.String(
                        namebuf), buflen) == ifcs_ctypes.IFCS_SUCCESS):
                    self.pen_names.append(compat_bytesToStr(namebuf.value))
                else:
                    break
            except BaseException:
                break
        self.pen_names.sort()

    def run_cmd(self, args):
        log_dbg(1, "in Pen run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in pen [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except (ValueError):
            log_dbg(
                1, "ValueError in pen [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except BaseException:
            log_dbg(
                1, "OtherError in pen [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper()
                    for i in self.pen_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.pen_names if i.lower().startswith(text)]

    complete_read = complete_show
    complete_readclear = complete_show
    complete_dump = complete_show
    complete_write = complete_show
    complete_modify = complete_show

    def getPenType(self, pen_id, pen_name):
        '''Get PEN Type Object'''
        pentype = c_uint(0)
        penacc = c_uint(0)

        log_dbg(1, " In getPenType: pen_id " + str(pen_id))
        rc = ifcs_ctypes.node_get_pen_type_acc(
            0, int(pen_id), byref(pentype), byref(penacc))

        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return None

        log_dbg(1, "pen type: " + str(pentype) + " pen acc: " + str(penacc))
        if (penacc.value & ifcs_ctypes.PEN_ACCESS_INDIR):  # Indirect access
            if (pentype.value & ifcs_ctypes.PEN_TYPE_INDEX):
                log_dbg(1, "Pen type direct index")
                return indirectIndexPen(self.cli, pen_id)

            if (pentype.value & ifcs_ctypes.PEN_TYPE_ILPM):
                log_dbg(1, "Pen type ilpm")
                return ilpmPen(self.cli, pen_id)

            if (pentype.value & ifcs_ctypes.PEN_TYPE_HASH):
                log_dbg(1, "Pen type hash")
                return hashPen(self.cli, pen_id)

            if ((pentype.value & ifcs_ctypes.PEN_TYPE_TCAM) or
                    (pentype.value & ifcs_ctypes.PEN_TYPE_ABB_TCAM)):
                log_dbg(1, "Pen type tcam")
                return indirectTcamPen(self.cli, pen_id)
        else:  # Direct Access
            if (pentype.value & ifcs_ctypes.PEN_TYPE_INDEX):
                return directIndexPen(self.cli, pen_id)

            if (pentype.value & ifcs_ctypes.PEN_TYPE_TCAM):
                return directTcamPen(self.cli, pen_id)

            if (pentype.value & ifcs_ctypes.PEN_TYPE_BCAM):
                return bcamPen(self.cli, pen_id)

        # return None
        return directIndexPen(self.cli, pen_id)


    # ------------
    # READ command
    # ------------
    def readclear(self, args):
        log_dbg(1, "In Pen Read Clear with args: " + args)

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        log_dbg(1, " pen_name: " + pen_name + " pen id: " + str(pen_id))
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log_err('Unknown PEN: ' + pen_name)
            return

        # Perform Read Op
        log_dbg(1, " args: " + args)
        rc = pen.readclear(args)
        return ifcs_ctypes.IFCS_SUCCESS



    # ------------
    # READ command
    # ------------
    def read(self, args):
        log_dbg(1, "In Pen Read with args: " + args)

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        log_dbg(1, " pen_name: " + pen_name + " pen id: " + str(pen_id))
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log_err('Unknown PEN: ' + pen_name)
            return

        # Perform Read Op
        log_dbg(1, " args: " + args)
        rc = pen.read(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # --------------
    # Modify command
    # --------------
    def modify(self, args):
        log_dbg(1, "In Pen Modify")

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        log_dbg(1, " pen_name: " + pen_name + " pen id: " + str(pen_id))
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log('Unknown PEN Object')
            return

        # Perform Modify op
        rc = pen.modify(args)
        return rc

    # -------------
    # Write command
    # -------------
    def write(self, args):
        log_dbg(1, "In Pen Write with args: " + args)
        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        log_dbg(1, " pen_name: " + pen_name + " pen id: " + str(pen_id))
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log_err('Unknown PEN: ' + pen_name)
            return

        # Perform Write Op
        log_dbg(1, " args: " + args)
        rc = pen.write(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # --------------
    # Insert command
    # --------------
    def insert(self, args):
        log_dbg(1, "In PEN Insert with args: " + args)

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log('Unknown PEN Object')
            return

        # Perform Insert Op
        rc = pen.insert(args)
        return ifcs_ctypes.IFCS_SUCCESS

    # --------------
    # Lookup command
    # --------------
    def lookup(self, args):
        log_dbg(1, "In PEN Lookup with args: " + args)

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log('Unknown PEN Object')
            return

        # Perform Lookup Op
        rc = pen.lookup(args)
        return rc

    # --------------
    # Delete command
    # --------------
    def delete(self, args):
        log_dbg(1, "In PEN Delete with args: " + args)

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log('Unknown PEN Object')
            return

        # Perform Delete Op
        rc = pen.delete(args)
        return rc

    # --------------
    # flush command
    # --------------
    def flush(self, args):
        log_dbg(1, "In PEN Flush with args: " + args)

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log('Unknown PEN Object')
            return

        # Perform Delete Op
        rc = pen.flush(args)
        return rc

    # ------------
    # Dump command
    # ------------
    def dump(self, args):
        log_dbg(1, "In Pen dump with args: " + args)

        # If filter is not present
        args = self.validate_and_reconstruct_args_for_dump(args)

        # Get pen_id, pen_name from args
        pen_id, pen_name = self.validate_get_pen_info_from_args(args)

        # Get PEN Type
        log_dbg(1, " pen_name: " + pen_name + " pen id: " + str(pen_id))
        pen = self.getPenType(pen_id, pen_name)
        if pen is None:
            log_err('Unknown PEN: ' + pen_name)
            return

        # Perform dump Op
        log_dbg(1, " args: " + args)
        rc = pen.dump(args)
        return ifcs_ctypes.IFCS_SUCCESS

 

    #=========================================================
    # Extensive help
    #=========================================================

    read_help_str = """
              Usage::
                    pen read ib <ib> [pic <pic_id>] <pen-name> [count] - node pen read
              Command Options:
                    <ib>                                  - IB #
                    [pic-id]                              - pic_id (mandatory for pic pens)
                    <pen_name>                            - pen name
                    [count]                               - number of entries  (optional)
                    <index>                               - Read index (mandatory for Direct index pen)
    """
    write_help_str = """
              Usage:
                    pen write ib <ib#> <pen_name> [pic <pid_id>]  [count] - node pen write
              Command Options:
                    <ib#>                                 - IB #
                    <pen_name>                            - pen name
                    <pic_id>                              - pic_id (mandatory for PIC pens)
                    [count]                               - number of entries  (optional)
                    <index>                               - Write Index (mandatory for ILPM,Indirect TCAM)
    """
    modify_help_str = """
              Usage:
                    pen modify ib <ib#> <pen_name> [pic <pid_id>] [count] - node pen write
              Command Options:
                    <ib#>                                 - IB #
                    <pen_name>                            - pen name
                    <pic_id>                              - pic_id (mandatory for PIC pens)
                    [count]                               - number of entries  (optional)
                    <index>                               - Write Index (mandatory for ILPM,Indirect TCAM)
    """
    lookup_help_str = """
              Usage:
                    pen lookup ib <ib#> pen_name key_name <key_value> .. - node pen lookup
              Command Options:
                    <ib#>                                 - IB #
                    <pen-id>                              - pen name
                    <key_name>                            - Key name from the hash table to lookup
                    <key_value>                           - Value for the key to lookup
    """
    insert_help_str = """
              Usage:
                    pen insert ib <ib#> pen_name key_name <key_value>..   - node pen insert
              Command Options:
                    <ib#>                                 - IB #
                    <pen-id>                              - pen name
                    <key_name>                            - key name from the hash table to insert
                    <key_value>                           - value for the key to insert
    """
    delete_help_str = """
              Usage:
                    pen delete ib <ib#> pen_name key_name <key_value> .. - node pen delete
              Command Options:
                    <ib#>                                 - IB #
                    <pen-id>                              - pen name
                    <key_name>                            - Key name from the hash table to delete
                    <key_value>                           - Value for the key to lookup
    """
    flush_help_str = """
              Usage:
                    pen flush ib <ib#> <pen_name> pic <pid_id> .. - node pen flush
              Command Options:
                    <ib#>                                 - IB #
                    <pen_name>                            - pen name
    """
    default_help_usage_str = """
              Usage:
                   pen read ib <ib#> pen_name <index>       - node pen read <pen_id> ...
                   pen write ib <ib#> pen_name <index>      - node pen write <pen_id> ...
                   pen modify ib <ib#> pen_name <index>     - node pen modify <pen_id> ...
                   pen insert ib <ib#> pen_name <index>     - node pen insert <pen_id> ...
                   pen lookup ib <ib#> pen_name <index>     - node pen lookup <pen_id> ...
                   pen delete ib <ib#> pen_name <index>     - node pen delete <pen_id> ...
                   pen flush ib <ib#> <pen_id>              - node pen flush <pen_id> ...
    """
 
    default_help_trailer_str = """
                   pen help or ?                            - show this text
              Command Details:
                   Type : \"pen <subcmd> ? or pen <subcmd> help\" For more specific sub cmd help
    """
    default_help_str = default_help_usage_str
 
    default_help_str += default_help_trailer_str

    show_help_str = """
              Usage:
                    pen show <pen_name>                   - node pen show
              Command Options:
                    <pen_name>                            - pen name
    """
 

    def help(self, args):
        self.help_menu = {
            'read': self.read_help_str,
            'write': self.write_help_str,
            'lookup': self.lookup_help_str,
            'insert': self.insert_help_str,
            'modify': self.modify_help_str,
            'delete': self.delete_help_str,
            'flush': self.flush_help_str,
            'show': self.show_help_str,
             
            'help': self.default_help_str,
            '?': self.default_help_str
        }
        self.arg_list = shlex.split(args)
        log(self.help_menu[self.arg_list[1]])


 

    # ----------
    # Pen helper
    # ----------
    def _id_name_from_str(self, pen_str):
        try:
            pen_id = int(pen_str)
            pen_name = pennum_str[pen_id]
        except ValueError:
            try:
                pen_id = penstr_num_dict[pen_str.upper()]
                pen_name = pen_str.upper()
            except KeyError:
                pen_name = pen_str.upper()
                pen_id = -1
                log('Invalid PEN name ' + pen_name)
        return pen_id, pen_name

    def _fld_id_name_from_str(self, penfld_str):
        try:
            penfld_id = int(penfld_str)
            field_name = penfldnum_str[penfld_id]
        except ValueError:
            try:
                penfld_id = penfldstr_num_dict[penfld_str.upper()]
                field_name = penfld_str.upper()
            except KeyError:
                penfld_id = -1
                field_name = penfld_str.upper()
                log('Invalid PEN field name ' + penfld_str)
        return penfld_id, field_name

    def _fld_id_from_str(self, penfld_str):
        try:
            penfld_id = int(penfld_str)
        except ValueError:
            try:
                penfld_id = penfldstr_num_dict[penfld_str.upper()]
            except KeyError:
                penfld_id = -1
                log('Invalid PEN field name ' + penfld_str)
        return penfld_id

    def get_area_id_name_from_str(self, area_str):
        buflen = 64
        namebuf = create_string_buffer(buflen)
        namebuf.value = b"unknown"
        area_name = c_char_p(compat_strToBytes(area_str)).value
        area_num = c_int()
        ifcs_ctypes.node_get_area_id(0, byref(area_num), area_name.upper())
        area_id = area_num.value
        if (area_id == -1):
            try:
                area_id = int(area_name)
            except ValueError:
                self.cli.error()
                log('Invalid area name ' + compat_bytesToStr(area_name))
                return
            # get the area name string
            try:
                ifcs_ctypes.node_get_area_name(0, area_id, ifcs_ctypes.String(namebuf), buflen)
            except Exception as ex:
                log(type(ex).__name__, ex.args)
                self.cli.error()
            area_name = namebuf.value
        return area_id, compat_bytesToStr(area_name)

    def get_id_name_from_str(self, pen_str):
        buflen = 64
        namebuf = create_string_buffer(buflen)
        namebuf.value = b"unknown"
        pen_name = c_char_p(compat_strToBytes(pen_str)).value
        pen_num = c_int()
        ifcs_ctypes.node_get_pen_id(0, byref(pen_num), pen_name.upper())
        pen_id = pen_num.value
        if (pen_id == -1):
            try:
                pen_id = int(pen_name)
            except ValueError:
                self.cli.error()
                log('Invalid PEN name ' + compat_bytesToStr(pen_name))
                return
            # get the pen name string
            try:
                ifcs_ctypes.node_get_pen_name(0, pen_id, ifcs_ctypes.String(namebuf), buflen)
            except Exception as ex:
                log(type(ex).__name__, ex.args)
                self.cli.error()
            pen_name = namebuf.value
        return pen_id, compat_bytesToStr(pen_name)

    def get_fld_id_from_str(self, penfld_str):
        buflen = 64
        namebuf = create_string_buffer(buflen)
        namebuf.value = b"unknown"
        field_name = c_char_p(compat_strToBytes(penfld_str)).value
        fld_num = c_int()
        ifcs_ctypes.node_get_pen_field_id(0, byref(fld_num), field_name.upper())
        penfld_id = fld_num.value
        if (penfld_id == -1):
            log('Invalid PEN field name ' + compat_bytesToStr(field_name))
        return penfld_id

    def get_flds_from_id(self, pen_id):
        peninfo = ifcs_ctypes.pen_t()
        ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
        buflen = 64
        namebuf = create_string_buffer(buflen)
        namebuf.value = b"unknown"
        nflds = c_uint()
        nflds.value = peninfo.num_flds
        fldinfo = (ifcs_ctypes.pen_field_t * nflds.value)()
        try:
            ifcs_ctypes.node_get_pen_fields(
                0,
                pen_id,
                pointer(peninfo),
                byref(nflds),
                compat_pointer(fldinfo, ifcs_ctypes.pen_field_t))
        except Exception as ex:
            self.cli.error()
            log(type(ex).__name__, ex.args)
        return nflds, fldinfo

    def is_pen_rd_clr(self, pen_id):
        peninfo = ifcs_ctypes.pen_t()
        ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
        pattr = peninfo.attributes
        if pattr & ifcs_ctypes.PA_CNTR:
            return True
        else:
            return False

    def get_is_ib_pic_from_args(self, args, ib_pos, pic_pos):
        # if ib is present, it must be in argument #3(1-based counting)
        # if pic is present, it must be in argment #5(1-based counting)
        is_ib_in_arg = False
        is_pic_in_arg = False

        if args.split()[ib_pos] == 'ib':
            is_ib_in_arg = True

        if is_ib_in_arg:
            if args.split()[pic_pos] == 'pic':
                is_pic_in_arg = True

        log_dbg(
            1,
            "is_ib_in_arg, is_pic_in_arg: " +
            str(is_ib_in_arg) +
            "," +
            str(is_pic_in_arg))
        return is_ib_in_arg, is_pic_in_arg

    ''' parses args and fetches, ib, pic, pen id, pen name
        Look for the command semantics in the comments
        below
    '''

    def get_ib_pic_pen_from_args(self, args):

        # Args will come in the following order:

        # If pen is a pic pen:
        #   cmd subcmd ib ib_# pic pic_# pic_pen_name ..
        # If non pic pen:
        #   cmd subcmd ib ib_# pen_name ..

        # Given the above, and that we're dealing with positional
        # arguments:
        # if non pic pen:
        #  cmd_pos = 0, subcmd_pos = 1, ib_pos = 2, ib_id_pos = 3,
        #  pen_name_pos = 4
        # if pic pen:
        #  cmd_pos = 0, subcmd_pos = 1, ib_pos = 2, ib_id_pos = 3,
        #  pic_pos = 4, pic_id_pos = 5, pen_name_pos = 6
        #
        # Anything other than the above will result in an error.
        # Additionally, if pen is a pic pen and no pic is present in the args, will
        # also result in an error.

        is_ib_in_arg = False
        is_pic_in_arg = False
        pen_name = ""

        ib_pos = 2
        pic_pos = 4
        is_ib_in_arg, is_pic_in_arg = self.get_is_ib_pic_from_args(
            args, ib_pos, pic_pos)

        if not is_ib_in_arg:
            log_err('Invalid pen operation ( no ib # in command) ' + args)
            raise KeyError
            return

        if is_pic_in_arg:
            if not is_ib_in_arg:
                log_err('Invalid pen operation ( no ib # in command) ' + args)
                raise KeyError
                return

        if is_pic_in_arg:
            pen_name_pos = 6
        else:
            pen_name_pos = 4

        pen_name = args.split()[pen_name_pos]
        pen_id, pen_name = self.get_id_name_from_str(pen_name)

        log_dbg(
            1, "is_ib_in_arg, is_pic_in_arg, pen_id, pen_name : %d %d %d %s " %
            (is_ib_in_arg, is_pic_in_arg, pen_id, pen_name))
        return is_pic_in_arg, is_ib_in_arg, pen_id, pen_name

    ''' Obtains whether pic pen or not
        based on pen id:
        looksup pen info, if component
        id is 16 then return true.
    '''

    def get_is_pic_pen(self, pen_id):
        peninfo = ifcs_ctypes.pen_t()
        is_pic_pen = False
        ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))

        if peninfo.cmpid == 16:
            is_pic_pen = True

        log_dbg(1, "is_pic_pen: " + str(is_pic_pen))
        return is_pic_pen

    ''' Parses the arguments to fetch the following:
        pen name
        pen id
    '''

    def validate_get_pen_info_from_args(self, args):

        is_pic_pen = False
        is_pic_in_arg = False
        is_ib_in_arg = False

        is_pic_in_arg, is_ib_in_arg, pen_id, pen_name = self.get_ib_pic_pen_from_args(
            args)
        is_pic_pen = self.get_is_pic_pen(pen_id)

        if is_pic_pen and not is_pic_in_arg:
            self.cli.error()
            log_err('Invalid PEN operation ( no pic # in command) ' + args)
            raise KeyError

        if is_pic_pen and not is_ib_in_arg:
            self.cli.error()
            log_err('Invalid PEN operation ( no ib # in command) ' + args)
            raise KeyError

        if is_pic_in_arg and not is_pic_pen:
            self.cli.error()
            log_err('Invalid PEN operation ( not a pic pen ) ' + args)
            raise KeyError

        if not is_ib_in_arg:
            self.cli.error()
            log_err('Invalid PEN operation ( no ib # in command) ' + args)
            raise KeyError

        return pen_id, pen_name

    ''' Parses the arguments list and checks for filter
        if not present, insert 'filter None' at position 5 and 6
    '''

    def validate_and_reconstruct_args_for_dump(self, args):

        new_args = []
        args_list = args.split()
        if 'filter' not in args_list:
            new_args = args_list[:5] + ['filter'] + ['None'] + args_list[5:]
            args = ' '.join(new_args)

        log_dbg(1, "New args : " + args)
        return args
