#-------------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2020
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from verbosity import *
from ctypes import *
from ifcs_ctypes import *
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
from ifcs_cmds.node import Node as ifcs_node
from ifcs_cmds.linkscan import Linkscan as ifcs_linkscan

# Class implements Credo serdes related command
class Credo(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'help'     : self.help,
                         '?'        : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        super(Credo, self).__init__()
        self.num_nodes = cli.num_nodes
        self.active_node = 0

    def run_cmd(self, args):
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (KeyError):
            self.help(args)
        except (ValueError):
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def help(self):
        """
        Usage:
        """
        return
