
#-------------------------------------------------------------------------
# Copyright (c) Innovium, Inc., 2016
#
# This material is proprietary to Innovium. All rights reserved.
# The methods and techniques described herein are considered trade secrets
# and/or confidential. Reproduction or distribution, in whole or in part, is
# forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------

import shlex
import sys
import argparse
import itertools
import time
import json
from utils.log_utils import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_cmds.all import *
from ifcs_cmds.cli_types import *

# Class implements Debug state dump related commands


class DebugParser(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(DebugParser, self).__init__()

        self.sub_cmds = {
            'ifcs': self.debug_ifcs,
            'help': self.help,
            '?': self.help
        }


        self.show_debug_names = ['']

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Ifcs run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in debugparser [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return IFCS_INVAL
        except (ValueError):
            log_dbg(
                1, "ValueError in debugparser [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return IFCS_INVAL
        except BaseException:
            log_dbg(
                1, "OtherError in debugparser [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return IFCS_INVAL


    def debug_all_ifcs(self, args):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        test_run_id = time.strftime("%b_%d_%Y_%H%M%S", time.localtime())
        fileName = os.environ['HOME'] + '/ifcsDump_' + str(test_run_id) + '.p'
        try:
            fh = open(fileName, 'wb')
        except Exception as e:
            log_dbg(1, "File open error (", e, "): " + str(fileName))
            return

        log_dbg(1, "Writing to file " + fileName + "...")
        fh.write(json.dumps(all_state,indent=4))
        fh.close()
        return IFCS_SUCCESS

    def debug_modlist_ifcs(self, args, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)

    def debug_modlist_lag_ifcs(self, args, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        for entry in all_state[0]["Lag"]:
            entry['obj.handle_value'] = IFCS_HANDLE_VALUE(entry['obj.handle'])

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)


    def debug_modlist_ecmp_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllecmp()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        ecmp_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["Ecmp"]:
            reqd_dict = {}

            reqd_dict['ecmp_mbr_list'] = []
            reqd_dict['ecmp_id'] = IFCS_HANDLE_VALUE(entry)
            arr = ifcs_obj.getMembers(entry)
            for mbr in arr:
                reqd_dict['ecmp_mbr_list'].append(IFCS_HANDLE_VALUE(mbr))

            reqd_obj_list.append(reqd_dict)
        ecmp_dict['Ecmp'] = reqd_obj_list

        # printing for remote cli to capture stdout
        log(json.dumps(ecmp_dict,indent=4))
        return json.dumps(ecmp_dict,indent=4)


    def debug_modlist_devport_ifcs(self, args, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        for entry in all_state[0]["Devport"]:
            entry['speed'] = ifcs_obj.enum_to_str('speed', entry['speed'])
            entry['fec_mode'] = ifcs_obj.enum_to_str('fec_mode', entry['fec_mode'])
            entry['link_status'] = ifcs_obj.enum_to_str('link_status', entry['link_status'])
            entry['loopback'] = ifcs_obj.enum_to_str('loopback', entry['loopback'])
            entry['intf_type'] = ifcs_obj.enum_to_str('type', entry['type'])


        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)

    def debug_modlist_devport_counters_ifcs(self, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            state = []
            try:
                all_devport = ifcs_obj.getAlldevport()
                for devport in all_devport:
                    statsList = {}
                    output = ifcs_obj.stats_get(devport)
                    statsList['hw_port'] = devport

                    statsList['rx_octets'] = output[IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
                    statsList['rx_uc_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_UNICAST]
                    statsList['rx_mc_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_MULTICAST]
                    statsList['rx_bc_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_BROADCAST]
                    statsList['rx_mac_ctrl'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_PFC]
                    statsList['rx_drop_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_DROP]
                    statsList['rx_err_pkts'] = output[IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]

                    statsList['tx_octets'] = output[IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
                    statsList['tx_uc_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_UNICAST]
                    statsList['tx_mc_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_MULTICAST]
                    statsList['tx_bc_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_BROADCAST]
                    statsList['tx_mac_ctrl'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_PFC]
                    statsList['tx_drop_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_DROP]
                    statsList['tx_err_pkts'] = output[IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]

                    state.append(statsList)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state['DevportStats'] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)


    def debug_modlist_ifcs_usage(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                if name.lower() == 'nexthop':
                    output = ifcs_obj.getNexthopUsage()
                elif name.lower() == 'intf':
                    output = ifcs_obj.getIntfUsage()
                elif name.lower() == 'ecmp':
                    if 'members' in modules:
                        output = ifcs_usage_t()
                        ifcs_usage_t_init(pointer(output))
                        rc = ifcs_ecmp_member_usage_get(self.cli.node_id,
                                                        0,
                                                        0,
                                                        None,
                                                        pointer(output))
                        name = name + '_members'
                    else:
                        output = ifcs_obj.getEcmpUsage()
                elif name.lower() == 'route_entry':
                    #output = ifcs_obj.getIntfUsage()
                    output = ifcs_usage_t()
                    ifcs_usage_t_init(pointer(output))
                    attr = ifcs_attr_t()
                    ifcs_attr_t_id_set(pointer(attr), IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE)

                    # Form the route key
                    ip_dest = ifcs_ip_prefix_t()
                    ifcs_ip_prefix_t_init(pointer(ip_dest))
                    if 'host' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_USAGE_GET_TYPE_HOST)
                        ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), IFCS_IP_ADDR_FAMILY_IPV4)
                    elif 'prefix' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_USAGE_GET_TYPE_PREFIX)
                        ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), IFCS_IP_ADDR_FAMILY_IPV4)
                    elif 'v6_host' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_USAGE_GET_TYPE_HOST)
                        ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), IFCS_IP_ADDR_FAMILY_IPV6)
                    elif 'v6_prefix' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IFCS_USAGE_GET_TYPE_PREFIX)
                        ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), IFCS_IP_ADDR_FAMILY_IPV6)
                    elif 'tcam_slots' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IM_USAGE_GET_TYPE_PREFIX_TCAM_SLOTS)
                    elif 'sram_slots' in modules:
                        ifcs_attr_t_value_u32_set(pointer(attr), IM_USAGE_GET_TYPE_PREFIX_SRAM_SLOTS)
                    # As of now fallback routes donot have a v4 or v6 bifurcation as yet even though we allow the filter
                    # to be provided in the command. So we donot pass any filter in the usage command.
                    # In case we start segregating fallback routes for v6 as well, we would need to set the address family
                    # for what ever is in the filter (modules).


                    route_key = ifcs_route_entry_key_t()
                    ifcs_route_entry_key_t_init(pointer(route_key))
                    if 'v4_fallback' in modules or 'v6_fallback' in modules:
                        if 'v4_fallback' in modules:
                            ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), IFCS_IP_ADDR_FAMILY_IPV4)
                        else:
                            ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), IFCS_IP_ADDR_FAMILY_IPV6)
                        ifcs_route_entry_key_t_key_type_set(pointer(route_key), IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
                        ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
                        ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))


                        rc = ifcs_route_entry_usage_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        0,
                                                        None,
                                                        pointer(output))
                    elif 'tcam_slots' in modules or 'sram_slots' in modules:
                        for addr_family in [IFCS_IP_ADDR_FAMILY_IPV4, IFCS_IP_ADDR_FAMILY_IPV6]:
                            ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), addr_family)
                            ifcs_route_entry_key_t_key_type_set(pointer(route_key), IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                            ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
                            ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))

                            rc = ifcs_route_entry_usage_get(self.cli.node_id,
                                                            pointer(route_key),
                                                            1,
                                                            pointer(attr),
                                                            pointer(output))
                            usage_dict_key = 'v4_curr' if addr_family is IFCS_IP_ADDR_FAMILY_IPV4 else 'v6_curr'
                            state[usage_dict_key] = output.current
                    else:
                        ifcs_route_entry_key_t_key_type_set(pointer(route_key), IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                        ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
                        ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni), pointer(ip_dest))


                        rc = ifcs_route_entry_usage_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        1,
                                                        pointer(attr),
                                                        pointer(output))
                    if rc != IFCS_SUCCESS:
                        log_err(
                            "Failed to get all {0} route_entry rc: {1}".format(filter_option,
                                convert_error_code_to_string(rc)))
                        return

                current_usage = output.current
                max_usage = output.max
                # For tcam_slots & sram_slots, we fill v4_curr and v6_curr above already.
                if 'tcam_slots' not in modules and 'sram_slots' not in modules:
                    state['curr'] = current_usage
                state['max'] = max_usage
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)


    def debug_modlist_nexthop_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllnexthop()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        nexthop_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["Nexthop"]:
            reqd_dict = {}
            reqd_dict['obj.handle'] = entry
            reqd_dict['intf'] = IFCS_HANDLE_VALUE(ifcs_obj.getIntf(entry))
            reqd_dict['port'] = IFCS_HANDLE_VALUE(ifcs_obj.getLocalDestination(entry))
            reqd_dict['dest_mac'] = ifcs_obj.getDestMac(entry)
            reqd_dict['dest_ip'] = ifcs_obj.getDestIp(entry)
            reqd_dict['no_decrement_ttl'] = ifcs_obj.getNoDecrementTtl(entry)
            reqd_dict['index_el.index'] = IFCS_HANDLE_VALUE(entry)
            reqd_dict['ctc_policy'] = ifcs_obj.getCtcPolicy(entry)[-1]
            reqd_dict['fwd_policy'] = ifcs_obj.getFwdPolicy(entry)[-1]

            if IFCS_HANDLE_VALUE(entry) < 129:
                reqd_dict['port_type'] = 'normal'
                continue
            handle_value = ifcs_obj.getLocalDestination(entry)
            if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_SYSPORT:
                sysportObj = ifcsObjs.get_ifcs_obj_from_name('sysport')
                val = sysportObj.getDevport(handle_value)
                #this can be a cpu dest
                #val = IFCS_HANDLE_VALUE(int(handle_value))
                if val == 0:
                    reqd_dict['port_type'] = 'cpu'
                else:
                    reqd_dict['port_type'] = 'normal'
            elif IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_LAG:
                reqd_dict['port_type'] = 'lag'
            elif IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_NEXTHOP:
                reqd_dict['port_type'] = 'nexthop'
            elif IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                reqd_dict['port_type'] = 'ecmp'
            else:
                reqd_dict['port_type'] = 'normal'
            reqd_obj_list.append(reqd_dict)
        nexthop_dict['Nexthop'] = reqd_obj_list

        # printing for remote cli to capture stdout
        log(json.dumps(nexthop_dict,indent=4))
        return json.dumps(nexthop_dict,indent=4)


    def debug_modlist_ecc_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        state = {}
        obj_state = {}
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        try:
            ecc_node_stat = ifcs_ecc_node_stats_t()
            ifcs_node_ecc_stats(0, pointer(ecc_node_stat))
            state['TOTAL'] = ecc_node_stat.total_count
            state['TYPE_CE'] = ecc_node_stat.type_ce_count
            state['TYPE_UE'] = ecc_node_stat.type_ue_count
            state['TYPE_TREE'] = ecc_node_stat.type_tree_count
            state['TYPE_INV'] = ecc_node_stat.type_invalid_count
            state['RATELIMIT'] = ecc_node_stat.rate_limit_hit_count
            state['SW_FIXED_CE'] = ecc_node_stat.sw_fixed_ce_count
            state['SW_FIXED_UE'] = ecc_node_stat.sw_fixed_ue_count
        except Exception as e:
            if 'no attribute' in e.message:
                state = ''
            else:
                log_err(e.message)
                return
        obj_state['Ecc'] = state
        all_state.append(obj_state)

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)


    def debug_modlist_l2_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs l2entry state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_l2_entry = ifcs_obj.bulkGetalll2_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_l2_entry
            all_state.append(obj_state)

        l2_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["L2_entry"]:
            reqd_entry = {}

            try:
                handle_value = ifcs_obj.getEntryDest(entry)
            except:
                continue
            #handle_value = entry['entry_dest']
            if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_SYSPORT:
                sysport_obj = ifcsObjs.get_ifcs_obj_from_name('sysport')
                val = sysport_obj.getDevport(handle_value)
                #val = sysport_obj.getDevport(entry['entry_dest'])
                #this can be a cpu dest
                #val = IFCS_HANDLE_VALUE(int(handle_value))
                if val == 0:
                    reqd_entry['port_type'] = 'cpu'
                else:
                    reqd_entry['port_type'] = 'normal'
            else:
                reqd_entry['port_type'] = 'normal'

            '''
            reqd_entry['l2_entry_key._dirty_mac_l2vni'] = entry['l2_entry_key._dirty_mac_l2vni']
            reqd_entry['key.mac_addr'] = entry['tl_l2_objects']['0']['key.mac_addr']
            reqd_entry['key.l2vni'] = entry['tl_l2_objects']['0']['key.l2vni']
            reqd_entry['fwd_action'] = entry['tl_l2_objects']['0']['pkt_policy.fwd_policy.fwd_action']
            reqd_entry['entry_dest'] = entry['entry_dest']
            reqd_entry['entry_type'] = entry['entry_type']
            '''
            reqd_entry['l2_entry_key._dirty_mac_l2vni'] = entry.contents._dirty_mac_l2vni
            reqd_entry['key.mac_addr'] = ifcs_obj.get_mac_addr_from_l2_entry(entry)
            l2vni_str = entry.contents.key.mac_l2vni.l2vni
            reqd_entry['key.l2vni'] = IFCS_HANDLE_VALUE(l2vni_str)
            try:
                reqd_entry['fwd_action'] = ifcs_obj.getEntryFwdPolicy(entry)
            except:
                continue
            reqd_entry['entry_dest'] = handle_value
            try:
                reqd_entry['entry_type'] = ifcs_obj.getEntryType(entry)
            except:
                continue
            reqd_obj_list.append(reqd_entry)

        l2_dict["L2_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        #log(json.dumps(all_state,indent=4))
        #return json.dumps(all_state,indent=4)

        # printing for remote cli to capture stdout
        dump = json.dumps(l2_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_intf_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_intf = ifcs_obj.getAllintf()
                intf_val_list = []
                for intf in all_intf:
                    intf_val_dict = {}
                    # need only svi and ipinip
                    if ifcs_obj.getType(intf) != self.cli.ifcs_ctypes.IFCS_INTF_TYPE_SVI and \
                            ifcs_obj.getType(intf) != self.cli.ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4:
                        continue
                    intf_type = ifcs_obj.getType(intf)
                    intf_val = ifcs_obj.handle_to_str(intf)
                    dir_val = ifcs_obj.getDirection(intf)
                    l3vni_val = ifcs_obj.getForwardingInstance(intf)
                    mtu_val = ifcs_obj.getMtu(intf)
                    l2vni_val = ifcs_obj.getTransportInstance(intf)
                    src_mac_val = ifcs_obj.getTransportMac(intf)
                    src_ip_val = ifcs_obj.getTransportIpaddr(intf)
                    ttl_mode = ifcs_obj.getTtlMode(intf)
                    ttl_value = ifcs_obj.getTtlValue(intf)

                    intf_val_dict['intf_type'] = intf_type
                    if intf != None:
                        intf_val_dict['intf_index'] = IFCS_HANDLE_VALUE(intf)
                    else:
                        intf_val_dict['intf_index'] = 0

                    intf_val_dict['direction'] = dir_val
                    if l3vni_val != None:
                        intf_val_dict['l3vni'] = IFCS_HANDLE_VALUE(l3vni_val)
                    else:
                        intf_val_dict['l3vni'] = 0

                    if l2vni_val != None:
                        intf_val_dict['l2vni'] = IFCS_HANDLE_VALUE(l2vni_val)
                    else:
                        intf_val_dict['l2vni'] = 0
                    intf_val_dict['mtu'] = mtu_val
                    intf_val_dict['src_mac'] = src_mac_val
                    intf_val_dict['src_ip'] = src_ip_val
                    intf_val_dict['ttl_mode'] = ttl_mode
                    intf_val_dict['ttl_value'] = ttl_value

                    intf_val_list.append(intf_val_dict)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return

        # printing for remote cli to capture stdout
        dump = json.dumps(intf_val_list,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v4_host_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            if addr_family == 0 and hex(entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4).strip('L') == '0xffffffff':
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry)
                except:
                    continue
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4
                reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
                reqd_entry['prefix_len'] = 32
                reqd_entry['nexthop'] = IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v6_host_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                #all_route_entry = ifcs_obj.getAllroute_entry()
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = 0
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()
            if prefix_len == 128:
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry)
                except:
                    continue
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump


    def debug_modlist_route_v4_prefix_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                #all_route_entry = ifcs_obj.getAllroute_entry()
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            if addr_family == 0 and hex(entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4).strip('L') != '0xffffffff':
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry)
                except:
                    continue
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4
                mask = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4
                mask_str = socket.inet_ntoa(struct.pack('!L', mask))
                reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
                reqd_entry['prefix_len'] = IPAddress(mask_str).netmask_bits()
                reqd_entry['nexthop'] = IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v6_prefix_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                #all_route_entry = ifcs_obj.getAllroute_entry()
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in e.message:
                    state = ''
                else:
                    log_err(e.message)
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = -1
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()
            if prefix_len != 128 and prefix_len != -1:
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry)
                except:
                    continue
                if IFCS_HANDLE_MODULE(int(handle_value)) == IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump


    def debug_ifcs(self, args):
        log_dbg(1, "Debugging ifcs state ..")

        ifcsObjs = IfcsAll(self.cli)
        arg_list = args.split()

        if (len(arg_list) > 6) and (arg_list[2] not in ifcsObjs.get_ifcs_obj_names()):
            log_err("Invalid command")
            return IFCS_INVAL

        modules = arg_list[2:]

        if len(modules) == 0:
            # All modules
            return self.debug_all_ifcs(args)
        else:
            if 'usage' in modules:
                #just get the usage details for the module
                return self.debug_modlist_ifcs_usage(modules)
            else:
                if 'nexthop' in modules:
                    return self.debug_modlist_nexthop_ifcs(modules)
                elif 'intf' in modules:
                    return self.debug_modlist_intf_ifcs(modules)
                elif 'ecc' in modules:
                    return self.debug_modlist_ecc_ifcs(modules)
                elif 'l2_entry' in modules:
                    return self.debug_modlist_l2_entry_ifcs(modules)
                elif 'route_entry' in modules:
                    #return self.debug_modlist_route_entry_ifcs(modules)
                    if 'v4_host' in modules:
                        return self.debug_modlist_route_v4_host_entry_ifcs(modules)
                    elif 'v4_prefix' in modules:
                        return self.debug_modlist_route_v4_prefix_entry_ifcs(modules)
                    elif 'v6_prefix' in modules:
                        return self.debug_modlist_route_v6_prefix_entry_ifcs(modules)
                    elif 'v6_host' in modules:
                        return self.debug_modlist_route_v6_host_entry_ifcs(modules)
                elif 'devport' in modules and 'counters' in modules:
                    return self.debug_modlist_devport_counters_ifcs(modules)
                elif 'devport' in modules:
                    return self.debug_modlist_devport_ifcs(args, modules)
                elif 'ecmp' in modules:
                    return self.debug_modlist_ecmp_ifcs(modules)
                elif 'lag' in modules:
                    return self.debug_modlist_lag_ifcs(args, modules)
                else:
                    return self.debug_modlist_ifcs(args, modules)


    def help(self, args):
        log(args, "helping..")
        return
